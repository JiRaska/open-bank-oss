#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) OpenBank contributors. Licensed under the Apache License, Version 2.0.
"""Merge train for `main` (ADR-0343): batch armed green PRs, verify the batch as ONE tree, merge in order.

WHY THIS EXISTS
---------------
`main-protection` requires an up-to-date branch (strict required status checks). That closes the
measured defect class — green PRs that merge cleanly and are jointly invalid (19 of 20 main breaks
on 2026-08-22, ADR-0272) — at a structural cost: one merge per CI latency, ~36/day against ~197/day
of demand, with every other candidate re-running CI after each merge. GitHub's merge queue is the
native answer and is unavailable to a user-owned repository. This script is the queue, as a bot.

THE INVARIANT
-------------
  * The App token never shares a runner with PR data being processed by code.
  * Privileged jobs act only on trees they re-derived themselves with execution-free git
    (`git merge-tree --write-tree`, `git commit-tree`, `git ls-tree`) — never on files a build wrote.
  * The one thing a privileged job cannot re-derive execution-free — the regeneration commit's
    CONTENT — is bounded by path (DERIVED_OUTPUTS, read from origin/main) and then proven by main's
    own derived-freshness gates, which CI runs on the exact train tree. Workflows and generators in
    that tree are main's, because a PR touching any of them never qualifies (under `.github/` only
    prose, gate-input data and allow-listed gate code ride a train — `Untrainable`, GATE_CODE_GLOBS),
    and a train carrying gate code never carries a regeneration commit, so its gates are main's too.

THREE JOBS, EACH ON ITS OWN RUNNER
----------------------------------
  build    no secrets. Lists candidates live, squashes the verified heads in order, overlays the
           generators from origin/main, regenerates in a scrubbed environment, and uploads ONE git
           bundle holding ONE train. Everything it produces is untrusted.
  publish  App token, fresh clone of origin/main, this script taken from origin/main and run with
           `python3 -I -S`, isolated git config. Admits build's declared batch (members.txt) only
           where each entry is a live train candidate at its live head, rebuilds every member
           squash with `git merge-tree --write-tree` onto its OWN commits, and requires each tree
           to equal the bundle's commit for that step. Accepts the bundle's single regeneration
           commit only within DERIVED_OUTPUTS, with no symlink or gitlink. Rejects any train whose
           tree has a symlink/gitlink main does not. Then commits its OWN chain (commit-tree over
           the verified trees), pushes it to `train/<run_id>-<attempt>`, records `tree=<sha>` as an
           App status on that commit, and opens the draft carrier PR so CI runs.
  settle   a later tick; App token; same isolation. For each App-authored carrier whose CI is done:
           the App record must exist on the exact head, its tree must equal the commit's tree, the
           chain's base must be live main, and every required context must be green on that sha.
           Green: `merge-train` success on each verified member head, merge with the head sha
           pinned. Red: halve (an App `bisect size N` status) or, at one member, name the culprit.
           A cancelled/stale context (or skipped next to a cancellation) is INCONCLUSIVE, never red:
           its jobs are re-run once (App `merge-train/rerun` marker), then the carrier is in flight;
           still inconclusive after that, it closes with no verdict. Only a real failure blames.
           Also computes the fast lane from live data. Comments are fixed text.

MODES
-----
  build --out DIR                  (no secrets) DIR/train.bundle, or nothing
  publish --bundle DIR             (App token)  verify + push own commits + open carrier
  settle                           (App token)  judge finished carriers, merge, bisect, fast lane
  --shadow                         settle posts statuses and comments, never merges
  --self-test                      pure logic + a synthetic repository driven through real ticks
  --check-declaration              merge-train.yml still wires the three jobs per ADR-0343
"""
from __future__ import annotations

import argparse
import base64
import contextlib
import datetime
import fnmatch
import http.client
import inspect
import io
import json
import os
import pathlib
import posixpath
import re
import shlex
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field

API = os.environ.get("GITHUB_API_URL", "https://api.github.com")
WORKFLOW = pathlib.Path(".github/workflows/merge-train.yml")
REGEN_INVENTORY = ".github/scripts/regen-derived.sh"

# The commit-status context this script owns. check-ruleset-context-parity.py reads this
# declaration, which is what lets the context be REQUIRED although no pull_request job emits it.
STATUS_CONTEXT = "merge-train"
RECORD_CONTEXT = "merge-train/record"          # publish's record of the tree it pushed
BOT_LOGIN = "openbank-gitops-bot[bot]"          # the only creator whose statuses/PRs are trusted
# The App merge-train.yml hands update-branch (UPDATE_BRANCH_TOKEN). Measured on #16719's branch
# (68c7fffab4, c96091eef2): author openbank-branch-updater[bot], committer web-flow, verified (#16947).
BRANCH_UPDATER_LOGIN = "openbank-branch-updater[bot]"
BOT_ID = 305_862_397                             # its numeric user id (carrier #13817); merge_train_carrier pins it too
EXCLUDED_BRANCH_PREFIXES = ("codex/",)
OWNER_APPROVAL_CONTEXT = "merge-train/owner-approval"
OWNER_APPROVAL_WORKFLOW = pathlib.Path(".github/workflows/merge-train-owner-approval.yml")
CARRIER_LABEL = "merge-train"
# Owner-applied ad-hoc priority: an armed PR carrying it is served first within its lane (after a
# fix for a red main, which always goes first). Agents run under the owner's token, so this is a
# policy, not an identity check: agents never apply it (CLAUDE.md, Multi-agent).
EXPEDITE_LABEL = "merge-priority:expedite"
# Expedite lane (ADR-0343 amendment 2026-11-13): ONE extra carrier, holding exactly one expedited member,
# may be published over live main while one ordinary carrier is still running, and merges first; the
# overtaken carrier then fails its "main moved" check and is rebuilt with no verdict. The carrier is
# identified by the App's own EXPEDITE_CONTEXT status on its head, never by its branch name: the
# `train/<run>-<attempt>` shape is hard-coded in merge_train_carrier.py, check-security-checklist.py and
# security.yml, and an expedite carrier is judged by exactly the same rules as any other carrier.
EXPEDITE_CONTEXT = "merge-train/expedite-carrier"
# App marker on an expedited PR's head: settle opened the expedite window for it over main <sha>. Read
# back by expedite_candidate: a head still carrying it for the SAME main was given the window and the
# lane produced nothing (build deferred it, publish refused it), so it is passed over this tick (#16874).
EXPEDITE_WINDOW_CONTEXT = "merge-train/expedite-window"
EXPEDITE_CARRIER_TITLE = "merge-train expedite carrier"
EXPEDITE_LANE_DEFAULT = False      # MERGE_TRAIN_EXPEDITE_LANE; "false" = the label only reorders, as before
EXPEDITE_DAILY_CAP_DEFAULT = 6     # expedite carriers per UTC day; the label is a policy, not an identity
# Urgent strict path (ADR-0343 amendment 2026-11-19). 2026-11-19: #16835, a workflow fix routing PR builds
# to a new runner pool, was green and up to date with main and still waited hours: `merge-train` is
# required and posted only by the train, the strict lane serves one PR at a time behind a reservation
# (#16760), ~15 strict PRs were queued, and expedite only reorders. An OWNER-applied, daily-capped
# `merge-priority:urgent` label lets one green strict PR take the reservation at the next tick, pre-empting
# a non-urgent holder whose CI is still running — once per holder head (URGENT_PREEMPT_CONTEXT on it).
# Nothing about the merge changes: the urgent PR still merges only green on a head containing exact main.
# On a red main every fix still comes first; a non-fix urgent PR waits for green main like any other.
URGENT_LABEL = "merge-priority:urgent"
URGENT_PREEMPT_CONTEXT = "merge-train/urgent-preempted"   # App marker: this head yielded main to an urgent PR once
URGENT_DAILY_CAP_DEFAULT = 2       # MERGE_TRAIN_URGENT_DAILY_CAP: distinct PRs owner-labelled urgent per UTC day
URGENT_CLOCK_CONTEXT = "merge-train/urgent-since"     # App marker: first tick this head outranked the other lanes
URGENT_DROPPED_CONTEXT = "merge-train/urgent-dropped"  # App marker: this head's urgent priority was dropped
# Deploy fix claim (#16943). A main red on a provider CONTRACT job can be fixed only by deploying the
# consumer pair whose pact it verifies: the auto-deploy gitops PR changes image pins under
# openbank-infra/gitops/, so path-scoped CI never re-runs the contract job on its head and
# fix_job_evidence reads it `(absent)` forever — the train deadlocks (2026-11-20, #16940). Such a PR may
# claim the fix slot only when ALL hold, each read from git or the Actions API, never from the PR body:
# authored by the App; its head branch is auto-deploy's `chore/gitops-auto-deploy-<sha>-run<id>`; every
# changed line is an image pin under gitops/components whose new tag is built from that <sha>; the run
# <id> is auto-deploy.yml over main at <sha>, an ancestor of main, and its `can-i-deploy` job (red if
# ANY service is blocked) succeeded; every job red on main for the context, besides the aggregate
# itself, is a `(contract)` job; and the OWNER applied DEPLOY_FIX_LABEL today, within a daily cap.
# The label is the human step, not decoration: a provider job names the provider, not the consumers it
# verifies, so "these pins fix that job" is not derivable from names, and a push to the bot branch that
# swaps a digest under the same tag is not visible to these checks. Everything unknown refuses.
DEPLOY_FIX_LABEL = "merge-priority:deploy-fix"
DEPLOY_FIX_DAILY_CAP = 1
AUTO_DEPLOY_WORKFLOW = ".github/workflows/auto-deploy.yml"
DEPLOY_BRANCH_RE = re.compile(r"chore/gitops-auto-deploy-([0-9a-f]{40})-run([1-9][0-9]{0,19})")
GITOPS_PIN_PREFIX = "openbank-infra/gitops/components/"
CONTRACT_JOB_RE = re.compile(r".*\(contract\)")
# One image pin, sign stripped: (indent, registry/repository, service, tag).
PIN_LINE_RE = re.compile(r"([ \t]*)image:[ \t]*([A-Za-z0-9.:_-]+/openbank-([a-z0-9-]+)):([A-Za-z0-9._-]+)@sha256:[0-9a-f]{64}[ \t]*")
ISO_Z_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
DEPLOY_REQUIRED_JOBS = ("can-i-deploy", "Gitops PR")
# A picked urgent PR leaves that state within one or two ticks (update-branch, or merge). 60 min is two
# TRAIN_TURN_S (each two */10 ticks at the measured p90 gap) and covers one carrier in flight finishing; past
# it the PR is not progressing, and it must not hold the train's and the fast lane's turns any longer.
URGENT_PATIENCE_S = 60 * 60
URGENT_EVENT_PAGES = 50    # repo issue-event pages read to enumerate today's grants; more = incomplete = refused
TRAIN_BRANCH_RE = re.compile(r"^train/[0-9]+-[0-9]+$")
# Strict carrier (ADR-0343 amendment 2026-11-05): green strict-lane PRs that are BEHIND main are
# batched into one execution-free tree over live main (`git merge-tree --write-tree` in settle, no
# build job, no generator, no regeneration commit) on `train/strict-<run>-<attempt>`, judged by its own
# CI exactly like one strict PR, and its members merge individually pinned to their heads. Measured
# 2026-11-05: 0.41 strict merges/h with 37 strict PRs queued, while a strict PR's own CI takes 3-25 min
# against a 2.4 h reservation slot (update-branch, full CI restart, one PR per slot).
STRICT_TRAIN_BRANCH_RE = re.compile(r"^train/strict-[0-9]+-[0-9]+$")
STRICT_BATCH_CAP_DEFAULT = 8      # members per strict carrier; 1 = today's behaviour (update-branch, one PR per slot)
STRICT_CARRIER_DESC = "strict lane: verified on strict carrier #{carrier} over main {base}"
# Disjoint judge batching (ADR-0343 amendment 2026-11-15): a JUDGE member (judge_path) no longer rides
# alone by default. It shares a strict carrier only with members whose changed path sets are pairwise
# DISJOINT from every other member's (no shared file, so no shared gates.yaml / rules.yaml entry and no
# shared workflow), and such a carrier holds at most this many members. The carrier is verified as one
# tree under its own final configuration — exactly the tree and configuration main holds after its last
# member merges, which is also what serial processing in ANY order reaches and verifies at its last
# step. Measured 2026-11-14/15: every queued strict PR was a judge member, so each carrier held one PR
# and the strict lane drained at ~1 PR per 30-40 min carrier. 1 = the rides-alone rule as before.
STRICT_JUDGE_BATCH_CAP_DEFAULT = 4
GATES_YAML = ".github/gates/gates.yaml"
GATE_ID_RE = re.compile(r"^\s*-\s+id:\s*([^\s#]+)")
SHA_RE = re.compile(r"^[0-9a-f]{40}$")
BUNDLE_FILE = "train.bundle"
MANIFEST_FILE = "members.txt"   # build's declared batch: "<number> <head sha>" per line, in order
DROPS_FILE = "drops.txt"        # build's dropped members, same format: a HINT publish re-derives, never trusts
BUNDLE_REF = "refs/heads/merge-train-bundle"
# Contexts that judge the PR object (its body, its issue link), not the tree.
TREE_INDEPENDENT_CONTEXTS = frozenset({"issue-hygiene"})
GUARD_CONTEXT_HINT = "agent-pr-guard"
STALE_RED_CAP = 2      # stale-red refreshes per settle tick (ADR-0343)
STALE_RED_WALK = 20    # first-parent commits searched for main's own CI verdict
# A strict-lane reservation (ADR-0343) holds main for one PR's CI and is released when that CI STALLS,
# not when it is merely slow (#13400). A fixed 64 min bound (2 x the ci.yml p95) livelocked #13204: its
# Services CI (336 jobs, 168 run) took 67.8 / 70.4 / 87.1 min per head, so every reservation lapsed
# minutes before green, main moved, and the next update-branch restarted the clock. Progress = the
# newest started_at/completed_at of any check run on the head (GitHub's clock, not the author's).
# Stall window: 3 x the longest gap between consecutive job completions on those four heads (4.8 min,
# measured 2026-10-22 from /actions/runs/{id}/attempts/1/jobs). The ceiling bounds a CI that keeps
# trickling forever; it is measured from the head's committer time, which update-branch sets.
RESERVATION_STALL_S = 15 * 60
RESERVATION_CEILING_S = 4 * 3600
# Queued CI is CI (#14302): required contexts produced by nested reusable-workflow jobs (`gates (*)`,
# `Validate manifests`) register no check run until their caller job starts, so a head whose CI only
# waits for runners has no check-run stamp to show. A workflow run for the head in one of these states
# counts as activity now; the ceiling still bounds it. `waiting` (an environment approval) is excluded:
# that is a human gate, not CI making progress.
LIVE_RUN_STATUSES = frozenset({"queued", "in_progress", "requested", "pending"})

# Hard cap for a GREEN holder (exempt from the ceiling above, #14624): measured from the same committer time.
GREEN_HOLDER_CAP_S = 2 * RESERVATION_CEILING_S
# Lane fairness (ADR-0343): after a strict-lane merge the train gets the next turn — no strict-lane
# update-branch while train candidates wait — for at most this long after that merge, so a train that
# cannot be built never freezes the strict lane. Two ticks of the */10 cron at its measured p90 gap.
# Measured 2026-10-21 over 12.5 h of merge-train.yml: 11 carriers published, 0 train merges, 13
# strict-lane merges — every strict merge was followed at once by the next strict update-branch.
TRAIN_TURN_S = 30 * 60
# How far down main's first-parent chain the train's turn looks for its strict merge, stepping over
# fast-lane and bot merges (each step is one PR read). Inside TRAIN_TURN_S main rarely takes more.
TRAIN_TURN_DEPTH = 6
# Green carrier first (#13400): a VERIFIED green carrier merges before any strict-lane PR is served in
# the same tick — it is not voided by a strict merge. ONE exception, bounded to one tick per holder
# head: a reservation holder that is itself GREEN on an up-to-date head AND did not defer to this
# carrier (no DEFER_CONTEXT on its head) merges first; a holder that deferred keeps its promise, the
# carrier built under its CI merges past it (2026-11-05: 9 carriers, 0 train merges). Trade-off: the
# holder carries the oldest reservation and a full fleet CI (~1.5 h, restarted from zero if main moves),
# while the carrier is cheap to rebuild from green heads; deploy/release PRs riding a carrier lose one
# tick, not an hour (#14191/#14338, #14183/#14327). Original rule, measured 2026-10-24 08:00Z to
# 2026-10-25 11:50Z: 25 merges and 21 carriers; carrier #13853 went green at 10:29Z, was held for green
# strict #13806 which merged in that very tick, and was rebuilt as #13857 (~1 h of CI lost); #13790 was
# voided by #13679 the same way. Ten full-CI carriers ran 51-91 min (median ~61); strict merges arrive
# about one an hour, so letting strict pre-empt a RUNNING carrier as well would void nearly every one.
# A strict PR therefore waits for a running carrier, but only while that carrier is younger than this:
# 2 x the ~61 min median and above the 91 min longest measured run. Older, the carrier no longer holds
# the strict lane (it may still merge if it goes green first).
CARRIER_PRIORITY_S = 120 * 60
# Fast lane's turn (ADR-0360): the train's turn above protects carriers, never the FAST lane, whose PRs
# are not train candidates. With strict PRs queued, every reservation end was followed in the very next
# tick by the next strict update-branch, so the fast lane was held for whole reservations back to back.
# Measured 2026-11-02: no merge to main 18:27Z-23:59Z+ while #14595 and #14607 each ran into the 240 min
# ceiling and #14644 was reserved straight after; fast PRs #14523/#14610/#14620 green and held every tick.
# So whenever a reservation ENDS — the strict PR merged, or it was released (stall/ceiling) — and green
# fast-lane PRs wait unposted, the next reservation starts one turn later. Main never moves under a
# reserved head (the fast merges land BEFORE the next update-branch), so nothing is merged untested
# against main that was not before. Bounded both ways: one turn per reservation end, at most this long
# from the App's own marker on main's head; a fast merge moves main and ends the trigger itself.
FAST_TURN_S = 30 * 60
FAST_TURN_CONTEXT = "merge-train/fast-turn"   # App marker on main's head: "opened <epoch>"
SQUASH_PR_RE = re.compile(r"(?:\(#|^#)(\d+)\)?$")
OK_STATES = frozenset({"success"})
# A cancelled (or stale) check ran nothing that could be judged — "Canceling since a higher priority
# waiting request exists" on carrier #13452 blamed #13137 for a job that executed no step. Such a
# context is INCONCLUSIVE: never red, never a bisect, never a culprit. A `skipped` context is
# inconclusive only next to a cancellation on the same head (a job skipped because its `needs`
# was cancelled); on its own it keeps today's meaning.
INCONCLUSIVE_STATES = frozenset({"cancelled", "stale"})
# Extra gates (ADR-0343): checks beyond the ruleset-required contexts that the train itself refuses to
# serve over when they are red on a PR head. ONE declaration, `merge_train.extra_gates` in rules.yaml,
# read from the live main being judged — never listed here. Absent on a head = PENDING (fail closed):
# not applicable only when the pinned workflow has COMPLETED for that head without producing the check.
RULES_FILE = "openbank-libs/governance/rules.yaml"
EXTRA_GATE_CONTEXT = "merge-train/extra-gate"     # App marker: the author was told once for this head
EXTRA_GATE_NA_STATES = frozenset({"skipped", "neutral"})
EXTRA_GATE_MESSAGE = ("merge-train: this PR is not served while a declared extra gate (`merge_train.extra_gates` in "
                      "rules.yaml, e.g. Security scan / Trivy) is red on its head. It stays armed: push a commit that "
                      "turns the scan green and the train picks it up on its own. Do not disable auto-merge for this.")
# Notices (#13400): a candidate build dropped because it conflicts with MAIN, or a strict-lane PR whose
# update-branch GitHub refused, was dropped/retried every tick in silence while GitHub showed BLOCKED,
# not DIRTY. The author is told once per head: a `merge-train` failure carrying one of NOTICE_PREFIXES
# (INFORMATION, not a verdict — qualifies ignores it, so no merge decision changes and a later train
# that applies the head overwrites it), one comment, and the NOTICE_CONTEXT marker. All per-sha: a
# push starts clean.
NOTICE_CONTEXT = "merge-train/notice"           # App marker: the author was told once for this head
CONFLICT_PREFIX = "conflicts with main "
REFUSED_PREFIX = "update-branch refused over main "
NOTICE_PREFIXES = (CONFLICT_PREFIX, REFUSED_PREFIX)
CONFLICT_COMMENT = ("merge-train: this PR conflicts with main, so every train leaves it out and GitHub can still "
                    "show it as BLOCKED rather than conflicting. Merge main into the branch (or rebase) and push; "
                    "the new head is picked up on its own. It stays armed.")
REFUSED_COMMENT = ("merge-train: GitHub refused to update this branch with main (update-branch), so the strict "
                   "lane cannot serve it. Merge main into the branch and push; the new head is picked up on its "
                   "own. It stays armed.")
# GitHub lets an App without the `workflows` permission update a branch only while every workflow file
# in the merge equals one parent. A file changed on BOTH sides merges into a blob the App would be
# creating, and update-branch answers non-202 although `git merge` is clean. Measured 2026-11-05 over 13
# strict-lane requests: refused 6 of 6 with such a blob, requested 7 of 7 without, including 3 with
# workflow edits on both sides in DIFFERENT files. The credential is the fix, so the train says so.
WORKFLOW_DIR = ".github/workflows"
WORKFLOW_REFUSED_COMMENT = ("merge-train: this branch and main both changed the same workflow file, so merging them "
                            "creates workflow content the train's App may not write and GitHub refuses update-branch "
                            "although the merge is clean. Merge main into the branch and push with your own "
                            "credentials; the new head is picked up on its own. It stays armed.")
# Past this age an armed PR's notice stops being news for its author and becomes a stalled queue entry
# for the owner: one tracking issue (STUCK_LABEL), rewritten only when its content changes, closed when empty.
STUCK_AFTER_S = 4 * 3600
STUCK_LABEL = "merge-train-stuck"
STUCK_TITLE = "merge-train: armed PRs stuck behind main"
STRICT_CONFLICT_COMMENT = ("merge-train: conflict — this strict-lane PR conflicts with main, so it cannot be "
                           "update-branched and holds no reservation: the strict queue moves on without it. Merge "
                           "main into the branch (or rebase), resolve the conflict and push; the new head is picked "
                           "up on its own. It stays armed.")
NOTICE_PATH_CAP = 20
RERUN_CONTEXT = "merge-train/rerun"              # App marker: this carrier's inconclusive jobs were re-run once
RELEASED_CONTEXT = "merge-train/strict-released"  # App marker: this head's reservation timed out once (#14302)
CARRIER_YIELD_CONTEXT = "merge-train/carrier-yielded"   # App marker: a green carrier waited one tick for this GREEN holder head
DEFER_CONTEXT = "merge-train/strict-deferral"   # App marker: this running strict head yielded once to a carrier
STRICT_READY_CONTEXT = "merge-train/strict-ready-hold"   # App marker: no carrier was built for one tick for this GREEN holder head (#15827)
# Speculative stacking (ADR-0343 amendment 2026-11-09): while a strict holder H is reserved and its CI
# runs on an up-to-date head h, the train carrier is published over h instead of over main, so the two
# CIs run at once instead of one after the other. Build is unchanged (it builds over main, with main's
# generators); publish re-applies its own verified chain onto h execution-free (3-way merge-tree with
# main as the merge base) and records STACK_CONTEXT on h. Settle never merges the stacked carrier
# before H: it waits while H runs, and once H has merged it accepts the carrier only if main's TREE is
# h's tree (the squash of an up-to-date head), proven with git alone. H failing, moving, closing or
# being released voids the carrier with no verdict: nobody is blamed. One stacked carrier per holder head.
# On by default because the path is the common case, not a spare part: measured 2026-11-09 16:18Z, 7
# strict PRs queued behind one reservation while a 2-member carrier ran, and nothing merged 15:31-16:18Z;
# a train carrier's CI is ~45-50 min against a strict holder's ~90 min, so serialising them costs the
# shorter one per reservation, while the bounded deferral that overlaps them pre-empts the holder instead
# (green carrier #15368 voided by strict #15295's merge, rebuilt as #15369: ~45 min lost). Rollback:
# MERGE_TRAIN_SPECULATIVE_STACK "false" — the bounded deferral then behaves exactly as before.
STACK_CONTEXT = "merge-train/stacked-carrier"   # App marker: a carrier was stacked (or refused) on this head
STACK_DESC_RE = re.compile(r"^stacked carrier (train/[0-9]+-[0-9]+) over #([0-9]+)$")   # on the holder head
STACK_TIP_RE = re.compile(r"^stacked over ([0-9a-f]{40}) of #([0-9]+)$")                  # on the carrier head
SPECULATIVE_STACK_DEFAULT = True
STALE_CULPRIT_CONTEXT = "merge-train/stale-culprit-refresh"   # App marker: this culprit head was update-branched once
# Every culprit status starts with CULPRIT_PREFIX; a member carrying it waits for a push. A failure
# whose description starts with LEGACY_CULPRIT_PREFIX was written before the inconclusive rule and
# the carrier-attestation rule existed (#12506, #13137 were marked by those defects), so it is NOT
# final: the member re-qualifies and rides one more train, which overwrites the mark either way —
# success when it was an artifact, a CULPRIT_PREFIX failure when it was real. Self-retiring: no
# new status is ever written with the legacy text.
CULPRIT_PREFIX = "culprit: "
LEGACY_CULPRIT_PREFIX = "isolated as the cause of a red train"
# Fast-lane exclusions.
PROTECTED_PREFIXES = ("openbank-libs/", "build-logic/", "openbank-infra/gitops/", "docs/adr/", ".github/")
PROTECTED_GLOBS = ("*/src/main/resources/openapi.yaml",)
# A member touching any of these never rides a train: generators, privileged gate scripts, the
# regen inventory and the WORKFLOWS that run the freshness gates all live under `.github/`, and
# the regeneration-content argument rests on CI running main's copies of them. Everything ELSE the
# generator runner executes is derived from origin/main's regen-derived.sh by `Untrainable` —
# never from a fixed-depth glob, which a deeper file walks straight past.
# Under `.github/` the default is UNTRAINABLE; only prose and gate-input data (*.md, *.txt) ride a
# train, and not where such a file still decides what executes: workflows and actions (any file),
# pip requirement pins (they choose what gets installed) and agent prompts (they instruct an agent
# that holds tools). Every script and every extension-less file stay out, except the allow-listed
# gate code below (#13400), which never shares a train with a regeneration commit.
UNTRAINABLE_PREFIXES = (".github/workflows/", ".github/actions/", ".github/agent-prompts/")
GITHUB_DIR = ".github/"
GITHUB_TRAINABLE_SUFFIXES = (".md", ".txt")
GITHUB_UNTRAINABLE_NAME_GLOBS = ("*requirements*",)
# GATE CODE that rides a train (#13400) — an ALLOW-LIST, so an unknown `.github/` path stays strict.
# A check script is reviewed at arm time like any code, and the carrier's CI runs the
# COMBINED head: the gate is judged together with the code it judges exactly as in the strict lane,
# and bisect isolates a culprit. The one thing the strict lane gave that a train does not is that
# "regeneration content is proven by MAIN's gates" — so a train carrying gate code never carries a
# regeneration commit (TrainBuilder separates them; publish rejects the mix). Then the carrier tree
# is only reviewed member diffs, the strict lane's trust exactly.
# gates.yaml is NOT gate code here (#13837): it DECLARES how every gate runs (run, selftest, mode,
# when, budget_seconds), so one edit can retire a PRIVILEGED_GATE_CODE script without touching it.
# Telling a privileged entry's edit from an ordinary one needs a YAML parse, and settle/publish run
# under `python3 -I -S` (no site-packages, so no PyYAML; the stdlib has no YAML parser); a
# hand-rolled parse of a document with anchors and duplicate-key hazards is a grep in disguise.
# So every gates.yaml change takes the strict lane, judged by main's own gates.
GATE_CODE_GLOBS = (".github/scripts/check-*.py", ".github/scripts/check-*.sh")
# TEST CODE rides a train the same way (#14888): under `.github/` (never workflows/actions/prompts) a
# Python file whose BASENAME is test-shaped — `test-*.py`, `test_*.py` or `*_test.py`. The shape is the
# whole rule: no directory-wide rule, because a non-test helper under a `tests/` directory (conftest.py,
# __init__.py, a helper module) can be imported by a privileged gate script or run by the extra-gate
# workflow and must stay strict (security review of #14888). A test is run by a gate's `selftest:` on
# the combined head exactly as a check script is, can only make a verdict redder, and is held to every
# gate-code rule: never next to a regeneration commit or a symlink; a test that exercises the train, a
# carrier, the merge policy or the ruleset, or that a privileged script or the extra-gate workflow
# names, stays strict (PRIVILEGED_GATE_CODE, drift-guarded by the self-test).
TEST_CODE_PREFIXES = ("test-", "test_")
TEST_CODE_SUFFIXES = (".py",)
TEST_CODE_SUFFIX_SHAPES = ("_test.py",)
# Check scripts that prove a DERIVED_OUTPUTS entry (ADR-0343 §Security): defence in depth on top of
# the separation above.
FRESHNESS_GATE_CODE = (".github/scripts/check-adr-registry.sh", ".github/scripts/check-eu-ai-act.sh")
# ...and gate code that stays strict because the train's own verdict depends on it: run by the pinned
# extra-gate workflow (security.yml), judging a CARRIER through merge_train_carrier, or judging the
# merge machinery itself (ruleset / merge-train context). The self-test re-derives this set from the
# real tree and fails when a new script of that kind is missing here.
PRIVILEGED_GATE_CODE = FRESHNESS_GATE_CODE + (
    ".github/scripts/check-codeql-compile-coverage.py",     # security.yml (extra gate's workflow)
    ".github/scripts/check-security-checklist.py",          # passes a carrier on its chain + App record
    ".github/scripts/check-api-contract.py",                # judges a carrier by its members
    ".github/scripts/check-coverage-floor-ratchet.py",      # judges a carrier by its members
    ".github/scripts/check-deploy-holds.py",                # reads the merge-train / ruleset contract
    ".github/scripts/check-ruleset-context-parity.py",      # reads the merge-train / ruleset contract
    ".github/scripts/check-ruleset-bypass-actors.py",       # judges the ruleset (who may bypass merge rules)
    ".github/scripts/check-branch-protection.py",           # judges branch protection on main
    ".github/scripts/check-agent-pr-guard.py",              # agent-pr-guard: the train reads it as a refusal
    ".github/scripts/check-agent-bounded-write-surface.py", # reads branch protection on main
    ".github/scripts/check-merged-past-red-check.py",       # reads the rulesets
    ".github/scripts/check-test-script-reachability.py",    # names merge-train in its text; a lenient copy must not ride a train
    ".github/scripts/test-merge-train-carrier-lock.py",     # exercises the carrier library
    ".github/scripts/test-merge-train-main-red-freshness.py",  # exercises settle / the strict lane
    ".github/scripts/test-merge-train-owner-approval.py",   # exercises the owner-approval writer
    ".github/scripts/test-merge-pr-policy.py",              # exercises the merge policy / ruleset reads
    ".github/scripts/test-ruleset-bypass-evidence.py",      # exercises the ruleset bypass evidence
    ".github/scripts/test-ruleset-bypass-verdict.py",       # exercises the ruleset bypass verdict
    ".github/scripts/test-merge-authorization-proof.py",    # imported by test-merge-pr-policy.py
    ".github/scripts/test-agent-pr-review.py",              # named by check-agent-pr-guard.py
    ".github/scripts/tests/test_codeql_scope_classifier.py",   # run by security.yml (extra gate's workflow)
    ".github/scripts/tests/test_codeql_compile_coverage.py",   # run by security.yml (extra gate's workflow)
    # Tests a workflow that mentions the train (ci.yml) runs by name: part of the carrier's own verdict.
    ".github/scripts/test-can-i-deploy-source.py",
    ".github/scripts/test-ci-latency-report.py",
    ".github/scripts/test-ci-ui-verdict.py",
    ".github/scripts/test-context-deploy-handoff.py",
    ".github/scripts/test-packaged-library-sbom.py",
    ".github/scripts/test-prepare-test-priority.py",
    ".github/scripts/test-service-build-artifact.py",
    ".github/scripts/test-slsa-source-identity.py",
    ".github/scripts/tests/test_select_admin_ui_rbac_tests.py",
    # Tests run by name from OTHER workflows (review of #14891: executed with that workflow's permissions).
    ".github/scripts/test-rerun-flake-artifact.py",         # auto-retry-cancelled.yml
    ".github/scripts/test-admin-ui-request-trace.py",       # admin-ui-deploy.yml
    ".github/scripts/test-agent-admission.py",              # agent-issue-worker.yml, agent-pr-steward.yml
    ".github/scripts/check-deploy-pin-monotonic.py",        # judges a carrier by its members' deploy-revert labels
    # Tests gates.yaml runs by name (merge of main after #15045): part of the carrier's own verdict.
    ".github/scripts/check_authz_pdp_parity_test.py",
    ".github/scripts/test-check-deploy-source-freshness.py",
    ".github/scripts/test-merge-train-close-linked-issues.py",
    ".github/scripts/test-merge-train-publish-siblings.py",
    ".github/scripts/test_runtime_resource_inputs.py",
    # Wired into gates.yaml by #14701 (ci-script-tests-previously-unreachable).
    ".github/scripts/test-finrep-historical-workflow.py",
    ".github/scripts/test-prove-finrep-historical-checkout.py",
)
# JUDGE paths (strict carrier): everything CI or gate configuration READS to decide a verdict — every
# workflow and action (a member editing ci.yml or a reusable workflow can neuter a required check), the
# gate declarations, the governance rules, CODEOWNERS, the privileged gate code above and the train's own
# script, workflow and carrier library. A member touching any of these rode ALONE (review of #14891);
# since the ADR-0343 amendment of 2026-11-15 it shares a strict carrier only with members whose changed
# paths are pairwise disjoint (STRICT_JUDGE_BATCH_CAP_DEFAULT) — unless it configures a verdict
# (config_judge_path) or is the train's own code (train_code_paths): those still ride alone.
# Non-judge strict members batch together as before.
JUDGE_CODE = PRIVILEGED_GATE_CODE + (
    ".github/scripts/merge-train.py",
    ".github/scripts/merge_train_carrier.py",
    ".github/workflows/merge-train.yml",
)
JUDGE_PREFIXES = (".github/workflows/", ".github/actions/")
WORKFLOWS_DIR = ".github/workflows"
JUDGE_PATHS = JUDGE_CODE + (".github/gates/gates.yaml", "openbank-libs/governance/rules.yaml", ".github/CODEOWNERS")
# CONFIGURATION judges (ADR-0343 amendment 2026-11-15, after review of #16290): a judge path that can
# change what a gate DECIDES — anything under `.github/` that judge_path flags (a workflow, an action, a
# checker script a workflow or gates.yaml names, gates.yaml, CODEOWNERS), the governance rules, and the
# build and lint configuration a gate reads. A member touching one rides a strict carrier ALONE: paired
# with an older member B, a relaxing J would turn B green where oldest-first serial processing judges B
# under main's configuration, and a tightening J would make a carrier red that neither half is alone.
# Only PRODUCTION sources share: since the security review of #16357 a test-shaped file (anything under
# src/ that is not src/main/, so src/test, integrationTest, testFixtures, ... alike) rides alone, so no
# denylist of ways a test can read another module is a safety boundary for what a member CHANGES.
# Disjoint batching is for the remaining judge members only, and that set is an ALLOW-LIST (security
# reviews of #16290): a judge path is configuration UNLESS it is Kotlin/Java source or a test under
# src/main or src/test of a LEAF module (shareable_modules: an `openbank-*` module no Gradle build file
# depends on and whose name is no analysis/rule/governance module). build-logic, buildSrc, the libs,
# detekt rule sets and architecture tests that other modules consume never qualify, and neither does any
# doc (diff-scoped gates read a carrier's UNION diff, so a threat model or ADR in one member would satisfy
# the gate for another member's code — masking by companion file). Members of such a carrier must also
# sit in DIFFERENT modules (disjoint_key), for the same reason inside a module: one member's test must
# not satisfy a "src/main change needs a test" gate for another member's code. Everything else (scanner allowlists, lint and build files, application.yaml, any dotfile, any
# path nobody thought of) rides alone. A test is shareable only inside a module whose tests read no
# other module's files and whose files no other module's test reads (shareable_modules derives both from
# `../openbank-<m>` and `"openbank-<m>/` references under */src/test/): such tests judge another module's
# code — HasActiveConsentScopeProducerPinTest in campaign-service reads consent-service's source — so
# both ends of a cross-module read ride alone.
SHAREABLE_JUDGE_RE = re.compile(r"^(?!(?:.*/)?\.)openbank-[a-z0-9-]+/(?:[A-Za-z0-9_.-]+/)*src/main/(?:kotlin|java)/(?:[A-Za-z0-9_.-]+/)*"
                                r"[A-Za-z0-9_-]+\.(?:kt|java)$")
TRAIN_CODE_RE = re.compile(r"^\.github/(scripts|workflows)/(test-)?merge[-_]train[-_.A-Za-z0-9]*$")
# Files that SUPPRESS security findings (scanner allowlists and rule sets). They were trainable as
# plain data; a loosened one must take the owner's strict lane, wherever it lives.
SECURITY_SUPPRESSION_PATHS = (".gitleaksignore", ".gitleaks.toml", ".trivyignore", ".semgrep.yml", ".semgrep.yaml")
SECURITY_SUPPRESSION_PREFIXES = (".semgrep/",)
SOURCED_BY_GEN_INDEX = "docs/adr/*.sh"         # gen-index.sh sources its sibling libraries
GENERATOR_OVERLAY_ROOTS = (".github/scripts", "docs/adr", "openbank-infra/gitops")
REGEN_COMMANDS = ("bash .github/scripts/regen-derived.sh --all", "bash docs/adr/gen-index.sh")
SPECIAL_MODES = ("120000", "160000")           # symlink, gitlink
GENERATOR_ENV_ALLOWLIST = ("PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TZ",
                           "PYTHONIOENCODING", "PYTHONDONTWRITEBYTECODE", "SSL_CERT_FILE")
REGEN_COMMIT_SUBJECT = "chore(train): regenerate derived files"
OWN_MEMBER_RE = re.compile(r"^merge-train: member #([0-9]+)\n\nPR-Number: #\1\nPR-Head: ([0-9a-f]{40})\n$")
OWN_REGEN_MSG = "merge-train: regenerate derived files\n"
BISECT_RE = re.compile(r"^bisect size ([0-9]+)$")
RECORD_RE = re.compile(r"^tree=([0-9a-f]{40})$")
COMMENT_MARK = "<!-- merge-train -->"
URGENT_DROPPED_COMMENT = (f"{COMMENT_MARK}\nMerge-train: this PR carried `merge-priority:urgent` and was green "
                          "on this head for an hour without merging (source intent changed, merge refused, or a "
                          "carrier stayed in flight). Its urgent priority is dropped for this head so the other "
                          "lanes are not held; it stays in the strict lane as an ordinary PR. A new head may be "
                          "urgent again.")
# Fixed comment text. Nothing from a PR, a bundle, a branch or a commit is ever interpolated.
DROP_MESSAGE = ("merge-train: this PR did not apply cleanly on top of main together with the PRs ahead of "
                "it in this train, so it was left out. Rebase on main; the next train picks it up again.")
CULPRIT_MESSAGE = ("merge-train: a train over main isolated this PR as the cause of a failing required "
                   "check, and its `merge-train` status is now failure. Push a fix; the next train that "
                   "passes clears it. The workflow run linked from the status has the details.")
STALE_CULPRIT_MESSAGE = ("merge-train: a train over main isolated this PR as the cause of a failing required "
                         "check while its own CI was green against an older main, so a rule that landed on main "
                         "since is the likely cause. The train has merged main into the branch once; its own "
                         "CI now shows the failure on this PR. Push a fix if it stays red.")
MANUAL_LANE_MESSAGE = ("merge-train: the train containing only this PR could not be verified by the merge "
                       "train (for example, it adds a symlink or its regeneration touches a file outside the "
                       "derived-output inventory). It needs the owner's manual lane; see ADR-0343.")


def log(msg: str) -> None:
    print(msg, flush=True)


# --------------------------------------------------------------------------- pure: paths
def glob_match(pattern: str, path: str) -> bool:
    """fnmatch where `*` never crosses a `/` (fnmatch's `*` does)."""
    rx = "".join("[^/]*" if c == "*" else "[^/]" if c == "?" else re.escape(c) for c in pattern)
    return re.fullmatch(rx, path) is not None


def unsafe_path(path: str) -> bool:
    """A path with a control character (newline, tab, ESC...) is refused outright. git QUOTES such
    paths in its default output, so every string comparison against them silently misses."""
    return any(ord(c) < 32 or ord(c) == 127 for c in path)


def zpaths(out: str) -> list[str]:
    """Split git `-z` output. Callers must pass `-z`: only NUL cannot occur inside a path."""
    return [p for p in out.split("\0") if p]


@dataclass
class Change:
    status: str
    old_mode: str
    new_mode: str
    paths: list[str]          # one path, or old AND new for a rename/copy entry


SHA_PAIR_RE = re.compile(r"^[0-9a-f]{40}(?:\.\.\.?[0-9a-f]{40})?$")   # `sha`, `a..b` or `a...b`, shas only
_CHANGES_MEMO: dict[tuple, list] = {}   # changed_entries of literal commit shas: immutable, see there


def changed_entries(git, *revs: str, cached: bool = False) -> list[Change]:
    """THE one way to ask git what changed. `--no-renames`: with rename detection on, a rename is
    reported under its NEW path only, so renaming a generator to `docs/x.md` would hide that the
    generator was deleted. `--raw -z`: NUL-separated, with modes (the symlink/gitlink check needs
    them). Every path of every entry is returned, and a rename/copy entry yields BOTH paths."""
    # A diff between two COMMIT shas is immutable, so it is remembered for the life of the process (one
    # tick in production; many ticks in the self-test, whose spawn budget this protects): partition,
    # fix_evidence and every later tick ask for the same `base...head` of the same shas. Never a
    # working-tree, index or ref-name diff — only literal shas on both sides.
    memo_key = tuple(revs) if not cached and revs and all(SHA_PAIR_RE.fullmatch(r) for r in revs) else None
    if memo_key is not None and memo_key in _CHANGES_MEMO:
        return list(_CHANGES_MEMO[memo_key])
    args = ["diff", "--no-renames", "--no-ext-diff", "--raw", "-z"] + (["--cached"] if cached else []) + list(revs)
    toks = git(*args).stdout.split("\0")
    out: list[Change] = []
    i = 0
    while i < len(toks):
        meta = toks[i]
        if not meta.startswith(":"):
            i += 1
            continue
        fields = meta[1:].split()
        status = fields[4] if len(fields) > 4 else "?"
        n = 2 if status[:1] in ("R", "C") else 1
        out.append(Change(status, fields[0], fields[1], toks[i + 1:i + 1 + n]))
        i += 1 + n
    if memo_key is not None:
        _CHANGES_MEMO[memo_key] = list(out)
    return out


def changed_paths(git, *revs: str, cached: bool = False) -> list[str]:
    seen: list[str] = []
    for c in changed_entries(git, *revs, cached=cached):
        for path in c.paths:
            if path not in seen:
                seen.append(path)
    return seen


class Untrainable:
    """Every path the generator runner would EXECUTE, derived from origin/main's regen-derived.sh:
    its `find <root> -name '<pattern>'` enumeration (any depth, as `find` recurses), every program
    its GENERATORS inventory and REGEN_COMMANDS invoke, the libraries gen-index.sh sources, and
    everything under `.github/` except prose and gate-input data (see GITHUB_TRAINABLE_SUFFIXES). If main's script cannot be parsed, it fails CLOSED: any `gen-*` file anywhere."""

    def __init__(self, regen_text: str, referenced_tests=()):
        m = re.search(r"find\s+(\S+)\s+-name\s+'([^']+)'", regen_text or "")
        self.find_root = m.group(1).rstrip("/") if m else None
        self.find_name = m.group(2) if m else None
        commands = [c for c in generator_commands(regen_text or "") if c != "__BUNDLES__"] + list(REGEN_COMMANDS)
        self.programs = {tok for c in commands for tok in shlex.split(c) if "/" in tok and tok.endswith((".py", ".sh"))}
        # Test code a workflow or gates.yaml on main runs BY NAME (referenced_tests, derived by one `git grep`
        # over main): executed with that workflow's or gate's permissions, so it stays strict (#14891 review).
        self.referenced_tests = frozenset(referenced_tests or ())

    def __call__(self, path: str) -> bool:
        if any(path.startswith(p) for p in UNTRAINABLE_PREFIXES) or path in self.programs:
            return True
        if path in SECURITY_SUPPRESSION_PATHS or path.startswith(SECURITY_SUPPRESSION_PREFIXES):
            return True
        if glob_match(SOURCED_BY_GEN_INDEX, path):
            return True
        name = path.rsplit("/", 1)[-1]
        if path.startswith(GITHUB_DIR):
            if path in self.referenced_tests or ("*" in self.referenced_tests and test_code(path)):
                return True
            if gate_code(path):
                return False
            return (not name.endswith(GITHUB_TRAINABLE_SUFFIXES)
                    or any(fnmatch.fnmatch(name, g) for g in GITHUB_UNTRAINABLE_NAME_GLOBS))
        if self.find_root is None:
            return name.startswith("gen-")
        return path.startswith(self.find_root + "/") and fnmatch.fnmatch(name, self.find_name)


# POSIX ERE (git grep -E): no `(?:`; -o prints the whole match.
TEST_REF_RE = r"\.github/scripts/([A-Za-z0-9_.-]+/)*(test[-_][A-Za-z0-9_.-]*\.py|[A-Za-z0-9_.-]+_test\.py)"


_REFERENCED_TESTS: dict[str, set[str]] = {}   # base sha -> referenced set (content-addressed: never stale)


def referenced_tests(git, base: str) -> set[str]:
    """Every test-shaped script path that main's workflows or gates.yaml name (one execution-free
    `git grep` over `base`, memoised per base sha — the answer is a function of that commit alone).
    Unreadable = every test-shaped path stays strict (fail closed: a sentinel `test_code` matches)."""
    if base not in _REFERENCED_TESTS:
        r = git("grep", "-h", "-o", "-I", "-E", TEST_REF_RE, base, "--", ".github/workflows", GATES_YAML, check=False)
        _REFERENCED_TESTS[base] = {"*"} if r.returncode not in (0, 1) else set(r.stdout.split())
    return set(_REFERENCED_TESTS[base])


def gate_code(path: str) -> bool:
    """Reviewed gate or test code that may ride a train (GATE_CODE_GLOBS, test_code), never a
    PRIVILEGED_GATE_CODE path."""
    return path not in PRIVILEGED_GATE_CODE and (any(glob_match(g, path) for g in GATE_CODE_GLOBS) or test_code(path))


def test_code(path: str) -> bool:
    """Test code under `.github/` (#14888): a `.py` whose basename is `test-*`, `test_*` or `*_test.py` —
    never under the untrainable prefixes (workflows, actions, agent prompts). Only the basename decides:
    conftest.py, __init__.py or a helper module under `tests/` is NOT test code."""
    if not path.startswith(GITHUB_DIR) or any(path.startswith(p) for p in UNTRAINABLE_PREFIXES):
        return False
    name = path.rsplit("/", 1)[-1]
    if not name.endswith(TEST_CODE_SUFFIXES):
        return False
    return name.startswith(TEST_CODE_PREFIXES) or name.endswith(TEST_CODE_SUFFIX_SHAPES)


def generator_commands(script_text: str) -> list[str]:
    return [m.group(2) for m in re.finditer(r'^\s*"([^"|]+)\|([^"|]+)\|([^"]*)"', script_text, re.MULTILINE)]


FAIL_CLOSED_UNTRAINABLE = Untrainable("")


def derived_output_patterns(script_text: str) -> list[str]:
    m = re.search(r"^DERIVED_OUTPUTS=\((.*?)^\)", script_text, re.MULTILINE | re.DOTALL)
    return re.findall(r'"([^"]+)"', m.group(1)) if m else []


def regen_inventory_fragments(script_text: str) -> list[str]:
    """The source path fragments of regen-derived.sh's GENERATORS inventory ("id|cmd|frag frag")."""
    frags: list[str] = []
    for m in re.finditer(r'^\s*"([^"|]+)\|([^"|]+)\|([^"]*)"', script_text, re.MULTILINE):
        frags += m.group(3).split()
    return frags


# --------------------------------------------------------------------------- pure: candidates
@dataclass
class Member:
    number: int
    title: str
    body: str
    head_sha: str
    head_ref: str
    created_at: str
    ref: str = ""
    files: list[str] = field(default_factory=list)


def parse_extra_gates(text: str) -> dict[str, str] | None:
    """`merge_train.extra_gates` from rules.yaml text: check name -> the workflow file that must produce
    it, from items `- {workflow: <path>, check: <name>}`. Runs under `python3 -I -S` (no PyYAML), so it
    reads exactly that one shape; None = key absent, empty or ANY item malformed (callers fail closed)."""
    lines = text.splitlines()
    try:
        i = next(k for k, ln in enumerate(lines) if re.fullmatch(r"merge_train:\s*(#.*)?", ln))
    except StopIteration:
        return None
    out: dict[str, str] | None = None
    for ln in lines[i + 1:]:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        if not ln.startswith(" "):
            break
        if out is None:
            if re.fullmatch(r"  extra_gates:\s*(#.*)?", ln):
                out = {}
            continue
        if not ln.startswith("    "):
            break
        m = re.fullmatch(r"    - \{\s*workflow:\s*(\.github/workflows/[A-Za-z0-9._-]+\.ya?ml)\s*,"
                         r"\s*check:\s*\"?([^\"{},]+?)\"?\s*\}\s*(#.*)?", ln)
        if not m:
            return None
        out[m.group(2)] = m.group(1)
    return out or None


def train_extra_gates(git, base: str) -> dict[str, str] | None:
    """TRAIN_EXTRA_GATES (check name -> producing workflow) as declared on `base` (live main) — the single
    source every lane reads. None = missing or unparseable: the caller serves NOTHING (fail closed)."""
    gates = parse_extra_gates(git("show", f"{base}:{RULES_FILE}", check=False).stdout)
    if gates is None:
        log(f"::error::{RULES_FILE} on {base[:12]}: merge_train.extra_gates missing or unparseable — "
            "the train serves no PR until it is fixed")
    return gates


def pinned_checks(gh, sha: str, gates: dict[str, str]) -> dict[str, str | None]:
    """gh.checks(sha) with every extra gate replaced by its PINNED verdict (gh.extra_checks): only runs
    from the declared workflow count, and any failing one of them is red — a same-name run from any
    other app or workflow can neither turn it green nor mask a red."""
    checks = {k: v for k, v in gh.checks(sha).items() if k not in gates}
    checks.update(gh.extra_checks(sha, gates))
    return checks


def extra_gate_red(checks: dict[str, str | None], extra) -> list[str]:
    """Declared extra gates that are red on this head. Skipped / neutral = not applicable; absent is not
    red here, but `qualifies` and `carrier_contexts` hold it as pending (fail closed)."""
    return [g for g in extra or () if g in checks and checks[g] is not None
            and checks[g] not in OK_STATES and checks[g] not in EXTRA_GATE_NA_STATES]


def extra_verdict(states: list[str | None]) -> str | None:
    """One pinned extra gate from all its runs on a head: any red wins, then running, then green/n.a."""
    red = [s for s in states if s is not None and s not in OK_STATES and s not in EXTRA_GATE_NA_STATES]
    if red:
        return "failure" if "failure" in red else red[0]
    if any(s is None for s in states):
        return None
    return "success" if any(s in OK_STATES for s in states) else states[0]


def owner_approval_valid(number: int, ref: str, app: dict | None) -> bool:
    """Only the App's owner decision on this exact head can admit a codex PR.

    app_statuses() authenticates the producer and SHA. The canonical description additionally
    binds the PR number, so two PRs sharing a head cannot borrow each other's approval.
    """
    if not any(ref.startswith(pre) for pre in EXCLUDED_BRANCH_PREFIXES):
        return True
    return (type(number) is int and number > 0
            and (app or {}).get(OWNER_APPROVAL_CONTEXT) == ("success", f"owner-approved PR #{number}"))


APPROVAL_CHAIN_MAX = 16   # heads inspected for live withdrawal; never approval inheritance


def approval_chain(git, base: str, head: str) -> list[str]:
    """`head`, then earlier pure main-update heads whose revocations may still withdraw intent.

    Walks first parents back from `head` while the commit is a pure main-update merge: exactly two
    parents, the second reachable from `base` (main brought in nothing but main), and its tree equal to
    the tree `git merge-tree --write-tree` computes from the two parents — conflict-free and with no
    edit smuggled into the merge. The walk stops at the first commit that is anything else (a push, a
    hand-resolved conflict, a merge of a non-main branch), so only withdrawals on the verified
    main-update chain are considered. Deterministic and local: commits are immutable, so the chain
    is a git fact, not approval inheritance. Only the current head may supply an approval;
    decisions on the walk are read live to preserve newer revocations (owner_decision)."""
    chain, c = [head], head
    while len(chain) < APPROVAL_CHAIN_MAX:
        parents = git("rev-list", "--parents", "-n", "1", c, check=False).stdout.split()
        if len(parents) != 3 or not all(SHA_RE.fullmatch(x) for x in parents):
            break
        _, first, second = parents
        if git("merge-base", "--is-ancestor", second, base, check=False).returncode != 0:
            break
        merged = git("merge-tree", "--write-tree", first, second, check=False)
        if merged.returncode != 0:   # 1 = conflicted, anything else = could not compute: fail closed
            break
        tree = merged.stdout.split("\n", 1)[0].strip()
        own = git("rev-parse", "--verify", "--quiet", f"{c}^{{tree}}", check=False).stdout.strip()
        if not SHA_RE.fullmatch(tree) or tree != own:
            break
        chain.append(first)
        c = first
    return chain


def remember_approval_chain(gh, git, base: str, head: str) -> list[str]:
    chain = approval_chain(git, base, head)
    gh.__dict__.setdefault("approval_chains", {})[head] = chain
    return chain


def owner_decision(gh, chain: list[str]) -> tuple[str, str] | None:
    """Current-head approval only; a newer revoke on the proven main-update chain still withdraws it.

    An ancestor approval never grants admission or overrides a current-head decision. A fresh
    current-head approval may supersede an older active revoke, but not a later one. As before,
    each head contributes its latest authenticated decision, not superseded status history."""
    current, revoke = None, None
    for sha in chain:
        rec = gh.app_status_latest(sha, OWNER_APPROVAL_CONTEXT)
        if rec is None:
            continue
        if sha == chain[0]:
            current = rec
        if rec[1] == "failure" and (revoke is None or rec[0] > revoke[0]):
            revoke = rec
    decision = revoke if revoke and (current is None or revoke[0] > current[0]) else current
    return (decision[1], decision[2]) if decision else None


def with_owner_decision(gh, app: dict, chain: list[str]) -> dict:
    out = {k: v for k, v in app.items() if k != OWNER_APPROVAL_CONTEXT}
    decision = owner_decision(gh, chain)
    if decision is not None:
        out[OWNER_APPROVAL_CONTEXT] = decision
    return out


def live_source_intent(gh, number: int, head: str) -> bool:
    """Re-read a SOURCE PR immediately before acting, for every branch prefix.

    A planner's armed snapshot expires while it judges other PRs or verifies a bundle. Internal
    carriers are deliberately draft/disarmed and are never passed here. This is a last read, not
    an atomic lock with GitHub's subsequent write; the merge API still pins the exact head.
    """
    with deciding():
        pr = gh.pr(number)
        if not isinstance(pr, dict):
            return False
        source = pr.get("head")
        if (pr.get("number") != number or pr.get("state") != "open" or pr.get("draft") is not False
                or not isinstance(pr.get("auto_merge"), dict) or not pr["auto_merge"]
                or not isinstance(source, dict) or source.get("sha") != head):
            return False
        target = pr.get("base")
        if not isinstance(target, dict) or target.get("ref") != gh.branch:
            return False
        for endpoint in (source, target):
            repo = endpoint.get("repo")
            if not isinstance(repo, dict) or repo.get("full_name") != gh.repo:
                return False
        ref = source.get("ref")
        if not isinstance(ref, str) or not ref or TRAIN_BRANCH_RE.fullmatch(ref):
            return False
        app = None
        if any(ref.startswith(pre) for pre in EXCLUDED_BRANCH_PREFIXES):
            # The chain was derived from git by live_candidates in this process; without it only the
            # exact head counts (fail closed). Every decision on it is re-read live here.
            chain = (gh.__dict__.get("approval_chains") or {}).get(head) or [head]
            app = with_owner_decision(gh, {}, chain) if len(chain) > 1 and chain[0] == head else gh.app_statuses(head)
        return owner_approval_valid(number, ref, app)


def already_merged_member(gh, git, number: int, head: str, expected: str) -> str | None:
    """#16932: the merge commit when GitHub's native auto-merge already merged this carrier member at
    exactly the verified head, directly over the main the train expected (first parent == `expected`)
    and that commit is on live main. None otherwise, so the caller stops (fail closed).

    A member stays armed while it rides a carrier, so auto-merge can race the train's own merge call
    (runs 44711788330 / #16776 and 44800662763 / #16915). The squash is then the one the train would
    have made: same head, same base. A different head, a merge over another main, a merge commit not on
    main, or closed-unmerged is never treated as success.

    Governance trade-off, deliberately NOT decided here: disabling native auto-merge for train-eligible
    PRs would let the train own every member merge and remove this race; but arming (auto_merge set) is
    today the author's intent signal live_source_intent reads, and native auto-merge is the fallback
    that still merges a green PR when the train is paused or broken. Keeping it costs this tolerance.
    """
    pr = gh.pr(number)
    if not isinstance(pr, dict) or pr.get("number") != number or pr.get("merged") is not True:
        return None
    source, merge = pr.get("head"), pr.get("merge_commit_sha")
    if (not isinstance(source, dict) or source.get("sha") != head
            or not isinstance(merge, str) or not re.fullmatch(r"[0-9a-f]{40}", merge)):
        return None
    if git("fetch", "-q", "origin", f"+refs/heads/{gh.branch}:refs/merge-train/native-main", check=False).returncode != 0:
        return None
    if git("merge-base", "--is-ancestor", merge, "refs/merge-train/native-main", check=False).returncode != 0:
        return None
    parent = git("rev-parse", "--verify", "-q", f"{merge}^1", check=False)
    if parent.returncode != 0 or parent.stdout.strip() != expected:
        return None
    return merge


def path_refusal(pr: dict, untrainable) -> str | None:
    """The part of qualifies() decided by the verified diff alone (files, gates_append, special_paths):
    no check, status or approval read can turn it into a pass. live_candidates uses it to skip those
    reads for a PR it already knows is not a candidate, where nothing but `ok` is consumed (#16955)."""
    for f in pr.get("files") or []:
        if unsafe_path(f):
            return "a path contains a control character — manual lane, never a train"
        if untrainable(f) and not (f == GATES_YAML and pr.get("gates_append") is True):
            return f"touches {f} (workflows, gates, generators, inventory) — manual lane, never a train"
    if pr.get("special_paths") and any(gate_code(f) or (f == GATES_YAML and pr.get("gates_append") is True)
                                       for f in pr.get("files") or []):
        # The strict lane refuses a symlink/gitlink outright; on the train publish would halve the
        # whole carrier for it. Gate code next to one never rides (review of #13750).
        return "gate code next to a symlink or gitlink — never a train"
    return None


def qualifies(pr: dict, required: list[str], checks: dict[str, str | None],
              app: dict[str, tuple[str, str]] | None = None, untrainable=None,
              extra: list[str] | None = None) -> tuple[bool, str]:
    """`checks`: context -> conclusion (None = running). `app`: the App's own latest statuses.
    `pr["files"]` must come from `git diff` against the verified head, never from the files API.
    `extra`: TRAIN_EXTRA_GATES — red refuses, running or never reported waits (fail closed), and only
    skipped/neutral (which GitHub.extra_checks also reports when every pinned run SUCCEEDED without it)
    is n/a — and not even that when the PR's own diff touches the gate's pinned workflow (red)."""
    untrainable = untrainable or FAIL_CLOSED_UNTRAINABLE
    if pr.get("state", "open") != "open":
        return False, f"state {pr.get('state')}"
    if pr.get("draft"):
        return False, "draft"
    if not pr.get("auto_merge"):
        return False, "auto-merge not armed"
    if not pr.get("same_repo", True):
        return False, "head is a fork"
    ref = pr.get("head_ref") or ""
    if not owner_approval_valid(pr.get("number"), ref, app):
        return False, "codex PR needs owner approval on this exact head"
    why = path_refusal(pr, untrainable)
    if why:
        return False, why
    app_state, app_desc = (app or {}).get(STATUS_CONTEXT, ("", ""))
    if app_state == "failure" and not app_desc.startswith((LEGACY_CULPRIT_PREFIX, *NOTICE_PREFIXES)):
        return False, "merge-train failure on this head (culprit or manual lane) — waits for a push"
    if not required:
        return False, "no required contexts resolved — refusing to judge green"
    for name, state in checks.items():
        if GUARD_CONTEXT_HINT in name and state not in OK_STATES and state is not None:
            return False, f"{name} refused ({state})"
    member = [c for c in required if c != STATUS_CONTEXT]
    for c in member:
        if c in checks and checks[c] is not None and checks[c] not in OK_STATES:
            return False, f"required context {checks[c]}: {c}"
    for g in extra_gate_red(checks, extra):
        return False, f"extra gate red: {g}" + ("" if checks[g] == "failure" else f" ({checks[g]})")
    for g in own_workflow_red({c: v for c, v in checks.items() if c in (extra or {})}, extra, pr.get("files")):
        if g in checks:   # absent stays "never reported" (pending) below; a settled n/a is red
            return False, f"extra gate red: {g} (the PR changes the extra gate's own workflow)"
    for c in member:
        if c not in checks:
            return False, f"required context never reported: {c}"
        if checks[c] is None:
            return False, f"required context pending: {c}"
    for g in extra or ():
        if g not in checks:
            return False, f"extra gate never reported: {g}"
        if checks[g] is None:
            return False, f"extra gate pending: {g}"
    return True, "armed + all required green"


def strict_lane_state(pr: dict, required: list[str], checks: dict[str, str | None],
                      app: dict[str, tuple[str, str]] | None, untrainable, modes: list[str],
                      main_red: dict[str, str] | None = None, extra: list[str] | None = None) -> tuple[str | None, str]:
    """The strict lane (ADR-0343): a PR the train refuses ONLY because it is manual-lane (an executable
    `.github/` path, a generator, gates.yaml, the inventory) is judged exactly as strict up-to-date used
    to judge every PR. Returns ("green" | "pending" | None, why). Every other refusal in `qualifies` —
    closed, draft, disarmed, fork, excluded prefix, a merge-train failure, agent-pr-guard, red — still
    applies, and a control-character path or a symlink/gitlink never enters this lane at all.
    "waiting": every required context it has failed is red on main's tip too (`main_red`, context ->
    the main commit that verdict came from) — it cannot go green until main is fixed, so it must
    neither hold the lane nor be served."""
    files = pr.get("files") or []
    if any(unsafe_path(f) for f in files):
        return None, "a path contains a control character — never the strict lane"
    if any(m in SPECIAL_MODES for m in modes):
        return None, "adds a symlink or gitlink — never the strict lane"
    untrainable = untrainable or FAIL_CLOSED_UNTRAINABLE
    if not any(untrainable(f) and not (f == GATES_YAML and pr.get("gates_append") is True) for f in files):
        return None, "not manual-lane"
    ok, why = qualifies(pr, required, checks, app, untrainable=lambda _f: False, extra=extra)
    if ok:
        return "green", why
    member = [c for c in required if c != STATUS_CONTEXT]
    failed = [c for c in member if checks.get(c) is not None and checks.get(c) not in OK_STATES]
    if main_red and failed and why.startswith("required context") and set(failed) <= set(main_red):
        return "waiting", main_red_reason(failed, main_red)
    red_extra = extra_gate_red(checks, extra)
    if main_red and red_extra and why.startswith("extra gate red") and set(red_extra) <= set(main_red):
        return "waiting", main_red_reason(red_extra, main_red)
    # "never reported" is the normal state for the first minutes after update-branch (no workflow has
    # registered its check yet): it is pending, or the fresh head holds no reservation exactly when
    # it needs one (#13485).
    if why.startswith(("required context pending", "required context never reported", "extra gate pending",
                           "extra gate never reported")) and not any(
            checks.get(c) is not None and checks.get(c) not in OK_STATES for c in member if c in checks):
        return "pending", why
    return None, why


def own_workflow_red(checks: dict[str, str | None], extra, files: list[str] | None) -> list[str]:
    """Declared extra gates that are absent or not applicable on a head whose diff touches the gate's
    OWN pinned workflow (#13400): a PR that removes or renames the job must not thereby skip it, so the
    n/a is red here — even when every pinned run succeeded. A present green gate is unaffected."""
    touched = set(files or ())
    return [g for g, wf in (extra or {}).items()
            if wf in touched and (g not in checks or checks[g] in EXTRA_GATE_NA_STATES)]


def own_workflow_checks(checks: dict[str, str | None], extra, files: list[str] | None) -> dict[str, str | None]:
    """Carrier form of own_workflow_red over the union of member diffs: the n/a becomes "failure".
    `files` None = the carrier diff could not be read: an n/a gate is held pending (fail closed)."""
    if files is None:
        return {**checks, **{g: None for g in extra or {} if checks.get(g) in EXTRA_GATE_NA_STATES}}
    return {**checks, **{g: "failure" for g in own_workflow_red(checks, extra, files)}}


def carrier_contexts(required: list[str], extra, checks: dict[str, str | None]) -> list[str]:
    """What a carrier is judged on: the train's required contexts plus every declared extra gate."""
    # Absent counts (classify_carrier reads it as pending): only an explicit skipped/neutral is n/a.
    return required + [g for g in extra if checks.get(g) not in EXTRA_GATE_NA_STATES]


def classify_carrier(checks: dict[str, str | None], required: list[str]) -> tuple[list[str], list[str], list[str]]:
    """(failing, pending, inconclusive) over `required`. Only `failing` may ever blame a member."""
    cancelled_here = any(v in INCONCLUSIVE_STATES for v in checks.values())
    inconclusive = [c for c in required if checks.get(c) in INCONCLUSIVE_STATES
                    or (checks.get(c) == "skipped" and cancelled_here)]
    pending = [c for c in required if checks.get(c) is None]
    failing = [c for c in required if checks.get(c) not in (None, *OK_STATES) and c not in inconclusive]
    return failing, pending, inconclusive


# A gate that PASSED on content but overran its wall-time budget, or could not read its subject (NOT
# EVALUATED — a timed-out API, an unreadable carrier member), says nothing about the members (#13400:
# carrier #13501 blamed #13137 for two gates that printed "every member ... passes" and "none lowered").
# Read from run-gates.py's --json `failure_kind`, the gate runner's own machine-readable verdict.
INCONCLUSIVE_GATE_KINDS = frozenset({"budget", "not_evaluated"})
GATE_SHARD_JOB_RE = re.compile(r"^gates \(([a-z0-9-]+)\)$")   # ci.yml `gates (${{ matrix.slug }})`
GATE_AGGREGATE_JOB = "Validate manifests"                      # red exactly when a shard is red
GATE_ARTIFACT_PREFIX = "gate-results-"                         # ci.yml uploads gate-results-<slug>-a<attempt>
# Mirror of run-gates.py UNIVERSAL_SELFTEST_INPUTS: a pull request touching any of these re-runs EVERY
# self-test. The train runs alone under `python3 -I -S` from $RUNNER_TEMP, so it cannot import the
# runner; the self-test holds this tuple equal to the runner's on any checkout that carries it.
UNIVERSAL_SELFTEST_INPUTS = (
    ".github/gates/gates.yaml",
    ".github/scripts/run-gates.py",
    ".github/scripts/gatelib.py",
    ".github/scripts/selftest_input_trace.py",
    ".github/gates/selftest-undeclared-inputs.baseline",
)
SELFTEST_INPUTS_RE = re.compile(r"^\s+selftest_inputs:\s*(\[(.*)\])?\s*(#.*)?$")


def parse_selftest_inputs(text: str) -> dict[str, list[str]]:
    """gate id -> its declared `selftest_inputs` from gates.yaml text, by line scan (no YAML under
    `python3 -I -S`): a flow list on the key's line, or a block list of `- path` lines under it. A gate
    with no declaration maps to []: run-gates runs its self-test on every pull request."""
    out: dict[str, list[str]] = {}
    gid, block = None, False
    for ln in text.splitlines():
        m = GATE_ID_RE.match(ln)
        if m:
            gid, block = m.group(1), False
            out.setdefault(gid, [])
            continue
        if gid is None:
            continue
        m = SELFTEST_INPUTS_RE.match(ln)
        if m:
            block = m.group(1) is None
            if not block:
                out[gid] = [p.strip().strip("\"'") for p in m.group(2).split(",") if p.strip()]
            continue
        if block:
            item = re.fullmatch(r"\s+-\s+(\S.*?)\s*(#.*)?", ln)
            if item:
                out[gid].append(item.group(1).strip("\"'"))
            elif ln.strip() and not ln.lstrip().startswith("#"):
                block = False
    return out


GATE_CMD_KEYS_RE = re.compile(r"^\s+(run|selftest):\s*(.*)$")   # NOT selftest_inputs: those are the gate's SUBJECTS
PATH_TOKEN_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_./@-]*/[A-Za-z0-9_./@-]*$")   # after normpath: repo-relative, has a `/`
# A single-segment directory token (`docs/`, `build-logic/`) loses its `/` under normpath and would fail
# PATH_TOKEN_RE; it is a directory only when the raw token ended in `/` (#16843).
DIR_SEGMENT_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.@-]*$")
# A file token with one of these extensions is EXECUTED code when a gate names it (`python3 dir/x.py`,
# `bash dir/x.sh`, `node x.mjs`); the directory holding one is where the judge's code lives.
EXEC_SCRIPT_EXT_RE = re.compile(r"\.(py|sh|bash|js|mjs|cjs|ts|pl|rb)$")
# Code ROOTS handed to an interpreter: each `:`-element of these assignments, and the `-s` start
# directory of `python3 -m unittest discover`. Code under them runs, so the directory is judge.
CODE_ROOT_ENV_RE = re.compile(r"(?:^|[\s;&|(])(?:PYTHONPATH|NODE_PATH|PERL5LIB|RUBYLIB)=([^\s\"';|&)]+)")
# A directory argument after one of these runs code FROM that directory (`cd dir && ./x`, `make -C dir`,
# `./gradlew -p build-logic test`, `npm --prefix dir`, `--project-dir dir`): judge, a bare single segment
# included (review of #16885).
DIR_EXEC_FLAGS = frozenset({"cd", "-C", "-p", "--prefix", "--project-dir"})
# A token after one of these is the program that runs; without an extension (`bash tools/gate/run`) it is
# still an executed FILE, never a directory.
EXEC_PROGRAMS = frozenset({"bash", "sh", "zsh", "python", "python3", "node", "exec", "source", ".", "perl", "ruby"})
# `bash -c`, `sh -c` or `eval` in a gate builds its command from a string this tokeniser cannot read:
# every directory that gate names is then judge (fail closed, review of #16885).
OPAQUE_SHELL_RE = re.compile(r"(?:^|[\s;&|(`])(?:(?:ba|z)?sh\s+-c|eval)(?=[\s\"'])")


def gate_named_paths(text: str, gate_ids: set[str], is_dir=None) -> tuple[set[str], set[str]]:
    """(files, directories) the repo paths the gates.yaml entries of `gate_ids` name in `run` and
    `selftest` that are the code that JUDGES, by simple tokenisation of those strings (security review of
    #16832: gates run scripts outside .github/ too, e.g. openbank-infra/scripts/check-db-migration.py,
    which no prefix covers). NOT `selftest_inputs`: those are the SUBJECTS a gate checks (eight services'
    src/main for event-contract-code-agreement); a subject edit cannot make a red gate pass vacuously, at
    worst it breaks it, and refusing it would send exactly the legitimate main-red fixes (#16599's class)
    to a human — the inverse of #16675. Every named FILE counts (a token with `/` and an extension). A
    named DIRECTORY (a `/`-token without an extension, or ending in `/` — a single segment like `docs/`
    included, #16843) counts only when the gate EXECUTES code under it: it holds a named script token
    (EXEC_SCRIPT_EXT_RE), or it is a code root (`PYTHONPATH=dir`, `unittest discover -s dir`). A directory
    a gate merely scans, diffs or generates into is its SUBJECT, not its judge (review of #16832:
    gen-network-policies-drift-gate diffs openbank-infra/gitops/components/, shellcheck lints
    openbank-infra/scripts/ — the legitimate fixes for those reds edit exactly those trees). Tokens split
    on whitespace, shell punctuation AND `:` (PYTHONPATH-style lists), normalised with posixpath.normpath
    (`./x`, `a/./b`); `..`-relative and absolute tokens, globs, `$VAR`s, flags and URLs are dropped —
    never a blanket refusal for an odd slash token: over-refusal is what bit before. No import parsing,
    no spawn. `.github/` prefixes and FIX_JUDGE_FILES stay refused by fix_evidence regardless.
    Also judge (review of #16885, which found the subject rule fail-open): a directory after `cd`, `-C`,
    `-p`, `--prefix` or `--project-dir` (a bare single segment too: `./gradlew -p build-logic`), the
    directory `node dir/` runs, the root a `find dir ... -exec` walks, a directory on an `xargs` line, and
    each package prefix of `-m a.b.c` that `is_dir` (default os.path.isdir, the checkout) says exists. A
    program token without an extension (`bash tools/gate/run`, a line's first word) is an executed file.
    A gate whose run/selftest contains `bash -c`, `sh -c` or `eval` makes every directory it names judge."""
    is_dir = is_dir or os.path.isdir
    files: set[str] = set()
    dirs: set[str] = set()
    # Per GATE: a directory one gate scans is not made judge by a script another red gate executes under it.
    named_dirs: dict[str, set[str]] = {}
    exec_files: dict[str, set[str]] = {}
    roots: dict[str, set[str]] = {}
    opaque: set[str] = set()
    gid, key = None, None

    def path_token(tok: str) -> tuple[str, bool] | None:
        """(normalised repo path, is_dir) for a token that names one, else None."""
        if not tok or tok.startswith(("$", "-", "#", "/")) or "*" in tok or "{" in tok or "/" not in tok:
            return None
        as_dir = tok.endswith("/")
        p = posixpath.normpath(tok)
        if p.startswith("..") or p == ".":
            return None
        if not PATH_TOKEN_RE.match(p) and not (as_dir and DIR_SEGMENT_RE.match(p)):
            return None
        return p, as_dir or not re.search(r"\.[A-Za-z0-9]+$", p.rsplit("/", 1)[-1])

    for ln in text.splitlines():
        m = GATE_ID_RE.match(ln)
        if m:
            gid, key = m.group(1), None
            continue
        if gid not in gate_ids:
            continue
        m = GATE_CMD_KEYS_RE.match(ln)
        if m:
            key, rest = m.group(1), m.group(2)
        elif key is not None and (ln.startswith("      ") or ln.strip().startswith("- ")):
            rest = ln
        else:
            key = None
            continue
        for assignment in CODE_ROOT_ENV_RE.findall(rest):
            for entry in assignment.split(":"):
                pt = path_token(entry)
                if pt and pt[1]:
                    roots.setdefault(gid, set()).add(pt[0] + "/")
        if OPAQUE_SHELL_RE.search(rest):
            opaque.add(gid)
        toks = re.split(r"[\s\"'|;&()<>=,:\[\]`]+", rest)
        discover = "discover" in toks
        find_exec = "find" in toks and ("-exec" in toks or "-execdir" in toks)
        xargs = "xargs" in toks
        first = next((j for j, t in enumerate(toks) if t), None)
        for i, tok in enumerate(toks):
            prev = toks[i - 1] if i > 0 else ""
            if prev == "-m" and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+", tok):
                parts = tok.split(".")
                for k in range(1, len(parts) + 1):
                    d = "/".join(parts[:k]) + "/"
                    if is_dir(d):
                        roots.setdefault(gid, set()).add(d)
                continue
            if (prev in DIR_EXEC_FLAGS and "/" not in tok and DIR_SEGMENT_RE.match(tok)
                    and not re.search(r"\.[A-Za-z0-9]+$", tok)):
                named_dirs.setdefault(gid, set()).add(tok + "/")
                roots.setdefault(gid, set()).add(tok + "/")
                continue
            pt = path_token(tok)
            if pt is None:
                continue
            p, is_d = pt
            if is_d and not tok.endswith("/") and (prev in EXEC_PROGRAMS or i == first):
                is_d = False                       # an extensionless program: `bash tools/gate/run`
                exec_files.setdefault(gid, set()).add(p)
            if is_d:
                named_dirs.setdefault(gid, set()).add(p + "/")
                if ((discover and prev == "-s") or prev in DIR_EXEC_FLAGS or (prev == "node" and tok.endswith("/"))
                        or (find_exec and prev == "find") or xargs):
                    roots.setdefault(gid, set()).add(p + "/")
            else:
                files.add(p)
                if EXEC_SCRIPT_EXT_RE.search(p):
                    exec_files.setdefault(gid, set()).add(p)
    for g, named in named_dirs.items():
        dirs |= {d for d in named if g in opaque or d in roots.get(g, ())
                 or any(f.startswith(d) for f in exec_files.get(g, ()))}
    for rs in roots.values():   # `-m a.b.c` package roots are named only through the dotted path
        dirs |= rs
    return files, dirs


def selftest_skip_refusal(main_jobs: dict[str, str | None] | None, records: dict[str, list | None] | None,
                          head_files: list[str], declared: dict[str, list[str]] | None) -> str | None:
    """Why a head green on every gate shard red on main still does NOT prove it fixes that shard, or
    None. run-gates skips a gate's self-test on a pull request unless one of the gate's declared
    `selftest_inputs` changed (selftest_is_needed), while every push to main runs every self-test. So
    when main's red is a self-test (`unfalsified` in the shard's --json records), a head whose shard job
    SKIPPED that self-test is green about it structurally — 2026-11-17: #16599 left
    `event-contract-code-agreement` unfalsified on main, and the train then served #16627 and #16644 as
    "fixes" of it, one full CI each, because their shard jobs ran green without the self-test. The head
    proves the fix only when its own run executed the self-test: it changed a universal input, or one of
    THAT gate's declared inputs as read from the head's own gates.yaml (`declared`; None = unreadable), or
    the gate declares none (then run-gates always runs it). A failed job that is no gate shard needs no
    records. Fails closed: unreadable records or declaration, or a gate the head's gates.yaml does not
    declare (its self-test cannot have run there), refuse. A content/budget failure is untouched."""
    failed = sorted(n for n, c in (main_jobs or {}).items() if c is not None and c not in FIX_JOB_OK)
    slugs = [m.group(1) for n in failed for m in [GATE_SHARD_JOB_RE.fullmatch(n)] if m]
    if not slugs:
        return None
    if records is None:
        return "gate results of main's red run unreadable"
    if any(f in UNIVERSAL_SELFTEST_INPUTS for f in head_files):
        return None   # every self-test ran on this head
    for slug in slugs:
        recs = records.get(slug)
        if not isinstance(recs, list):
            return f"gate results of shard `{slug}` on main unreadable"
        for r in recs:
            if not isinstance(r, dict) or "unfalsified" not in (r.get("status"), r.get("failure_kind")):
                continue
            gid = str(r.get("id") or "?")
            if declared is None:
                return f"self-test of gate `{gid}` failed on main and {GATES_YAML} is unreadable on the head"
            if gid not in declared:
                return f"self-test of gate `{gid}` failed on main and the head's {GATES_YAML} does not declare it: it never ran there"
            inputs = declared[gid]
            if inputs and not any(f == d or f.startswith(d.rstrip("/") + "/") for f in head_files for d in inputs):
                return (f"self-test of gate `{gid}` failed on main (unfalsified) and was skipped on the head: "
                        f"no declared selftest input changed ({', '.join(inputs)})")
    return None


# Evidence strength of a main-red fix claim (ADR-0343 amendment 2026-11-18). Measured over 23 h
# (2026-11-17T09:00Z to 11-18T08:00Z): main red 12 h; 15 "fix" merges, 12 not fixes. In the stale-ADR-index
# episode the real fix #16690 was opened 3 min after main went red and the lane served four older false
# fixes first — perf/* PRs touching workflows run full-fleet CI, so every job red on main "ran green on the
# head" (fix_job_evidence) while the one GATE red on main had been skipped inside that green job.
FIX_JOB_LEVEL = 1        # every job red on main ran green on the head (gate results unreadable on the head)
FIX_GATE_VERIFIED = 2    # ...and every gate red on main is `ok` in the head's own gate-results artifact
FIX_STRENGTH_KEY = "fix_strength"   # cache slot: (FIX_STRENGTH_KEY, head sha, context) -> level
NOT_FIX_HEAD_KEY = ("not_fix_head",)   # cache slot: PR number -> head sha the refusal in NOT_FIX_KEY is about
FIX_CLAIM_CONTEXT = "merge-train/fix-claim"   # App marker: why this head was refused as a main-red fix (publish_fix_claims)
# The JUDGE (security review of 75ca372b, HIGH): a fix claim may not edit anything that judges it. A
# dependency parser was tried first and could not be made to follow the fleet's own `__file__` idioms —
# run-gates.py itself read as UNKNOWN, every gate shard's fix claim was refused, and main-red recovery
# was defeated. So no parsing: a fail-closed PREFIX rule over the trees that hold gate scripts and their
# helpers, the workflows, the actions, and the gate manifest, baselines and measurements.
FIX_JUDGE_PREFIXES = (".github/scripts/", ".github/workflows/", ".github/actions/", ".github/gates/")
FIX_JUDGE_FILES = (".github/scripts/run-gates.py",                  # covered by the prefixes; named so the rule reads whole
                   "openbank-libs/governance/rules.yaml")             # the governance rules gates read (as in JUDGE_PATHS)


RED_GATE_STATES = ("failed", "unfalsified")


def gate_level_evidence(main_records: dict[str, list | None] | None,
                        head_records: dict[str, list | None] | None) -> tuple[str | None, int, str]:
    """(why not a fix, strength, word). For every gate red on main (`failed` or `unfalsified` in
    main's shard records, content failures included) the gate id is looked up across ALL of the
    head's shards (`head_records`: slug -> records, None = that artifact unreadable): a gate may move
    shard or be renamed between main and the head. `ok` anywhere = verified for that gate (where
    main's red was the self-test, an `ok` whose `selftest_skipped` is true does not count and
    refuses). Red on the head refuses. Skipped or absent on the head is NOT a refusal — a head may
    legitimately skip a gate it does not touch, and refusing would stall its update-branch while
    main is red — it only caps the strength at FIX_JOB_LEVEL (still a fix under the job rule), with
    one exception kept from the self-test rule: main's red was an unfalsified self-test and the head
    skipped the gate. Unreadable head records, an unreadable main shard, and a red main shard whose
    records name no failed gate all read as FIX_JOB_LEVEL: nothing was checked, so nothing is
    claimed (never fail-open to verified). The predicate is never looser than the job rule."""
    if head_records is None:
        return None, FIX_JOB_LEVEL, "job-level: gate results unreadable on the head"
    index: dict[str, list[dict]] = {}
    for recs in head_records.values():
        for h in recs if isinstance(recs, list) else []:
            if isinstance(h, dict) and h.get("id") is not None:
                index.setdefault(str(h["id"]), []).append(h)
    level, notes = FIX_GATE_VERIFIED, []
    for slug, recs in sorted((main_records or {}).items()):
        if not isinstance(recs, list):
            level, _ = FIX_JOB_LEVEL, notes.append(f"shard `{slug}` unreadable on main")
            continue
        red = [r for r in recs if isinstance(r, dict) and r.get("status") in RED_GATE_STATES]
        if not red:
            level, _ = FIX_JOB_LEVEL, notes.append(f"shard `{slug}` red on main names no failed gate")
            continue
        for r in red:
            gid = str(r.get("id") or "?")
            hs = index.get(gid, [])
            # RED first: any red record for this id on the head refuses, whatever else the head says —
            # a second `ok` record (a duplicate id across shards) never overrides a red one.
            reds = [h for h in hs if h.get("status") in RED_GATE_STATES]
            if reds:
                return f"gate `{gid}` red on main is red on the head too ({reds[0].get('status')})", FIX_JOB_LEVEL, ""
            if r.get("status") == "unfalsified" and not any(h.get("status") == "ok" and not h.get("selftest_skipped") for h in hs):
                # The self-test rule (#16675) applies to skipped AND absent: a self-test the head did not
                # run cannot be shown fixed by that head.
                return f"self-test of gate `{gid}` failed on main and the head did not run it ({'skipped' if hs else 'absent'})", FIX_JOB_LEVEL, ""
            if hs and all(h.get("status") == "ok" for h in hs):
                continue   # verified: EVERY record for this id on the head is ok
            level, _ = FIX_JOB_LEVEL, notes.append(f"gate `{gid}` {'not ok everywhere' if hs else 'absent'} on the head")
    return None, level, "gate-verified" if level >= FIX_GATE_VERIFIED else "job-level: " + "; ".join(notes)


def trusted_head_records(head_records: dict[str, list | None] | None, main_jobs: dict[str, str | None] | None,
                         head_jobs: dict[str, str | None] | None) -> dict[str, list | None] | None:
    """Only artifacts the TRUSTED side vouches for: a shard slug counts when the base run (main's own
    CI, `main_jobs`) has a `gates (<slug>)` job — the base shard set, never anything the head's tree
    declares — and the head's run has that same job completed `success` (an artifact with no green job
    behind it is not evidence). Everything else is dropped as unreadable."""
    if head_records is None:
        return None
    base = {m.group(1) for n in (main_jobs or {}) for m in [GATE_SHARD_JOB_RE.fullmatch(n)] if m}
    return {slug: recs for slug, recs in head_records.items()
            if slug in base and (head_jobs or {}).get(f"gates ({slug})") in OK_STATES}


def fix_strength(cache: dict | None, view: dict, ctxs: list[str]) -> int:
    """The weakest evidence level over the contexts a fix claims, as fix_evidence recorded it for the
    view's head; unrecorded (a pending combined head, no cache) reads as job-level."""
    return min((cache or {}).get((FIX_STRENGTH_KEY, view.get("head_sha"), c), (FIX_JOB_LEVEL, ""))[0]
               for c in ctxs) if ctxs else FIX_JOB_LEVEL


def strength_word(cache: dict | None, view: dict, ctxs: list[str]) -> str:
    """The recorded word of the weakest context (what the log and `strict_why` say)."""
    recs = [(cache or {}).get((FIX_STRENGTH_KEY, view.get("head_sha"), c), (FIX_JOB_LEVEL, "job-level: unrecorded")) for c in ctxs]
    return min(recs, key=lambda lw: lw[0])[1] if recs else "job-level: unrecorded"


def fixes_first(strict: list, fixes: dict[int, list[str]], cache: dict | None,
                relevant: set[int] | None = None) -> list:
    """The strict list with every fix first — the RELEVANT ones (their diff touches what broke main,
    #16700) before the rest, strongest evidence first within each (#16760), then oldest — and everything
    else after in its existing order."""
    rel = relevant or set()
    def key(sv):
        n = sv[1]["number"]
        if n in fixes or n in rel:
            return (0 if n in rel else 1, -fix_strength(cache, sv[1], fixes.get(n, [])), sv[1].get("created_at") or "", n)
        return (2, 0, "", 0)
    return sorted(strict, key=key)


def gate_failures_inconclusive(failed_jobs: list[str], records: dict[str, list | None]) -> tuple[bool, str]:
    """(True, why) only when EVERY failed job of the carrier's CI run is a gate shard whose every non-ok
    gate failed for an inconclusive kind (or the aggregate that mirrors the shards). `records` maps shard
    slug -> that shard's --json records (None = unreadable). Anything unknown is conclusive: a missing
    artifact, an old runner without `failure_kind`, a failed non-gate job, an unfalsified gate."""
    shards = []
    for job in failed_jobs:
        m = GATE_SHARD_JOB_RE.fullmatch(job)
        if m:
            shards.append(m.group(1))
        elif job != GATE_AGGREGATE_JOB:
            return False, f"job `{job}` failed"
    if not shards:
        return False, "no gate shard failed"
    kinds = []
    for slug in shards:
        recs = records.get(slug)
        if not isinstance(recs, list):
            return False, f"gate results of `{slug}` unreadable"
        bad = [r for r in recs if isinstance(r, dict) and r.get("status") in ("failed", "unfalsified")]
        if not bad:
            return False, f"shard `{slug}` failed with no failed gate recorded"
        for r in bad:
            if r.get("failure_kind") not in INCONCLUSIVE_GATE_KINDS:
                return False, f"gate `{r.get('id')}` failed ({r.get('failure_kind') or 'unknown kind'})"
            kinds.append(f"{r.get('id')}: {str(r.get('failure_kind')).replace('_', ' ')}")
    return True, "; ".join(kinds)


def culprit_description(failing: list[str], base: str) -> str:
    return f"{CULPRIT_PREFIX}{', '.join(failing)} red on a train over main {base[:12]}"[:140]


def likely_flake_rerun(gh, git, sha: str, failing: list[str], head: str, base: str,
                       extra: dict[str, str] | None = None, inconclusive=()) -> str | None:
    """Before blaming a carrier's ONLY member (#15420): when every failing context is green on that
    member's own head AND green in main's CI at the carrier's base, the red says the combination OR the
    run is bad, and a flaky gate (#15416/#15344, #15419) is the cheaper explanation. Re-run the failed
    jobs once — the same App `merge-train/rerun` marker as an inconclusive carrier, so a carrier head
    gets at most ONE rerun of either kind, never a second. A cancelled context next to the red one is
    re-run in the same request, so the rerun can end in a full verdict. Returns the reason it re-ran, else None
    (the caller blames as before: red on the head, red or unknown on main, already re-run, refused)."""
    if not failing or gh.app_statuses(sha).get(RERUN_CONTEXT, ("", ""))[0]:
        return None
    extra = extra or {}
    own = gh.checks(head)
    cache: dict = {}
    for ctx in failing:
        state = (gh.extra_checks(head, {ctx: extra[ctx]}).get(ctx) if ctx in extra else own.get(ctx))
        if state not in OK_STATES:
            return None
        at_main = main_ci_result(gh, git, ctx, base, cache)
        if not at_main or at_main[1] not in OK_STATES:
            return None
    if not gh.rerun_inconclusive(sha, sorted(set(failing) | set(inconclusive))):
        return None
    why = f"{', '.join(failing)} green on the member head and on main {base[:12]}"
    gh.post_status(sha, "success", ("rerun 1 of 1, likely flake: " + why)[:140], context=RERUN_CONTEXT)
    return why


def main_red_reason(ctxs, main_red: dict[str, str]) -> str:
    ctxs = sorted(ctxs)
    return f"waiting for main ({', '.join(ctxs)} red on main {main_red[ctxs[0]][:12]})"


def main_red_contexts(gh, git, required: list[str], base: str, cache: dict | None = None) -> dict[str, str]:
    """Required contexts (merge-train aside) that are FAILURE in main's latest completed CI at `base`:
    context -> the main commit carrying that verdict. A still-running main run reads as its nearest
    first-parent ancestor's verdict, so a fix that just merged keeps main red until its own push run reports."""
    # checks(sha) already returns every context. Share each commit's complete result within this
    # evaluation, including when build/publish omit cache; otherwise the history is fetched again
    # for every context. Never retain this implicit cache across evaluations: CI results can change.
    if cache is None:
        cache = {}
    out: dict[str, str] = {}
    # Extra gates count too: a scan red on main itself makes PRs wait and never makes anyone a culprit.
    for ctx in sorted({c for c in required if c != STATUS_CONTEXT} | set(train_extra_gates(git, base) or {})):
        res = main_ci_result(gh, git, ctx, base, cache)
        if res and res[1] == "failure":
            out[ctx] = res[0]
    return out


def urgent_grant(events, owner: str, label: str = URGENT_LABEL) -> tuple[str | None, str]:
    """(labelled_at, why). The LATEST `labeled` event for URGENT_LABEL decides: only the repo owner may have
    applied it (anyone else re-applying it after the owner takes the grant away). Fail closed: unreadable
    events, no such event, or an event without a timestamp grant nothing."""
    if events is None:
        return None, "label events unreadable"
    last = None
    for e in events:
        if e.get("event") == "labeled" and (e.get("label") or {}).get("name") == label:
            last = e
    if last is None:
        return None, f"no readable {label} label event"
    actor = (last.get("actor") or {}).get("login") or ""
    if actor != owner:
        return None, f"{label} applied by {actor or 'unknown'}, not the repo owner {owner}"
    at = last.get("created_at") or ""
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T.*", at):
        return None, "label event carries no timestamp"
    return at, ""


def urgent_grants(events, owner: str, day: str, label: str = URGENT_LABEL) -> dict[int, str]:
    """{PR: its FIRST owner `labeled merge-priority:urgent` event on UTC `day`} from repository issue events.
    An event is never deleted, so removing the label afterwards does not uncount a grant, and re-applying it
    to the same PR counts once."""
    out: dict[int, str] = {}
    for e in events or []:
        at = e.get("created_at") or ""
        n = (e.get("issue") or {}).get("number")
        if (e.get("event") == "labeled" and (e.get("label") or {}).get("name") == label
                and (e.get("actor") or {}).get("login") == owner and at[:10] == day and isinstance(n, int)):
            out[n] = min(out.get(n, at), at)
    return out


def urgent_refusal(n: int, events, owner: str, grants: dict | None, cap: int, day: str,
                   label: str = URGENT_LABEL) -> str | None:
    """Why #n's urgent label grants nothing; None = admitted. The latest label event must be the owner's
    (urgent_grant) and fall on UTC `day`: a grant lasts the day it was made, so yesterday's grants never
    carry over uncounted. `grants` = every PR the owner granted on `day` (urgent_grants over a COMPLETE
    enumeration; None = incomplete -> refused); #n must be among its first `cap` by grant time."""
    at, why = urgent_grant(events, owner, label)
    if at is None:
        return why
    if at[:10] != day:
        return f"granted on {at[:10]}, not today ({day}): a grant lasts its UTC day — re-apply to use today's cap"
    if grants is None:
        return f"today's {label} grants could not be enumerated completely"
    if n not in grants:
        return "today's grant enumeration does not contain this PR's own grant (incomplete)"
    rank = sorted(grants, key=lambda k: (grants[k], k)).index(n)
    if rank >= cap:
        return f"daily cap reached ({rank + 1} PRs granted {label} on {day}, cap {cap})"
    return None


def is_urgent(view: dict) -> bool:
    return any((lb.get("name") if isinstance(lb, dict) else lb) == URGENT_LABEL for lb in view.get("labels") or [])


def urgent_prs(gh, repo: str, strict: list, cap: int, now: float | None = None) -> set[int]:
    """The strict-lane PRs whose urgent label is admitted this tick (urgent_refusal). No labelled PR = no
    API read at all. A head whose urgent priority was dropped (URGENT_DROPPED_CONTEXT) is not urgent again;
    a new head may be. Every refusal is logged, once per tick."""
    labelled = [v["number"] for _st, v in strict
                if is_urgent(v) and URGENT_DROPPED_CONTEXT not in (v.get("app") or {})]
    if not labelled:
        return set()
    owner = repo.split("/", 1)[0]
    day = time.strftime("%Y-%m-%d", time.gmtime(time.time() if now is None else now))
    grants = gh.urgent_grants_today(day, owner)
    out: set[int] = set()
    for n in labelled:
        why = urgent_refusal(n, gh.issue_events(n), owner, grants, cap, day)
        if why:
            log(f"#{n:>6} urgent    not admitted: {why}")
        else:
            out.add(n)
    return out


def urgent_servable(git, base: str, view: dict) -> bool:
    """An urgent PR the strict lane can serve over THIS main: never told it conflicts with it or that
    update-branch was refused over it, and — when behind — merging cleanly with it by `git merge-tree`
    (execution-free; exit 0 only: a conflict or an undecided merge pre-empts nobody, so a conflicting
    urgent PR can never spend a holder's single yield)."""
    told = (view.get("app") or {}).get(NOTICE_CONTEXT, ("", ""))[1]
    if told.startswith((f"{CONFLICT_PREFIX}{base[:12]}", f"{REFUSED_PREFIX}{base[:12]}")):
        return False
    head = view["head_sha"]
    if git("merge-base", "--is-ancestor", base, head, check=False).returncode == 0:
        return True
    return git("merge-tree", "--write-tree", "--name-only", "--no-messages", "-z", base, head,
               check=False).returncode == 0


def urgent_clock(view: dict) -> int | None:
    m = re.search(r"since (\d+)", (view.get("app") or {}).get(URGENT_CLOCK_CONTEXT, ("", ""))[1])
    return int(m.group(1)) if m else None


def urgent_stamp(gh, strict: list, pick: int | None, now: float, shadow: bool) -> None:
    """Start the patience clock on the head of the urgent PR that outranks the other lanes this tick
    (urgent_pick), the first tick it does: only ticks in which it holds those lanes back are counted."""
    for _st, v in strict:
        if v["number"] == pick and urgent_clock(v) is None and not shadow:
            gh.post_status(v["head_sha"], "success", f"urgent: outranking the other lanes since {int(now)}",
                           context=URGENT_CLOCK_CONTEXT)
            v.setdefault("app", {})[URGENT_CLOCK_CONTEXT] = ("success", f"since {int(now)}")


def urgent_expire(gh, strict: list, urgent: set[int], now: float, shadow: bool) -> set[int]:
    """Bound an urgent PR that cannot progress (starvation review of #16856). An urgent PR picked this tick
    outranks the train's and the fast lane's turns, and should leave that state within a tick or two
    (update-branch, or merge). If it cannot — source intent changed, the merge refused, a carrier staying in
    flight — it must not suppress the other lanes forever: once URGENT_PATIENCE_S have passed since the
    head's clock started (urgent_stamp), its urgent priority is dropped FOR THAT HEAD (URGENT_DROPPED_CONTEXT
    plus a one-time comment) and it is an ordinary strict PR. A new head starts afresh. Run before the
    reservation, so a dropped head pre-empts nobody. Returns the urgent set still in force."""
    out = set(urgent)
    for _st, v in strict:
        n, since = v["number"], urgent_clock(v)
        if n not in urgent or since is None or now - since <= URGENT_PATIENCE_S:
            continue
        out.discard(n)
        log(f"#{n:>6} urgent    outranked the other lanes for > {URGENT_PATIENCE_S // 60} min on this head "
            f"without progress: urgent priority dropped")
        if not shadow:
            # Once per head: URGENT_DROPPED_CONTEXT keeps this head out of urgent_prs from now on. Not
            # notice_once: that posts a `merge-train` failure, and this PR is still a mergeable strict PR.
            gh.comment(n, URGENT_DROPPED_COMMENT)
            gh.post_status(v["head_sha"], "success", "urgent: priority dropped on this head (no progress)",
                           context=URGENT_DROPPED_CONTEXT)
            v.setdefault("app", {})[URGENT_DROPPED_CONTEXT] = ("success", "")
    return out


def urgent_pick(git, base: str, strict: list, urgent: set[int], holder: int | None, main_red: bool,
                carrier_in_flight: bool) -> int | None:
    """The urgent PR the strict lane can actually serve THIS tick, or None: main green, no holder (an urgent
    holder in CI already has main), green, servable over this main (urgent_servable), and — when up to date —
    no carrier in flight, since strict_lane merges nothing then. Only then does it outrank the other lanes."""
    if main_red or holder is not None:
        return None
    for st, v in strict:
        if st != "green" or v["number"] not in urgent or not urgent_servable(git, base, v):
            continue
        current = git("merge-base", "--is-ancestor", base, v["head_sha"], check=False).returncode == 0
        if current and carrier_in_flight:
            continue
        return v["number"]
    return None


def urgent_yield(yield_why: str | None, pick: int | None) -> str | None:
    """The strict lane's yield after urgency: an urgent PR servable this tick outranks the train's and the
    fast lane's turns."""
    if pick is not None and yield_why:
        log(f"urgent #{pick} served before this turn: {yield_why}")
        return None
    return yield_why


def post_urgent_marks(gh, strict: list, preempted: list, shadow: bool) -> list[int]:
    """Mark every head that yielded main to an urgent PR (URGENT_PREEMPT_CONTEXT), once: strict_reservation
    reads it back and never pre-empts that head again, and never times it out while the urgent PR runs."""
    marked = []
    for _st, view in strict:
        if view["number"] in preempted and not shadow and URGENT_PREEMPT_CONTEXT not in (view.get("app") or {}):
            gh.post_status(view["head_sha"], "success",
                           "strict lane: yielded main once to an urgent PR on this head; not blamed",
                           context=URGENT_PREEMPT_CONTEXT)
            view.setdefault("app", {})[URGENT_PREEMPT_CONTEXT] = ("success", "")
            marked.append(view["number"])
    return marked


def is_expedited(p: dict) -> bool:
    return any((lb.get("name") if isinstance(lb, dict) else lb) == EXPEDITE_LABEL for lb in p.get("labels") or [])


def order_candidates(prs: list[dict]) -> list[dict]:
    """Expedited first, then oldest first. Every later ordering is a stable sort over this one."""
    return sorted(prs, key=lambda p: (not is_expedited(p), p.get("created_at") or "", p["number"]))


def is_protected(path: str, fragments: list[str]) -> str | None:
    for pre in PROTECTED_PREFIXES:
        if path.startswith(pre):
            return pre
    for g in PROTECTED_GLOBS:
        if fnmatch.fnmatch(path, g):
            return g
    for frag in fragments:          # same semantics as regen-derived.sh's matches_any()
        if frag in path:
            return f"regen-derived inventory ({frag})"
    return None


def fast_lane_eligible(pr_files: list[str], main_files: list[str], other_files: list[str],
                       fragments: list[str]) -> tuple[bool, str]:
    for f in pr_files:
        why = is_protected(f, fragments)
        if why:
            return False, f"touches protected path {f} ({why})"
    overlap = sorted(set(pr_files) & set(main_files))
    if overlap:
        return False, f"overlaps main since merge-base: {overlap[0]}"
    overlap = sorted(set(pr_files) & set(other_files))
    if overlap:
        return False, f"overlaps another candidate: {overlap[0]}"
    return True, "disjoint from main and from the batch, no protected path"


def bisect_size(app: dict[str, tuple[str, str]]) -> int | None:
    state, desc = app.get(STATUS_CONTEXT, ("", ""))
    m = BISECT_RE.fullmatch(desc or "") if state == "pending" else None
    return int(m.group(1)) if m else None


def batch_cap(applied: list[Member], sizes: dict[int, int | None], default: int) -> int:
    """How many members a train may APPLY: the smallest `bisect size N` among the members that
    actually APPLY, else the default. Two earlier rules failed against the live queue:
    - read off the OLDEST candidate only (#13794): measured 2026-10-25 (#13801..#13817), the oldest
      candidate #13697 was dropped by every build (its squash is a no-op on main), so it never rode,
      never got a status, and the cap stayed 8 while the five halved members carried `bisect size 2`
      through six carriers; a newly armed older PR (#13710) defeated it the same way;
    - the smallest size over the candidate WINDOW: a member that carries `bisect size 1` and is then
      dropped by every build would pin the whole train at one forever (review of #13840).
    A dropped candidate's size therefore never counts — build applies one member at a time and stops
    before the member that would exceed the cap of those applied so far (TrainBuilder._build)."""
    got = [sizes[m.number] for m in applied if sizes.get(m.number)]
    return max(1, min([default, *got]))


def select_batch(train_cands: list[Member], sizes: dict[int, int | None], default: int) -> list[Member]:
    """Oldest first: the default window. The cap (batch_cap) bounds the members build APPLIES, not the
    candidates it tries — a candidate build drops (no-op, conflict, untrainable) must not consume a slot,
    or a permanently dropped oldest PR at cap 1 would starve the train."""
    return train_cands[:max(1, default)] if train_cands else []


def first_paragraph(body: str | None) -> str:
    text = (body or "").replace("\r", "")
    for para in re.split(r"\n\s*\n", text):
        lines = [ln for ln in para.strip().splitlines() if not ln.strip().startswith(("#", "<!--"))]
        if lines:
            return "\n".join(lines).strip()
    return ""


def squash_message(m: Member) -> str:
    para = first_paragraph(m.body)
    return f"{m.title}\n\n{para}\n\nPR-Number: #{m.number}\n" if para else f"{m.title}\n\nPR-Number: #{m.number}\n"


def own_member_message(n: int, head: str) -> str:
    return f"merge-train: member #{n}\n\nPR-Number: #{n}\nPR-Head: {head}\n"


def train_branch(run_id: str, attempt: str) -> str:
    name = f"train/{run_id}-{attempt}"
    assert_train_branch(name)
    return name


def strict_train_branch(run_id: str, attempt: str) -> str:
    name = f"train/strict-{run_id}-{attempt}"
    assert_train_branch(name)
    return name


def assert_train_branch(name: str) -> None:
    ok = bool(TRAIN_BRANCH_RE.fullmatch(name or "") or STRICT_TRAIN_BRANCH_RE.fullmatch(name or "")) and subprocess.run(
        ["git", "check-ref-format", f"refs/heads/{name}"], capture_output=True).returncode == 0
    if not ok:
        raise ValueError(f"refusing ref {name!r}: not of the form train/<run_id>-<attempt> or train/strict-<run_id>-<attempt>")


# gates.yaml APPEND (ADR-0343 amendment 2026-11-14): a member whose only change to gates.yaml is new,
# whole `- id:` entries rides a train like gate code. #13837 kept every gates.yaml edit strict because one
# edit can retire or weaken a PRIVILEGED gate without touching its script, and settle runs with no YAML
# parser. An append cannot: every existing entry must survive BYTE-FOR-BYTE and in order, the header
# before the first entry is unchanged, a new id collides with no id on main, and a new entry can neither
# start a top-level key (every line indented under it) nor define a YAML anchor (which would redefine an
# alias a LATER entry already uses). Anything else returns a reason and the member stays strict.
GATE_ENTRY_RE = re.compile(r"^  - id:\s*([^\s#]+)\s*(#.*)?$")
YAML_ANCHOR_RE = re.compile(r"(?:^|[\s:\[{,-])&[A-Za-z0-9_.-]")
# A new entry's own shape (review of #16109): its id is a plain token (a quoted id is a YAML duplicate the
# line scan would not see); its keys come from the set gates.yaml already uses, never `env:` (PATH or
# PYTHONPATH would redirect every later command) and never a second `id:`; and the only EXECUTABLE fields,
# `run:` and `selftest:`, may do nothing but invoke one trainable gate or test script per line with plain
# arguments. A free shell line would run inside the judging shard beside the existing gates and could
# rewrite a privileged gate's script on the shared tree before that gate runs.
GATE_PLAIN_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]*")
APPENDED_GATE_KEYS = frozenset({"name", "group", "mode", "run", "selftest", "selftest_inputs", "selftest_expect",
                                "selftest_exempt", "min_subjects", "rationale", "review_after", "budget_seconds",
                                "verified", "needs_base", "when"})
APPENDED_GATE_EXEC_KEYS = ("run", "selftest")
GATE_KEY_RE = re.compile(r"^    ([A-Za-z_][A-Za-z0-9_]*):(.*)$")
GATE_CMD_RE = re.compile(r"(python3|bash) (\.github/scripts/[A-Za-z0-9_./-]+\.(?:py|sh))((?: [A-Za-z0-9_./=:,@+-]+)*)")


def appended_gate_script_ok(interpreter: str, path: str) -> bool:
    """A script an appended gate may invoke: a canonical path (no `.`/`..` segment, no `//`, so a glob
    like check-*.py cannot be walked out of .github/scripts/), the interpreter matching the extension,
    and trainable gate or test code (never PRIVILEGED_GATE_CODE)."""

    if posixpath.normpath(path) != path or any(seg in ("", ".", "..") for seg in path.split("/")):
        return False
    if not path.startswith(".github/scripts/"):
        return False
    if (interpreter == "python3") != path.endswith(".py"):
        return False
    return gate_code(path)


def appended_gate_problem(gid: str, lines: list[str]) -> str | None:
    """Why one new gate entry (its lines after `  - id:`) may not ride a train, or None."""
    if not GATE_PLAIN_ID_RE.fullmatch(gid):
        return f"new gate id {gid!r} is not a plain token"
    key, exec_lines, seen = None, {}, set()
    for ln in lines:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        m = GATE_KEY_RE.match(ln)
        if m:
            key, value = m.group(1), m.group(2).strip()
            if key not in APPENDED_GATE_KEYS or key in seen:
                return f"new gate {gid!r} sets {key!r}, which an appended gate may not"
            seen.add(key)
            if key in APPENDED_GATE_EXEC_KEYS:
                exec_lines[key] = [] if value.split("#")[0].strip() in ("|", "|-", "|+", ">", ">-", ">+") else [value]
            continue
        if not ln.startswith("      "):
            return f"new gate {gid!r} has a line outside any of its keys"
        if key in exec_lines:
            exec_lines[key].append(ln.strip())
    if "run" not in exec_lines:
        return f"new gate {gid!r} has no run"
    for k, cmds in exec_lines.items():
        cmds = [c for c in cmds if c and not c.startswith("#")]
        if not cmds:
            return f"new gate {gid!r}: {k} is empty"
        for c in cmds:
            m = GATE_CMD_RE.fullmatch(c)
            if not m or not appended_gate_script_ok(m.group(1), m.group(2)):
                return f"new gate {gid!r}: {k} line {c[:60]!r} is not a plain call of a trainable gate script"
    return None


def gate_blocks(text: str) -> tuple[str, list[str]]:
    """(header before the first `  - id:` line, one text block per entry up to the next one)."""
    head: list[str] = []
    blocks: list[list[str]] = []
    for ln in text.splitlines(keepends=True):
        if GATE_ENTRY_RE.match(ln.rstrip("\r\n")):
            blocks.append([ln])
        elif blocks:
            blocks[-1].append(ln)
        else:
            head.append(ln)
    return "".join(head), ["".join(b) for b in blocks]


def gates_append_problem(old: str | None, new: str | None, main_ids: set[str] | frozenset = frozenset()) -> str | None:
    """None when `new` is `old` plus whole new gate entries only (see GATE_ENTRY_RE above), else why not."""
    if old is None or new is None:
        return "gates.yaml is missing on one side"
    if old == new:
        return "gates.yaml is unchanged"
    old_head, old_blocks = gate_blocks(old)
    new_head, new_blocks = gate_blocks(new)
    if not old_blocks:
        return "gates.yaml has no `- id:` entries to append to"
    if new_head != old_head:
        return "the text before the first gate entry changed"
    added: list[str] = []
    j = 0
    for b in new_blocks:
        if j < len(old_blocks) and b == old_blocks[j]:
            j += 1
        else:
            added.append(b)
    if j != len(old_blocks):
        return "an existing gate entry was changed, moved or removed"
    taken = {GATE_ENTRY_RE.match(b.splitlines()[0]).group(1).strip("'\"") for b in old_blocks} | set(main_ids)
    for b in added:
        lines = b.splitlines()
        gid = GATE_ENTRY_RE.match(lines[0]).group(1)
        if gid.strip("'\"") in taken:
            return f"new gate id {gid!r} already exists"
        taken.add(gid)
        for ln in lines:
            if YAML_ANCHOR_RE.search(ln) or "\t" in ln:
                return f"new gate {gid!r} defines a YAML anchor or uses a tab"
        for ln in lines[1:]:
            if ln.strip() and not ln.startswith("    ") and not ln.lstrip().startswith("#"):
                return f"new gate {gid!r} has a line not indented under its entry"
        why = appended_gate_problem(gid, lines[1:])
        if why:
            return why
    return None


def gates_append_at(git, old_rev: str, new_rev: str, main_rev: str | None = None) -> str | None:
    """gates_append_problem over two revisions read execution-free with `git show`; `main_rev`'s ids
    are taken too (main may have added the same id since the member branched)."""
    def text(rev: str) -> str | None:
        r = git("show", f"{rev}:{GATES_YAML}", check=False)
        return r.stdout if r.returncode == 0 else None
    main_ids = gate_ids(text(main_rev) or "") if main_rev else set()
    return gates_append_problem(text(old_rev), text(new_rev), main_ids)


def gate_ids(text: str) -> set[str]:
    """The `- id:` set of a gates.yaml, by line scan (no YAML parse under `python3 -I -S`)."""
    return {m.group(1) for ln in text.splitlines() for m in [GATE_ID_RE.match(ln)] if m}


def judge_path(path: str, refs=None) -> bool:
    """A path whose change may alter what JUDGES a strict carrier: it rides alone. The INVERSE rule, fail
    closed (re-review of #14891): a path may be batched only if it is under `.github/scripts/` AND no
    workflow, action or gates.yaml entry on main names it — by full path, or by bare basename (a script
    run as `"$DIR/name.sh"`). Everything else (a workflow, an action, gates.yaml, rules.yaml, CODEOWNERS,
    the privileged and train code, run-gates.py, any invoked script) rides alone. `refs` is
    referenced_scripts(); None (or its error sentinel) batches nothing."""
    if path.startswith(JUDGE_PREFIXES) or path in JUDGE_PATHS or not path.startswith(".github/scripts/"):
        return True
    if refs is None or "*" in refs[0]:
        return True
    return path in refs[0] or path.rsplit("/", 1)[-1] in refs[1]


SCRIPT_REF_RE = r"\.github/scripts/[^] \"'`)}]+"
SCRIPT_NAME_RE = r"[A-Za-z0-9_.-]+\.(py|sh|bash|mjs|cjs|js|ts)"
_REFERENCED_SCRIPTS: dict[str, tuple[set[str], set[str]]] = {}


def referenced_scripts(git, base: str) -> tuple[set[str], set[str]]:
    """(full paths, bare basenames) of every script that main's workflows, actions or gates.yaml name —
    one execution-free `git grep` over `base`, memoised per base sha. A grep error returns the sentinel
    ({"*"}, set()): nothing batches."""
    if base not in _REFERENCED_SCRIPTS:
        r = git("grep", "-h", "-o", "-I", "-E", "-e", SCRIPT_REF_RE, "-e", SCRIPT_NAME_RE, base,
                "--", ".github/workflows", ".github/actions", GATES_YAML, check=False)   # ONE spawn per base
        if r.returncode not in (0, 1):
            _REFERENCED_SCRIPTS[base] = ({"*"}, set())
        else:
            toks = r.stdout.split()
            _REFERENCED_SCRIPTS[base] = ({x for x in toks if x.startswith(".github/scripts/")},
                                         {x.rsplit("/", 1)[-1] for x in toks})
    paths, names = _REFERENCED_SCRIPTS[base]
    return set(paths), set(names)


# --------------------------------------------------------------------------- git
# Every git/python spawn this process makes goes through here; the self-test asserts a CEILING on
# the count (SELF_TEST_SPAWN_CEILING) because spawn time IS its wall time — measured 2026-11-03:
# 18,534 spawns, 95 % of a 721 s loaded-Mac run and all of the 77-109 s on ubuntu-latest, where a
# raised budget_seconds (#14685) was exceeded twice. Bounding the count is what keeps the budget.
SPAWNS = [0]


def sh(cmd: list[str], cwd: str | None = None, check: bool = True, env: dict | None = None) -> subprocess.CompletedProcess:
    SPAWNS[0] += 1
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, check=check, env=env)


def base_env() -> dict[str, str]:
    """Allowlisted environment with isolated git config. No token of any kind."""
    env = {k: os.environ[k] for k in GENERATOR_ENV_ALLOWLIST if k in os.environ}
    env.update({"GIT_AUTHOR_NAME": "openbank-gitops-bot", "GIT_COMMITTER_NAME": "openbank-gitops-bot",
                "GIT_AUTHOR_EMAIL": "gitops-bot@openbank.invalid", "GIT_COMMITTER_EMAIL": "gitops-bot@openbank.invalid",
                "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull, "GIT_TERMINAL_PROMPT": "0",
                # Never put the script's directory or the cwd on sys.path: main's bundle scripts run
                # `python3 -` from their own directory, where a PR-added re.py would shadow `re`.
                "PYTHONSAFEPATH": "1"})
    return env


def generator_env() -> dict[str, str]:
    """The ONLY environment build's generators see: no token, no RUNNER_TEMP, no GITHUB_*."""
    return base_env()


class Git:
    """Isolated git: no system/global config, no hooks, no fsmonitor; credentials only per call."""

    # Read-only subcommands whose output, given FULL-sha arguments, is a pure function of the object
    # store: content-addressed, so identical argv in the same clone answers identically until the
    # store changes. Any other subcommand (fetch, checkout, merge, ...) may change the store or the
    # worktree, so it clears the memo. A non-zero result is never memoised (a missing object becomes
    # present after a fetch — which clears the memo anyway — and an error should be re-asked).
    # Measured 2026-11-03: 7,125 of 18,291 git spawns in the self-test were exact (cwd, argv) repeats
    # of such read-only commands; a ref name (`main`, `HEAD`, `origin/x`) is NEVER a memo key.
    _MEMO_SUBCOMMANDS = frozenset({"rev-list", "rev-parse", "diff", "show", "merge-base", "log", "ls-tree",
                                   "cat-file", "merge-tree", "diff-tree"})
    _SHA_ARG = re.compile(r"^[0-9a-f]{40}(\^\{tree\}|\^\{commit\}|:[^\s]*|(\.\.|\.\.\.)[0-9a-f]{40})?$")

    def __init__(self, workdir: str, token: str | None = None):
        self.workdir, self.token = workdir, token
        self._memo: dict[tuple, subprocess.CompletedProcess] = {}

    # Subcommands that compare TWO revisions when given two, but read the WORKTREE or the INDEX when
    # given one (`diff <sha>`), or when told to (`--cached`, `--staged`, `--no-index`, `--work-tree`).
    # Neither is a function of the shas, so those shapes are never memoised (review on the first
    # draft: a squash-merge or a generator run in the same workdir would otherwise be served a
    # stale answer from a merge gate's own cache).
    _TWO_REV_SUBCOMMANDS = frozenset({"diff", "diff-tree", "merge-base", "merge-tree"})
    _NEVER_MEMO_FLAGS = frozenset({"--cached", "--staged", "--no-index", "--work-tree", "--index"})

    def _memo_key(self, args: tuple[str, ...]) -> tuple | None:
        """The argv if its output is a pure function of immutable shas, else None (never memoised).

        Every positional must be a full 40-hex sha (optionally `^{tree}`, `^{commit}`, `:path`, or a
        `..`/`...` range of two full shas); a `--` pathspec separator or anything after it, a symbolic
        ref, an abbreviated sha, an index/worktree flag, or a single revision to a two-revision
        subcommand all return None."""
        sub = next((a for a in args if not a.startswith("-")), None)
        if sub not in self._MEMO_SUBCOMMANDS:
            return None
        rest = args[args.index(sub) + 1:]
        if "--" in rest or any(a.split("=", 1)[0] in self._NEVER_MEMO_FLAGS for a in rest):
            return None
        positional = [a for a in rest if not a.startswith("-")]
        if not positional or not all(self._SHA_ARG.match(a) for a in positional):
            return None
        if sub in self._TWO_REV_SUBCOMMANDS:
            revs = sum(2 if ".." in a else 1 for a in positional)
            if revs < 2:
                return None
        return args

    def __call__(self, *args: str, check: bool = True, auth: bool = False) -> subprocess.CompletedProcess:
        key = self._memo_key(args)
        if key is None:
            self._memo.clear()   # a write, or a read through a movable ref: nothing cached survives it
        elif key in self._memo:
            r = self._memo[key]
            if check and r.returncode != 0:
                raise subprocess.CalledProcessError(r.returncode, r.args, r.stdout, r.stderr)
            return r
        env = base_env()
        if auth and self.token:
            basic = base64.b64encode(f"x-access-token:{self.token}".encode()).decode()
            env.update({"GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": "http.https://github.com/.extraheader",
                        "GIT_CONFIG_VALUE_0": f"AUTHORIZATION: basic {basic}"})
        r = sh(["git", "-c", "core.hooksPath=/dev/null", "-c", "core.fsmonitor=false", *args],
               cwd=self.workdir, check=check, env=env)
        if key is not None and r.returncode == 0:
            self._memo[key] = r
        return r

    def tree(self, rev: str) -> str:
        r = self("rev-parse", "--verify", "--quiet", f"{rev}^{{tree}}", check=False)
        return r.stdout.strip() if r.returncode == 0 else ""

    def special_entries(self, rev: str) -> set[tuple[str, str, str]]:
        """{(mode, oid, path)} for every symlink/gitlink in the tree of `rev`."""
        entries = set()
        for rec in self("ls-tree", "-r", "-z", rev).stdout.split("\0"):
            if not rec:
                continue
            meta, _, path = rec.partition("\t")
            mode, _typ, oid = meta.split()
            if mode in SPECIAL_MODES:
                entries.add((mode, oid, path))
        return entries


class Pusher:
    """The only code path that writes refs: a full sha to the run's own train branch, or its delete."""

    def __init__(self, git, branch: str, remote: str):
        assert_train_branch(branch)
        self.git, self.branch, self.remote = git, branch, remote

    def push(self, sha: str) -> None:
        assert_train_branch(self.branch)
        if not SHA_RE.fullmatch(sha):
            raise ValueError(f"refusing to push non-sha {sha!r}")
        self.git("push", "-q", "-f", self.remote, f"{sha}:refs/heads/{self.branch}", auth=True)

    def delete(self) -> None:
        assert_train_branch(self.branch)
        self.git("push", "-q", self.remote, "--delete", f"refs/heads/{self.branch}", check=False, auth=True)


# --------------------------------------------------------------------------- build (untrusted)
class TrainBuilder:
    """Squashes verified heads in a working copy and regenerates with main's generators. No secrets."""

    def __init__(self, workdir: str, regen_commands: tuple[str, ...] = REGEN_COMMANDS,
                 overlay_roots: tuple[str, ...] = GENERATOR_OVERLAY_ROOTS, untrainable=None):
        self.workdir, self.regen_commands, self.overlay_roots = workdir, regen_commands, overlay_roots
        self.untrainable = untrainable or FAIL_CLOSED_UNTRAINABLE
        self.env = generator_env()
        self.quarantined: list[str] = []
        self.overlaid_gate: list[str] = []
        # Path fragments main's inventory declares as generator INPUTS (set from origin/main by
        # mode_build). Only added files under these stay visible while the generators run.
        self.declared_inputs: list[str] = []
        self.keep_declared_inputs = True
        # #13400: gate code and a regeneration commit never share a train; members held back for that
        # are DEFERRED (no drop notice; the next tick takes them), never dropped.
        self.separate_gate_code = True
        self.deferred: list[int] = []
        self.sizes: dict[int, int | None] = {}   # live `bisect size N` per candidate (batch_cap)
        self.default_size: int | None = None      # batch size; None = no cap (direct builds in tests)
        self.attempted: list[int] = []       # members _build tried (applied or dropped), in order

    def git(self, *args: str, check: bool = True) -> subprocess.CompletedProcess:
        return sh(["git", "-c", "core.hooksPath=/dev/null", *args], cwd=self.workdir, check=check, env=self.env)

    def build(self, base: str, members: list[Member]) -> tuple[str, list[int], list[int]]:
        """(tip, applied, dropped); self.deferred lists members held back for the next train."""
        self.deferred = []
        tip, applied, dropped, regen, gate = self._build(base, members)
        if not (self.separate_gate_code and regen and gate):
            return tip, applied, dropped
        # Keep the class of the OLDEST applied member, so neither class starves behind the other.
        keep_gate = applied[0] in gate
        keep = [m for m in members if (m.number in gate) == keep_gate]
        log(f"build: gate code {sorted(gate)} and a regeneration commit never share a train — "
            f"keeping the {'gate-code' if keep_gate else 'other'} member(s)")
        tip, applied2, dropped2, regen2, gate2 = self._build(base, keep)
        if regen2 and gate2:
            # Main itself needs regeneration: gate code cannot ride until it does not.
            keep = [m for m in members if m.number not in gate]
            tip, applied2, dropped2, regen2, gate2 = self._build(base, keep) if keep else (base, [], [], False, [])
        kept = {m.number for m in keep}
        self.deferred = [m.number for m in members if m.number not in kept]
        log(f"build: deferred {self.deferred} to the next train")
        return tip, applied2, dropped2

    def _build(self, base: str, members: list[Member]) -> tuple[str, list[int], list[int], bool, list[int]]:
        self.git("checkout", "-q", "--detach", "-f", base)
        self.git("clean", "-qfdx")
        applied: list[int] = []
        dropped: list[int] = []
        gate: list[int] = []
        self.attempted = []
        by_number = {m.number: m for m in members}
        for m in members:
            r = self.git("merge", "--squash", "--no-commit", m.ref, check=False)
            staged = changed_paths(self.git, cached=True) if r.returncode == 0 else []
            # gates.yaml rides only as a pure append over what this train has built so far (HEAD).
            appended = (GATES_YAML in staged and r.returncode == 0 and gates_append_problem(
                self.git("show", f"HEAD:{GATES_YAML}", check=False).stdout or None,
                self.git("show", f":{GATES_YAML}", check=False).stdout or None,
                gate_ids(self.git("show", f"{base}:{GATES_YAML}", check=False).stdout)) is None)
            if r.returncode != 0 or not staged or any(
                    unsafe_path(f) or (self.untrainable(f) and not (f == GATES_YAML and appended)) for f in staged):
                self.git("merge", "--abort", check=False)
                self.git("reset", "-q", "--hard", "HEAD")
                self.attempted.append(m.number)
                dropped.append(m.number)
                continue
            if self.default_size is not None:
                cap = batch_cap([by_number[n] for n in applied] + [m], self.sizes, self.default_size)
                if len(applied) + 1 > cap:
                    # The bisect cap counts APPLIED members only; this one and the rest are not
                    # tried this train (not dropped, no notice) and lead the next one.
                    self.git("reset", "-q", "--hard", "HEAD")
                    break
            self.attempted.append(m.number)
            self.git("commit", "-q", "-m", squash_message(m))
            applied.append(m.number)
            if any(gate_code(f) for f in staged) or GATES_YAML in staged:
                gate.append(m.number)   # an appended gate is judged like gate code: never with a regen commit
        regen = False
        if applied:
            try:
                self.overlay_trusted_generators(base)
            except RuntimeError as exc:
                # A member changed what the runner would execute: nobody rides this train.
                log(f"::warning::train refused before any generator ran: {exc}")
                self.git("checkout", "-q", "--detach", "-f", base)
                return base, [], dropped + applied, False, []
            self.quarantine_new_executables(base)
            try:
                regen = self.regenerate()
            finally:
                self.restore_quarantined()
                self.restore_overlaid_gate()
        return self.git("rev-parse", "HEAD").stdout.strip(), applied, dropped, regen, gate

    def quarantine_new_executables(self, base: str) -> None:
        """Before any generator runs: remove from the working tree every file that is not on
        origin/main — except the files main's inventory declares as generator INPUTS (a new ADR, a
        new version.txt), which the generators must see or the train is wrong. A kept file is
        never untrainable, and PYTHONSAFEPATH keeps it off sys.path, so it cannot be imported in
        place of a module. A generator or a module added by a PR therefore never runs."""
        in_base = set(zpaths(self.git("ls-tree", "-r", "-z", "--name-only", base).stdout))
        on_disk = zpaths(self.git("ls-files", "-z", "--cached", "--others", "--exclude-standard").stdout)

        def keep(f: str) -> bool:
            return (self.keep_declared_inputs and not unsafe_path(f) and not self.untrainable(f)
                    and any(frag in f for frag in self.declared_inputs))
        self.quarantined = [f for f in on_disk if f not in in_base and not keep(f)]
        for f in self.quarantined:
            os.unlink(os.path.join(self.workdir, f))
        if self.quarantined:
            log(f"quarantined {len(self.quarantined)} file(s) not on main while the generators run")

    def restore_overlaid_gate(self) -> None:
        """Put the member's gate code back after the generators ran over main's copy."""
        gate, self.overlaid_gate = self.overlaid_gate, []
        for e in gate:
            if e.startswith("??"):
                os.unlink(os.path.join(self.workdir, e[3:]))
        tracked = [e[3:] for e in gate if not e.startswith("??")]
        if tracked:
            self.git("checkout", "HEAD", "--", *tracked)

    def restore_quarantined(self) -> None:
        tracked = [f for f in self.quarantined if self.git("cat-file", "-e", f"HEAD:{f}", check=False).returncode == 0]
        if tracked:
            self.git("checkout", "HEAD", "--", *tracked)

    def overlay_trusted_generators(self, base: str) -> None:
        roots = [p for p in self.overlay_roots if self.git("cat-file", "-e", f"{base}:{p}", check=False).returncode == 0]
        if roots:
            archive = subprocess.run(["git", "archive", base, "--", *roots], cwd=self.workdir,
                                     capture_output=True, check=True, env=self.env).stdout
            subprocess.run(["tar", "-x", "-C", self.workdir], input=archive, check=True, capture_output=True)
        entries = [e for e in zpaths(self.git("status", "--porcelain", "--no-renames", "--untracked-files=all", "-z").stdout)
                   if len(e) > 3]
        # The overlay exists to put main's GENERATORS back. A trainable data file under an overlay
        # root (a baseline, an ADR) is the member's content and must stay so — otherwise the regen
        # commit carries main's copy as a revert and publish rejects it as a non-derived path.
        # Gate code is NOT restored: the generators see main's copy, as they see main's generators;
        # regenerate() puts the member's copy back before anything is committed (review of #13750).
        self.overlaid_gate = [e for e in entries if gate_code(e[3:])]
        data = [e for e in entries if not self.untrainable(e[3:]) and not gate_code(e[3:])]
        modified = [e[3:] for e in data if not e.startswith("??")]
        if modified:
            self.git("checkout", "HEAD", "--", *modified)
        for e in data:
            if e.startswith("??"):
                os.unlink(os.path.join(self.workdir, e[3:]))
        dirty = [e[3:] for e in entries if self.untrainable(e[3:])]
        if dirty:
            raise RuntimeError(f"generator paths differ from the trusted base after overlay: {dirty[:5]}")

    def regenerate(self) -> bool:
        for cmd in self.regen_commands:
            r = subprocess.run(shlex.split(cmd), cwd=self.workdir, text=True, capture_output=True, env=self.env)
            if r.returncode != 0:
                log(f"::warning::regen command failed ({cmd}): {r.stderr.strip()[-300:]}")
        self.restore_quarantined()
        self.restore_overlaid_gate()
        changed = zpaths(self.git("ls-files", "-z", "-m", "-o", "--exclude-standard").stdout)
        if any(unsafe_path(f) for f in changed):
            raise RuntimeError("a generator wrote a path with a control character — refusing the train")
        if not changed:
            return False
        self.git("add", "--", *changed)
        self.git("commit", "-q", "-m", REGEN_COMMIT_SUBJECT)
        return True


# --------------------------------------------------------------------------- publish (trusted)
class Reject(Exception):
    def __init__(self, reason: str, member_fault: bool = True):
        super().__init__(reason)
        self.member_fault = member_fault


@dataclass
class Verified:
    tip: str
    tree: str
    applied: list[int]
    dropped: list[int]


def verify_bundle_train(git: Git, base: str, members: list[Member], bundle_tip: str | None,
                        outputs: list[str]) -> Verified:
    """Re-derive the train execution-free and require the bundle to match it step by step.
    Returns publish's OWN commit chain (commit-tree over verified trees) — the bundle's commits are
    never pushed. Raises Reject.

    `bundle_tip=None` (#15827): re-derive the members' chain over `base` from their live heads alone,
    with nothing taken from the bundle. Used only when a declared member left the batch after build,
    so the bundle's per-member commits no longer line up; there is no regeneration commit (the caller
    refuses that case), so every tree pushed is a merge-tree of live, re-verified heads."""
    if bundle_tip is None:
        return _rederive_train(git, base, members)
    if not SHA_RE.fullmatch(bundle_tip):
        raise Reject("bundle tip is not a full sha", member_fault=False)
    chain = git("rev-list", "--reverse", "--first-parent", f"{base}..{bundle_tip}").stdout.split()
    every = git("rev-list", f"{base}..{bundle_tip}").stdout.split()
    if not chain or len(every) != len(chain):
        raise Reject("bundle is not one linear chain over the live base", member_fault=False)
    if git("rev-parse", f"{chain[0]}^").stdout.strip() != base:
        raise Reject("bundle chain does not start at the live base", member_fault=False)
    for c in chain:
        if len(git("rev-list", "--parents", "-n", "1", c).stdout.split()) != 2:
            raise Reject(f"bundle commit {c[:12]} is not a single-parent commit", member_fault=False)

    own, own_tree = base, git.tree(base)
    applied: list[int] = []
    dropped: list[int] = []
    gate: list[int] = []
    idx = 0
    for m in members:
        r = git("merge-tree", "--write-tree", own, m.head_sha, check=False)
        if r.returncode not in (0, 1):
            raise Reject(f"merge-tree failed for #{m.number}: rc={r.returncode}", member_fault=False)
        tree = r.stdout.split()[0] if r.stdout.split() else ""
        if r.returncode == 1 or tree == own_tree:
            dropped.append(m.number)
            continue
        if idx >= len(chain):
            raise Reject(f"bundle has no commit for #{m.number}", member_fault=False)
        if git.tree(chain[idx]) != tree:
            raise Reject(f"bundle commit for #{m.number} differs from the merge-tree rebuild", member_fault=False)
        moved = changed_paths(git, own_tree, tree)
        if GATES_YAML in moved and gates_append_at(git, own_tree, tree) is not None:
            raise Reject(f"#{m.number} changes gates.yaml beyond a pure append", member_fault=True)
        if any(gate_code(f) for f in moved) or GATES_YAML in moved:
            gate.append(m.number)
        own = git("commit-tree", tree, "-p", own, "-m", own_member_message(m.number, m.head_sha)).stdout.strip()
        own_tree = tree
        applied.append(m.number)
        idx += 1
    rest = chain[idx:]
    if len(rest) > 1:
        raise Reject(f"bundle carries {len(rest)} commits beyond its members", member_fault=False)
    if rest and gate:
        # #13400: the regeneration content is proven by MAIN's gates only while no member changed one.
        raise Reject(f"regeneration commit next to gate-code member(s) {gate}", member_fault=False)
    if rest:
        regen = rest[0]
        for change in changed_entries(git, f"{regen}^", regen):
            for path in change.paths:
                if unsafe_path(path):
                    raise Reject("regeneration commit touches a path with a control character")
                if change.new_mode in SPECIAL_MODES:
                    raise Reject(f"regeneration commit adds a symlink/gitlink: {path}")
                if not any(glob_match(g, path) for g in outputs):
                    raise Reject(f"regeneration commit touches {path}, which is not a declared derived output")
        own = git("commit-tree", git.tree(regen), "-p", own, "-m", OWN_REGEN_MSG).stdout.strip()
        own_tree = git.tree(regen)
    if not applied:
        raise Reject("no member applied", member_fault=False)
    extra = git.special_entries(own) - git.special_entries(base)
    if extra:
        raise Reject(f"train tree contains a symlink/gitlink main does not: {sorted(p for _, _, p in extra)[:3]}")
    return Verified(own, own_tree, applied, dropped)


def _rederive_train(git: Git, base: str, members: list[Member]) -> Verified:
    """verify_bundle_train without a bundle: publish's own chain, merge-tree only, nothing executed."""
    own, own_tree = base, git.tree(base)
    applied: list[int] = []
    dropped: list[int] = []
    for m in members:
        r = git("merge-tree", "--write-tree", own, m.head_sha, check=False)
        if r.returncode not in (0, 1):
            raise Reject(f"merge-tree failed for #{m.number}: rc={r.returncode}", member_fault=False)
        tree = r.stdout.split()[0] if r.stdout.split() else ""
        if r.returncode == 1 or tree == own_tree:
            dropped.append(m.number)
            continue
        own = git("commit-tree", tree, "-p", own, "-m", own_member_message(m.number, m.head_sha)).stdout.strip()
        own_tree = tree
        applied.append(m.number)
    if not applied:
        raise Reject("no member applied", member_fault=False)
    extra = git.special_entries(own) - git.special_entries(base)
    if extra:
        raise Reject(f"train tree contains a symlink/gitlink main does not: {sorted(p for _, _, p in extra)[:3]}")
    return Verified(own, own_tree, applied, dropped)


# --------------------------------------------------------------------------- settle (trusted)
def parse_own_chain(git: Git, tip: str, limit: int = 64) -> tuple[str, list[tuple[int, str]]] | None:
    """Walk publish's own commits down from `tip`. -> (base, [(pr, head)]) or None if not ours."""
    members: list[tuple[int, str]] = []
    cur = tip
    for _ in range(limit):
        msg = git("log", "-1", "--format=%B", cur).stdout.rstrip("\n") + "\n"
        m = OWN_MEMBER_RE.fullmatch(msg)
        if not (m or (msg == OWN_REGEN_MSG and cur == tip)):
            break
        if m:
            members.append((int(m.group(1)), m.group(2)))
        parents = git("rev-list", "--parents", "-n", "1", cur).stdout.split()[1:]
        if len(parents) != 1:
            return None
        cur = parents[0]
    else:
        return None
    if not members:
        return None
    return cur, list(reversed(members))


def record_problem(record_desc: str | None, record_creator: str | None, sha_tree: str) -> str | None:
    if record_creator != BOT_LOGIN:
        return "no merge-train/record status from the App on this exact sha"
    m = RECORD_RE.fullmatch(record_desc or "")
    if not m:
        return "malformed record"
    if not sha_tree or m.group(1) != sha_tree:
        return f"tree {sha_tree[:12] or '?'} is not the recorded tree {m.group(1)[:12]}"
    return None


# --------------------------------------------------------------------------- GitHub
# Transient GitHub API failures (#13400). On 2026-10-26 one 503 in publish (16:33Z, a check-runs GET) and
# one installation-quota 403 in build (16:39Z) each killed a tick's carrier, ~25 min of fast lane lost.
# ONE policy, here, in the only helper every mode's API call goes through:
# - retried with bounded exponential backoff: 500/502/503/504, a connection reset/refusal or timeout, and a
#   SECONDARY rate limit (403/429 carrying Retry-After). Only for GET — a write whose response was lost
#   may have been applied (a retried update-branch would answer 422 and read as a refusal), so a
#   transient failure on a write aborts the tick instead;
# - PRIMARY quota exhaustion (403/429 with x-ratelimit-remaining: 0) is never retried: the tick aborts at
#   once, logging the reset time — waiting in-process could only burn runner minutes until it;
# - everything else (401, 403 without a rate-limit signal, 404, 422, ...) is returned exactly as before,
#   so every caller stays fail-closed on it.
# An abort raises ApiAbort, which main() turns into a clean exit: no member is blamed, nothing is
# bisected or halved, the batch stays armed for the next tick. Sleep is bounded per call
# (API_RETRY_ATTEMPTS, API_BACKOFF_CAP_S) and per process (API_RETRY_BUDGET_S, 5 min against the
# 30-45 min step timeouts in merge-train.yml).
TRANSIENT_HTTP = frozenset({500, 502, 503, 504})   # 500: run 41640891760, check-runs page 2
API_RETRY_ATTEMPTS = 5
API_BACKOFF_BASE_S = 2.0
API_BACKOFF_CAP_S = 60.0
API_RETRY_BUDGET_S = 300.0
_api_slept = [0.0]
# Quota (#13400): one tick read the same check-runs of a sha up to three times (checks, ci_activity,
# extra_checks) and the open-PR list three times. Those GETs are memoised ONLY inside planning_reads()
# (settle's view of main and the armed PRs, build's batch plan), and EVERY write clears the memo.
# Cache safety (#13988 review): a memoised read is never a write's verdict. Outside planning_reads()
# nothing is memoised (publish plans fresh, extra-gate runs included), and the writes that act on a
# verdict re-read it live inside deciding(), where the memo neither serves nor stores: GitHub.merge
# re-reads the ruleset guard and the head's required contexts, and a `merge-train` success status
# re-reads the head's required contexts — in the GitHub class itself, so no call site can skip it.
# Never memoised anywhere: the main ref and a single PR (`pulls/<n>`).
_GET_MEMO: dict[str, bytes] = {}
_MEMO_SCOPE = [0]    # > 0 inside planning_reads()
_DECIDING = [0]      # > 0 inside deciding(): verdict reads bypass the memo entirely


@contextlib.contextmanager
def planning_reads():
    """Reads that only classify and plan: memoised (until the next write)."""
    _MEMO_SCOPE[0] += 1
    try:
        yield
    finally:
        _MEMO_SCOPE[0] -= 1
        if not _MEMO_SCOPE[0]:
            _GET_MEMO.clear()


@contextlib.contextmanager
def deciding():
    """Reads a write is about to act on: always live, never memoised, whatever scope encloses them."""
    _DECIDING[0] += 1
    try:
        yield
    finally:
        _DECIDING[0] -= 1
GET_MEMO_RE = re.compile(r"^/repos/[^/]+/[^/]+/(?:commits/[0-9a-f]{40}/(?:check-runs|status|statuses)"
                         r"|rules/branches/[^/?]+|actions/runs\?head_sha=[0-9a-f]{40}|pulls\?state=open&base=[^&]+)(?:[?&].*)?$")


class ApiAbort(Exception):
    """The GitHub API is unavailable for this tick (transient retries spent, or primary quota out).
    Never a verdict about any PR: main() exits cleanly and the next tick starts over."""

    def __init__(self, kind: str, detail: str, reset: int | None = None):
        super().__init__(f"{kind}: {detail}")
        self.kind, self.detail, self.reset = kind, detail, reset


def _http_open(req, timeout):
    """(status, body bytes, headers) for a 2xx/3xx; raises urllib errors otherwise. Replaced in self-test."""
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read(), r.headers


def _api_sleep(s: float) -> None:
    time.sleep(s)


def _header(headers, name: str) -> str:
    try:
        return (headers.get(name) if headers is not None else None) or ""
    except AttributeError:
        return ""


def api_retry_delay(method: str, code: int | None, headers, attempt: int) -> float | None:
    """Seconds to wait before retrying, or None when this failure is not retried. Raises ApiAbort for
    primary quota exhaustion. `code` None = connection reset/refused or timeout (no response)."""
    if code in (403, 429):
        if _header(headers, "x-ratelimit-remaining") == "0":
            reset = _header(headers, "x-ratelimit-reset")
            when = (datetime.datetime.fromtimestamp(int(reset), datetime.timezone.utc).strftime("%H:%M:%SZ")
                    if reset.isdigit() else "unknown")
            raise ApiAbort("quota", f"primary rate limit exhausted, resets at {when}",
                           int(reset) if reset.isdigit() else None)
        retry_after = _header(headers, "retry-after")
        if not retry_after.isdigit():
            return None                       # auth/permission 403: fail closed, never retried
        if method != "GET":
            raise ApiAbort("secondary", f"secondary rate limit on a {method} (Retry-After {retry_after}s)")
        return float(retry_after)
    if code is not None and code not in TRANSIENT_HTTP:
        return None
    if method != "GET":
        raise ApiAbort("transient", f"{method} failed with {code or 'no response'}; a write is never retried")
    return min(API_BACKOFF_CAP_S, API_BACKOFF_BASE_S * (2 ** attempt))


# Quota accounting (#quota): requests actually sent this process, memo hits, and the last
# x-ratelimit-* headers seen. Logged once per mode so each tick's REST cost is measurable from
# its log instead of estimated. Read-only bookkeeping; never consulted by any decision.
API_STATS = {"sent": 0, "memo_hits": 0, "used": "", "remaining": "", "resource": ""}


def _note_ratelimit(headers) -> None:
    for k in ("used", "remaining", "resource"):
        v = _header(headers, f"x-ratelimit-{k}")
        if v:
            API_STATS[k] = v


def api_stats_line(mode: str) -> str:
    return (f"merge-train {mode}: api requests sent={API_STATS['sent']} memo_hits={API_STATS['memo_hits']} "
            f"prefetched_heads={API_STATS.get('prefetched', 0)} "
            f"x-ratelimit-used={API_STATS['used'] or '?'} remaining={API_STATS['remaining'] or '?'} "
            f"resource={API_STATS['resource'] or '?'}")


def api(method: str, path: str, body: dict | None = None, token: str | None = None,
        graphql_read: bool = False) -> tuple[int, object]:
    """`token` overrides GH_TOKEN for this one call (only update_branch passes one). `graphql_read`
    marks a POST /graphql that is a pure query: it writes nothing, so it leaves the GET memo intact."""
    data = json.dumps(body).encode() if body is not None else None
    memo = (method == "GET" and _MEMO_SCOPE[0] > 0 and not _DECIDING[0]
            and GET_MEMO_RE.match(path) is not None)
    if method != "GET" and not (graphql_read and path == "/graphql"):
        _GET_MEMO.clear()
    elif memo and path in _GET_MEMO:
        API_STATS["memo_hits"] += 1
        return 200, json.loads(_GET_MEMO[path])
    for attempt in range(API_RETRY_ATTEMPTS):
        req = urllib.request.Request(API + path, method=method, data=data)
        req.add_header("Accept", "application/vnd.github+json")
        req.add_header("X-GitHub-Api-Version", "2022-11-28")
        req.add_header("Authorization", f"Bearer {token or os.environ['GH_TOKEN']}")
        API_STATS["sent"] += 1
        try:
            status, raw, _h = _http_open(req, 30)
            if path != "/graphql":     # the GraphQL bucket's headers must not stand in for core's
                _note_ratelimit(_h)
            if memo and status == 200:
                _GET_MEMO[path] = raw or b"null"
            return status, json.loads(raw or b"null")
        except urllib.error.HTTPError as e:
            code, headers, text = e.code, e.headers, e.read().decode(errors="replace")[:300]
            _note_ratelimit(headers)
        except (urllib.error.URLError, ConnectionError, TimeoutError, http.client.HTTPException) as e:
            # HTTPException covers IncompleteRead: a response body cut off mid-read (run 43181889887,
            # publish died on 330268 of 356777 bytes). Same class as a reset: retried on a GET only.
            code, headers, text = None, None, f"{type(e).__name__}: {e}"
        delay = api_retry_delay(method, code, headers, attempt)
        if delay is None:
            return code, text                 # not transient: the caller decides, fail-closed as before
        if attempt + 1 >= API_RETRY_ATTEMPTS or _api_slept[0] + delay > API_RETRY_BUDGET_S:
            raise ApiAbort("transient", f"{method} {path} -> {code or 'no response'} after {attempt + 1} attempt(s)")
        log(f"::notice::{method} {path} -> {code or 'no response'}: retry {attempt + 1} in {delay:.0f}s")
        _api_sleep(delay)
        _api_slept[0] += delay
    raise ApiAbort("transient", f"{method} {path}: retries exhausted")   # unreachable: the loop returns or raises


def get(path: str) -> object:
    code, data = api("GET", path)
    if code != 200:
        raise SystemExit(f"::error::GET {path} -> {code}: {data}")
    return data


PREFETCH_BATCH = 8        # 20 heads per query hit RESOURCE_LIMITS_EXCEEDED on 2026-11-14; 8 answered 24/24
PREFETCH_PAGE_ROUNDS = 5  # follow-up rounds for a check suite with more than 100 runs (Services CI's matrix)
_RUN_FIELDS = "databaseId name status conclusion detailsUrl url startedAt completedAt"
PREFETCH_FRAGMENT = """fragment H on Commit {
  oid
  checkSuites(first: 100) {
    pageInfo { hasNextPage }
    nodes {
      id
      app { slug }
      checkRuns(first: 100, filterBy: {checkType: LATEST}) {
        pageInfo { hasNextPage endCursor }
        nodes { %s }
      }
    }
  }
  status { state contexts { context state description targetUrl createdAt creator { login } } }
}""" % _RUN_FIELDS
PREFETCH_MORE = ('p%d: node(id: %s) { ... on CheckSuite { checkRuns(first: 100, after: %s, '
                 'filterBy: {checkType: LATEST}) { pageInfo { hasNextPage endCursor } nodes { ' + _RUN_FIELDS + ' } } } }')


def _rest_run(r, sha: str, slug) -> dict | None:
    if not isinstance(r, dict) or type(r.get("databaseId")) is not int or not r.get("name"):
        return None
    return {"id": r["databaseId"], "name": r["name"], "head_sha": sha,
            "status": str(r.get("status") or "").lower(),
            "conclusion": str(r["conclusion"]).lower() if r.get("conclusion") else None,
            "details_url": r.get("detailsUrl"), "html_url": r.get("url"),
            "started_at": r.get("startedAt"), "completed_at": r.get("completedAt"),
            "app": {"slug": slug}}


def prefetch_payloads(node, sha: str, extra: dict | None = None) -> tuple[list[dict], dict] | None:
    """GraphQL Commit -> (REST check_runs, REST combined status), or None when it is not COMPLETE.
    `extra` maps a suite id to the runs its follow-up pages returned; a suite still marked as having
    a further page without them is incomplete, and so is the head."""
    if not isinstance(node, dict) or node.get("oid") != sha:
        return None
    suites = node.get("checkSuites") or {}
    if (suites.get("pageInfo") or {}).get("hasNextPage") is not False:
        return None
    runs: list[dict] = []
    for suite in suites.get("nodes") or []:
        cr = (suite or {}).get("checkRuns") or {}
        nodes = list(cr.get("nodes") or [])
        if (cr.get("pageInfo") or {}).get("hasNextPage") is not False:
            more = (extra or {}).get((suite or {}).get("id"))
            if more is None:
                return None
            nodes += more
        slug = ((suite or {}).get("app") or {}).get("slug")
        for r in nodes:
            rr = _rest_run(r, sha, slug)
            if rr is None:
                return None
            runs.append(rr)
    st = node.get("status")
    contexts = (st or {}).get("contexts") or []
    if len(contexts) > 30:
        return None   # the REST combined status returns 30; keep exactly what it would have shown
    statuses = [{"id": len(contexts) - k, "context": c.get("context"), "state": str(c.get("state") or "").lower(),
                 "description": c.get("description"), "target_url": c.get("targetUrl"),
                 "created_at": c.get("createdAt"), "creator": {"login": (c.get("creator") or {}).get("login")}}
                for k, c in enumerate(contexts) if isinstance(c, dict) and c.get("context")]
    if len(statuses) != len(contexts):
        return None
    return runs, {"state": str((st or {}).get("state") or "pending").lower(), "sha": sha,
                  "total_count": len(statuses), "statuses": statuses}


def rest_pages(runs: list[dict]) -> list[list[dict]]:
    """The REST check-runs pages `paginate` reads (100 each, a short page last; every consumer
    aggregates over all pages, so order within the set does not change any verdict)."""
    pages = [runs[i:i + 100] for i in range(0, len(runs), 100)]
    if not pages or len(pages[-1]) == 100:
        pages.append([])
    return pages


def paginate(path: str, key: str | None = None) -> list:
    out: list = []
    page = 1
    sep = "&" if "?" in path else "?"
    while True:
        data = get(f"{path}{sep}per_page=100&page={page}")
        items = data[key] if key else data
        out += items
        if len(items) < 100:
            return out
        page += 1


def ruleset_guard(rules, app_id) -> str | None:
    """Why settle must NOT merge yet, or None when the ruleset says the train owns merging (ADR-0343 phase 1).

    Both must hold: `merge-train` is a required context pinned to THIS App's integration id (so no other
    actor's status can satisfy it), and strict up-to-date is off on every rule that carries it. Anything
    unreadable or unparseable refuses: the guard fails closed."""
    try:
        want = int(str(app_id).strip())
    except (TypeError, ValueError):
        return "GITOPS_APP_ID is not an integer, cannot verify the pin"
    pinned, strict = False, False
    for r in rules if isinstance(rules, list) else []:
        if not isinstance(r, dict) or r.get("type") != "required_status_checks":
            continue
        params = r.get("parameters") or {}
        strict = strict or bool(params.get("strict_required_status_checks_policy"))
        pinned = pinned or any(isinstance(c, dict) and c.get("context") == STATUS_CONTEXT and c.get("integration_id") == want
                               for c in params.get("required_status_checks") or [])
    if not pinned:
        return f"ruleset does not require `{STATUS_CONTEXT}` pinned to integration {want}"
    if strict:
        return "strict up-to-date is still on"
    return None


def owner_approval_error(repo: str, number: int, head: str, decision: str,
                         env: dict, metadata: dict, pr: dict) -> str | None:
    """Fail closed before writing a decision; the workflow performs the same actor checks pre-token."""
    owner = metadata.get("owner") or {}
    if (metadata.get("full_name") != repo or owner.get("type") != "User"
            or env.get("GITHUB_REPOSITORY") != repo
            or env.get("GITHUB_EVENT_NAME") != "workflow_dispatch"
            or env.get("GITHUB_REF") != "refs/heads/main"
            or env.get("GITHUB_RUN_ATTEMPT") != "1"
            or env.get("GITHUB_ACTOR") != owner.get("login")
            or env.get("GITHUB_TRIGGERING_ACTOR") != owner.get("login")
            or env.get("GITHUB_ACTOR_ID") != str(owner.get("id"))):
        return "only a first-attempt main dispatch by the live User repository owner may decide"
    if type(number) is not int or number < 1 or not isinstance(head, str) or not SHA_RE.fullmatch(head) or decision not in ("approve", "revoke"):
        return "invalid PR number, full head SHA or decision"
    target, base = pr.get("head") or {}, pr.get("base") or {}
    if (pr.get("number") != number
            or (decision == "approve" and (pr.get("state") != "open" or pr.get("draft")))
            or target.get("sha") != head or (target.get("repo") or {}).get("full_name") != repo
            or base.get("ref") != "main" or (base.get("repo") or {}).get("full_name") != repo
            or not any((target.get("ref") or "").startswith(pre) for pre in EXCLUDED_BRANCH_PREFIXES)):
        return "decision requires an open, non-draft, same-repository codex PR to main at the supplied head"
    return None


def owner_status_line(statuses: list) -> str | None:
    """Newest owner-approval status created by the App itself (login AND id); anyone else's is ignored.
    The description is attacker-influenceable text on a shared summary, so strip all but plain
    printable ASCII (no markdown/HTML metacharacters) and truncate."""
    mine = [st for st in statuses if st.get("context") == OWNER_APPROVAL_CONTEXT
            and (st.get("creator") or {}).get("login") == BOT_LOGIN and (st.get("creator") or {}).get("id") == BOT_ID]
    if not mine:
        return None
    st = max(mine, key=lambda x: x["id"])
    desc = re.sub(r"[^A-Za-z0-9 #:._-]", "", str(st.get("description") or ""))[:80]
    return f"state={re.sub(r'[^a-z_]', '', str(st.get('state')))[:20]} description={desc}"


def mode_owner_approval(gh, number: int, head: str, decision: str) -> None:
    metadata = get(f"/repos/{gh.repo}")
    pr = gh.pr(number)
    error = owner_approval_error(gh.repo, number, head, decision, os.environ, metadata, pr)
    if error:
        raise SystemExit(f"::error::{error}")
    state = "success" if decision == "approve" else "failure"
    description = f"owner-{'approved' if decision == 'approve' else 'revoked'} PR #{number}"
    # This is a decision record, never a CI verdict or the required merge-train context.
    gh.post_status(head, state, description, context=OWNER_APPROVAL_CONTEXT)
    log(f"owner decision: {decision} PR #{number} at {head}")


LINKED_ISSUES_QUERY = ("query($owner:String!,$name:String!,$n:Int!){repository(owner:$owner,name:$name){"
                       "pullRequest(number:$n){closingIssuesReferences(first:50){nodes{number state "
                       "repository{nameWithOwner}}}}}}")


def close_linked_issues(repo: str, n: int, sha: str) -> list[int]:
    """Close the issues PR `n` links with `Closes #N` (#14510). GitHub records the link but emits no
    close when an App merges, so the train does it. Same-repository, still-OPEN issues only (so a
    re-run is a no-op); every failure is logged and swallowed — the merge already happened and must
    never be reported as failed because of this. Returns the issue numbers it closed."""
    closed: list[int] = []
    try:
        owner, name = repo.split("/", 1)
        code, data = api("POST", "/graphql", {"query": LINKED_ISSUES_QUERY,
                                              "variables": {"owner": owner, "name": name, "n": int(n)}})
        nodes = (((((data or {}).get("data") or {}).get("repository") or {}).get("pullRequest") or {})
                 .get("closingIssuesReferences") or {}).get("nodes") if code == 200 and isinstance(data, dict) else None
        if nodes is None:
            log(f"::warning::#{n}: could not read linked issues ({code}); none closed")
            return closed
        for node in nodes:
            if not isinstance(node, dict) or node.get("state") != "OPEN":
                continue
            if (node.get("repository") or {}).get("nameWithOwner") != repo or type(node.get("number")) is not int:
                continue
            i = node["number"]
            try:
                c, _ = api("POST", f"/repos/{repo}/issues/{i}/comments",
                           {"body": f"Closed by #{int(n)} ({sha}) — merged by the merge train."})
                if c != 201:
                    log(f"::warning::#{n}: comment on issue #{i} -> {c} (needs issues:write); not closed")
                    continue
                c, _ = api("PATCH", f"/repos/{repo}/issues/{i}", {"state": "closed", "state_reason": "completed"})
                if c == 200:
                    closed.append(i)
                    log(f"#{n}: closed linked issue #{i}")
                else:
                    log(f"::warning::#{n}: close issue #{i} -> {c} (needs issues:write)")
            except Exception as e:  # noqa: BLE001 — never fail the merge job over an issue
                log(f"::warning::#{n}: closing issue #{i} failed: {type(e).__name__}: {e}")
    except Exception as e:  # noqa: BLE001
        log(f"::warning::#{n}: linked-issue close skipped: {type(e).__name__}: {e}")
    return closed


class GitHub:
    """Every GitHub read and write. The self-test substitutes a fake with the same methods."""

    def __init__(self, repo: str, branch: str, run_url: str):
        self.repo, self.branch, self.run_url = repo, branch, run_url
        self.remote = f"https://github.com/{repo}.git"

    def head_refspec(self, n: int) -> str:
        return f"refs/pull/{int(n)}/head"

    def required(self) -> list[str]:
        ctx: list[str] = []
        for r in get(f"/repos/{self.repo}/rules/branches/{self.branch}"):
            if r.get("type") == "required_status_checks":
                ctx += [c["context"] for c in r["parameters"]["required_status_checks"]]
        return sorted(set(ctx))

    def merge_guard(self) -> str | None:
        code, data = api("GET", f"/repos/{self.repo}/rules/branches/{self.branch}")
        if code != 200:
            return f"cannot read the ruleset ({code})"
        return ruleset_guard(data, os.environ.get("GITOPS_APP_ID", ""))

    def main_sha(self) -> str:
        return get(f"/repos/{self.repo}/git/ref/heads/{self.branch}")["object"]["sha"]

    def open_prs(self) -> list[dict]:
        prs = paginate(f"/repos/{self.repo}/pulls?state=open&base={self.branch}")
        if _MEMO_SCOPE[0] > 0 and not _DECIDING[0]:
            try:
                self.prefetch_checks([((p.get("head") or {}).get("sha") or "") for p in prs])
            except Exception as exc:  # noqa: BLE001 - an optimisation: any failure means "read via REST"
                log(f"::notice::check prefetch failed ({type(exc).__name__}); planning reads fall back to REST")
        return prs

    def prefetch_checks(self, shas: list[str]) -> int:
        """Planning only: read every head's check runs and combined status in GraphQL batches and seed the
        GET memo with the exact REST payloads `checks()`, `ci_activity()` and `extra_checks()` would read.

        Quota: `plan_train` walks every open PR and read `/check-runs` + `/status` per head — two REST
        calls per PR from the GITHUB_TOKEN core quota every workflow shares (the build job sent ~180
        requests a run, 2026-11-14). One GraphQL query covers PREFETCH_BATCH heads and is charged to the
        separate GraphQL bucket. Safety: the memo only serves planning reads; every write's verdict is
        re-read live under deciding() (`unverified`), so a seeded payload can at worst mis-PLAN a tick,
        never decide a merge. A head is seeded only when GraphQL saw ALL of it (no further page, fewer
        than 100 runs, at most 30 statuses — what the REST pages hold); anything else falls back to REST."""
        # open_prs() is called from many places in one tick; a head already seeded in this planning
        # scope is not read again (the memo is cleared on exit and by every write, so this never
        # outlives the data it describes).
        shas = sorted({s for s in shas if re.fullmatch(r"[0-9a-f]{40}", s or "")
                       and f"/repos/{self.repo}/commits/{s}/status" not in _GET_MEMO})
        owner, name = self.repo.split("/", 1)
        seeded = 0
        for i in range(0, len(shas), PREFETCH_BATCH):
            chunk = shas[i:i + PREFETCH_BATCH]
            fields = " ".join(f'c{j}: object(oid: "{sha}") {{ ...H }}' for j, sha in enumerate(chunk))
            query = (f"query($owner: String!, $name: String!) {{ repository(owner: $owner, name: $name) "
                     f"{{ {fields} }} }} {PREFETCH_FRAGMENT}")
            try:
                code, data = api("POST", "/graphql", {"query": query, "variables": {"owner": owner, "name": name}},
                                 graphql_read=True)
            except ApiAbort:
                return seeded
            repo_data = (((data or {}).get("data") or {}).get("repository") or None) \
                if code == 200 and isinstance(data, dict) else None
            if repo_data is None:
                log(f"::notice::check prefetch unavailable ({code}); planning reads fall back to REST")
                return seeded
            # A partial answer (e.g. RESOURCE_LIMITS_EXCEEDED under one alias) names the alias in each
            # error's path: only those heads fall back to REST, the rest of the batch is still complete.
            errors = data.get("errors") or []
            broken = {e["path"][1] for e in errors if isinstance(e, dict) and len(e.get("path") or []) > 1}
            if errors and not broken:
                log("::notice::check prefetch returned unattributed errors; planning reads fall back to REST")
                return seeded
            nodes = {j: repo_data.get(f"c{j}") for j in range(len(chunk)) if f"c{j}" not in broken}
            extra = self._prefetch_more_pages(owner, name, nodes)
            for j, node in nodes.items():
                sha = chunk[j]
                payloads = prefetch_payloads(node, sha, extra)
                if payloads is None:
                    continue
                runs, status = payloads
                base_path = f"/repos/{self.repo}/commits/{sha}/check-runs"
                total = len(runs)
                for k, page in enumerate(rest_pages(runs), 1):
                    _GET_MEMO[f"{base_path}?per_page=100&page={k}"] = \
                        json.dumps({"total_count": total, "check_runs": page}).encode()
                _GET_MEMO[f"/repos/{self.repo}/commits/{sha}/status"] = json.dumps(status).encode()
                seeded += 1
        API_STATS["prefetched"] = API_STATS.get("prefetched", 0) + seeded
        return seeded

    def _prefetch_more_pages(self, owner: str, name: str, nodes: dict) -> dict:
        """suite id -> its runs after the first 100, read in batched GraphQL follow-ups. A suite that does
        not finish within PREFETCH_PAGE_ROUNDS stays absent, which makes its head fall back to REST."""
        pending: dict[str, str] = {}
        for node in nodes.values():
            for suite in (((node or {}).get("checkSuites") or {}).get("nodes") or []):
                info = ((suite or {}).get("checkRuns") or {}).get("pageInfo") or {}
                if info.get("hasNextPage") and suite.get("id") and info.get("endCursor"):
                    pending[suite["id"]] = info["endCursor"]
        got: dict[str, list] = {}
        done: dict[str, list] = {}
        for _ in range(PREFETCH_PAGE_ROUNDS):
            if not pending:
                break
            items = list(pending.items())
            pending = {}
            for i in range(0, len(items), PREFETCH_BATCH):
                chunk = items[i:i + PREFETCH_BATCH]
                fields = " ".join(PREFETCH_MORE % (k, json.dumps(sid), json.dumps(cur)) for k, (sid, cur) in enumerate(chunk))
                try:
                    code, data = api("POST", "/graphql", {"query": f"query {{ {fields} }}"}, graphql_read=True)
                except ApiAbort:
                    return done
                if code != 200 or not isinstance(data, dict) or data.get("errors"):
                    continue          # these suites stay incomplete: their heads fall back to REST
                for k, (sid, _cur) in enumerate(chunk):
                    cr = ((((data.get("data") or {}).get(f"p{k}")) or {}).get("checkRuns")) or {}
                    info = cr.get("pageInfo") or {}
                    got.setdefault(sid, []).extend(cr.get("nodes") or [])
                    if info.get("hasNextPage") is False:
                        done[sid] = got[sid]
                    elif info.get("hasNextPage") and info.get("endCursor"):
                        pending[sid] = info["endCursor"]
        return done

    def pr(self, n: int) -> dict:
        return get(f"/repos/{self.repo}/pulls/{int(n)}")

    def checks(self, sha: str) -> dict[str, str | None]:
        latest: dict[str, dict] = {}
        for check in paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"):
            if check["name"] not in latest or check["id"] > latest[check["name"]]["id"]:
                latest[check["name"]] = check
        out = {name: (c["conclusion"] if c["status"] == "completed" else None) for name, c in latest.items()}
        for st in sorted(get(f"/repos/{self.repo}/commits/{sha}/status")["statuses"], key=lambda s: s["id"], reverse=True):
            out.setdefault(st["context"], None if st["state"] == "pending" else st["state"])
        return out

    def ci_activity(self, sha: str) -> float | None:
        """Newest CI activity on `sha` (epoch) or None: see latest_ci_activity. The workflow-runs read is
        made only when the check-run stamps are already stale, so a live head costs no extra call."""
        return latest_ci_activity(
            paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"),
            lambda: [r for r in paginate(f"/repos/{self.repo}/actions/runs?head_sha={sha}", "workflow_runs")
                     if r.get("head_sha", sha) == sha],
            time.time())

    def extra_checks(self, sha: str, gates: dict[str, str]) -> dict[str, str | None]:
        """Pinned extra-gate verdicts on `sha`: only check runs by the `github-actions` app whose workflow
        run's path is the declared workflow. Any completed non-success, non-skipped run = that state (red
        wins over every later green); else running = None; else success/skipped. No pinned check run:
        "skipped" (not applicable) ONLY when the pinned workflow has a run for `sha` and every such run
        completed with conclusion success; "failure" when one failed; None (pending) when one ended
        cancelled/timed_out/startup_failure/action_required; absent while none has completed — every
        caller holds absent and None as pending (fail closed, #13400)."""
        runs: dict[str, list[str | None]] = {}
        for check in paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"):
            name = check.get("name")
            if name not in gates or (check.get("app") or {}).get("slug") != "github-actions":
                continue
            m = re.search(r"/actions/runs/([0-9]+)/job", check.get("details_url") or check.get("html_url") or "")
            if not m:
                continue
            path = self._run_path(int(m.group(1)))
            if path.split("@", 1)[0] != gates[name]:
                continue
            runs.setdefault(name, []).append(check["conclusion"] if check["status"] == "completed" else None)
        out = {name: extra_verdict(states) for name, states in runs.items()}
        missing = [n for n in gates if n not in out]
        if missing:
            wruns = paginate(f"/repos/{self.repo}/actions/runs?head_sha={sha}", "workflow_runs")
            for name in missing:
                pinned = [r for r in wruns if r.get("head_sha", sha) == sha
                          and (r.get("path") or "").split("@", 1)[0] == gates[name]]
                if not pinned or any(r.get("status") != "completed" for r in pinned):
                    continue   # absent: no completed pinned run yet — pending (fail closed)
                concl = [r.get("conclusion") for r in pinned]
                # #13400: n/a ONLY when every pinned run SUCCEEDED. A failed run is red; any other
                # conclusion (cancelled, timed_out, startup_failure, action_required, ...) proves
                # nothing — pending, never served.
                out[name] = ("failure" if "failure" in concl
                             else "skipped" if all(c == "success" for c in concl) else None)
        return out

    def _run_path(self, run_id: int) -> str:
        cache = self.__dict__.setdefault("_paths", {})
        if run_id not in cache:
            cache[run_id] = (get(f"/repos/{self.repo}/actions/runs/{run_id}") or {}).get("path") or ""
        return cache[run_id]

    def app_statuses(self, sha: str) -> dict[str, tuple[str, str]]:
        """The App's own latest status per context on `sha` — statuses by anyone else are ignored."""
        out: dict[str, tuple[str, str]] = {}
        for st in sorted(paginate(f"/repos/{self.repo}/commits/{sha}/statuses"), key=lambda s: s["id"], reverse=True):
            if (st.get("creator") or {}).get("login") == BOT_LOGIN:
                out.setdefault(st["context"], (st["state"], st.get("description") or ""))
        return out

    def app_status_latest(self, sha: str, context: str) -> tuple[int, str, str] | None:
        """(id, state, description) of the App's latest `context` status on `sha`; ids order globally."""
        rows = [st for st in paginate(f"/repos/{self.repo}/commits/{sha}/statuses")
                if (st.get("creator") or {}).get("login") == BOT_LOGIN and st.get("context") == context
                and type(st.get("id")) is int]
        if not rows:
            return None
        st = max(rows, key=lambda r: r["id"])
        return st["id"], st["state"], st.get("description") or ""

    def unverified(self, sha: str, guard: bool) -> str | None:
        """Why a write acting on `sha`'s verdict must NOT happen, re-read live (deciding): the ruleset —
        and, when `guard`, the merge guard on it — and every required context but `merge-train` itself
        must be green on the exact head NOW. None = verified."""
        with deciding():
            code, rules = api("GET", f"/repos/{self.repo}/rules/branches/{self.branch}")
            if code != 200 or not isinstance(rules, list):
                return f"cannot re-read the ruleset ({code})"
            if guard:
                why = ruleset_guard(rules, os.environ.get("GITOPS_APP_ID", ""))
                if why:
                    return f"merge guard: {why}"
            required = sorted({c["context"] for r in rules if r.get("type") == "required_status_checks"
                               for c in r["parameters"]["required_status_checks"]})
            checks = self.checks(sha)
        bad = [c for c in required if c != STATUS_CONTEXT and checks.get(c) != "success"]
        return f"required context(s) not green on the head now: {', '.join(bad)}" if bad else None

    def post_status(self, sha: str, state: str, description: str, context: str = STATUS_CONTEXT,
                    *, source_number: int | None = None) -> None:
        if not SHA_RE.fullmatch(sha):
            raise SystemExit(f"::error::refusing a status on non-sha {sha!r}")
        if state == "success" and context == STATUS_CONTEXT:
            if type(source_number) is not int or source_number <= 0:
                raise SystemExit("::error::merge-train success requires a source PR number")
            why = self.unverified(sha, guard=False)
            if why:
                log(f"::warning::no merge-train success on {sha[:12]}: {why}")
                return
            # A success status can release native auto-merge before our explicit merge call.
            if not live_source_intent(self, source_number, sha):
                log(f"::notice::#{source_number} source intent changed — no merge-train success")
                return
        code, data = api("POST", f"/repos/{self.repo}/statuses/{sha}",
                         {"state": state, "context": context, "description": description[:140], "target_url": self.run_url})
        if code != 201:
            raise SystemExit(f"::error::POST status on {sha} -> {code}: {data}")

    def comment(self, n: int, text: str) -> None:
        api("POST", f"/repos/{self.repo}/issues/{int(n)}/comments", {"body": f"{COMMENT_MARK}\n{text}\n\n{self.run_url}"})

    def merge(self, n: int, head: str) -> str | None:
        """Squash-merge pinned to the verified head sha (the API's `sha` = --match-head-commit)."""
        why = self.unverified(head, guard=True)   # live verdict and ruleset (cache safety)
        if why:
            log(f"::warning::#{n} not merged: {why}")
            return None
        if not live_source_intent(self, n, head):  # last read, after potentially slow verdict reads
            log(f"::notice::#{n} source intent or head changed — not merged")
            return None
        code, data = api("PUT", f"/repos/{self.repo}/pulls/{int(n)}/merge", {"merge_method": "squash", "sha": head})
        sha = data.get("sha") if code == 200 and isinstance(data, dict) and data.get("merged") else None
        if sha:
            close_linked_issues(self.repo, n, sha)
        return sha

    def rerun_inconclusive(self, sha: str, contexts: list[str]) -> bool:
        """Retry once per run, including CI's attempt-bound evidence ancestor. The caller keeps the
        carrier's one-retry budget; a refused/uncertain write never triggers another scope of retry."""
        latest: dict[str, dict] = {}
        for check in paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"):
            if check["name"] in contexts and (check["name"] not in latest or check["id"] > latest[check["name"]]["id"]):
                latest[check["name"]] = check
        if set(latest) != set(contexts):
            return False
        runs = set()
        for check in latest.values():
            m = re.search(r"/actions/runs/([0-9]+)/job", check.get("details_url") or check.get("html_url") or "")
            if not m:
                return False
            runs.add(int(m.group(1)))
        if not runs:
            return False
        plans = []
        for run in sorted(runs):
            path = f"/repos/{self.repo}/actions/runs/{run}"
            code, info = api("GET", path)
            if (code != 200 or not isinstance(info, dict) or info.get("head_sha") != sha
                    or info.get("status") != "completed" or type(info.get("run_attempt")) is not int
                    or info["run_attempt"] < 1 or not isinstance(info.get("path"), str)):
                return False
            workflow = info["path"].split("@", 1)[0]
            if not re.fullmatch(r"\.github/workflows/[^/]+\.ya?ml", workflow):
                return False
            retry = path + "/rerun-failed-jobs"
            if workflow == ".github/workflows/ci.yml":
                attempt = info["run_attempt"]
                jobs = paginate(path + "/jobs?filter=latest", "jobs")
                # Latest results can include a successful ancestor retained from an OLD attempt.
                # Such a job cannot be retried by id, and its snapshot cannot authorize a new one.
                conclusions = {"success", "skipped", "neutral", "failure", "cancelled", "timed_out",
                               "action_required", "stale", "startup_failure"}
                if not jobs or any(not isinstance(j, dict) or type(j.get("id")) is not int or j["id"] < 1
                                   or j.get("run_id") != run or not isinstance(j.get("name"), str)
                                   or j.get("status") != "completed" or j.get("conclusion") not in conclusions
                                   or type(j.get("run_attempt")) is not int or not 1 <= j["run_attempt"] <= attempt
                                   for j in jobs):
                    return False
                receiver_name = "Receive trusted ruleset evidence"
                receivers = [j for j in jobs if j["name"] == receiver_name]
                if len(receivers) > 1:
                    return False
                failed = [j for j in jobs if j["conclusion"] not in {"success", "skipped", "neutral"}]
                descendants_only = all(j["name"] in {receiver_name, GATE_AGGREGATE_JOB}
                                       or GATE_SHARD_JOB_RE.fullmatch(j["name"]) for j in failed)
                if receivers and receivers[0]["run_attempt"] == attempt and descendants_only:
                    # GitHub reruns this job AND its dependents in one attempt. Never retry a gate
                    # first and then the receiver: that creates yet another attempt boundary.
                    retry = f"/repos/{self.repo}/actions/jobs/{receivers[0]['id']}/rerun"
                else:
                    # Full CI is necessary when the receiver is inherited or another failed job
                    # is outside its dependency closure. The separate Services CI is untouched.
                    retry = path + "/rerun"
            plans.append(retry)
        # Finish every read before the first mutation. api() never retries an uncertain POST;
        # no failed-only/full-run fallback is permitted after a refused receiver request either.
        return all(api("POST", path, {})[0] == 201 for path in plans)

    def ctx_jobs(self, sha: str, ctx: str) -> dict[str, str | None] | None:
        """Latest-attempt jobs of the workflow run whose check run is `ctx` on `sha`: job name ->
        conclusion (None while running). None when `ctx` is no Actions check run on `sha` (a commit
        status, another app) or the job list is unreadable: no job evidence, never an empty pass."""
        latest = None
        for check in paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"):
            if check.get("name") == ctx and (latest is None or check["id"] > latest["id"]):
                latest = check
        if latest is None:
            return None
        m = re.search(r"/actions/runs/([0-9]+)/job", latest.get("details_url") or latest.get("html_url") or "")
        if not m:
            return None
        out: dict[str, str | None] = {}
        for j in paginate(f"/repos/{self.repo}/actions/runs/{m.group(1)}/jobs?filter=latest", "jobs"):
            name = j.get("name") if isinstance(j, dict) else None
            if not isinstance(name, str):
                return None
            v = j.get("conclusion") if j.get("status") == "completed" else None
            out[name] = v if out.get(name, v) == v else None   # two jobs, one name, disagreeing: not green
        return out or None

    def workflow_run(self, run_id: int) -> dict | None:
        """The Actions run object (path, head_sha, head_branch), or None when unreadable (callers fail closed)."""
        code, data = api("GET", f"/repos/{self.repo}/actions/runs/{int(run_id)}")
        return data if code == 200 and isinstance(data, dict) else None

    def compare_commits(self, base: str, head: str) -> list[dict] | None:
        """The commits of base...head as {sha, author, committer, verified, date, parents}; None when
        unreadable or truncated (the compare API lists at most 250)."""
        code, data = api("GET", f"/repos/{self.repo}/compare/{base}...{head}")
        if code != 200 or not isinstance(data, dict) or not isinstance(data.get("commits"), list):
            return None
        cs = data["commits"]
        if data.get("total_commits") != len(cs):
            return None
        return [{"sha": c.get("sha"), "author": (c.get("author") or {}).get("login"),
                 "committer": (c.get("committer") or {}).get("login"),
                 "verified": ((c.get("commit") or {}).get("verification") or {}).get("verified"),
                 "date": ((c.get("commit") or {}).get("committer") or {}).get("date"),
                 "parents": len(c.get("parents") or [])} for c in cs if isinstance(c, dict)]

    def run_jobs(self, run_id: int) -> dict[str, str | None] | None:
        """Latest-attempt job name -> conclusion (None while running) of run `run_id`; None when unreadable
        or two jobs of one name disagree being indistinguishable is folded to None like ctx_jobs."""
        out: dict[str, str | None] = {}
        for j in paginate(f"/repos/{self.repo}/actions/runs/{int(run_id)}/jobs?filter=latest", "jobs"):
            name = j.get("name") if isinstance(j, dict) else None
            if not isinstance(name, str):
                return None
            v = j.get("conclusion") if j.get("status") == "completed" else None
            out[name] = v if out.get(name, v) == v else None
        return out or None

    def failures_inconclusive(self, sha: str, failing: list[str]) -> tuple[bool, str]:
        """Whether the carrier's failing contexts failed ONLY for inconclusive gate kinds (budget overrun,
        NOT EVALUATED), from the gate runner's own --json artifacts — never from the log. Any read that
        does not succeed answers False: today's conclusive verdict, never a silent pass."""
        latest: dict[str, dict] = {}
        for check in paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"):
            if check["name"] in failing and (check["name"] not in latest or check["id"] > latest[check["name"]]["id"]):
                latest[check["name"]] = check
        if set(latest) != set(failing):
            return False, "a failing context is not a check run"
        runs = set()
        for check in latest.values():
            m = re.search(r"/actions/runs/([0-9]+)/job", check.get("details_url") or check.get("html_url") or "")
            if not m:
                return False, f"`{check['name']}` has no workflow run"
            runs.add(int(m.group(1)))
        why = []
        for run in sorted(runs):
            code, run_info = api("GET", f"/repos/{self.repo}/actions/runs/{run}")
            attempt = run_info.get("run_attempt") if code == 200 and isinstance(run_info, dict) else None
            if type(attempt) is not int or attempt < 1:
                return False, f"workflow run `{run}` has no current attempt"
            jobs = paginate(f"/repos/{self.repo}/actions/runs/{run}/jobs?filter=latest", "jobs")
            failed_jobs = [j for j in jobs if j.get("conclusion") not in ("success", "skipped", "neutral", None)]
            if any(j.get("run_attempt") != attempt for j in failed_jobs):
                return False, f"a failing job of run `{run}` is not from attempt {attempt}"
            failed = [j["name"] for j in failed_jobs]
            arts: dict[str, dict] = {}
            for a in paginate(f"/repos/{self.repo}/actions/runs/{run}/artifacts", "artifacts"):
                name = a.get("name") or ""
                if name.startswith(GATE_ARTIFACT_PREFIX) and not a.get("expired") and (
                        name not in arts or a["id"] > arts[name]["id"]):
                    arts[name] = a
            records: dict[str, list | None] = {}
            for job in failed:
                m = GATE_SHARD_JOB_RE.fullmatch(job)
                if m:
                    a = arts.get(f"{GATE_ARTIFACT_PREFIX}{m.group(1)}-a{attempt}")
                    records[m.group(1)] = self.artifact_json(a["id"]) if a else None
            ok, reason = gate_failures_inconclusive(failed, records)
            if not ok:
                return False, reason
            why.append(reason)
        return True, "; ".join(why)

    def artifact_json(self, artifact_id: int) -> list | None:
        """The single JSON file inside an artifact zip. The archive URL redirects to blob storage, which
        must NOT receive the GitHub token, so the redirect is followed by hand without it."""
        import io
        import zipfile

        class _NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        req = urllib.request.Request(f"{API}/repos/{self.repo}/actions/artifacts/{int(artifact_id)}/zip")
        req.add_header("Accept", "application/vnd.github+json")
        req.add_header("Authorization", f"Bearer {os.environ['GH_TOKEN']}")
        try:
            try:
                with urllib.request.build_opener(_NoRedirect).open(req, timeout=30) as r:
                    blob = r.read()
            except urllib.error.HTTPError as e:
                if e.code not in (301, 302, 303, 307, 308) or not e.headers.get("Location", "").startswith("https://"):
                    return None
                with urllib.request.urlopen(e.headers["Location"], timeout=30) as r:
                    blob = r.read()
            with zipfile.ZipFile(io.BytesIO(blob)) as z:
                names = [n for n in z.namelist() if n.endswith(".json")]
                data = json.loads(z.read(names[0])) if len(names) == 1 else None
        except (OSError, ValueError, zipfile.BadZipFile, KeyError):
            return None
        return data if isinstance(data, list) else None

    def gate_shard_records(self, sha: str, ctx: str, slugs: list[str]) -> dict[str, list | None] | None:
        """The --json records of gate shards `slugs` from the CURRENT attempt of the workflow run behind
        check run `ctx` on `sha`: slug -> records (None = that shard's artifact missing or unreadable).
        None = the run itself is unreadable (no such check run, no run id, no current attempt). Only the
        named shards' artifacts are downloaded (a few KB each); a rerun keeps attempt-1 artifacts under
        the same run id, so the artifact name carries the attempt (ci.yml `gate-results-<slug>-a<n>`)."""
        latest = None
        for check in paginate(f"/repos/{self.repo}/commits/{sha}/check-runs", "check_runs"):
            if check.get("name") == ctx and (latest is None or check["id"] > latest["id"]):
                latest = check
        if latest is None:
            return None
        m = re.search(r"/actions/runs/([0-9]+)/job", latest.get("details_url") or latest.get("html_url") or "")
        if not m:
            return None
        run = int(m.group(1))
        code, info = api("GET", f"/repos/{self.repo}/actions/runs/{run}")
        attempt = info.get("run_attempt") if code == 200 and isinstance(info, dict) else None
        if type(attempt) is not int or attempt < 1:
            return None
        arts: dict[str, dict] = {}
        for a in paginate(f"/repos/{self.repo}/actions/runs/{run}/artifacts", "artifacts"):
            name = a.get("name") or ""
            if name.startswith(GATE_ARTIFACT_PREFIX) and not a.get("expired") and (
                    name not in arts or a["id"] > arts[name]["id"]):
                arts[name] = a
        out: dict[str, list | None] = {}
        suffix = f"-a{attempt}"
        if slugs is None:   # every shard of the current attempt (a gate may have moved shard on the head)
            for name, a in sorted(arts.items()):
                if name.endswith(suffix):
                    out[name[len(GATE_ARTIFACT_PREFIX):-len(suffix)]] = self.artifact_json(a["id"])
            return out
        for slug in sorted(set(slugs)):
            a = arts.get(f"{GATE_ARTIFACT_PREFIX}{slug}{suffix}")
            out[slug] = self.artifact_json(a["id"]) if a else None
        return out

    def update_branch(self, n: int, head: str) -> bool:
        """Merge main into the PR branch, pinned to the head the strict lane judged.

        Uses UPDATE_BRANCH_TOKEN (a dedicated App holding `workflows: write`) when settle minted one: the
        GitOps App lacks that permission, so GitHub refuses with 403 whenever main changed a workflow file
        since the PR's base. Empty (mint failed / key unset) falls back to GH_TOKEN — today's behaviour."""
        override = os.environ.get("UPDATE_BRANCH_TOKEN", "")
        log(f"#{n:>6} update-branch credential: {'branch-updater App' if override else 'GH_TOKEN (GitOps App)'}")
        code, detail = api("PUT", f"/repos/{self.repo}/pulls/{int(n)}/update-branch", {"expected_head_sha": head},
                           token=override or None)
        if code != 202:
            log(f"#{n:>6} update-branch answered {code}: {json.dumps(detail)[:300]}")
        return code == 202

    def notice_since(self, sha: str) -> str | None:
        return notice_since(paginate(f"/repos/{self.repo}/commits/{sha}/statuses"))

    def stuck_issue(self) -> tuple[int | None, str | None]:
        code, data = api("GET", f"/repos/{self.repo}/issues?state=open&labels={STUCK_LABEL}&per_page=1")
        if code != 200 or not isinstance(data, list) or not data:
            return None, None
        return data[0]["number"], data[0].get("body")

    def save_stuck_issue(self, number: int | None, body: str) -> None:
        code, detail = (api("PATCH", f"/repos/{self.repo}/issues/{int(number)}", {"body": body}) if number else
                        api("POST", f"/repos/{self.repo}/issues",
                            {"title": STUCK_TITLE, "body": body, "labels": [STUCK_LABEL]}))
        if code not in (200, 201):
            log(f"::error::merge train: tracking issue not written ({code}): {json.dumps(detail)[:200]}")

    def close_stuck_issue(self, number: int) -> None:
        code, detail = api("PATCH", f"/repos/{self.repo}/issues/{int(number)}", {"state": "closed"})
        if code != 200:
            log(f"::error::merge train: tracking issue #{number} not closed ({code}): {json.dumps(detail)[:200]}")

    def create_carrier(self, branch: str, expedite: bool = False) -> int | None:
        assert_train_branch(branch)
        kind = ("strict carrier" if STRICT_TRAIN_BRANCH_RE.fullmatch(branch)
                else "expedite carrier" if expedite else "carrier")
        code, data = api("POST", f"/repos/{self.repo}/pulls", {
            "title": f"merge-train {kind} {branch}", "head": branch, "base": self.branch, "draft": True,
            "body": f"{COMMENT_MARK}\nMerge-train {kind} (ADR-0343): CI on this head verifies one "
                    f"{'strict-lane batch' if kind == 'strict carrier' else 'train'}. "
                    "Closed automatically by the next settle. Never merge this PR."})
        if code != 201:
            log(f"::warning::carrier PR not created: {code} {data}")
            return None
        api("POST", f"/repos/{self.repo}/issues/{data['number']}/labels", {"labels": [CARRIER_LABEL]})
        return int(data["number"])

    def close_carrier(self, n: int) -> None:
        api("PATCH", f"/repos/{self.repo}/pulls/{int(n)}", {"state": "closed"})

    def issue_events(self, n: int) -> list | None:
        """Every issue event of #n (who applied which label, when); None = unreadable (callers fail closed)."""
        out: list = []
        for page in range(1, 11):
            code, data = api("GET", f"/repos/{self.repo}/issues/{int(n)}/events?per_page=100&page={page}")
            if code != 200 or not isinstance(data, list):
                log(f"::warning::#{n} issue events unreadable ({code}) — not admitted as urgent")
                return None
            out += data
            if len(data) < 100:
                return out
        return None   # more than 1000 events: cannot be read whole, so it is not read at all

    def urgent_grants_today(self, day: str, owner: str, label: str = URGENT_LABEL) -> dict[int, str] | None:
        """urgent_grants over the repository's issue events for UTC `day`, newest first. Authoritative: an
        event exists the moment the label is applied (no search index), and a removed label leaves its
        `labeled` event in place. Complete once a page reaches before `day` or the stream ends; None when a
        read fails or URGENT_EVENT_PAGES pages do not reach back to `day` — the cap then admits nothing."""
        seen: list = []
        for page in range(1, URGENT_EVENT_PAGES + 1):
            code, data = api("GET", f"/repos/{self.repo}/issues/events?per_page=100&page={page}")
            if code != 200 or not isinstance(data, list):
                log(f"::warning::repository issue events unreadable ({code}) — no PR admitted as urgent")
                return None
            seen += data
            if len(data) < 100 or any((e.get("created_at") or "9")[:10] < day for e in data):
                return urgent_grants(seen, owner, day, label)
        log(f"::warning::{URGENT_EVENT_PAGES} event pages do not reach back to {day} — no PR admitted as urgent")
        return None

    def expedite_carriers_today(self, day: str) -> int | None:
        """Expedite carriers the App opened on UTC `day` (YYYY-MM-DD), open or closed, from ONE search call
        scoped to the App's own PRs created that day (a repo opens hundreds of PRs a day, so paging the PR
        list cannot reach back reliably). Every hit is re-checked: author, title prefix, day. None = the
        search answered incompletely or not at all; the caller then fails closed."""
        bot = BOT_LOGIN.removesuffix("[bot]")
        q = urllib.parse.quote(f'repo:{self.repo} is:pr author:app/{bot} created:{day} in:title "{EXPEDITE_CARRIER_TITLE}"')
        code, data = api("GET", f"/search/issues?q={q}&per_page=100")   # an outage still raises ApiAbort
        if code != 200:
            log(f"::warning::expedite daily count unreadable ({code}) — the lane stays closed")
            return None
        return count_expedite_hits(data, day)


def is_carrier(pr: dict, repo: str) -> bool:
    return ((pr.get("user") or {}).get("login") == BOT_LOGIN and TRAIN_BRANCH_RE.fullmatch(pr["head"]["ref"]) is not None
            and (pr["head"].get("repo") or {}).get("full_name") == repo)


def is_strict_carrier(pr: dict, repo: str) -> bool:
    """A strict carrier (`train/strict-<run>-<attempt>`, opened by the App): judged by settle like one
    strict PR, never by the train's build/publish path. is_carrier never matches it."""
    return ((pr.get("user") or {}).get("login") == BOT_LOGIN
            and STRICT_TRAIN_BRANCH_RE.fullmatch(pr["head"]["ref"]) is not None
            and (pr["head"].get("repo") or {}).get("full_name") == repo)


def any_carrier_open(gh, repo: str) -> bool:
    return any(is_carrier(p, repo) or is_strict_carrier(p, repo) for p in gh.open_prs())


def count_expedite_hits(data, day: str) -> int | None:
    """Expedite carriers in one /search/issues answer; None when it is not a complete answer."""
    if not isinstance(data, dict) or data.get("incomplete_results") or not isinstance(data.get("items"), list):
        return None
    items = data["items"]
    if not isinstance(data.get("total_count"), int) or data["total_count"] > len(items):
        return None   # more hits than one page holds: far over any cap, and uncounted
    return sum(1 for p in items
               if (p.get("user") or {}).get("login") == BOT_LOGIN and "pull_request" in p
               and (p.get("title") or "").startswith(EXPEDITE_CARRIER_TITLE)
               and (p.get("created_at") or "")[:10] == day)


def is_expedite_carrier(gh, p: dict) -> bool:
    """A train carrier publish marked as the expedite lane's (App status on its head)."""
    return gh.app_statuses(p["head"]["sha"]).get(EXPEDITE_CONTEXT, ("", ""))[0] == "success"


def carrier_member_numbers(git, gh, p: dict) -> set[int] | None:
    """Member PR numbers of an open train carrier, read execution-free from its own chain; None = unreadable."""
    sha, branch = p["head"]["sha"], p["head"]["ref"]
    if git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/merge-train/expedite-probe", check=False).returncode != 0:
        return None
    if git("rev-parse", "refs/merge-train/expedite-probe", check=False).stdout.strip() != sha:
        return None
    chain = parse_own_chain(git, sha)
    return None if chain is None else {n for n, _ in chain[1]}


def expedite_problem(gh, git, repo: str, n: int, cap: int, today: str | None = None) -> str | None:
    """Why the expedite lane may NOT open a carrier for #n right now; None = it may. Read from live data
    by settle (to open the window) and again by publish (never trusting settle's output). Bounds
    (ADR-0343 amendment 2026-11-13): exactly one carrier open and it is an ordinary, unstacked train
    carrier that does not already hold #n; no strict carrier; #n armed, open and carrying the label;
    fewer than `cap` expedite carriers opened today."""
    prs = gh.open_prs()
    if any(is_strict_carrier(p, repo) for p in prs):
        return "a strict carrier is open"
    carriers = [p for p in prs if is_carrier(p, repo)]
    if len(carriers) != 1:
        return f"{len(carriers)} train carrier(s) open, the lane needs exactly one to overtake"
    c = carriers[0]
    marks = gh.app_statuses(c["head"]["sha"])
    if marks.get(EXPEDITE_CONTEXT, ("", ""))[0] == "success":
        return "an expedite carrier is already open"
    if marks.get(STACK_CONTEXT, ("", ""))[0] == "success":
        return "the open carrier is stacked over a strict holder"
    pr = next((p for p in prs if p["number"] == n), None)
    if pr is None or pr.get("draft") or not pr.get("auto_merge") or not is_expedited(pr):
        return f"#{n} is not an open, armed PR carrying {EXPEDITE_LABEL}"
    members = carrier_member_numbers(git, gh, c)
    if members is None:
        return f"carrier #{c['number']}: members unreadable"
    if n in members:
        return f"#{n} already rides carrier #{c['number']}"
    day = today or time.strftime("%Y-%m-%d", time.gmtime())
    used = gh.expedite_carriers_today(day)
    if used is None:
        return "today's expedite carrier count is unreadable"
    if used >= cap:
        return f"daily cap reached ({used}/{cap} expedite carriers on {day})"
    return None


def pr_view(repo: str, p: dict, files: list[str]) -> dict:
    return {"number": p["number"], "state": p.get("state"), "draft": p.get("draft"), "auto_merge": p.get("auto_merge"),
            "same_repo": (p["head"].get("repo") or {}).get("full_name") == repo, "head_ref": p["head"]["ref"],
            "head_sha": p["head"]["sha"], "created_at": p.get("created_at", ""), "title": p.get("title", ""),
            "body": p.get("body") or "", "files": files, "author": (p.get("user") or {}).get("login"),
            "labels": [lb.get("name") if isinstance(lb, dict) else lb for lb in p.get("labels") or []]}


# Admission prerequisites judged on the PR OBJECT (#14684). `security-checklist-money-path` runs inside
# the tree-dependent `Validate manifests` context, which a body edit does not re-run: an unticked
# money-path PR sits red there, and every path that looks past a red context — fix-head masking,
# stale-red refresh (an update-branch = a full CI run), strict-lane "waiting" — could still spend CI
# or a reservation on a PR whose own gate will fail again. So the train runs the SAME gate script
# (from its own trusted checkout, never the PR's) on the body it just listed, against the verified
# head, before any lane. It can only REFUSE: a PR it passes still needs every required context
# green. Draft and issue-hygiene need nothing here — draft is filtered before fetch, and
# issue-hygiene is its own required context, re-run by GitHub on every body edit.
CHECKLIST_GATE = pathlib.Path(__file__).resolve().parent / "check-security-checklist.py"


def admission_refusal(git, base: str, view: dict, runner=None) -> str | None:
    """None = admissible. Otherwise why not. Fail closed: anything but exit 0/1 refuses."""
    head = view.get("head_sha") or ""
    if not SHA_RE.fullmatch(head) or not SHA_RE.fullmatch(base or ""):
        return "admission check: no verified head/base sha — fail closed"
    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False) as fh:
        fh.write(view.get("body") or "")   # a file, never argv: the body is attacker-controlled text
        body_file = fh.name
    cmd = [sys.executable, "-I", str(CHECKLIST_GATE), "--body-file", body_file, "--base", base,
           "--head", head, "--root", ".", "--enforce"]
    try:
        rc = (runner or (lambda c: subprocess.run(c, cwd=git.workdir, env=base_env(), capture_output=True,
                                                   text=True, timeout=120).returncode))(cmd)
    except Exception as exc:   # noqa: BLE001 — any failure to judge is a refusal
        return f"admission check could not run ({type(exc).__name__}) — fail closed"
    finally:
        with contextlib.suppress(OSError):
            os.unlink(body_file)
    if rc == 0:
        return None
    if rc == 1:
        return ("security-checklist-money-path fails on the live body — tick the checklist, then re-run "
                "Validate manifests; the train re-reads the body every tick")
    if not CHECKLIST_GATE.is_file():
        return f"admission gate missing at {CHECKLIST_GATE} — fail closed, this is a train wiring defect"
    return f"admission check exited {rc} — fail closed"


PATH_SHORTCUT_OFF = [False]   # self-test switch: True = the pre-#16955 full read path


def live_candidates(gh, git, repo: str, required: list[str], base: str, untrainable,
                    limit: int = 64, strict: list | None = None,
                    red: list | None = None, main_red: dict[str, str] | None = None,
                    cache: dict | None = None) -> tuple[list[Member], dict[int, dict]]:
    """Open PRs that qualify RIGHT NOW. Each head is fetched and must equal the API's head sha, and
    the file list is changed_paths(<base>...<verified head>) — the PR files API stops at
    3000 entries, so a long PR could hide a path there; git has no such cap."""
    member_required = [c for c in required if c != STATUS_CONTEXT]
    extra = train_extra_gates(git, base)
    if extra is None:
        return [], {}
    armed = []
    for p in order_candidates([p for p in gh.open_prs() if not is_carrier(p, repo)]):
        if p.get("auto_merge") and not p.get("draft"):
            armed.append(p)
        else:
            # Every open PR gets a decision line: a disarmed or draft PR used to be filtered out in
            # silence, so a settle log with no line for a PR could not say whether it was ever seen.
            log(f"#{p['number']:>6} skip      {'draft' if p.get('draft') else 'auto-merge not armed'}")
    def spec(p: dict) -> str:
        return f"+{gh.head_refspec(p['number'])}:refs/merge-train/pr-{p['number']}"
    batch = git("fetch", "-q", "origin", *[spec(p) for p in armed], check=False) if armed else None
    if batch is not None and batch.returncode != 0:
        # One unfetchable head (GitHub sometimes never creates refs/pull/<n>/head) fails the whole
        # batch. Ask the remote which refs exist — ls-remote runs no PR code. Fail-closed on every
        # other outcome: rc 2 is the only "no such ref" answer; any other rc (network, auth) raises,
        # and a batch failure with no ref found absent re-raises the fetch error, so an outage can
        # never read as an empty candidate list.
        fetchable, absent = [], 0
        for p in armed:
            ref = gh.head_refspec(p["number"])
            probe = git("ls-remote", "--exit-code", "origin", ref, check=False)
            if probe.returncode == 0:
                fetchable.append(p)
            elif probe.returncode == 2:
                absent += 1
                log(f"#{p['number']:>6} skip      head ref {ref} not fetchable — waits for a push")
            else:
                raise subprocess.CalledProcessError(probe.returncode, ["git", "ls-remote", "origin", ref],
                                                    probe.stdout, probe.stderr)
        if not absent:
            raise subprocess.CalledProcessError(batch.returncode, ["git", "fetch", "origin", "<armed heads>"],
                                                batch.stdout, batch.stderr)
        armed = fetchable
        if armed:
            git("fetch", "-q", "origin", *[spec(p) for p in armed])
    out: list[Member] = []
    apps: dict[int, dict] = {}
    for p in armed:
        n = p["number"]
        fetched = git("rev-parse", "--verify", "--quiet", f"refs/merge-train/pr-{n}", check=False).stdout.strip()
        if fetched != p["head"]["sha"]:
            log(f"#{n:>6} skip      fetched head differs from the API head (pushed meanwhile)")
            continue
        # The ordinary candidate list is capped, but stale-red refresh must still inspect every
        # armed PR. Once full, check only the verified head's required statuses: no diff, app-status,
        # or strict-lane work is needed to decide whether it is red and belongs in the refresh queue.
        if len(out) >= limit and red is not None:
            view = pr_view(repo, p, [])
            failing = stale_red_candidate(view, member_required, pinned_checks(gh, fetched, extra))
            if failing:
                red.append((view, failing))
            continue
        entries = changed_entries(git, f"{base}...{fetched}")
        files = changed_paths(git, f"{base}...{fetched}")
        view = pr_view(repo, p, files)
        view["special_paths"] = [x for c in entries if c.new_mode in SPECIAL_MODES for x in c.paths]
        if GATES_YAML in files:
            fork = git("merge-base", base, fetched, check=False).stdout.strip()
            why_not = gates_append_at(git, fork, fetched, base) if fork else "no merge base"
            view["gates_append"] = why_not is None
            if why_not:
                log(f"#{p['number']:>6} gates.yaml not a pure append ({why_not}) — strict lane")
        if strict is None and red is None and not PATH_SHORTCUT_OFF[0]:
            # build/publish (#16955): only `ok` is consumed here, and qualifies() refuses on the diff
            # alone whatever the API says, so the statuses, approval chain, admission subprocess and
            # check-runs (~16 requests, ~7 s per PR live) cannot change this PR's verdict. settle
            # passes strict/red — a manual-lane PR may still be a strict-lane or stale-red entry there.
            pwhy = path_refusal(view, untrainable or FAIL_CLOSED_UNTRAINABLE)
            if pwhy:
                log(f"#{n:>6} skip      {pwhy}")
                continue
        app = gh.app_statuses(fetched)
        if any(p["head"]["ref"].startswith(pre) for pre in EXCLUDED_BRANCH_PREFIXES):
            chain = remember_approval_chain(gh, git, base, fetched)
            if len(chain) > 1:   # an exact-head decision is already in `app`: no extra read
                app = with_owner_decision(gh, app, chain)
        view["app"] = app                    # strict_lane reads the notice from it, no second read
        refusal = admission_refusal(git, base, view)
        if refusal:
            # Before every lane AND the stale-red queue: no batch, no reservation, no update-branch.
            log(f"#{n:>6} skip      {refusal}")
            continue
        checks = pinned_checks(gh, fetched, extra)
        ok, why = qualifies(view, member_required, checks, app, untrainable, extra=extra)
        log(f"#{n:>6} {'CANDIDATE' if ok else 'skip     '} {why}")
        # The lane-independent verdict (manual-lane paths aside): is an extra gate the reason it waits?
        xwhy = why if ok else qualifies(view, member_required, checks, app, lambda _f: False, extra=extra)[1]
        if strict is not None and xwhy.startswith("extra gate red") and EXTRA_GATE_CONTEXT not in app:
            # settle only (build never writes): tell the author once per head, never disarm.
            gh.comment(n, EXTRA_GATE_MESSAGE)
            gh.post_status(fetched, "failure", f"{xwhy} on this head; the train waits for a green scan",
                           context=EXTRA_GATE_CONTEXT)
        fixed: list[str] = []
        if not ok and strict is not None:
            modes = [m for c in changed_entries(git, f"{base}...{fetched}") for m in (c.old_mode, c.new_mode)]
            state, fixed, swhy = fix_head_state(gh, git, base, view, member_required, checks, app, modes, main_red,
                                                cache=cache, extra=extra)
            if state:
                view["fix"] = fixed
            else:
                state, swhy = strict_lane_state(view, member_required, checks, app, untrainable, modes, main_red, extra)
            if state:
                view["strict_why"] = swhy
                log(f"#{n:>6} strict    {state}: {swhy}")
                strict.append((state, view))
        if not ok and red is not None and not fixed:
            failing = stale_red_candidate(view, member_required, checks)
            if failing:
                red.append((view, failing))
        if ok:
            out.append(Member(n, view["title"], view["body"], fetched, view["head_ref"], view["created_at"],
                              ref=fetched, files=files))
            apps[n] = app
        if len(out) >= limit and red is None:
            break
    return out, apps


def partition(git, base: str, cands: list[Member], fragments: list[str]) -> tuple[list[Member], list[Member]]:
    """(fast lane, train). Computed from live git data only."""
    for m in cands:
        m.files = changed_paths(git, f"{base}...{m.head_sha}")
    fast, train = [], []
    for m in cands:
        mb = git("merge-base", base, m.head_sha).stdout.strip()
        main_files = changed_paths(git, mb, base)
        others = [f for o in cands if o is not m for f in o.files]
        ok, _ = fast_lane_eligible(m.files, main_files, others, fragments)
        (fast if ok else train).append(m)
    return fast, train


def main_regen_text(git, base: str) -> str:
    return git("show", f"{base}:{REGEN_INVENTORY}", check=False).stdout


def plan_train(gh, git, repo: str, base: str) -> tuple[list[Member], list[Member], dict[int, int | None]]:
    """(fast lane, every train candidate in order, bisect sizes) from live data."""
    required = gh.required()
    regen_text = main_regen_text(git, base)
    cands, apps = live_candidates(gh, git, repo, required, base, Untrainable(regen_text, referenced_tests(git, base)))
    fragments = regen_inventory_fragments(regen_text)
    fast, train = partition(git, base, cands, fragments)
    main_red = main_red_contexts(gh, git, required, base)
    if main_red and train:
        # A train over a red main is red on that context whatever its members do (the settle lane serves
        # a FIX alone, promote_fixes), so it would only burn a CI run to reach "inconclusive".
        log(f"train: none while main {base[:12]} is red on {', '.join(sorted(main_red))} — fixes go first, alone")
        train = []
    return fast, train, {n: bisect_size(a) for n, a in apps.items()}


def plan_batch(gh, git, repo: str, base: str, batch_size: int) -> tuple[list[Member], list[Member], dict[int, int | None]]:
    """(fast lane, this tick's candidate window, live bisect sizes) — the same function in build and settle."""
    fast, train, sizes = plan_train(gh, git, repo, base)
    return fast, select_batch(train, sizes, batch_size), sizes


MANIFEST_RE = re.compile(r"^([0-9]{1,9}) ([0-9a-f]{40})$")


def write_manifest(path: str, batch: list[Member]) -> None:
    pathlib.Path(path).write_text("".join(f"{m.number} {m.head_sha}\n" for m in batch))


def declared_batch(manifest_text: str, train: list[Member], sizes: dict[int, int | None],
                   batch_size: int, tolerate_moved: bool = False):
    """The batch build declared, admitted only member by member against LIVE data. The manifest is
    untrusted (build ran generators over PR data), so it can only SELECT: every entry must be a
    live train candidate at exactly its live head, and the selection obeys the same size cap as
    select_batch. Re-planning instead would reject a legitimate bundle whenever any candidate
    changed state in the minutes between build and publish. Raises Reject.

    `tolerate_moved` (#15827): a declared member that is no longer a live candidate at its declared
    head (a bot rewrote or closed it) is left OUT instead of rejecting the batch; returns
    (batch, moved). Leaving a member out can only shrink the selection, never add to it."""
    lines = manifest_text.splitlines()
    if not lines:
        raise Reject("bundle carries no member manifest", member_fault=False)
    live = {m.number: m for m in train}
    want: dict[int, str] = {}
    for ln in lines:
        mm = MANIFEST_RE.fullmatch(ln)
        if not mm or int(mm.group(1)) in want:
            raise Reject("member manifest is malformed", member_fault=False)
        want[int(mm.group(1))] = mm.group(2)
    moved = [n for n, head in want.items() if n not in live or live[n].head_sha != head]
    for n in moved:
        if n not in live:
            # Closed or disarmed since build — or never a candidate at all (a tampered manifest). The
            # selection only shrinks either way, but the second must stay visible.
            log(f"::warning::declared member #{n} is not a live train candidate at all (closed, disarmed, or never "
                f"one — check the build manifest)")
        else:
            log(f"::notice::declared member #{n} moved: declared head {want[n][:12]}, live {live[n].head_sha[:12]}")
    if moved and not tolerate_moved:
        raise Reject(f"declared member #{moved[0]} is no longer a live train candidate at that head — the next tick rebuilds",
                     member_fault=False)
    if len(want) > max(1, batch_size):
        raise Reject(f"declared batch of {len(want)} exceeds the batch size of {batch_size}", member_fault=False)
    batch = [m for m in train if m.number in want and m.number not in moved]
    if not batch:
        raise Reject("no declared member is still a live train candidate at its head — the next tick rebuilds",
                     member_fault=False)
    return (batch, moved) if tolerate_moved else batch


def live_base(gh, git) -> str:
    git("fetch", "-q", "origin", f"+refs/heads/{gh.branch}:refs/remotes/origin/{gh.branch}")
    return git("rev-parse", f"refs/remotes/origin/{gh.branch}").stdout.strip()


# --------------------------------------------------------------------------- the three modes
def mode_build(gh, git, builder: TrainBuilder, repo: str, out_dir: str, batch_size: int,
               expedite: int | None = None) -> list[int]:
    base = live_base(gh, git)
    with planning_reads():           # build writes nothing to GitHub; publish re-plans live
        _fast, batch, sizes = plan_batch(gh, git, repo, base, batch_size)
        if expedite is not None:
            # Expedite lane: a one-member train, that PR alone, or nothing. Publish re-validates everything.
            _fast, train, sizes = plan_train(gh, git, repo, base)
            batch = [m for m in train if m.number == expedite][:1]
            log(f"build: expedite lane for #{expedite}: {'one-member train' if batch else 'not a live candidate, no train'}")
    builder.sizes, builder.default_size = sizes, batch_size
    capped = sorted({sizes[m.number] for m in batch if sizes.get(m.number)})
    if capped:
        log(f"build: bisect size(s) {capped} on candidates — the cap counts only members that apply")
    regen_text = main_regen_text(git, base)
    builder.untrainable = Untrainable(regen_text, referenced_tests(git, base))
    builder.declared_inputs = regen_inventory_fragments(regen_text)
    os.makedirs(out_dir, exist_ok=True)
    if not batch:
        log("build: no train this tick")
        return []
    tip, applied, dropped = builder.build(base, batch)
    log(f"build over {base[:12]}: applied {applied}, dropped {dropped}")
    if dropped:
        heads = {m.number: m.head_sha for m in batch}
        pathlib.Path(out_dir, DROPS_FILE).write_text("".join(f"{n} {heads[n]}\n" for n in dropped))
    if applied:
        tried = set(builder.attempted)
        write_manifest(os.path.join(out_dir, MANIFEST_FILE),
                       [m for m in batch if m.number in tried and m.number not in builder.deferred])
        git("update-ref", BUNDLE_REF, tip)
        git("bundle", "create", os.path.join(out_dir, BUNDLE_FILE), BUNDLE_REF, f"^{base}")
    return applied


def conflict_paths(git, base: str, head: str) -> list[str] | None:
    """Paths `head` conflicts on against `base` by `git merge-tree` (execution-free), or None when it
    merges cleanly or merge-tree could not decide (anything but exit 1 is not a conflict)."""
    r = git("merge-tree", "--write-tree", "--name-only", "--no-messages", "-z", base, head, check=False)
    if r.returncode != 1:
        return None
    return sorted({f for f in r.stdout.split("\0")[1:] if f})


def workflow_merge_blobs(git, base: str, head: str) -> list[str]:
    """Workflow files whose clean merge of `head` into `base` equals NEITHER parent; [] when the merge
    conflicts or undecidable. Execution-free, like conflict_paths."""
    r = git("merge-tree", "--write-tree", base, head, check=False)
    if r.returncode != 0:
        return []
    def blobs(rev: str) -> dict[str, str]:
        out = git("ls-tree", "-r", "-z", rev, "--", WORKFLOW_DIR, check=False).stdout
        return {e.split("\t", 1)[1]: e.split("\t", 1)[0] for e in out.split("\0") if e}
    ours, theirs = blobs(base), blobs(head)
    return sorted(f for f, b in blobs(r.stdout.split()[0]).items() if b not in (ours.get(f), theirs.get(f)))


def notice_since(rows: list) -> str | None:
    """created_at of the App's latest notice on a head, while `merge-train` has not gone green since."""
    latest: dict[str, dict] = {}
    for st in sorted(rows, key=lambda r: r["id"]):
        if (st.get("creator") or {}).get("login") == BOT_LOGIN:
            latest[st["context"]] = st
    if NOTICE_CONTEXT not in latest or latest.get(STATUS_CONTEXT, {}).get("state") == "success":
        return None
    return latest[NOTICE_CONTEXT].get("created_at")


def stuck_body(stuck: list[tuple[int, str, str]]) -> str:
    """The issue's whole content. Stable across ticks (no clock), so an unchanged set writes nothing."""
    return ("Armed PRs the merge train cannot serve until someone acts; each has its own comment saying what "
            f"to do. Closed by the train when the list is empty. Threshold: {STUCK_AFTER_S // 3600} h.\n\n"
            + "".join(f"- #{n}: since {since} ({why})\n" for n, since, why in stuck))


def stuck_prs(gh, repo: str, now: float | None = None) -> list[tuple[int, str, str]]:
    """Armed PRs told of a conflict or refusal more than STUCK_AFTER_S ago, on their current head.
    Called inside settle_view's planning scope, so its status reads are the ones already memoised."""
    now = time.time() if now is None else now
    stuck: list[tuple[int, str, str]] = []
    for p in gh.open_prs():
        if not p.get("auto_merge") or is_carrier(p, repo):
            continue
        since = gh.notice_since(p["head"]["sha"])
        if not since:
            continue
        try:
            t = datetime.datetime.fromisoformat(since.replace("Z", "+00:00")).timestamp()
        except ValueError:
            continue
        if now - t >= STUCK_AFTER_S:
            why = gh.app_statuses(p["head"]["sha"]).get(NOTICE_CONTEXT, ("", ""))[1]
            stuck.append((int(p["number"]), since, why))
    return sorted(stuck)


def report_stuck(gh, shadow: bool, summary: dict, stuck: list[tuple[int, str, str]]) -> None:
    """Summary, ::error and tracking issue. A failed issue write never costs the tick: the settle log's
    ::error says the same thing."""
    summary["stuck"] = [n for n, _, _ in stuck]
    if stuck:
        log(f"::error::merge train: {len(stuck)} armed PR(s) stuck over {STUCK_AFTER_S // 3600} h: "
            f"{', '.join(f'#{n}' for n, _, _ in stuck)}")
    if shadow:
        return
    number, body = gh.stuck_issue()
    if stuck and body != stuck_body(stuck):
        gh.save_stuck_issue(number, stuck_body(stuck))
    elif not stuck and number:
        gh.close_stuck_issue(number)


def notice_text(message: str, paths: list[str] | None, heading: str = "Conflicting paths") -> str:
    """Fixed text plus the conflicting paths as inline code. A path that could break out of the code
    span or the line (control character, backtick) is counted, never printed."""
    shown = [f for f in (paths or []) if not unsafe_path(f) and "`" not in f][:NOTICE_PATH_CAP]
    if not paths:
        return message
    more = len(paths) - len(shown)
    return message + f"\n\n{heading}:\n" + "".join(f"- `{f}`\n" for f in shown) + (
        f"- ... and {more} more\n" if more else "")


def notice_once(gh, n: int, head: str, description: str, text: str) -> bool:
    """Tell the author once per head (NOTICE_CONTEXT marks it). The `merge-train` failure is posted
    only over no App failure, so a culprit or manual-lane verdict on the same head is never replaced."""
    app = gh.app_statuses(head)
    if NOTICE_CONTEXT in app:
        return False
    if app.get(STATUS_CONTEXT, ("", ""))[0] != "failure":
        gh.post_status(head, "failure", description)
    gh.comment(n, text)
    gh.post_status(head, "failure", description, context=NOTICE_CONTEXT)
    log(f"#{n:>6} notice    {description}")
    return True


def mode_notice_drops(gh, git, bundle_dir: str) -> list[int]:
    """Publish (App token), before anything else: build's drops file is DATA from a job that ran
    generators over PR code, so it only nominates. A line is admitted only as `<number> <sha>` of an
    open, armed PR whose live head is exactly that sha, and a notice is posted only when THIS job's own
    `git merge-tree` of that head against live main conflicts. Nothing in the file is executed."""
    path = os.path.join(bundle_dir, DROPS_FILE)
    if not os.path.isfile(path):
        return []
    lines = pathlib.Path(path).read_text()[:8192].splitlines()
    nominated = [MANIFEST_RE.fullmatch(ln) for ln in lines[:64]]
    if any(m is None for m in nominated):
        log("::warning::drops file is malformed — no notices this tick")
        return []
    base = live_base(gh, git)
    told: list[int] = []
    for n, head in {int(m.group(1)): m.group(2) for m in nominated}.items():
        p = gh.pr(n)
        if p.get("state") != "open" or not p.get("auto_merge") or p["head"]["sha"] != head:
            continue
        git("fetch", "-q", "origin", f"+{gh.head_refspec(n)}:refs/merge-train/pr-{n}")
        if git("rev-parse", "--verify", "--quiet", f"refs/merge-train/pr-{n}", check=False).stdout.strip() != head:
            continue
        paths = conflict_paths(git, base, head)
        if paths is None:
            continue   # dropped for another reason (an earlier member, a path rule): publish says so as before
        if notice_once(gh, n, head, f"{CONFLICT_PREFIX}{base[:12]}: merge main into the branch",
                       notice_text(CONFLICT_COMMENT, paths)):
            told.append(n)
    return told


def mark_unverifiable(gh, batch: list[Member]) -> None:
    """A train publish cannot verify is halved like a red one; at one member it is the manual lane."""
    if len(batch) == 1:
        gh.post_status(batch[0].head_sha, "failure", "not verifiable by the merge train: manual lane")
        gh.comment(batch[0].number, MANUAL_LANE_MESSAGE)
        return
    for m in batch:
        gh.post_status(m.head_sha, "pending", f"bisect size {max(1, len(batch) // 2)}")


def mode_publish(gh, git, repo: str, bundle_dir: str, run_id: str, attempt: str, batch_size: int,
                 stack: tuple[int, str] | None = None, expedite: int | None = None,
                 expedite_cap: int = EXPEDITE_DAILY_CAP_DEFAULT) -> str:
    """Returns one of: idle, in-flight, rejected, published. `stack` = (holder PR, holder head) from
    settle's speculative-stacking window: re-validated from live data here, never trusted as given.
    `expedite` = the PR of settle's expedite window, likewise re-validated (expedite_problem)."""
    if expedite is not None:
        if stack is not None:
            log("::warning::expedite and stacking windows together — refusing both")
            return "rejected"
        why = expedite_problem(gh, git, repo, expedite, expedite_cap)
        if why:
            log(f"::notice::expedite lane for #{expedite} closed since settle: {why}")
            return "in-flight"
    elif any_carrier_open(gh, repo):   # a train carrier, or a strict carrier holding the strict reservation
        return "in-flight"
    branch = train_branch(run_id, attempt)
    base = live_base(gh, git)
    _fast, train, sizes = plan_train(gh, git, repo, base)
    bundle = os.path.join(bundle_dir, BUNDLE_FILE)
    if not train or not os.path.isfile(bundle):
        return "idle"
    manifest = os.path.join(bundle_dir, MANIFEST_FILE)
    try:
        batch, moved = declared_batch(pathlib.Path(manifest).read_text() if os.path.isfile(manifest) else "",
                                      train, sizes, batch_size, tolerate_moved=True)
    except Reject as exc:
        log(f"::warning::train rejected: {exc}")
        return "rejected"
    if moved:
        log(f"::notice::declared member(s) {moved} no longer live train candidates at their declared heads — "
            f"left out, the rest re-derived this tick (#15827)")
    log(f"publish: declared batch {[m.number for m in batch]}")
    if expedite is not None and [m.number for m in batch] != [expedite]:
        log(f"::warning::expedite lane: declared batch is not exactly [#{expedite}] — rejected")
        return "rejected"
    outputs = derived_output_patterns(git("show", f"{base}:{REGEN_INVENTORY}", check=False).stdout)
    if not outputs:
        log("::error::origin/main declares no DERIVED_OUTPUTS — refusing")
        return "rejected"
    live = {m.number: m for m in train}
    rederive = bool(moved)
    declared_n = len(batch) + len(moved)
    inputs = regen_inventory_fragments(git("show", f"{base}:{REGEN_INVENTORY}", check=False).stdout)
    while True:
        try:
            if git("bundle", "verify", bundle, check=False).returncode != 0:
                raise Reject("bundle does not verify against this clone (stale base or corrupt)", member_fault=False)
            git("fetch", "-q", bundle, f"+{BUNDLE_REF}:refs/merge-train/bundle")
            tip = git("rev-parse", "refs/merge-train/bundle").stdout.strip()
            if rederive:
                # Publish executes nothing, so a re-derived train can carry no regeneration commit. Decided
                # from main's inventory, never from the (untrusted) bundle: a remaining member touching a
                # declared generator INPUT may need one — whether or not the original batch did — so the
                # next tick rebuilds instead (a carrier missing it would fail derived-drift and could blame
                # an innocent member). Belt: a bundle chain longer than its declared members carries an
                # extra commit, which can only be a regeneration commit.
                touching = [m.number for m in batch
                            if any(frag in f for f in changed_paths(git, f"{base}...{m.head_sha}") for frag in inputs)]
                chain_len = len(git("rev-list", "--first-parent", f"{base}..{tip}", check=False).stdout.split())
                if touching or chain_len > declared_n or (
                        git("log", "-1", "--format=%s", tip, check=False).stdout.strip() == REGEN_COMMIT_SUBJECT):
                    why = (f"remaining member(s) {touching} touch generator inputs" if touching
                           else "the bundle carries a regeneration commit")
                    raise Reject(f"a member left the batch and {why}; publish cannot regenerate — the next tick rebuilds",
                                 member_fault=False)
            v = verify_bundle_train(git, base, batch, None if rederive else tip, outputs)
            cap = batch_cap([live[n] for n in v.applied if n in live], sizes, batch_size)
            if len(v.applied) > cap:
                raise Reject(f"train applies {len(v.applied)} member(s), over the bisect cap of {cap}", member_fault=False)
        except Reject as exc:
            log(f"::warning::train rejected: {exc}")
            if exc.member_fault:
                mark_unverifiable(gh, batch)
            return "rejected"
        heads = {m.number: m.head_sha for m in batch}
        gone = [n for n in v.applied if not live_source_intent(gh, n, heads[n])]
        if not gone:
            break
        # #15827: one member moving (release-please rewrites its branch after every merge to main, deploy
        # bots supersede and close) no longer discards the batch. It is left out and the rest is re-derived
        # from live heads in this tick; every remaining member is re-read live again on the next pass.
        log(f"::notice::#{', #'.join(map(str, gone))} source intent or head changed — left out, the rest re-derived")
        batch = [m for m in batch if m.number not in gone]
        rederive = True
        if not batch:
            log("::notice::no declared member is left — carrier not published")
            return "rejected"
    if not rederive:
        # A re-derived train's drops may come only from a member having left, so no drop notice is sent.
        for n in v.dropped:
            gh.comment(n, DROP_MESSAGE)
    if stack:
        hn, hh = stack
        why = stack_target_problem(gh, git, base, hn, hh)
        stacked = None
        if why is None:
            try:
                stacked = restack_chain(git, base, hh, v.tip)
            except Reject as exc:
                why = str(exc)
                # One attempt per holder head: settle does not reopen the window on it.
                gh.post_status(hh, "failure", f"stack refused: {why}"[:140], context=STACK_CONTEXT)
        if stacked is not None:
            tip, tree = stacked
            Pusher(git, branch, gh.remote).push(tip)
            gh.post_status(tip, "success", f"tree={tree}", context=RECORD_CONTEXT)
            gh.post_status(tip, "success", f"stacked over {hh} of #{hn}", context=STACK_CONTEXT)
            # Recorded on the holder head BEFORE the carrier exists: settle identifies a stacked carrier by it.
            gh.post_status(hh, "success", f"stacked carrier {branch} over #{hn}", context=STACK_CONTEXT)
            gh.create_carrier(branch)
            log(f"published {branch} STACKED over #{hn} head {hh[:12]} (main {base[:12]}): members {v.applied}")
            return "published"
        log(f"::notice::not stacked over #{hn}: {why}")
        if SHA_RE.fullmatch(hh or "") and deferral_used(gh, git, hh):
            # Over main it could merge past a holder that already yielded once: never pre-empted twice.
            log(f"::notice::#{hn} already yielded once — carrier not published over main either")
            return "rejected"
    if expedite is not None and v.applied != [expedite]:
        log(f"::warning::expedite lane: train applies {v.applied}, not exactly [#{expedite}] — rejected")
        return "rejected"
    Pusher(git, branch, gh.remote).push(v.tip)
    gh.post_status(v.tip, "success", f"tree={v.tree}", context=RECORD_CONTEXT)
    if expedite is not None:
        # Marked BEFORE the carrier exists: settle identifies an expedite carrier by this status alone.
        gh.post_status(v.tip, "success", f"expedite lane: #{expedite} alone over {base[:12]}", context=EXPEDITE_CONTEXT)
        gh.create_carrier(branch, expedite=True)
    else:
        gh.create_carrier(branch)
    record_deferral(gh, git, repo, base, branch)
    log(f"published {branch} over {base[:12]}: members {v.applied}, dropped {v.dropped}")
    return "published"


def defer_recovered_main_red(gh, base: str, main_red: dict[str, str], summary: dict) -> bool:
    """Fresh current-tip health before exceptional fix priority; never reuse planning reads.
    Pending/missing results retain existing ancestor-red semantics. An observed healthy context
    invalidates this plan, not the PR: the next tick reconstructs reservation and candidate order.
    """
    if not main_red:
        return False
    try:
        with deciding():
            current = gh.checks(base)
        recovered = sorted(ctx for ctx in main_red if current.get(ctx) == "success")
    except (OSError, RuntimeError, ValueError, KeyError, TypeError):
        reason = "current main health could not be read"
    else:
        if not recovered:
            return False
        reason = "current main recovered: " + ", ".join(recovered)
    summary["in_flight"] = True  # suppress build as well as every later mutation this tick
    summary["main_health_deferred"] = reason
    log(f"::notice::{reason}; stale main-red priority discarded — next tick")
    return True



def expedite_window_held(gh, head: str, base: str) -> bool:
    """`head` was given the expedite window over THIS main on an earlier tick (EXPEDITE_WINDOW_CONTEXT
    names `base`) and no expedite carrier came of it — the caller has already established that none is
    open. A moved main is a fresh attempt: the marker names the main it was opened over."""
    state, desc = gh.app_statuses(head).get(EXPEDITE_WINDOW_CONTEXT, ("", ""))
    return state == "success" and desc.endswith(f"over main {base}")


def expedite_candidate(gh, git, repo: str, train_waiting: list, cap: int, base: str | None = None) -> int | None:
    """The first expedited train candidate the lane may serve now, or None. Order is the train's own,
    except (#16874) that a candidate whose head HELD the window over this very main and got nothing
    from it (its one-member train was deferred by the build — gate code beside a regeneration commit,
    #13400 — or refused by publish) is passed over for the next expedited candidate this tick, so one
    perpetually deferred member cannot starve every other expedited PR (#16807 held the slot ~6 h while
    #16852, the main-red fix, waited). When every expedited candidate has had its turn over this main,
    the first is served again: a rotation bounded by the number of expedited candidates, never a
    permanent exclusion. Still one expedited PR per tick: the chosen one, never a later one past it."""
    labels = {p["number"]: p for p in gh.open_prs()}
    expedited = [m for m in train_waiting if is_expedited(labels.get(m.number) or {})]
    if not expedited:
        return None
    held = [m for m in expedited if base and expedite_window_held(gh, m.head_sha, base)]
    fresh = [m for m in expedited if m not in held]
    m = (fresh or held)[0]
    if held and fresh:
        log(f"expedite lane: {[h.number for h in held]} held the window over main {base[:12]} and nothing was built — "
            f"passed over for #{m.number} this tick (#16874)")
    elif held:
        log(f"expedite lane: every expedited candidate {[h.number for h in held]} has held the window over main "
            f"{base[:12]} — rotation restarts at #{m.number}")
    why = expedite_problem(gh, git, repo, m.number, cap)
    if why is None:
        return m.number
    log(f"expedite lane: #{m.number} not served — {why}")
    return None   # one expedited PR per tick: the chosen one, never a later one past it


def mode_settle(gh, git, repo: str, shadow: bool, run_id: str = "", attempt: str = "",
                strict_cap: int = STRICT_BATCH_CAP_DEFAULT, judge_cap: int = STRICT_JUDGE_BATCH_CAP_DEFAULT,
                stack: bool = SPECULATIVE_STACK_DEFAULT,
                expedite: bool = EXPEDITE_LANE_DEFAULT, expedite_cap: int = EXPEDITE_DAILY_CAP_DEFAULT,
                urgent_cap: int = URGENT_DAILY_CAP_DEFAULT) -> dict:
    """Judge every finished App carrier (strict carriers first), build the next strict carrier when the
    strict lane is free, then post the fast lane from live data. `run_id`/`attempt` name the strict
    carrier branch; without them (or at `strict_cap` 1) the strict lane behaves exactly as before."""
    summary: dict = {"in_flight": False, "merged": [], "culprits": [], "bisected": [], "rejected": [], "fast": [],
                     "inconclusive": [], "rerun": [], "refreshed": [], "culprit_refreshed": []}
    if not shadow:
        # Phase 1 is gated on the live ruleset, not on the env flag alone: until it requires the App-pinned
        # context with strict off, behave exactly as shadow. Flip order of env vs ruleset is irrelevant.
        why = gh.merge_guard()
        if why:
            log(f"::notice::merge guard: shadow behaviour, nothing merges — {why}")
            shadow = True
    required = gh.required()
    train_required = [c for c in required if c != STATUS_CONTEXT and c not in TREE_INDEPENDENT_CONTEXTS]
    carrier_in_flight = False
    # Read the strict lane BEFORE settling any carrier: a reservation holds train merges as well as the
    # fast lane, or main moves under the reserved head's CI and it is re-updated forever (#13456).
    stuck: list = []
    base, regen_text, strict, red, cands, apps, main_red, main_cache = settle_view(gh, git, repo, required, stuck)
    not_fix: dict[int, str] = {}   # summary["not_fix"]: refusals from EVERY settle view this tick, not just the last
    not_fix_heads: dict[int, str] = {}   # PR number -> the head the refusal was about (publish_fix_claims)
    if defer_recovered_main_red(gh, base, main_red, summary):
        return summary
    relevant = served_relevant_fixes(gh, git, base, strict, main_red, main_cache)
    urgent = urgent_expire(gh, strict, urgent_prs(gh, repo, strict, urgent_cap), time.time(), shadow)
    preempted: list[int] = []
    holder, timed_out = strict_reservation(git, base, strict, shadow,
                                           fixes=strict_fixes(gh, git, base, strict, main_red, main_cache),
                                           activity=gh.ci_activity, relevant=relevant,
                                           urgent=urgent, preempted=preempted, main_red=bool(main_red))
    # Strict carriers first (ADR-0343 amendment 2026-11-05): an open one holds the strict reservation.
    strict_carrier_open, acted = judge_strict_carriers(gh, git, repo, base, required, main_red, shadow, summary)
    if strict_carrier_open:
        summary["in_flight"] = True
        carrier_in_flight = True
    pending_carrier = None   # the one ordinary carrier still running CI, the only one the expedite lane overtakes
    # Expedite carriers first (ADR-0343 amendment 2026-11-13): a green one merges in this tick before the
    # carrier it overtook is judged, and that one then fails "main moved" with no verdict.
    for p in sorted([p for p in gh.open_prs() if is_carrier(p, repo)], key=lambda p: not is_expedite_carrier(gh, p)):
        sha, branch, carrier = p["head"]["sha"], p["head"]["ref"], p["number"]
        # Speculative stacking: judged BEFORE any verdict on the carrier's own CI, so a red stacked carrier
        # over a holder without a verdict can never blame, bisect or halve anything.
        stacked, stack_why = stack_verdict(gh, git, p, gh.main_sha())
        if stacked == "wait":
            # Not carrier_in_flight: the holder must still be free to merge in this tick's strict_lane.
            log(f"carrier #{carrier}: stacked, {stack_why} — waits, never merged before its holder")
            summary["in_flight"] = True
            continue
        if stacked in ("void", "reject"):
            log(f"::warning::carrier #{carrier}: stacked, {stack_why} — closed with no verdict, nobody blamed")
            summary["inconclusive" if stacked == "void" else "rejected"].append(carrier)
            gh.close_carrier(carrier)
            Pusher(git, branch, gh.remote).delete()
            acted = True
            continue
        stacked_over = stack_why if stacked == "merged" else None
        extra = train_extra_gates(git, base)
        if extra is None:   # fail closed: no carrier is judged (nothing merges, nobody blamed) until fixed
            summary["in_flight"] = True
            carrier_in_flight = True
            continue
        checks = pinned_checks(gh, sha, extra)
        if any(checks.get(g) in EXTRA_GATE_NA_STATES for g in extra):
            # An n/a extra gate holds only if no member touches the gate's own workflow (#13400):
            # read the carrier's diff (= the union of member diffs) from its verified head.
            got = git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/merge-train/settle", check=False).returncode == 0
            ok = got and git("rev-parse", "refs/merge-train/settle", check=False).stdout.strip() == sha
            checks = own_workflow_checks(checks, extra, changed_paths(git, f"{base}...{sha}") if ok else None)
        failing, pending, inconclusive = classify_carrier(
            checks, carrier_contexts(train_required, extra, checks))
        if stacked_over is not None and failing:
            # A stacked carrier is accepted green or not at all: its members were regenerated over main,
            # never over the holder, so a red one (derived drift of holder + member, say) names no culprit.
            log(f"::warning::carrier #{carrier}: stacked, red on {', '.join(failing)} — closed with no verdict, "
                f"nobody blamed; the next tick rebuilds over main")
            summary["inconclusive"].append(carrier)
            gh.close_carrier(carrier)
            Pusher(git, branch, gh.remote).delete()
            acted = True
            continue
        gate_inconclusive = False   # inconclusive because a GATE overran its budget / was not evaluated
        main_extra = [c for c in failing if c in extra and c in main_red]
        failing = [c for c in failing if c not in main_extra]   # red on main too: never a culprit
        if main_extra and not failing:
            if pending:
                summary["in_flight"] = True
                carrier_in_flight = True
                continue
            log(f"::warning::carrier #{carrier}: red only on extra gate(s) {', '.join(main_extra)}, red on main too — no verdict")
            summary["inconclusive"].append(carrier)
            gh.close_carrier(carrier)
            if TRAIN_BRANCH_RE.fullmatch(branch):
                Pusher(git, branch, gh.remote).delete()
            continue
        if failing:
            # Red only because gates overran a budget or were NOT EVALUATED (#13400) — the same as a
            # cancelled job: no verdict about any member, so no culprit and no bisect.
            only_inconclusive, why = gh.failures_inconclusive(sha, failing)
            if only_inconclusive:
                log(f"carrier #{carrier}: {', '.join(failing)} red only for inconclusive gates ({why}) — inconclusive")
                failing, inconclusive = [], sorted(set(inconclusive) | set(failing))
                gate_inconclusive = True
        if not failing and pending and gate_inconclusive:
            # Early no-verdict close (#13400): the gate shard's job has COMPLETED and the runner's own
            # --json says every failed gate overran a budget or was not evaluated. Nothing still running
            # can turn that red into a culprit or a merge (a required context is red), so waiting ~1 h for
            # the rest of CI only delays the same close. Only when the batch can be halved: a single
            # member keeps today's wait-then-rerun-once path, since closing early could only rebuild it.
            halved = halve_without_verdict(gh, git, branch, sha)
            if halved:
                log(f"::warning::carrier #{carrier}: gate verdict inconclusive while {len(pending)} context(s) still "
                    f"run — closed now with no verdict, next batch halved, nobody blamed")
                summary["inconclusive"].append(carrier)
                summary["bisected"].append(halved)
                gh.close_carrier(carrier)
                if TRAIN_BRANCH_RE.fullmatch(branch):
                    Pusher(git, branch, gh.remote).delete()
                continue
        if not failing and pending:
            summary["in_flight"] = True
            if stacked_over is None and not is_expedite_carrier(gh, p):
                pending_carrier = carrier
            if carrier_holds_strict(p):
                carrier_in_flight = True
            else:
                log(f"carrier #{carrier}: CI still running after > {CARRIER_PRIORITY_S // 60} min — no longer holds the strict lane")
            continue
        if not failing and inconclusive:
            # Wait for a terminal non-cancelled result: re-run the cancelled jobs ONCE, then the
            # carrier is in flight again. A second all-inconclusive verdict (or a refused rerun)
            # closes the carrier with NO verdict — nobody is blamed and the next tick rebuilds.
            if not gh.app_statuses(sha).get(RERUN_CONTEXT, ("", ""))[0] and gh.rerun_inconclusive(sha, inconclusive):
                gh.post_status(sha, "success", "rerun 1 of 1: " + ", ".join(inconclusive), context=RERUN_CONTEXT)
                log(f"carrier #{carrier}: inconclusive ({', '.join(inconclusive)}) — re-ran once, in flight")
                summary["rerun"].append(carrier)
                summary["in_flight"] = True
                carrier_in_flight = True
                continue
            log(f"::warning::carrier #{carrier}: still inconclusive ({', '.join(inconclusive)}) — closed with no verdict")
            summary["inconclusive"].append(carrier)
            if gate_inconclusive:
                halved = halve_without_verdict(gh, git, branch, sha)
                if halved:
                    log(f"carrier #{carrier}: gate verdict scales with the train — next batch halved, nobody blamed")
                    summary["bisected"].append(halved)
            gh.close_carrier(carrier)
            if TRAIN_BRANCH_RE.fullmatch(branch):
                Pusher(git, branch, gh.remote).delete()
            continue
        got = git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/merge-train/settle", check=False).returncode == 0
        fetched = git("rev-parse", "refs/merge-train/settle").stdout.strip() if got else ""
        rec_state, rec_desc = gh.app_statuses(sha).get(RECORD_CONTEXT, ("", ""))
        problem = None if fetched == sha else "carrier branch missing or moved under the carrier"
        problem = problem or record_problem(rec_desc if rec_state == "success" else None,
                                            BOT_LOGIN if rec_state == "success" else None, git.tree(sha))
        chain = None if problem else parse_own_chain(git, sha)
        if not problem and chain is None:
            problem = "head is not a chain of the train's own commits"
        live_main = gh.main_sha()
        if not problem and chain[0] != live_main and not (
                stacked_over is not None and chain[0] == stacked_over and git.tree(live_main) == git.tree(chain[0])):
            # A stacked carrier is accepted over a moved main ONLY when main's tree is exactly the holder
            # head's tree it was verified over (the holder's squash), re-read against live main here.
            problem = "main moved since publish — the next tick rebuilds"
        if not problem and not failing and holder is not None:
            hstate, hview = next(((st, v) for st, v in strict if v["number"] == holder), (None, None))
            if (hstate == "green" and not shadow and len(chain[1]) <= STRICT_FIRST_MAX_MEMBERS
                    and git("merge-base", "--is-ancestor", live_main, hview["head_sha"], check=False).returncode == 0
                    and gh.app_statuses(hview["head_sha"]).get(CARRIER_YIELD_CONTEXT, ("", ""))[0] != "success"
                    and gh.app_statuses(hview["head_sha"]).get(DEFER_CONTEXT, ("", ""))[0] != "success"):
                # Green holder first, ONE tick per holder head: the holder is green on a head that contains
                # live main (re-checked against live main, since an earlier carrier of this tick may have
                # moved it), so it merges in THIS tick's strict_lane. A carrier merging first would push it
                # behind main and restart ~1.5 h of full CI (#14191 after deploy #14338; #14183 after
                # release #14327). The carrier is left open and NOT in flight; the yield is recorded on the
                # holder head so the wait is bounded: if the holder is still green and unmerged next tick
                # (merge refused, source intent changed, a train in flight, main-red deferral) the carrier
                # takes the green-carrier-first path below instead of stalling behind it.
                # NOT for a holder that DEFERRED to this carrier (DEFER_CONTEXT on its head, recorded by
                # publish under the bounded deferral): that record is the promise that the carrier built
                # under its CI may merge past it. Honouring the holder first instead voided every such
                # carrier — the holder's CI always starts before the carrier's (the carrier is built
                # during it), so it goes green first, merges, and the carrier is rejected next tick as
                # "main moved since publish"; the rebuilt carrier is then built under the NEXT reservation
                # and loses again. Measured 2026-11-05 00:00-10:50Z: 9 carriers, 0 train merges, 22 strict
                # PRs queued (#14860 lost to #14831 at 07:47Z, #14871 to #14562 at 10:35Z). The deferring
                # holder keeps the ADR-0343 bound: pre-empted at most once, its update-branch inherits the
                # record through the first parent and no further carrier is built under it.
                gh.post_status(hview["head_sha"], "success", f"green carrier #{carrier} waited one tick for this head",
                               context=CARRIER_YIELD_CONTEXT)
                # The holder's merge moves main, so next tick this carrier is rejected as "main moved since
                # publish" and rebuilt: yielding VOIDS the carrier, it does not delay it. That is why the
                # yield is limited to a carrier of STRICT_FIRST_MAX_MEMBERS (see there).
                log(f"carrier #{carrier}: green, but strict-lane #{holder} is green and up to date — it merges "
                    f"first; this {len(chain[1])}-member carrier is voided by that merge and rebuilt")
                continue
            # Green carrier first (#13400): VERIFIED green on its exact head over live main, extra gates
            # satisfied, so it merges now, before strict_lane runs below — never held for a RUNNING holder,
            # nor for a green one that already had its one tick (CARRIER_YIELD_CONTEXT)
            # and voided by its merge (#13853 / #13806). The holder waits one tick and is update-branched,
            # inheriting its deferral record through the first parent, so no further carrier is built
            # under it. Before merging, withdraw any `merge-train` success the App left on the holder's
            # head (a refused merge earlier): auto-merge must not act on it while main moves under it.
            if hview is not None and not shadow:
                if hstate == "green" and len(chain[1]) > STRICT_FIRST_MAX_MEMBERS:
                    # A green holder pre-empted by the size rule has not deferred (no DEFER_CONTEXT): record
                    # the pre-emption as its one deferral, so its update-branch inherits it through the first
                    # parent (deferral_used) and no further carrier is built under it — ADR-0343's
                    # "pre-empted at most once", whichever rule did the pre-empting.
                    gh.post_status(hview["head_sha"], "success", f"pre-empted once by green carrier #{carrier}",
                                   context=DEFER_CONTEXT)
                hstate = gh.app_statuses(hview["head_sha"]).get(STATUS_CONTEXT, ("", ""))[0]
                if hstate == "success":
                    gh.post_status(hview["head_sha"], "pending", f"strict lane: green carrier #{carrier} merges first — next tick")
            log(f"carrier #{carrier}: green — merging before strict-lane #{holder} (green carrier first)")
        stacked_steps: list[str] = []
        if not problem and not failing and stacked_over is not None:
            # The holder that is running NOW (reserved in the tick its predecessor merged) contains main ==
            # tree(h); this merge puts it behind main, i.e. pre-empts it. Same bound as the deferral: once.
            running = next((v for st, v in strict if v["number"] == holder and st == "pending"), None)
            if (running is not None
                    and git("merge-base", "--is-ancestor", live_main, running["head_sha"], check=False).returncode == 0):
                if deferral_used(gh, git, running["head_sha"]):
                    problem = f"strict-lane #{holder} already yielded once — not pre-empted again"
                elif not shadow:
                    gh.post_status(running["head_sha"], "success",
                                   f"strict lane: yielded once to stacked carrier {branch}; priority from here",
                                   context=DEFER_CONTEXT)
            stacked_steps = git("rev-list", "--reverse", "--first-parent", f"{chain[0]}..{sha}").stdout.split()
            if len(stacked_steps) != len(chain[1]):
                problem = problem or "stacked chain does not match its members"
            elif not problem:
                # BEFORE any merge: the squash GitHub will make of each member (merge-tree of the member head
                # over the tree before it) must be exactly the verified stacked step, or nothing merges.
                why = stacked_squash_mismatch(gh, git, live_main, chain[1], stacked_steps)
                if why:
                    log(f"::warning::carrier #{carrier}: stacked, {why} — closed with no verdict, nothing merged, "
                        f"nobody blamed")
                    summary["inconclusive"].append(carrier)
                    gh.close_carrier(carrier)
                    Pusher(git, branch, gh.remote).delete()
                    acted = True
                    continue
        acted = True
        if problem:
            log(f"::warning::carrier #{carrier}: {problem}")
            summary["rejected"].append(carrier)
        elif not failing:
            expected = live_main
            for i, (n, head) in enumerate(chain[1]):
                if not live_source_intent(gh, n, head):
                    native = None if shadow else already_merged_member(gh, git, n, head, expected)
                    if native is None or (stacked_steps and git.tree(native) != git.tree(stacked_steps[i])):
                        log(f"#{n} source intent or head changed since the train was verified; stopping")
                        break
                    # #16932: native auto-merge won the race at the verified head over the expected main.
                    log(f"#{n} already merged by native auto-merge at the verified head ({native[:12]}); continuing")
                    expected = native
                    summary.setdefault("native_merged", []).append(n)
                    continue
                if not shadow and gh.main_sha() != expected:
                    log("main advanced by a foreign merge; stopping, the next tick rebuilds")
                    break
                if stacked_steps and not shadow and stacked_squash_mismatch(
                        gh, git, expected, [(n, head)], [stacked_steps[i]]):
                    # Re-predicted over the exact main this merge lands on: still the verified tree, or stop.
                    log(f"::error::carrier #{carrier}: #{n}'s squash over main {expected[:12]} is not the verified "
                        f"stacked tree — not merged, stopping")
                    summary.setdefault("stack_tree_mismatch", []).append(n)
                    break
                gh.post_status(head, "success", f"verified on train over main {chain[0][:12]}", source_number=n)
                if shadow:
                    continue
                merged = gh.merge(n, head)
                if not merged:
                    log(f"#{n} did not merge; stopping")
                    break
                expected = merged
                summary["merged"].append(n)
                if stacked_steps:
                    # Verified tree == merged tree, step by step: GitHub's squash of a member over main-after-H
                    # is a different 3-way merge from publish's restack, so it is compared, never assumed.
                    # A fetch failure raises: fail closed, nothing further merges.
                    git("fetch", "-q", "origin", f"+refs/heads/{gh.branch}:refs/merge-train/stack-main")
                    if git.tree(merged) != git.tree(stacked_steps[i]):
                        # Second line of defence only (the pre-check above should make this unreachable):
                        # main moved to an unverified tree, so stop and raise an alert on main itself.
                        log(f"::error::carrier #{carrier}: main {merged[:12]} after #{n} is not the verified "
                            f"stacked tree — stopping")
                        gh.post_status(merged, "failure", f"ALERT: tree after #{n} differs from stacked carrier "
                                       f"#{carrier}'s verified tree", context=STACK_CONTEXT)
                        summary.setdefault("stack_tree_mismatch", []).append(n)
                        break
        elif not [c for c in failing if c not in main_red]:
            # Red only on contexts main itself is red on: says nothing about any member — never a culprit,
            # never a bisect (a bisect ends in a culprit). Closed with no verdict; nobody is blamed.
            log(f"::warning::carrier #{carrier}: red only on {', '.join(failing)}, red on main {chain[0][:12]} too — inconclusive")
            summary["inconclusive"].append(carrier)
        else:
            members = chain[1]
            failing = [c for c in failing if c not in main_red]  # blame names only what main is green on
            if len(members) == 1:
                n, head = members[0]
                # Order with the stale-culprit refresh below: the one likely-flake rerun (failed jobs only,
                # minutes) comes first; only a red that survives it is blamed, and only then may a behind-main
                # culprit get its one update-branch (a full CI run). A flake therefore never costs a refresh.
                flake = likely_flake_rerun(gh, git, sha, failing, head, chain[0], extra, inconclusive)
                if flake:
                    log(f"carrier #{carrier}: {flake} — re-ran once before blaming #{n}, in flight")
                    summary["rerun"].append(carrier)
                    summary["in_flight"] = True
                    carrier_in_flight = True
                    continue
                gh.post_status(head, "failure", culprit_description(failing, chain[0]))
                summary["culprits"].append(n)
                # A train member was admitted with every required context green on its OWN head. If that
                # head is behind the main it was trained over, the red is most likely a rule main gained
                # after the PR's CI ran (#15254: a chart bump green against a main without the ADR-0366
                # lock). Waiting for a push leaves it stuck until someone diagnoses it from the carrier;
                # one update-branch moves its CI onto today's main, where the author sees the failure on
                # the PR itself. No loop: afterwards the merge-base is that main, and a culprit that is
                # not behind main gets the ordinary message and waits for a push.
                # One refresh per lineage: a head that was itself refreshed, or whose first parent was
                # (the head update-branch produced), is never refreshed again, however often main moves
                # under it — the same first-parent rule as deferral_used. A separate summary key keeps
                # these out of STALE_RED_CAP, which bounds the stale-red refresh below.
                behind = git("merge-base", "--is-ancestor", chain[0], head, check=False).returncode == 1
                parents = git("rev-list", "--parents", "-n", "1", head, check=False).stdout.split()
                refreshed_before = any(gh.app_statuses(sha).get(STALE_CULPRIT_CONTEXT, ("", ""))[0] == "success"
                                       for sha in [head] + parents[1:2])
                if behind and not refreshed_before and not shadow and gh.update_branch(n, head):
                    gh.post_status(head, "success", f"update-branched once as a culprit behind main {chain[0][:12]}",
                                   context=STALE_CULPRIT_CONTEXT)
                    gh.comment(n, STALE_CULPRIT_MESSAGE)
                    summary["culprit_refreshed"].append(n)
                    log(f"#{n:>6} culprit behind main {chain[0][:12]}: update-branch requested")
                else:
                    gh.comment(n, CULPRIT_MESSAGE)
            else:
                for _n, head in members:
                    gh.post_status(head, "pending", f"bisect size {max(1, len(members) // 2)}")
                summary["bisected"].append([n for n, _ in members])
        gh.close_carrier(carrier)
        if TRAIN_BRANCH_RE.fullmatch(branch):
            Pusher(git, branch, gh.remote).delete()
    if acted:  # a carrier was judged: main or member statuses may have changed — read everything again
        not_fix.update(main_cache.get(NOT_FIX_KEY, {}))
        not_fix_heads.update(main_cache.get(NOT_FIX_HEAD_KEY, {}))
        base, regen_text, strict, red, cands, apps, main_red, main_cache = settle_view(gh, git, repo, required, stuck)
        relevant = served_relevant_fixes(gh, git, base, strict, main_red, main_cache)
        urgent = urgent_expire(gh, strict, urgent_prs(gh, repo, strict, urgent_cap), time.time(), shadow)
        preempted = []
        holder, timed_out = strict_reservation(git, base, strict, shadow,
                                               fixes=strict_fixes(gh, git, base, strict, main_red, main_cache),
                                               activity=gh.ci_activity, relevant=relevant,
                                               urgent=urgent, preempted=preempted, main_red=bool(main_red))
    summary["main_red"] = sorted(main_red)
    if urgent:
        summary["urgent"] = sorted(urgent)
    post_urgent_marks(gh, strict, preempted, shadow)
    if preempted:
        summary["urgent_preempted"] = sorted(set(preempted))
    # An admitted urgent PR the lane can actually serve this tick (urgent_pick) outranks the train's and the
    # fast lane's turns, and is served by update-branch rather than batched into a strict carrier. Its clock
    # starts now (urgent_stamp), bounding how long it may hold the other lanes back (urgent_expire).
    urgent_now = urgent_pick(git, base, strict, urgent, holder, bool(main_red), carrier_in_flight)
    urgent_stamp(gh, strict, urgent_now, time.time(), shadow)
    if urgent_now is not None:
        summary["urgent_pick"] = urgent_now
    fragments = regen_inventory_fragments(regen_text)
    fast, train_waiting = partition(git, base, cands, fragments)
    # While main is red no train is built (plan_train serves only fixes), so the train's turn after a strict
    # merge would hold the strict lane, which is the lane that serves the fix, for TRAIN_TURN_S with nobody
    # using it; every further strict or bot merge restarted that wait (2026-11-13: fixes #15991/#15987 sat
    # behind "train's turn" for ~2 h of red main). An open carrier still keeps its turn.
    yield_why = train_turn(gh, git, base, train_waiting,
                           any(is_carrier(p, repo) and carrier_holds_strict(p) for p in gh.open_prs()), main_red=main_red)
    yield_why = urgent_yield(yield_why, urgent_now)
    if holder is None and not yield_why and not main_red and urgent_now is None:
        # A reservation already running is never affected; the fast lane only gets the gap between two.
        yield_why = fast_turn(gh, git, base,
                              [m for m in fast if apps.get(m.number, {}).get(STATUS_CONTEXT, ("",))[0] != "success"],
                              bool(timed_out), shadow)
    if timed_out:
        summary["timed_out"] = timed_out
        # Released: never reserving again on that head (RELEASED_CONTEXT, read back by
        # strict_reservation on later ticks), and served after every other strict-lane PR.
        strict.sort(key=lambda sv: sv[1]["number"] in timed_out)
        for _st, view in strict:
            if (not shadow and view["number"] in timed_out
                    and RELEASED_CONTEXT not in (view.get("app") or {})):
                gh.post_status(view["head_sha"], "success",
                               "strict lane: reservation timed out on this head; it does not reserve main again",
                               context=RELEASED_CONTEXT)
                view.setdefault("app", {})[RELEASED_CONTEXT] = ("success", "")
    # Strict carrier (ADR-0343 amendment 2026-11-05): when the strict lane is free — no holder, no carrier of
    # either kind, main green, no turn owed to the train or the fast lane, no green strict PR already
    # current (strict_lane merges that one this tick and main moves) — the green strict PRs that are behind
    # main ride ONE execution-free carrier instead of taking a 2.4 h update-branch slot each. STRICT_BATCH_CAP
    # 1 (or no run id) keeps today's behaviour exactly.
    if (not strict_carrier_open and not shadow and strict_cap >= 2 and run_id and attempt and holder is None
            and urgent_now is None and not main_red and not yield_why and not carrier_in_flight and not any_carrier_open(gh, repo)
            and not summary.get("strict_tree_mismatch")
            and not any(st == "green" and git("merge-base", "--is-ancestor", base, v["head_sha"], check=False).returncode == 0
                        for st, v in strict)):
        fixes = strict_fixes(gh, git, base, strict, main_red, main_cache)
        views = strict_batch_views(gh, git, base, strict, fixes, summary)
        if views:
            refs = referenced_scripts(git, base)
            own_code = train_code_paths(git, base)
            leaf_modules = shareable_modules(git, base)
            built = build_strict_carrier(git, base, views, strict_cap, lambda f: judge_path(f, refs),
                                         regen_inventory_fragments(regen_text), derived_output_patterns(regen_text),
                                         judge_cap=judge_cap,
                                         alone_is=lambda f: f in own_code or config_judge_path(f, refs, leaf_modules),
                                         member_alone=lambda h, fs: member_test_reaches_out(git, h, fs))
            if built:
                carrier = publish_strict_carrier(gh, git, base, built[0], built[1], run_id, attempt)
                if carrier is not None:
                    strict_carrier_open, carrier_in_flight = True, True
                    summary["in_flight"] = True
                    summary["strict_carrier"] = carrier
                    summary["strict_batch"] = [n for n, _ in built[1]]
    if strict_carrier_open:
        yield_why = yield_why or "a strict carrier is open over main"
    # Strict lane first: an update-branch it issues starts a reservation THIS tick, so the fast lane
    # below must already see it.
    strict_lane(gh, git, base, strict, carrier_in_flight, shadow, summary, main_red, main_cache, holder, timed_out,
                yield_why, relevant=relevant, urgent=urgent)
    not_fix.update(main_cache.get(NOT_FIX_KEY, {}))
    not_fix_heads.update(main_cache.get(NOT_FIX_HEAD_KEY, {}))
    if not_fix:
        summary["not_fix"] = dict(sorted(not_fix.items()))
        posted = publish_fix_claims(gh, base, not_fix, not_fix_heads, shadow)
        if posted:
            summary["fix_claim_posted"] = posted
    if summary.get("main_health_deferred"):
        return summary
    stack_head = next((v["head_sha"] for st, v in strict if v["number"] == holder and st == "pending"), None)
    if (stack and not shadow and stack_head and not carrier_in_flight and not summary["updated"]
            and not summary["strict"] and train_waiting and not main_red and not any_carrier_open(gh, repo)
            and stack_target_problem(gh, git, base, holder, stack_head, main_red) is None):
        # Speculative stacking: the carrier is built as today and publish stacks it over the holder's
        # running up-to-date head instead of over main; the holder is never pre-empted (no deferral used).
        log(f"strict-lane #{holder} CI running on {stack_head[:12]}: the train carrier may be stacked over it")
        summary["in_flight"] = False
        summary["stack_window"] = (holder, stack_head)
    elif (holder is not None and not carrier_in_flight and not summary["updated"] and not summary["strict"]
            and train_waiting and not main_red and not any_carrier_open(gh, repo)
            and deferral_state(gh, git, strict, holder) == "open"):
        # Bounded deferral (#13400): the running reservation lets ONE carrier be built from green
        # candidates during its CI; publish records the yield on the strict head (DEFER_CONTEXT).
        log(f"strict-lane #{holder} CI running, no deferral yet: a carrier may be built during it (bounded deferral)")
        summary["in_flight"] = False
        summary["deferral_window"] = holder
    elif (holder is None and len(summary["updated"]) == 1 and not carrier_in_flight and not summary["strict"]
            and train_waiting and not main_red and not any_carrier_open(gh, repo)
            and update_opens_deferral(gh, git, strict, summary["updated"][0])):
        # Overlap from the update tick (#13400): the update-branch just issued starts a reservation over
        # THIS main, and its one deferral is still unused, so the carrier is built over the same main in
        # this tick instead of the next one. Measured 2026-10-26 16:06-17:14Z: every update-branch tick
        # reported in_flight and built nothing, so the fast lane lost one whole tick per reservation.
        # Publish records the yield on the updated head (record_deferral: head contains the carrier's
        # base, CI pending), which then inherits it through its first parent on any re-update — the same
        # one-yield bound as above, so the strict PR is never pre-empted twice.
        n = summary["updated"][0]
        log(f"strict-lane #{n} update-branch requested over {base[:12]}, no deferral yet: a carrier may be built "
            f"over the same main during its CI (bounded deferral)")
        summary["in_flight"] = False
        summary["deferral_window"] = n
    if (expedite and not shadow and pending_carrier is not None and summary["in_flight"]
            and holder is None and not strict_carrier_open and not main_red
            and not summary["updated"] and not summary["strict"] and not summary["merged"]
            and not summary.get("stack_window") and not summary.get("deferral_window")):
        n = expedite_candidate(gh, git, repo, train_waiting, expedite_cap, base)
        if n is not None:
            log(f"expedite lane: #{n} may ride its own carrier over main {base[:12]} beside carrier #{pending_carrier}")
            summary["in_flight"] = False
            summary["expedite_window"] = n
            # The window is recorded on the head it was opened for, naming this main (#16874): if the lane
            # builds nothing from it (a deferred one-member train), the next tick passes this head over.
            head = next((m.head_sha for m in train_waiting if m.number == n), None)
            desc = f"expedite window over main {base}"
            if head and gh.app_statuses(head).get(EXPEDITE_WINDOW_CONTEXT, ("", "")) != ("success", desc):
                gh.post_status(head, "success", desc, context=EXPEDITE_WINDOW_CONTEXT)
    # Strict priority (#15827): a holder GREEN on a head that contains live main but not merged in this
    # tick's strict_lane (a train in flight, merge refused, source intent re-read, main moved under the
    # read) would be pushed behind main by the next carrier and restart its full CI. For ONE tick per
    # holder head no carrier is built, so the holder merges next tick; the marker bounds the hold, so a
    # holder that still cannot merge never stalls the fast lane twice.
    train_open = next((p["number"] for p in gh.open_prs() if is_carrier(p, repo)), None)
    ready = next((v for st, v in strict if v["number"] == holder and st == "green"), None)
    # An open carrier already blocks every publish; the hold is for the NEXT carrier only.
    if (ready is not None and not shadow and holder not in summary["merged"] and not summary["in_flight"]
            and train_open is None and not strict_carrier_open
            and git("merge-base", "--is-ancestor", gh.main_sha(), ready["head_sha"], check=False).returncode == 0):
        if gh.app_statuses(ready["head_sha"]).get(STRICT_READY_CONTEXT, ("", ""))[0] != "success":
            gh.post_status(ready["head_sha"], "success", f"no carrier built for one tick over main {base[:12]}",
                           context=STRICT_READY_CONTEXT)
            log(f"strict-lane #{holder} green and up to date but not merged this tick: no carrier is built this tick "
                f"(strict priority, once per head)")
            summary["in_flight"] = True
            summary["strict_ready_hold"] = holder
        else:
            log(f"strict-lane #{holder} green and up to date, already held a tick for it — the fast lane proceeds")
    # Fast lane, from live data only — nothing here reads a stored classification. Held while main is
    # reserved for a strict-lane PR (or was just moved by one): GitHub auto-merge acts on this status,
    # and a merge now would put the reserved head behind main again. Held as well while a train carrier
    # is open (#15827): a disjoint PR released by native auto-merge moves main under the carrier, and
    # settle then rejects the green carrier as "main moved since publish" — the carrier always lost.
    train_open = next((p["number"] for p in gh.open_prs() if is_carrier(p, repo)), None)   # re-read: may have changed
    hold = (f"main reserved for strict-lane #{holder}" if holder is not None
            else f"a strict carrier is open over main (#{summary.get('strict_carrier', '?')})" if strict_carrier_open
            else "strict-lane update-branch requested" if summary["updated"]
            else "a strict-lane PR merged; main moved" if summary["strict"]
            else f"train carrier #{train_open} is in flight over main" if train_open is not None else None)
    for m in fast:
        if hold:
            log(f"#{m.number:>6} fast      held: {hold} — next tick")
            continue
        if apps.get(m.number, {}).get(STATUS_CONTEXT, ("",))[0] != "success":
            gh.post_status(m.head_sha, "success", f"fast lane: disjoint from main {base[:12]} and the batch",
                           source_number=m.number)
        summary["fast"].append(m.number)
    stale_red_refresh(gh, git, base, red, shadow, summary)
    report_stuck(gh, shadow, summary, stuck)
    return summary


def halve_without_verdict(gh, git, branch: str, sha: str) -> list[int]:
    """A carrier closed with NO verdict because a gate overran its budget or was not evaluated
    (#13400): halve the next batch (the ordinary `bisect size N` status) WITHOUT blaming anyone.
    Measured 2026-10-24: security-checklist-money-path judges every member's body in turn, so its time
    grows with the train; the same five members were rebuilt into four carriers (#13768 #13783 #13786
    #13791, ~4.5 h of CI) and each overran the same 20 s budget — rebuilding the identical batch is a
    livelock, a smaller one converges. The status only caps the next batch size: it is no verdict, the
    smaller carrier still needs every required context green, and a single member is never halved.
    Anything unreadable (branch moved, not our own chain) halves nothing — today's behaviour."""
    if git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/merge-train/settle", check=False).returncode != 0:
        return []
    if git("rev-parse", "refs/merge-train/settle", check=False).stdout.strip() != sha:
        return []
    chain = parse_own_chain(git, sha)
    if chain is None or len(chain[1]) < 2:
        return []
    for _n, head in chain[1]:
        gh.post_status(head, "pending", f"bisect size {len(chain[1]) // 2}")
    return [n for n, _ in chain[1]]


def settle_view(gh, git, repo: str, required: list[str], stuck: list | None = None):
    """Live main and every armed PR judged against it: (base, regen_text, strict, red, cands, apps).
    Planning only, so its reads are memoised; every write acts on a live re-read (deciding)."""
    with planning_reads():
        view = _settle_view(gh, git, repo, required)
        if stuck is not None:
            stuck[:] = stuck_prs(gh, repo)
        return view


def _settle_view(gh, git, repo: str, required: list[str]):
    base = live_base(gh, git)
    regen_text = main_regen_text(git, base)
    strict: list = []
    red: list = []
    main_cache: dict = {}
    main_red = main_red_contexts(gh, git, required, base, main_cache)
    if main_red:
        log(f"::notice::main {base[:12]} is red on {', '.join(sorted(main_red))}: no update-branch except onto a fix")
    cands, apps = live_candidates(gh, git, repo, required, base, Untrainable(regen_text, referenced_tests(git, base)),
                                  strict=strict, red=red,
                                  main_red=main_red, cache=main_cache)
    cands = promote_fixes(gh, git, repo, base, cands, strict, main_red, main_cache)
    return base, regen_text, strict, red, cands, apps, main_red, main_cache


def promote_fixes(gh, git, repo: str, base: str, cands: list, strict: list, main_red: dict[str, str],
                  cache: dict | None = None) -> list:
    """Main red (ADR-0343): a train/fast-lane candidate that demonstrably FIXES a main-red context (the
    same test as the strict lane's, fix_contexts) leaves the train and the fast lane and joins the strict
    list as a green fix, so strict_lane serves it first, alone: update-branch, then merge only the
    combined head fix_head_state verified. Returns the candidates that stay. No-op while main is green."""
    if not main_red:
        return cands
    keep = []
    for m in cands:
        view = pr_view(repo, gh.pr(m.number), m.files)
        if view["head_sha"] != m.head_sha:
            keep.append(m)
            continue
        fixed = fix_contexts(gh, git, base, view, main_red, cache, record=False)
        if not fixed:
            keep.append(m)
            continue
        word = strength_word(cache, view, fixed)
        view["strict_why"] = f"fix for {', '.join(fixed)} red on main {base[:12]} ({word})"
        log(f"#{m.number:>6} fix       green over a base red on {', '.join(fixed)} ({word}): served first, alone, "
            "update then verify")
        strict.append(("green", view))
    return keep


def strict_fixes(gh, git, base: str, strict: list, main_red: dict[str, str], cache: dict | None = None) -> dict[int, list[str]]:
    """Green strict-lane PRs that demonstrably fix a main-red context (see fix_contexts): number -> contexts."""
    if not main_red:
        return {}
    out: dict[int, list[str]] = {}
    for state, view in strict:
        if state == "green":
            fixed = view["fix"] if "fix" in view else fix_contexts(gh, git, base, view, main_red, cache)
            if fixed:
                out[view["number"]] = fixed
    return out


def last_merge_was_strict(gh, git, base: str) -> bool:
    """True when main's head is the squash of a PR this App merged through the strict lane: its
    head carries the App's own `strict lane:` status. Anything unreadable counts as not strict."""
    m = SQUASH_PR_RE.search(git("show", "-s", "--format=%s", base, check=False).stdout.strip())
    if not m:
        return False
    try:
        head = gh.pr(int(m.group(1)))["head"]["sha"]
    except (KeyError, TypeError, ValueError):
        return False
    return gh.app_statuses(head).get(STATUS_CONTEXT, ("", ""))[1].startswith("strict lane:")


def carrier_age_s(p: dict, now: float | None = None) -> float | None:
    """Seconds since the carrier PR was opened (GitHub's created_at), or None when unreadable."""
    try:
        t = datetime.datetime.strptime(p.get("created_at") or "", "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=datetime.timezone.utc)
    except ValueError:
        return None
    return (time.time() if now is None else now) - t.timestamp()


def carrier_holds_strict(p: dict, now: float | None = None) -> bool:
    """A running carrier keeps the strict lane waiting only while younger than CARRIER_PRIORITY_S. An
    unreadable age holds (today's behaviour); a carrier past the bound releases the strict lane."""
    age = carrier_age_s(p, now)
    return age is None or age <= CARRIER_PRIORITY_S


def selftest_deploy_fix(check) -> None:
    """#16943: an App-authored auto-deploy PR may claim a main-red CONTRACT context only on the full
    evidence of deploy_fix_refusal. Built on the real #16940 shape (two image pins, run 44740185064, one
    App commit committed by web-flow, main red on a libs-runtime contract job), then every must-FAIL
    case, then the live path (claim_evidence -> deploy_fix_claim) over a stubbed GitHub and git."""
    AG, CJ = "all-green", "build (openbank-libs-runtime) / openbank-libs-runtime (contract)"
    src, run_id, day = "730965564a4ff9706b4817238ded37e367281c25", 44740185064, "2026-11-20"
    reg = "registry.example"
    pin = lambda sign, svc, tag, c, r=reg: f"{sign}          image: {r}/openbank-{svc}:{tag}@sha256:{c * 64}"
    files = ["openbank-infra/gitops/components/customer-edge/customer-edge.yaml",
             "openbank-infra/gitops/components/payments/payments-services.yaml"]
    entries = [("M", "100644", "100644", f) for f in files]
    def block(f, hunks):
        out = [f"diff --git a/{f} b/{f}", "index 1111111..2222222 100644", f"--- a/{f}", f"+++ b/{f}"]
        for h in hunks:
            out += ["@@ -1 +1 @@"] + h
        return out
    ce = [pin("-", "customer-edge", "sandbox-abaa92c7", "3"), pin("+", "customer-edge", "sandbox-73096556", "0")]
    dp = [pin("-", "domestic-payment", "sandbox-7e9d36e9", "7"), pin("+", "domestic-payment", "sandbox-73096556", "1")]
    mk = lambda ce_h=ce, dp_h=dp, extra=(): "\n".join(block(files[0], [ce_h]) + block(files[1], [dp_h]) + list(extra))
    diff = mk()
    head = "5a25b16b195fa1f74c5720b597437e392ccd71f7"
    view = {"number": 16940, "author": BOT_LOGIN, "head_sha": head,
            "head_ref": f"chore/gitops-auto-deploy-{src}-run{run_id}", "labels": ["chore", "gitops", DEPLOY_FIX_LABEL]}
    main_jobs = {CJ: "failure", AG: "failure", "build (openbank-x)": "success"}
    run = {"id": run_id, "path": AUTO_DEPLOY_WORKFLOW, "head_sha": src, "head_branch": "main"}
    run_jobs = {"Detect changed services": "success", "Build + push": "success", "can-i-deploy": "success",
                "Gitops PR": "success", "Push failures": "skipped"}
    bot_commit = {"sha": head, "author": BOT_LOGIN, "committer": "web-flow", "verified": True,
                  "date": f"{day}T13:07:43Z", "parents": 1}
    label_at = f"{day}T13:30:00Z"
    base = dict(view=view, ctx=AG, main_jobs=main_jobs, entries=entries, diff=diff, run=run, run_jobs=run_jobs,
                src_on_main=True, label_why=None, commits=[bot_commit], label_at=label_at)
    got = deploy_fix_refusal(**base)
    check("deploy fix: the real #16940 shape is admitted", got is None, str(got))
    update_merge = {**bot_commit, "sha": "c" * 40, "date": f"{day}T14:00:00Z", "parents": 2}
    got = deploy_fix_refusal(**{**base, "commits": [bot_commit, update_merge]})
    check("deploy fix: the train's own update-branch merge after the label still admits", got is None, str(got))
    human = {**bot_commit, "sha": "d" * 40, "author": "JiRaska", "committer": "JiRaska", "date": f"{day}T14:00:00Z"}
    # The real shape of a train update-branch merge (#16719's 68c7fffab4, #16947).
    updater_merge = {**update_merge, "author": BRANCH_UPDATER_LOGIN, "committer": "web-flow", "verified": True}
    got = deploy_fix_refusal(**{**base, "commits": [bot_commit, updater_merge]})
    check("deploy fix: the branch-updater App's real update-branch merge admits", got is None, str(got))
    for label, change, want in [
        ("a non-bot author", {"view": {**view, "author": "JiRaska"}}, "is not"),
        ("an unknown author", {"view": {k: v for k, v in view.items() if k != "author"}}, "is not"),
        ("a branch that is not auto-deploy's", {"view": {**view, "head_ref": "agent/pins"}}, "not an auto-deploy"),
        ("an extra file outside gitops", {"entries": entries + [("M", "100644", "100644", ".github/scripts/merge-train.py")]},
         "not a gitops image-pin file"),
        ("an extra non-yaml gitops file", {"entries": entries + [("M", "100644", "100644", "openbank-infra/gitops/components/x/run.sh")]},
         "not a gitops"),
        ("a new file", {"entries": entries + [("A", "000000", "100644", "openbank-infra/gitops/components/x/new.yaml")]}, "plain modification"),
        ("a deleted file", {"entries": [("D", "100644", "000000", files[0]), entries[1]]}, "plain modification"),
        ("a renamed file", {"entries": [("R100", "100644", "100644", files[0]), entries[1]]}, "plain modification"),
        ("a mode change", {"entries": [("M", "100644", "100755", files[0]), entries[1]]}, "plain modification"),
        ("a new-file header in the diff", {"diff": mk(extra=block("openbank-infra/gitops/components/x/n.yaml", [])[:1]
                                                        + ["new file mode 100644"])}, "plain modification"),
        ("an extra non-pin line in a gitops file", {"diff": mk(ce_h=ce + ["+          replicas: 3"])}, "not an image pin"),
        ("an added `++evil: true` line", {"diff": mk(ce_h=[ce[0], "+++evil: true", ce[1]])}, "not an image pin"),
        ("a removed `---` YAML separator", {"diff": mk(ce_h=[ce[0], "----", ce[1]])}, "not an image pin"),
        ("a pin moved to a foreign registry host",
         {"diff": mk(ce_h=[ce[0], pin("+", "customer-edge", "sandbox-73096556", "0", "evil.example")])}, "registry or repository"),
        ("an unreadable diff", {"diff": None}, "unreadable"),
        ("unreadable files", {"entries": None}, "unreadable"),
        ("a pin not built from the run's source (carried)",
         {"diff": mk(dp_h=[dp[0], pin("+", "domestic-payment", "sandbox-deadbeef", "1")])}, "not built from"),
        ("a pin added for a service it did not remove",
         {"diff": mk(dp_h=[dp[0], pin("+", "ledger", "sandbox-73096556", "1")])}, "registry or repository"),
        ("a human commit pushed after the label", {"commits": [bot_commit, human]}, "not the App's verified commit"),
        ("an unverified App-authored commit", {"commits": [{**bot_commit, "verified": False}]}, "not the App's verified"),
        ("an App-authored commit committed by a human", {"commits": [{**bot_commit, "committer": "JiRaska"}]}, "not the App's"),
        ("a human-authored merge", {"commits": [bot_commit, {**updater_merge, "author": "JiRaska"}]}, "not the App's verified"),
        ("an unverified branch-updater merge", {"commits": [bot_commit, {**updater_merge, "verified": False}]}, "not the App's verified"),
        ("a merge by another App", {"commits": [bot_commit, {**updater_merge, "author": "dependabot[bot]"}]}, "not the App's verified"),
        ("a non-merge commit by the branch-updater App",
         {"commits": [bot_commit, {**updater_merge, "parents": 1}]}, "not the App's verified"),
        ("unreadable commits", {"commits": None}, "unreadable"),
        ("a label applied before the last push", {"label_at": f"{day}T13:00:00Z"}, "before the last commit"),
        ("an unreadable label time", {"label_at": None}, "unreadable"),
        ("a missing can-i-deploy job", {"run_jobs": {k: v for k, v in run_jobs.items() if k != "can-i-deploy"}}, "can-i-deploy"),
        ("a failed can-i-deploy job", {"run_jobs": {**run_jobs, "can-i-deploy": "failure"}}, "can-i-deploy"),
        ("a can-i-deploy still running", {"run_jobs": {**run_jobs, "can-i-deploy": None}}, "can-i-deploy"),
        ("unreadable run jobs", {"run_jobs": None}, "can-i-deploy"),
        ("an unreadable run", {"run": None}, "unreadable"),
        ("a run of another workflow", {"run": {**run, "path": ".github/workflows/ci.yml"}}, "is not"),
        ("a run over another commit", {"run": {**run, "head_sha": "f" * 40}}, "is not"),
        ("a run over another branch", {"run": {**run, "head_branch": "agent/x"}}, "is not"),
        ("a run id that does not match the branch", {"run": {**run, "id": run_id + 1}}, "is not"),
        ("a source not on main", {"src_on_main": False}, "not on main"),
        ("main red on an unrelated, non-contract job (unrelated service)",
         {"main_jobs": {**main_jobs, "build (openbank-ledger-service)": "failure"}}, "not a contract job"),
        ("main red only on the aggregate", {"main_jobs": {AG: "failure", CJ: "success"}}, "no failed job"),
        ("no job record for main", {"main_jobs": None}, "no job record"),
        ("a missing or refused owner label", {"label_why": f"no readable {DEPLOY_FIX_LABEL} label event"}, "label"),
    ]:
        got = deploy_fix_refusal(**{**base, **change})
        check(f"deploy fix must FAIL: {label}", got is not None and want in got, str(got))

    # Live path: claim_evidence over a stub GitHub/git. The job rule refuses (the contract job is absent
    # on the head), the deploy path admits — and refuses again without the label or without its grant.
    class G:
        repo = "JiRaska/open-bank-oss"
        def __init__(self, events, grants, cid="success", commits=(bot_commit,)):
            self.events, self.grants, self.cid, self.commits = events, grants, cid, list(commits)
        def ctx_jobs(self, sha, ctx):
            return main_jobs if sha == "m" * 40 else {AG: "success"}
        def workflow_run(self, rid):
            return run if rid == run_id else None
        def run_jobs(self, rid):
            return {**run_jobs, "can-i-deploy": self.cid} if rid == run_id else None
        def compare_commits(self, mb, h):
            return self.commits if (mb, h) == (src, head) else None
        def issue_events(self, n):
            return self.events
        def urgent_grants_today(self, d, owner, label=URGENT_LABEL):
            return self.grants if label == DEPLOY_FIX_LABEL else {}

    class R:
        def __init__(self, out="", rc=0):
            self.stdout, self.returncode = out, rc
    raw = "".join(f":100644 100644 {'a' * 7} {'b' * 7} M\0{f}\0" for f in files)
    def git(*args, check=True):
        if args[0] == "diff" and "--raw" in args:
            return R(raw)
        if args[0] == "diff":
            return R(diff)
        if args[:2] == ("merge-base", "--is-ancestor"):
            return R("", 0 if args[2] == src else 1)
        if args[0] == "merge-base":
            return R(src + "\n")
        return R("", 1)
    owner_ev = [{"event": "labeled", "label": {"name": DEPLOY_FIX_LABEL}, "actor": {"login": "JiRaska"},
                 "created_at": label_at}]
    grant = {16940: label_at}
    now = datetime.datetime(2026, 11, 20, 15, tzinfo=datetime.timezone.utc).timestamp()
    def live(gh, v=view):
        cache: dict = {}
        why = fix_evidence(gh, git, "b" * 40, AG, "m" * 40, v["head_sha"], cache)
        d = deploy_fix_claim(gh, git, "b" * 40, AG, "m" * 40, v, cache, now=now)
        return why, d
    why, d = live(G(owner_ev, grant))
    check("deploy fix live: the job rule alone refuses #16940 (the deadlock)", why is not None and "absent" in why, str(why))
    check("deploy fix live: the owner-labelled #16940 shape is admitted", d is None, str(d))
    _w, d = live(G([{**owner_ev[0], "actor": {"login": "some-agent"}}], {}))
    check("deploy fix live must FAIL: label applied by someone other than the owner", d is not None and "not the repo owner" in d, str(d))
    _w, d = live(G(owner_ev, {1: f"{day}T09:00:00Z", **grant}))
    check("deploy fix live must FAIL: over the daily cap", d is not None and "daily cap" in d, str(d))
    _w, d = live(G(owner_ev, None))
    check("deploy fix live must FAIL: grants not enumerable", d is not None and "enumerated" in d, str(d))
    _w, d = live(G(owner_ev, grant, cid="failure"))
    check("deploy fix live must FAIL: can-i-deploy failed in the run", d is not None and "can-i-deploy" in d, str(d))
    _w, d = live(G(owner_ev, grant, commits=[bot_commit, human]))
    check("deploy fix live must FAIL: a human commit pushed after the label", d is not None and "verified commit" in d, str(d))
    _w, d = live(G(owner_ev, grant, commits=[{**bot_commit, "date": f"{day}T14:00:00Z"}]))
    check("deploy fix live must FAIL: the label predates the last push", d is not None and "before the last commit" in d, str(d))
    d = deploy_fix_claim(G(owner_ev, grant), git, "b" * 40, AG, "m" * 40, {**view, "labels": ["chore", "gitops"]}, {}, now=now)
    check("deploy fix live must FAIL: no label", d is not None and DEPLOY_FIX_LABEL in d, str(d))
    gh = G(owner_ev, grant)
    cache: dict = {}
    check("deploy fix live: claim_evidence admits and records a job-level strength",
          claim_evidence(gh, git, "b" * 40, AG, "m" * 40, view, cache, now=now) is None
          and cache.get((FIX_STRENGTH_KEY, view["head_sha"], AG), (0,))[0] == FIX_JOB_LEVEL)
    w = claim_evidence(gh, git, "b" * 40, AG, "m" * 40, {**view, "author": "JiRaska"}, {}, now=now)
    check("deploy fix live must FAIL: claim_evidence keeps the job-rule refusal for a non-bot author",
          w is not None and "deploy fix" not in w, str(w))


def selftest_skip_fix_self_test(check) -> None:
    """A head green on a gate shard whose red on main is a SELF-TEST (unfalsified) is a fix only if its
    own run executed that self-test (2026-11-17: #16627/#16644 served as fixes of
    `event-contract-code-agreement`, which their shard jobs never ran). Pure rule first, then the live
    path (fix_contexts -> fix_evidence) over a stubbed GitHub and git, then the declaration parser and
    the universal-input mirror against the real runner."""
    MR = "Validate manifests"
    main_jobs = {MR: "failure", "gates (data)": "failure"}
    unf = {"data": [{"id": "g1", "status": "unfalsified", "failure_kind": "unfalsified"}]}
    content = {"data": [{"id": "g1", "status": "failed", "failure_kind": "content"}]}
    decl = {"g1": [".github/scripts/check-g1.py", "openbank-x/src/"], "g2": []}
    for label, records, files, declared, want in [
        ("unfalsified gate, head changed no declared input -> refused", unf, ["openbank-y/Foo.kt"], decl, "skipped on the head"),
        ("unfalsified gate, head changed the gate script -> accepted", unf, [".github/scripts/check-g1.py"], decl, None),
        ("unfalsified gate, head changed a file under a declared dir -> accepted", unf, ["openbank-x/src/a/B.kt"], decl, None),
        ("unfalsified gate, head changed a universal input -> accepted", unf, [".github/gates/gates.yaml"], decl, None),
        ("unfalsified gate that declares no inputs (always runs) -> accepted",
         {"data": [{"id": "g2", "status": "unfalsified", "failure_kind": "unfalsified"}]}, ["openbank-y/Foo.kt"], decl, None),
        ("content failure on the shard -> unchanged, accepted", content, ["openbank-y/Foo.kt"], decl, None),
        ("records of main's run unreadable -> refused", None, [".github/scripts/check-g1.py"], decl, "unreadable"),
        ("the red shard's artifact unreadable -> refused", {"data": None}, ["openbank-y/Foo.kt"], decl, "unreadable"),
        ("gates.yaml unreadable on the head -> refused", unf, ["openbank-y/Foo.kt"], None, "unreadable on the head"),
        ("gate not declared on the head -> refused", unf, ["openbank-y/Foo.kt"], {"g2": []}, "never ran there"),
        ("a prefix that is not a path component is not a match", unf, ["openbank-xy/src/a.kt"], decl, "skipped on the head"),
    ]:
        got = selftest_skip_refusal(main_jobs, records, files, declared)
        check(f"self-test skip: {label}", (got is None) if want is None else (got is not None and want in got), str(got))
    check("self-test skip: no gate shard failed on main -> nothing read, accepted",
          selftest_skip_refusal({MR: "failure", "Admin UI": "failure"}, None, [], None) is None)
    check("self-test skip: an unfalsified record is found by failure_kind as well as status",
          "skipped on the head" in (selftest_skip_refusal(
              main_jobs, {"data": [{"id": "g1", "status": "failed", "failure_kind": "unfalsified"}]}, ["x"], decl) or ""))

    # The live path: fix_contexts over a stubbed GitHub and git.
    main_c, head, mb = "m" * 40, "h" * 40, "b" * 40
    gates_text = ("gates:\n  - id: g1\n    selftest: |\n      x\n"
                  "    selftest_inputs:\n      - \".github/scripts/check-g1.py\"\n      - openbank-x/src/\n"
                  "  - id: g2\n    selftest: |\n      y\n")

    class _R:
        def __init__(self, rc=0, out=""):
            self.returncode, self.stdout = rc, out

    def mk_git(files, gates=gates_text):
        def git(*a, **_k):
            if a[0] == "merge-base":
                return _R(0, mb)
            if a[0] == "show" and a[1] == f"{head}:{GATES_YAML}":
                return _R(0 if gates is not None else 128, gates or "")
            if a[0] == "show":
                return _R(0, "merge_train:\n  extra_gates:\n")   # rules.yaml: no extra gates
            if a[0] == "rev-list":
                return _R(0, main_c + "\n")
            if a[0] == "diff":
                return _R(0, "".join(f":100644 100644 a b M\0{f}\0" for f in files))
            return _R(0, "")
        return git

    class _Gh:
        def __init__(self, records):
            self.records, self.reads = records, 0

        def checks(self, sha):
            return {MR: "failure"} if sha == main_c else {MR: "success"}

        def ctx_jobs(self, sha, _ctx):
            return dict(main_jobs) if sha == main_c else {MR: "success", "gates (data)": "success"}

        def extra_checks(self, _sha, _gates):
            return {}

        def gate_shard_records(self, sha, _ctx, slugs):
            if sha != main_c:
                return None   # the head's artifacts are unreadable here: the gate-level rule stands aside
            self.reads += 1
            return None if self.records is None else {s: self.records.get(s) for s in slugs}

    def live(records, files, gates=gates_text):
        gh, cache = _Gh(records), {}
        got = fix_contexts(gh, mk_git(files, gates), mb, {"number": 7, "head_sha": head}, {MR: main_c}, cache)
        return got, (cache.get(NOT_FIX_KEY) or {}).get(7, ""), gh, cache

    got, why, gh, cache = live(unf, ["openbank-y/Foo.kt"])
    check("live: a green head that skipped the red self-test is not a fix, and the reason reaches not_fix",
          got == [] and "self-test of gate `g1`" in why and "skipped on the head" in why, f"{got} {why}")
    check("live: the records are read once per main commit and shared by every context",
          gh.reads == 1 and fix_contexts(gh, mk_git(["openbank-y/Foo.kt"]), mb, {"number": 8, "head_sha": head},
                                         {MR: main_c, "gates (data)": main_c}, cache) == [] and gh.reads == 1, str(gh.reads))
    got, why, gh, _c = live(unf, [".github/scripts/check-g1.py"])
    check("live: a head that changed the red gate's OWN script passes the self-test rule but is refused as a fix by the "
          "judge rule (security review of 7ca5c4a1): it is merged by a human, never by its own verdict",
          got == [] and "changes the judge" in why, f"{got} {why}")
    got, why, gh, _c = live(unf, ["openbank-x/src/k/E.kt"])
    check("live: a block-list declared directory counts — a declared input is a SUBJECT, never judge code, so the head is the fix",
          got == [MR], f"{got} {why}")
    got, why, gh, _c = live(content, ["openbank-y/Foo.kt"])
    check("live: a content failure on the shard keeps today's behaviour (the fix is accepted)", got == [MR], f"{got} {why}")
    got, why, gh, _c = live(None, [".github/scripts/check-g1.py"])
    check("live: an unreadable run fails closed", got == [] and "unreadable" in why, f"{got} {why}")
    got, why, gh, _c = live(unf, ["openbank-y/Foo.kt"], gates=None)
    check("live: gates.yaml unreadable on the head fails closed", got == [] and "unreadable on the head" in why, f"{got} {why}")

    class _GhLeaf(_Gh):
        def ctx_jobs(self, sha, _ctx):
            return {MR: "failure", "Admin UI": "failure"} if sha == main_c else {MR: "success", "Admin UI": "success"}
    gh, cache = _GhLeaf(None), {}
    got = fix_contexts(gh, mk_git(["openbank-y/Foo.kt"]), mb, {"number": 9, "head_sha": head}, {MR: main_c}, cache)
    check("live: a non-gate job red on main (build, Admin UI) is judged by job evidence alone, no artifact read",
          got == [MR] and gh.reads == 0, f"{got} reads={gh.reads}")

    parsed = parse_selftest_inputs(gates_text + "  - id: g3\n    selftest_inputs: ['a/b.py', \"c/\"]  # flow\n"
                                   "  - id: g4\n    selftest_inputs:\n      - d.py   # c\n    run: true\n")
    check("declaration parser: block list, flow list, quotes, comments, and a gate with none",
          parsed == {"g1": [".github/scripts/check-g1.py", "openbank-x/src/"], "g2": [], "g3": ["a/b.py", "c/"], "g4": ["d.py"]},
          str(parsed))
    real = pathlib.Path(GATES_YAML)
    if real.is_file():
        got = parse_selftest_inputs(real.read_text(encoding="utf-8")).get("event-contract-code-agreement")
        check("declaration parser: the real gates.yaml names the event-contract gate's two scripts",
              got is not None and ".github/scripts/check-event-contract-code-agreement.py" in got, str(got))
    runner = pathlib.Path(".github/scripts/run-gates.py")
    if runner.is_file():
        m = re.search(r"^UNIVERSAL_SELFTEST_INPUTS = \((.*?)^\)", runner.read_text(encoding="utf-8"), re.S | re.M)
        theirs = tuple(re.findall(r"\"([^\"]+)\"", re.sub(r"#.*", "", m.group(1)))) if m else None
        check("universal self-test inputs: the train's mirror equals run-gates.py's tuple",
              theirs == UNIVERSAL_SELFTEST_INPUTS, f"runner={theirs} train={UNIVERSAL_SELFTEST_INPUTS}")


def gate_level_fix_self_test(check) -> None:
    """Gate-level fix evidence (ADR-0343 amendment 2026-11-18): a gate red on main is looked up across
    ALL of the head's gate results; `ok` anywhere verifies it, red on the head refuses, skipped/absent only
    caps the strength at job-level (never a refusal that would stall the head's update-branch), with the
    self-test rule kept: an unfalsified self-test the head skipped refuses. Unreadable records, or a red
    shard naming no failed gate, read as job-level — nothing checked, nothing claimed. Fixes are served
    strongest evidence first, then oldest. A head that edits the judge is capped at job-level."""
    MR = "Validate manifests"
    main_c, mb = "m" * 40, "b" * 40
    main_jobs = {MR: "failure", "gates (data)": "failure"}
    red = {"data": [{"id": "adr-registry", "status": "failed", "failure_kind": "content"}]}
    red_self = {"data": [{"id": "adr-registry", "status": "unfalsified", "failure_kind": "unfalsified"}]}
    ok_skipped_st = {"data": [{"id": "adr-registry", "status": "ok", "selftest_skipped": True}]}
    ok = {"data": [{"id": "adr-registry", "status": "ok", "selftest_skipped": False}]}
    V, J = FIX_GATE_VERIFIED, FIX_JOB_LEVEL
    for label, main, head, want_why, want_level, want_word in [
        ("red gate ok on the head -> fix, gate-verified", red, ok, None, V, "gate-verified"),
        ("red gate skipped on the head (full-fleet green job) -> still a fix, job-level", red,
         {"data": [{"id": "adr-registry", "status": "skipped"}]}, None, J, "not ok everywhere"),
        ("duplicate records for the id, one ok and one failed -> RED wins, not a fix", red,
         {"data": [{"id": "adr-registry", "status": "ok"}], "kotlin": [{"id": "adr-registry", "status": "failed"}]}, "red on the head too", None, None),
        ("duplicate records for the id, one ok and one skipped -> not verified, job-level", red,
         {"data": [{"id": "adr-registry", "status": "ok"}], "kotlin": [{"id": "adr-registry", "status": "skipped"}]}, None, J, "not ok everywhere"),
        ("red gate absent from the head's results -> still a fix, job-level", red, {"data": [{"id": "other", "status": "ok"}]},
         None, J, "absent on the head"),
        ("red gate moved to another shard and ok there -> gate-verified", red,
         {"data": [{"id": "other", "status": "ok"}], "kotlin": [{"id": "adr-registry", "status": "ok"}]}, None, V, "gate-verified"),
        ("red gate still red on the head -> not a fix", red, {"data": [{"id": "adr-registry", "status": "failed"}]}, "red on the head too", None, None),
        ("head run unreadable -> job rule stands, job-level", red, None, None, J, "unreadable on the head"),
        ("the shard's head artifact unreadable -> job-level", red, {"data": None}, None, J, "absent on the head"),
        ("MEDIUM-1: a red main shard whose records name no failed gate -> job-level, never verified",
         {"data": [{"id": "adv", "status": "warned"}]}, ok, None, J, "names no failed gate"),
        ("an unreadable main shard -> job-level, never verified", {"data": None}, ok, None, J, "unreadable on main"),
        ("self-test red on main, head ok but its self-test skipped -> not a fix", red_self, ok_skipped_st, "did not run it", None, None),
        ("self-test red on main, head skipped the gate -> not a fix (the #16675 rule)", red_self,
         {"data": [{"id": "adr-registry", "status": "skipped"}]}, "did not run it (skipped)", None, None),
        ("self-test red on main, gate ABSENT on the head -> not a fix either (the rule covers absent)", red_self,
         {"data": [{"id": "other", "status": "ok"}]}, "did not run it (absent)", None, None),
        ("self-test red on main, head ok with its self-test run -> gate-verified", red_self, ok, None, V, "gate-verified"),
        ("two red gates, one ok and one skipped -> job-level (the weakest wins)",
         {"data": [{"id": "a", "status": "failed"}, {"id": "b", "status": "failed"}]},
         {"data": [{"id": "a", "status": "ok"}, {"id": "b", "status": "skipped"}]}, None, J, "gate `b` not ok everywhere"),
    ]:
        why, level, word = gate_level_evidence(main, head)
        check(f"gate evidence: {label}", (why is None and level == want_level and want_word in word) if want_why is None
              else (why is not None and want_why in why), f"why={why} level={level} word={word}")

    base_jobs = {MR: "failure", "gates (data)": "failure", "gates (kotlin)": "success"}
    hjobs = {MR: "success", "gates (data)": "success", "gates (kotlin)": "success"}
    arts = {"data": ok["data"], "kotlin": [{"id": "x", "status": "ok"}], "rogue": [{"id": "adr-registry", "status": "ok"}]}
    kept = trusted_head_records(arts, base_jobs, hjobs)
    check("artifact trust: a shard outside the BASE shard set is ignored even though the head uploaded it",
          kept is not None and set(kept) == {"data", "kotlin"}, str(kept))
    check("artifact trust: a shard whose `gates (<slug>)` job is not green on the head is ignored",
          set(trusted_head_records(arts, base_jobs, {**hjobs, "gates (kotlin)": "failure"})) == {"data"})
    check("artifact trust: unreadable stays unreadable; no base jobs -> nothing trusted",
          trusted_head_records(None, base_jobs, hjobs) is None and trusted_head_records(arts, None, hjobs) == {})
    check("artifact trust: a red gate ok only in a rogue shard is not verified",
          gate_level_evidence(red, trusted_head_records({"rogue": [{"id": "adr-registry", "status": "ok"}]}, base_jobs, hjobs))[1] == J)

    # Live path (fix_contexts -> fix_evidence) over a stubbed GitHub and git.
    A, B, C, D, E, G = "a" * 40, "b" * 39 + "1", "c" * 40, "d" * 40, "e" * 40, "f" * 40
    gates_text = "gates:\n  - id: adr-registry\n    run: python3 .github/scripts/check-adr-registry.py\n"

    class _R:
        def __init__(self, rc=0, out=""):
            self.returncode, self.stdout = rc, out

    files = {A: "docs/adr/0001-x.md", B: "perf/scenarios.yaml", C: "docs/adr/0002-y.md", D: ".github/scripts/check-adr-registry.py",
             E: ".github/workflows/ci.yml", G: "docs/adr/0003-z.md"}

    def git(*a, **_k):
        if a[0] == "merge-base":
            return _R(0, mb)
        if a[0] == "show" and a[1].endswith(f":{GATES_YAML}"):
            return _R(0, gates_text)
        if a[0] == "show":
            return _R(0, "merge_train:\n  extra_gates:\n")
        if a[0] == "rev-list":
            return _R(0, main_c + "\n")
        if a[0] == "diff":
            head = a[-1].split("...")[-1]
            return _R(0, f":100644 100644 a b M\0{files.get(head, 'x')}\0")
        return _R(0, "")

    class _Gh:
        def __init__(self, heads):
            self.heads, self.reads = heads, []

        def checks(self, sha):
            return {MR: "failure"} if sha == main_c else {MR: "success"}

        def ctx_jobs(self, sha, _ctx):
            return dict(main_jobs) if sha == main_c else {MR: "success", "gates (data)": "success"}

        def extra_checks(self, _sha, _gates):
            return {}

        def gate_shard_records(self, sha, _ctx, slugs):   # noqa: D401
            self.reads.append(sha)
            recs = red if sha == main_c else self.heads.get(sha)
            if recs is None:
                return None
            return dict(recs) if slugs is None else {s: recs.get(s) for s in slugs}

    heads = {A: {"data": [{"id": "adr-registry", "status": "ok"}]},          # #16690: ran and passed the gate
             B: {"data": [{"id": "adr-registry", "status": "skipped"}]},     # full-fleet CI, gate skipped
             C: None,                                                         # artifacts unreadable
             D: {"data": [{"id": "adr-registry", "status": "ok"}]},          # ok, but edits the gate's script
             E: {"data": [{"id": "adr-registry", "status": "ok"}]},          # ok, but edits a workflow
             G: {"rogue": [{"id": "adr-registry", "status": "ok"}]}}         # ok only in a shard main never ran
    gh, cache = _Gh(heads), {}
    def claim(n, head):
        return fix_contexts(gh, git, mb, {"number": n, "head_sha": head, "created_at": f"2026-01-{n:02d}"}, {MR: main_c}, cache)
    def rec(head):
        return cache.get((FIX_STRENGTH_KEY, head, MR), (None, ""))
    got_a, got_b, got_c, got_d, got_e, got_g = claim(2, A), claim(1, B), claim(3, C), claim(4, D), claim(5, E), claim(6, G)
    check("live: the head that ran the red gate green is the fix, gate-verified",
          got_a == [MR] and rec(A) == (V, "gate-verified"), f"{got_a} {rec(A)}")
    check("live: the full-fleet head whose green job skipped the red gate stays a fix, job-level, not refused",
          got_b == [MR] and rec(B)[0] == J and "not ok everywhere" in rec(B)[1] and 1 not in cache.get(NOT_FIX_KEY, {}), f"{got_b} {rec(B)}")
    check("live: unreadable head artifacts fall back to the job rule unchanged, job-level",
          got_c == [MR] and rec(C)[0] == J and "unreadable" in rec(C)[1], f"{got_c} {rec(C)}")
    nf = cache.get(NOT_FIX_KEY, {})
    check("judge: a head that edits the red gate's own script is REFUSED as a fix even though the gate is ok",
          got_d == [] and "changes the judge" in nf.get(4, ""), f"{got_d} {nf.get(4)}")
    check("judge: a head that edits a workflow is REFUSED as a fix", got_e == [] and "changes the judge" in nf.get(5, ""), f"{got_e} {nf.get(5)}")
    check("artifact trust (live): a red gate ok only in a shard outside the base set is job-level, not verified",
          got_g == [MR] and rec(G)[0] == J and "absent" in rec(G)[1], f"{got_g} {rec(G)}")
    check("live: main's records are read once, each head's once", gh.reads.count(main_c) == 1 and gh.reads.count(A) == 1
          and gh.reads.count(C) == 1, str(gh.reads))
    strict = [("green", {"number": 1, "head_sha": B, "created_at": "2026-01-01"}),
              ("green", {"number": 3, "head_sha": C, "created_at": "2026-01-03"}),
              ("green", {"number": 2, "head_sha": A, "created_at": "2026-01-02"}),
              ("green", {"number": 9, "head_sha": "9" * 40, "created_at": "2026-01-09"})]
    fixes = {1: [MR], 3: [MR], 2: [MR]}
    order = [v["number"] for _s, v in fixes_first(strict, fixes, cache)]
    check("order: the gate-verified fix is served before older job-level fixes; non-fixes keep their place after",
          order == [2, 1, 3, 9], str(order))
    cache[(FIX_STRENGTH_KEY, C, MR)] = (V, "gate-verified")
    order = [v["number"] for _s, v in fixes_first(strict, fixes, cache)]
    check("order: equal strength -> oldest first", order == [2, 3, 1, 9], str(order))
    check("strength: an unrecorded head reads as job-level", fix_strength({}, {"head_sha": "x"}, [MR]) == J
          and fix_strength(None, {"head_sha": "x"}, []) == J and strength_word({}, {"head_sha": "x"}, [MR]) == "job-level: unrecorded")

    class _GhLeaf(_Gh):
        def ctx_jobs(self, sha, _ctx):
            return {MR: "failure", "Admin UI": "failure"} if sha == main_c else {MR: "success", "Admin UI": "success"}
    gh, cache = _GhLeaf(heads), {}
    got = fix_contexts(gh, git, mb, {"number": 9, "head_sha": A}, {MR: main_c}, cache)
    check("LOW-4: a non-gate job red on main is judged by job evidence alone, no artifact read, worded as such",
          got == [MR] and gh.reads == [] and rec(A) == (J, "job-level (no gate red on main)"), f"{got} reads={gh.reads} {rec(A)}")
    # Follow-ups (review LOWs of #16760) and the HIGH of 75ca372b: the judge is a PREFIX rule, not a parser.
    judge_edits = {"g" * 40: ".github/scripts/gatelib.py", "i" * 40: ".github/actions/setup/action.yml",
                   "2" * 40: ".github/scripts/lib/probe.sh", "4" * 40: ".github/scripts/selftest_input_trace.py",
                   "5" * 40: ".github/gates/selftest-undeclared-inputs.baseline", "6" * 40: ".github/gates/gates.yaml",
                   "7" * 40: ".github/scripts/run-gates.py", "8" * 40: ".github/gates/gate-runtime-measurements.json",
                   "0" * 40: "openbank-libs/governance/rules.yaml"}
    service_edits = {"9" * 40: "openbank-ledger-service/src/main/kotlin/com/openbank/ledger/Foo.kt", "1" * 40: "docs/adr/0009-q.md"}
    files.update(judge_edits); files.update(service_edits)
    for h_ in list(judge_edits) + list(service_edits):
        heads[h_] = {"data": [{"id": "adr-registry", "status": "ok"}]}
    gh, cache = _Gh(heads), {}
    got = {h_: fix_contexts(gh, git, mb, {"number": i + 20, "head_sha": h_}, {MR: main_c}, cache)
           for i, h_ in enumerate(list(judge_edits) + list(service_edits))}
    nf = cache.get(NOT_FIX_KEY, {})
    for i, (h_, path) in enumerate(judge_edits.items()):
        check(f"judge prefix: a head editing {path} is refused as a fix, naming the path",
              got[h_] == [] and "changes the judge" in nf.get(i + 20, "") and path in nf.get(i + 20, ""), f"{got[h_]} {nf.get(i + 20)}")
    for h_ in service_edits:
        check(f"judge prefix: a head editing only {service_edits[h_].split('/')[0]} with the red gate ok is the fix, gate-verified",
              got[h_] == [MR] and rec(h_)[0] == V, f"{got[h_]} {rec(h_)}")
    check("judge prefix: every universal self-test input (the runner's data) lies under the judge prefixes",
          all(p.startswith(FIX_JUDGE_PREFIXES) for p in UNIVERSAL_SELFTEST_INPUTS), str(UNIVERSAL_SELFTEST_INPUTS))
    check("refusal visibility: note_not_fix records the head the refusal is about",
          cache.get(NOT_FIX_HEAD_KEY, {}).get(20) == "g" * 40, str(cache.get(NOT_FIX_HEAD_KEY)))
    # Paths a RED gate's entry names outside .github/ (security review of #16832): tokenised, both revs.
    gates_named = ("gates:\n  - id: adr-registry\n    run: |\n      PYTHONPATH=build-logic/ python3 openbank-infra/scripts/check-db-migration.py --root docs/adr/ > /dev/null\n"
                   "    selftest_inputs: [\"openbank-infra/scripts/lib/db.py\"]\n"
                   "  - id: green-one\n    run: python3 openbank-infra/scripts/other.py\n")
    fs, ds = gate_named_paths(gates_named, {"adr-registry"})
    check("named paths: a red gate's run/selftest yield its files and code-root directories; its selftest_inputs (subjects), a scanned "
          "directory (`--root docs/adr/`) and a green gate's paths do not",
          fs == {"openbank-infra/scripts/check-db-migration.py"} and ds == {"build-logic/"}
          and "openbank-infra/scripts/lib/db.py" not in fs and "openbank-infra/scripts/other.py" not in fs, f"{fs} {ds}")
    fs, ds = gate_named_paths("gates:\n  - id: n\n    run: |\n      PYTHONPATH=a:openbank-infra/scripts python3 ./openbank-infra/scripts/x.py openbank-infra/./scripts/y.py ../up.py /dev/null --root=docs/adr/\n", {"n"})
    check("named paths: `./x`, `a/./b` normalise, `PYTHONPATH=a:dir` splits on `:` (a code root), `..` and absolute tokens are dropped, "
          "`--root=docs/adr/` is a subject",
          fs == {"openbank-infra/scripts/x.py", "openbank-infra/scripts/y.py"} and ds == {"openbank-infra/scripts/"}, f"{fs} {ds}")
    # #16843: a single-segment directory token (`build-logic/`, `docs/`) loses its `/` under normpath and was
    # dropped by PATH_TOKEN_RE; recorded as a directory from the raw token. Both are named here; both hold
    # executed code (a PYTHONPATH root, a `python3 docs/x.py`), so both are judge.
    # stale-ref-ok: docs/x.py is a synthetic self-test input, not a file reference.
    fs, ds = gate_named_paths("gates:\n  - id: n\n    run: PYTHONPATH=build-logic/ python3 docs/x.py --root=docs/\n", {"n"})
    check("named paths (#16843): single-segment directory tokens `PYTHONPATH=build-logic/` and `--root=docs/` are recognised",
          ds == {"build-logic/", "docs/"} and fs == {"docs/x.py"}, f"{fs} {ds}")
    # Review of #16832: a directory a gate SCANS, DIFFS or GENERATES INTO is its subject, never its judge —
    # the real shapes: shellcheck's `for root in ... openbank-infra/scripts`, gen-network-policies-drift-gate's
    # `git diff --exit-code openbank-infra/gitops/components/`, service-runbook-drift's `docs/runbooks/`.
    # A directory counts only when the gate executes code under it: a named script token, a PYTHONPATH
    # root, or `unittest discover -s`. Named FILES always count.
    gates_subject = ("gates:\n  - id: s\n    run: |\n"
                     "      for root in .github/scripts openbank-infra/scripts; do\n"
                     "        shellcheck -S warning $(find \"$root\" -name '*.sh')\n"
                     "      done\n"
                     "  - id: g\n    run: |\n"
                     "      python3 openbank-infra/scripts/gen-network-policies.py\n"
                     "      git add -A --intent-to-add openbank-infra/gitops/components/\n"
                     "      git diff --exit-code openbank-infra/gitops/components/ docs/runbooks/ --root=docs/\n"
                     "  - id: t\n    run: |\n"
                     "      python3 -m unittest discover -s perf/tests -p 'test_*.py'\n"
                     "      # the harness lives in openbank-infra/tests/promtool/ (prose names the directory)\n"
                     "      bash openbank-infra/tests/promtool/run.sh\n"
                     "      ls -s docs/build/\n")
    fs, ds = gate_named_paths(gates_subject, {"s", "g"})
    check("named paths (subject dirs): a scanned (`for root in`), diffed (`git diff`) or generated-into directory is NOT judge; the "
          "executed script still is",
          fs == {"openbank-infra/scripts/gen-network-policies.py"} and ds == set(), f"{fs} {ds}")
    fs, ds = gate_named_paths(gates_subject, {"t"})
    check("named paths (code roots): `unittest discover -s dir` and a directory holding a named `bash dir/run.sh` are judge; "
          "`-s` outside a discover is not",
          fs == {"openbank-infra/tests/promtool/run.sh"} and ds == {"perf/tests/", "openbank-infra/tests/promtool/"}, f"{fs} {ds}")
    # Per gate: the directory red gate `s` SCANS is not made judge by the script red gate `g` executes under it.
    gates_pair = gates_subject.replace("gen-network-policies.py", "x.py").replace("      done\n", "      done\n      echo openbank-infra/scripts/\n")
    fs, ds = gate_named_paths(gates_pair, {"s", "g"})
    check("named paths (per gate): a directory one red gate scans is not judge because ANOTHER red gate executes a script under it",
          "openbank-infra/scripts/" not in ds and fs == {"openbank-infra/scripts/x.py"}, f"{fs} {ds}")
    # Review of #16885: the subject rule was fail-open for directories code runs FROM. Each shape below is a
    # judge directory; each is must-FAIL against the rule that only knew named scripts and code roots.
    real_dirs = {"tools/", "tools/lint/", "pkg/", "pkg/sub/"}
    shapes = [
        ("cd", "cd openbank-infra/tooling && ./run-all", {"openbank-infra/tooling/"}),
        ("make -C", "make -C openbank-infra/make check", {"openbank-infra/make/"}),
        ("-C", "git -C openbank-x/sub status", {"openbank-x/sub/"}),
        ("-p bare segment (gates.yaml selftest shape)", "./gradlew -p build-logic test --build-cache", {"build-logic/"}),
        ("--prefix", "npm --prefix openbank-admin-ui run lint-gate", {"openbank-admin-ui/"}),
        ("--project-dir", "tool --project-dir=perf/proj verify", {"perf/proj/"}),
        ("node dir/", "node openbank-x/gate/ --check", {"openbank-x/gate/"}),
        ("find -exec", "find openbank-x/checks -name '*.t' -exec {} +", {"openbank-x/checks/"}),
        ("xargs", "ls openbank-x/bin | xargs -n1 sh", {"openbank-x/bin/"}),
        ("-m a.b.c", "python3 -m pkg.sub.mod --strict", {"pkg/", "pkg/sub/"}),
        ("bash -c fallback", "bash -c \"$CMD\" openbank-x/opaque/", {"openbank-x/opaque/"}),
        ("eval fallback", "eval \"$X\"; ls openbank-x/also/", {"openbank-x/also/"}),
    ]
    for name, cmd, want in shapes:
        _fs, ds = gate_named_paths(f"gates:\n  - id: q\n    run: {cmd}\n", {"q"}, is_dir=lambda d: d in real_dirs)
        check(f"named paths (#16885 review): `{name}` makes its directory judge", want <= ds, f"{cmd!r}: {ds}")
    fs, ds = gate_named_paths("gates:\n  - id: q\n    run: bash tools/gate/run --all\n", {"q"}, is_dir=lambda d: False)
    check("named paths (#16885 review): an extensionless program `bash tools/gate/run` is an executed FILE, never a (subject) directory",
          fs == {"tools/gate/run"} and ds == set(), f"{fs} {ds}")
    fs, ds = gate_named_paths("gates:\n  - id: q\n    run: ls tools/gate/; bash tools/gate/run\n", {"q"}, is_dir=lambda d: False)
    check("named paths (#16885 review): a named directory holding an extensionless executed program is judge",
          fs == {"tools/gate/run"} and ds == {"tools/gate/"}, f"{fs} {ds}")
    fs, ds = gate_named_paths("gates:\n  - id: q\n    run: python3 -m nopkg.mod; git diff --exit-code docs/runbooks/\n", {"q"},
                              is_dir=lambda d: False)
    check("named paths (#16885 review): `-m` prefixes that are not directories, and a diffed directory, are still not judge",
          ds == set(), f"{fs} {ds}")
    # REAL text: this checkout's own gates.yaml (synthetic fixtures once hid 355/355 UNKNOWN, #16832). The
    # subject directories of the review finding must not be judge; the code roots and named scripts must be.
    real_gates = pathlib.Path(GATES_YAML)
    if real_gates.is_file():
        rtext = real_gates.read_text(encoding="utf-8")
        rids = set(gate_ids(rtext))
        want = {"gen-network-policies-drift-gate", "shellcheck", "service-runbook-drift", "governance-script-unit-tests"}
        rfs, rds = gate_named_paths(rtext, want)
        rfs_net, rds_net = gate_named_paths(rtext, {"gen-network-policies-drift-gate"})
        rfs_sh, rds_sh = gate_named_paths(rtext, {"shellcheck"})
        rfs_rb, rds_rb = gate_named_paths(rtext, {"service-runbook-drift"})
        rfs_gu, rds_gu = gate_named_paths(rtext, {"governance-script-unit-tests"})
        check("real gates.yaml: the four gates of the review finding exist (a renamed gate makes this case vacuous)",
              want <= rids, str(sorted(want - rids)))
        check("real gates.yaml: gen-network-policies-drift-gate names its generator as judge and NOT openbank-infra/gitops/components/",
              "openbank-infra/scripts/gen-network-policies.py" in rfs_net and "openbank-infra/gitops/components/" not in rds_net
              and not any(d.startswith("openbank-infra/gitops/") for d in rds_net), f"{rfs_net} {rds_net}")
        check("real gates.yaml: shellcheck (lints openbank-infra/scripts/) names no judge directory at all",
              rds_sh == set(), f"{rfs_sh} {rds_sh}")
        check("real gates.yaml: service-runbook-drift names its generator, NOT docs/runbooks/",
              "openbank-infra/scripts/generate-service-runbooks.py" in rfs_rb and "docs/runbooks/" not in rds_rb, f"{rfs_rb} {rds_rb}")
        _f, rds_tp = gate_named_paths(rtext, {"test-provenance-cache"})
        check("real gates.yaml: test-provenance-cache's `./gradlew -p build-logic` selftest makes build-logic/ judge (#16885 review)",
              "test-provenance-cache" in rids and "build-logic/" in rds_tp, f"{rds_tp}")
        check("real gates.yaml: governance-script-unit-tests' `unittest discover -s` roots are judge directories",
              {"openbank-infra/scripts/", "perf/tests/"} <= rds_gu, f"{rfs_gu} {rds_gu}")
        all_fs, all_ds = gate_named_paths(rtext, rids)
        check("real gates.yaml: no judge directory is a top-level service, docs or gitops tree (over-refusal is what bit before)",
              not any(d.startswith(("openbank-infra/gitops/", "docs/")) or re.fullmatch(r"openbank-[a-z-]+/src/main/", d) for d in all_ds),
              str(sorted(all_ds)))
    def ngit(*a, **_k):
        if a[0] == "show" and a[1].endswith(f":{GATES_YAML}"):
            return _R(0, gates_named)
        return git(*a, **_k)
    named_edits = {"a" * 39 + "2": "openbank-infra/scripts/check-db-migration.py", "a" * 39 + "3": "docs/adr/0011-under-named-dir.md",
                   "a" * 39 + "4": "openbank-infra/scripts/lib/db.py", "a" * 39 + "5": "openbank-infra/scripts/other.py",
                   "a" * 39 + "9": "build-logic/helper.py"}
    files.update(named_edits)
    for h_ in named_edits:
        heads[h_] = {"data": [{"id": "adr-registry", "status": "ok"}]}
    gh_n, cache_n = _Gh(heads), {}
    got_n = {h_: fix_contexts(gh_n, ngit, mb, {"number": i + 40, "head_sha": h_}, {MR: main_c}, cache_n) for i, h_ in enumerate(named_edits)}
    nf_n = cache_n.get(NOT_FIX_KEY, {})
    check("named paths (live): a head editing the script a RED gate's run names (outside .github/) is refused, naming the path",
          got_n["a" * 39 + "2"] == [] and "check-db-migration.py" in nf_n.get(40, "") and "names in its run/selftest" in nf_n.get(40, ""), f"{got_n['a' * 39 + '2']} {nf_n.get(40)}")
    check("named paths (live): a head editing a file under a directory the red gate merely SCANS (`--root docs/adr/`) is the fix, gate-verified",
          got_n["a" * 39 + "3"] == [MR] and 41 not in nf_n and cache_n.get((FIX_STRENGTH_KEY, "a" * 39 + "3", MR), (0, ""))[0] == V,
          f"{got_n['a' * 39 + '3']} {nf_n.get(41)}")
    check("named paths (live, #16843): a head editing a file under a single-segment code root (`PYTHONPATH=build-logic/`) is refused",
          got_n["a" * 39 + "9"] == [] and "build-logic/helper.py" in nf_n.get(44, "") and "names in its run/selftest" in nf_n.get(44, ""),
          f"{got_n['a' * 39 + '9']} {nf_n.get(44)}")
    check("named paths (live): a head editing a red gate's declared selftest INPUT outside .github/ is still the fix, gate-verified "
          "(subjects are not judge code)",
          got_n["a" * 39 + "4"] == [MR] and 42 not in nf_n and cache_n.get((FIX_STRENGTH_KEY, "a" * 39 + "4", MR), (0, ""))[0] == V,
          f"{got_n['a' * 39 + '4']} {nf_n.get(42)}")
    check("named paths (live): a script named only by a gate GREEN on main does not refuse — still the fix",
          got_n["a" * 39 + "5"] == [MR] and 43 not in nf_n, f"{got_n['a' * 39 + '5']} {nf_n.get(43)}")
    gates_norm = ("gates:\n  - id: adr-registry\n    run: |\n      PYTHONPATH=a:openbank-infra/lib python3 ./openbank-infra/scripts/x.py openbank-infra/./scripts/y.py\n")
    def mgit(*a, **_k):
        if a[0] == "show" and a[1].endswith(f":{GATES_YAML}"):
            return _R(0, gates_norm)
        return git(*a, **_k)
    norm_edits = {"a" * 39 + "6": "openbank-infra/scripts/x.py", "a" * 39 + "7": "openbank-infra/scripts/y.py", "a" * 39 + "8": "openbank-infra/lib/helper.py"}
    files.update(norm_edits)
    for h_ in norm_edits:
        heads[h_] = {"data": [{"id": "adr-registry", "status": "ok"}]}
    gh_m, cache_m = _Gh(heads), {}
    got_m = {h_: fix_contexts(gh_m, mgit, mb, {"number": i + 50, "head_sha": h_}, {MR: main_c}, cache_m) for i, h_ in enumerate(norm_edits)}
    nf_m = cache_m.get(NOT_FIX_KEY, {})
    check("named paths (live): `./openbank-infra/scripts/x.py` in a red gate's run resolves — a head editing x.py is refused",
          got_m["a" * 39 + "6"] == [] and "openbank-infra/scripts/x.py" in nf_m.get(50, ""), f"{got_m['a' * 39 + '6']} {nf_m.get(50)}")
    check("named paths (live): `openbank-infra/./scripts/y.py` resolves — a head editing y.py is refused",
          got_m["a" * 39 + "7"] == [] and "openbank-infra/scripts/y.py" in nf_m.get(51, ""), f"{got_m['a' * 39 + '7']} {nf_m.get(51)}")
    check("named paths (live): `PYTHONPATH=a:openbank-infra/lib` names the directory — a head editing a file under it is refused",
          got_m["a" * 39 + "8"] == [] and "openbank-infra/lib/helper.py" in nf_m.get(52, ""), f"{got_m['a' * 39 + '8']} {nf_m.get(52)}")
    # REAL text, not a synthetic fixture (the HIGH of 75ca372b was invisible to every fixture): the runner on
    # this checkout uses `__file__` in shapes a parser did not follow; the prefix rule needs none of that.
    runner = pathlib.Path(".github/scripts/run-gates.py")
    if runner.is_file():
        text = runner.read_text(encoding="utf-8")
        check("real run-gates.py: it uses `__file__` (the shapes that defeated the parser) and a head editing it is refused by the prefix rule alone",
              text.count("__file__") >= 1 and ".github/scripts/run-gates.py".startswith(FIX_JUDGE_PREFIXES)
              and got["7" * 40] == [] and "run-gates.py" in nf.get(26, ""), f"__file__ x{text.count('__file__')} {nf.get(26)}")

    class _GhMask:
        def __init__(self, jobs):
            self.jobs = jobs
        def ctx_jobs(self, sha, _ctx):
            return self.jobs[sha]
    check("masking: a head with the same failing job as main may be masked",
          masked_no_worse(_GhMask({"m": {MR: "failure", "A": "failure"}, "h": {MR: "failure", "A": "failure"}}), MR, "h", "m", {}))
    check("masking: a head red on the context with NO failing job (inconsistent) never masks",
          not masked_no_worse(_GhMask({"m": {MR: "failure"}, "h": {MR: "success"}}), MR, "h", "m", {}))
    check("masking: a head failing an extra job never masks",
          not masked_no_worse(_GhMask({"m": {MR: "failure"}, "h": {MR: "failure", "B": "failure"}}), MR, "h", "m", {}))

    class _GhPost:
        def __init__(self, existing=None):
            self.existing, self.posted = existing or {}, []
        def app_statuses(self, sha):
            return self.existing.get(sha, {})
        def post_status(self, sha, state, desc, context=STATUS_CONTEXT, **_kw):
            self.posted.append((sha, state, desc, context))
    g = _GhPost()
    p = publish_fix_claims(g, "m" * 40, {5: "the head changes the judge (x)"}, {5: "1" * 40}, shadow=False)
    check("refusal visibility: the reason is posted as the App's merge-train/fix-claim status on the refused head",
          p == [5] and g.posted == [("1" * 40, "failure", "not a fix over main mmmmmmmmmmmm: the head changes the judge (x)", FIX_CLAIM_CONTEXT)], str(g.posted))
    g = _GhPost({"1" * 40: {FIX_CLAIM_CONTEXT: ("failure", "not a fix over main mmmmmmmmmmmm: the head changes the judge (x)")}})
    check("refusal visibility: idempotent — the same reason over the same main posts nothing",
          publish_fix_claims(g, "m" * 40, {5: "the head changes the judge (x)"}, {5: "1" * 40}, False) == [] and g.posted == [])
    check("refusal visibility: shadow posts nothing; a refusal with no recorded head posts nothing",
          publish_fix_claims(_GhPost(), "m" * 40, {5: "x"}, {5: "1" * 40}, True) == [] and publish_fix_claims(_GhPost(), "m" * 40, {5: "x"}, {}, False) == [])


def fix_preempts_strict_self_test(check) -> None:
    """ADR-0343 amendment 2026-11-14: on a red main a fix pre-empts a strict reservation whose CI is still
    running (#15991 behind #16005/#16009, #16096 behind #15976); a GREEN holder, which merges this tick,
    is never interrupted. `fixes` always comes from the real strict_fixes, as live settle computes it.
    git is stubbed: only heads named cur-* contain main."""
    now = 2_000_000_000.0
    red = {"Validate manifests": "failure"}

    class _R:
        def __init__(self, rc=0, out=""):
            self.returncode, self.stdout = rc, out

    def git(*a, **_k):
        if a[:2] == ("merge-base", "--is-ancestor"):
            return _R(0 if a[3].startswith("cur-") else 1)
        if a[:2] == ("show", "-s"):
            return _R(0, str(int(now) - 60))
        return _R(0, "")

    def view(n, head, fix=False, notice=None):
        v = {"number": n, "head_sha": head, "app": {}}
        if fix:
            v["fix"] = ["Validate manifests"]
        if notice:
            v["app"][NOTICE_CONTEXT] = ("success", notice)
        return v

    def reserve(strict):
        return strict_reservation(git, "b", strict, now=now, fixes=strict_fixes(None, git, "b", strict, red))[0]

    strict_cur, strict_green = view(16005, "cur-strict"), view(16005, "cur-strict")
    fix_behind, fix_cur = view(15991, "old-fix", fix=True), view(15991, "cur-fix", fix=True)
    h = reserve([("pending", strict_cur), ("green", fix_behind)])
    check("main red: a green fix pre-empts a strict reservation still in CI", h is None, f"holder={h}")
    h = reserve([("green", strict_green), ("green", fix_behind)])
    check("main red: a strict holder already GREEN (merging this tick) is not interrupted", h == 16005, f"holder={h}")
    h = strict_reservation(git, "b", [("pending", strict_cur)], now=now, fixes=strict_fixes(None, git, "b",
                           [("pending", strict_cur)], {}))[0]
    check("main green: a strict PR in CI still holds main", h == 16005, f"holder={h}")
    # A LONE fix whose combined head is in CI: strict_fixes lists only green PRs, so this is fixes={}.
    h = reserve([("pending", view(15976, "cur-strict2")), ("pending", fix_cur)])
    check("main red: a lone fix in CI on its combined head keeps main over an older strict PR in CI",
          h == 15991, f"holder={h}")
    h = reserve([("pending", fix_cur), ("green", view(15987, "old-fix2", fix=True))])
    check("main red: a fix in CI is not pre-empted by a second green fix", h == 15991, f"holder={h}")
    for told in (f"{CONFLICT_PREFIX}b: strict lane", f"{REFUSED_PREFIX}b (422)"):
        h = reserve([("pending", strict_cur), ("green", view(15991, "old-fix", fix=True, notice=told))])
        check(f"main red: a fix that cannot be served ({told.split()[0]}) pre-empts nothing", h == 16005, f"holder={h}")

    # End to end, as settle wires it: the holder comes from strict_reservation, then strict_lane must
    # update-branch the fix this tick (with a strict holder, every other strict PR is "held").
    class _Gh:
        def __init__(self):
            self.updates = []

        def app_statuses(self, _sha):
            return {}

        def checks(self, _sha):
            return dict(red)

        def update_branch(self, n, _head):
            self.updates.append(n)
            return True

        def __getattr__(self, _name):
            return lambda *a, **k: None

    gh, summary = _Gh(), {}
    strict = [("pending", view(16005, "cur-strict")), ("green", view(15991, "old-fix", fix=True))]
    h = reserve(strict)
    strict_lane(gh, git, "b", strict, False, False, summary, red, {}, holder=h, timed_out=[])
    check("main red: settle's strict lane update-branches the fix while a strict PR's CI runs",
          gh.updates == [15991], f"holder={h} updates={gh.updates} {summary}")

    # 2026-11-17/18: perf PRs #16583/#16602 merged as "fixes" for a stale-ADR-registry red (their CI was green
    # there) and main stayed red; #16586 held main ~1 h as a fix in CI while #16690, which regenerates the
    # ADR files, waited. A fix whose diff touches what broke main is served first and pre-empts the others.
    def fv(n, head, files, fix=True):
        v = view(n, head, fix=fix)
        v["files"] = files
        return v
    dirs = {"docs/adr"}
    perf_ci = fv(16586, "cur-perf", ["perf/scenarios.yaml"])
    regen = fv(16690, "old-regen", ["docs/adr/CURRENT.md", "docs/adr/index.json"])
    strict = [("pending", perf_ci), ("green", regen)]
    fx = strict_fixes(None, git, "b", strict, red)
    rel = relevant_fixes(strict, fx, dirs) & preempting_fixes("b", strict, fx)
    check("main red: only the fix touching the breakage is relevant", rel == {16690}, f"rel={rel}")
    h = strict_reservation(git, "b", strict, now=now, fixes=fx, relevant=rel)[0]
    check("main red: a fix in CI elsewhere is pre-empted by a green fix that touches the breakage",
          h is None, f"holder={h}")
    check("main red: without relevance a fix in CI is still not pre-empted (today's rule kept)",
          strict_reservation(git, "b", strict, now=now, fixes=fx)[0] == 16586)
    gh, summary = _Gh(), {}
    strict_lane(gh, git, "b", strict, False, False, summary, red, {}, holder=h, timed_out=[], relevant=rel)
    check("main red: the relevant fix is update-branched, not the other fix", gh.updates == [16690],
          f"updates={gh.updates} {summary}")
    perf_green = fv(16583, "cur-perf2", ["perf/scenarios.yaml"])

    class _MergeGh(_Gh):
        def __init__(self):
            super().__init__()
            self.merges = []

        def main_sha(self):
            return "b"

        def merge(self, n, _head):
            self.merges.append(n)
            return True
    saved_intent = globals()["live_source_intent"]
    globals()["live_source_intent"] = lambda *_a, **_k: True
    try:
        gh, summary = _MergeGh(), {"merged": []}
        strict_lane(gh, git, "b", [("green", perf_green), ("green", regen)], False, False, summary, red, {},
                    holder=None, timed_out=[], relevant=rel)
    finally:
        globals()["live_source_intent"] = saved_intent
    check("main red: a green up-to-date fix elsewhere does not merge onto red main ahead of the relevant fix",
          gh.merges == [] and gh.updates == [16690], f"merges={gh.merges} updates={gh.updates} {summary}")
    told = fv(16690, "old-regen", regen["files"])
    told["app"][NOTICE_CONTEXT] = ("success", f"{CONFLICT_PREFIX}b: strict lane")
    st2 = [("pending", perf_ci), ("green", told)]
    fx2 = strict_fixes(None, git, "b", st2, red)
    check("main red: a relevant fix that conflicts holds nobody",
          relevant_fixes(st2, fx2, dirs) & preempting_fixes("b", st2, fx2) == set())
    check("main red: unknown breakage ranks nothing", relevant_fixes(strict, fx, None) == set())

    class _Hist:
        def checks(self, c):
            return {"c3": {"Validate manifests": "failure"}, "c2": {"Validate manifests": "failure"},
                    "c1": {"Validate manifests": "success"}}.get(c, {})

    def hgit(*a, **_k):
        if a[0] == "rev-list":
            return _R(0, "c3\nc2\nc1\n")
        if a[0] == "diff":
            return _R(0, "docs/adr/0386-x.md\0" if a[-2:] == ("c1", "c2") else "perf/x\0")
        return _R(0, "")
    check("main red: breakage is the diff from the last green to the FIRST red commit, not to main's tip",
          breakage_dirs(_Hist(), hgit, "c3", red, {}) == {"docs/adr"}, str(breakage_dirs(_Hist(), hgit, "c3", red, {})))


def urgent_strict_self_test(check) -> None:
    """ADR-0343 amendment 2026-11-19 (urgent strict path). 2026-11-19: #16835, a green, up-to-date workflow
    fix, could not merge for hours behind ~15 queued strict PRs; expedite only reorders. An owner-applied,
    capped `merge-priority:urgent` PR takes the strict reservation at the next tick, pre-empting a non-urgent
    holder whose CI is still running (once per holder head); a fix for a red main still comes first.
    git is stubbed: heads named cur-* contain main; heads named conf-* conflict with it in merge-tree."""
    now = 2_000_000_000.0
    day = time.strftime("%Y-%m-%d", time.gmtime(now))
    yday = time.strftime("%Y-%m-%d", time.gmtime(now - 86400))

    class _R:
        def __init__(self, rc=0, out=""):
            self.returncode, self.stdout = rc, out

    def git(*a, **_k):
        if a[:2] == ("merge-base", "--is-ancestor"):
            return _R(0 if a[3].startswith("cur-") else 1)
        if a[0] == "merge-tree":
            return _R(1 if a[-1].startswith("conf-") else 0, "t\0")
        if a[:2] == ("show", "-s"):   # a *-stalled head: CI idle past the stall rule
            return _R(0, str(int(now) - (RESERVATION_STALL_S + 600 if "stalled" in a[-1] else 60)))
        return _R(0, "")

    def view(n, head, urgent=False, marked=False, fix=False, notice=None, app=None):
        v = {"number": n, "head_sha": head, "app": dict(app or {}), "labels": [URGENT_LABEL] if urgent else []}
        if marked:
            v["app"][URGENT_PREEMPT_CONTEXT] = ("success", "pre-empted")
        if fix:
            v["fix"] = ["Validate manifests"]
        if notice:
            v["app"][NOTICE_CONTEXT] = ("success", notice)
        return v

    def reserve(strict, urgent, red=None, preempted=None):
        red = red or {}
        return strict_reservation(git, "b", strict, now=now, fixes=strict_fixes(None, git, "b", strict, red),
                                  urgent=urgent, preempted=preempted, main_red=bool(red))

    holder = view(16760, "cur-holder")
    out: list = []
    h, _t = reserve([("pending", holder), ("green", view(16835, "old-urgent", urgent=True))], {16835}, preempted=out)
    check("urgent: a green urgent PR pre-empts a non-urgent holder whose CI is running", h is None and out == [16760],
          f"holder={h} preempted={out}")
    out = []
    h, _t = reserve([("pending", view(16760, "cur-holder", marked=True)), ("green", view(16900, "old-u2", urgent=True))],
                    {16900}, preempted=out)
    check("urgent: a holder head pre-empted once is never pre-empted again", h == 16760 and out == [], f"holder={h} {out}")
    h, _t = reserve([("green", holder), ("green", view(16835, "old-urgent", urgent=True))], {16835})
    check("urgent: a GREEN holder (merging this tick) is not interrupted", h == 16760, f"holder={h}")
    h, _t = reserve([("pending", holder), ("pending", view(16835, "old-urgent", urgent=True))], {16835})
    check("urgent: an urgent PR whose CI is not green (behind main) pre-empts nothing", h == 16760, f"holder={h}")
    h, _t = reserve([("pending", holder), ("green", view(16835, "old-urgent", urgent=True))], set())
    check("urgent: a labelled PR not admitted (owner/cap refused) pre-empts nothing", h == 16760, f"holder={h}")
    told = f"{CONFLICT_PREFIX}b: strict lane"
    h, _t = reserve([("pending", holder), ("green", view(16835, "old-urgent", urgent=True, notice=told))], {16835})
    check("urgent: an urgent PR already told it conflicts pre-empts nothing", h == 16760, f"holder={h}")
    # Review of #16856, item 5: a conflict NOT yet told must not burn the holder's single yield either.
    out = []
    h, _t = reserve([("pending", holder), ("green", view(16835, "conf-urgent", urgent=True))], {16835}, preempted=out)
    check("urgent: an urgent PR that conflicts with live main (merge-tree) pre-empts nothing, spends no yield",
          h == 16760 and out == [], f"holder={h} preempted={out}")
    out = []
    h, t = reserve([("pending", view(16760, "cur-holder", marked=True)), ("pending", view(16835, "cur-urgent", urgent=True))],
                   {16835}, preempted=out)
    check("urgent: the urgent PR's up-to-date head in CI holds main over the pre-empted head", h == 16835, f"holder={h}")
    check("urgent: the pre-empted head is never blamed (not timed out, not marked twice)", t == [] and out == [],
          f"timed_out={t} preempted={out}")
    # Its own CI may go idle while it waits for the urgent PR: still not timed out (no RELEASED marker).
    h, t = reserve([("pending", view(16760, "cur-stalled", marked=True)), ("pending", view(16835, "cur-urgent", urgent=True))],
                   {16835})
    check("urgent: a pre-empted head whose CI stalls while it waits is not timed out (not blamed)",
          h == 16835 and t == [], f"holder={h} timed_out={t}")
    # Re-review of #16856: the URGENT head's own CI stalls and the stall rule releases it. Nobody holds main
    # then, so the head that yielded to it must hold again instead of "waiting" on every tick forever.
    h, t = reserve([("pending", view(16760, "cur-holder", marked=True)),
                    ("pending", view(16835, "cur-urgent-stalled", urgent=True))], {16835})
    check("urgent: an urgent head released by the stall rule does not keep the pre-empted head waiting",
          h == 16760 and t == [16835], f"holder={h} timed_out={t}")
    released = view(16835, "cur-urgent", urgent=True, app={RELEASED_CONTEXT: ("success", "released")})
    h, t = reserve([("pending", view(16760, "cur-holder", marked=True)), ("pending", released)], {16835})
    check("urgent: an urgent head released earlier (RELEASED marker) does not keep the pre-empted head waiting",
          h == 16760 and t == [16835], f"holder={h} timed_out={t}")
    red = {"Validate manifests": "failure"}
    h, _t = reserve([("pending", view(15991, "cur-fix", fix=True)), ("green", view(16835, "old-urgent", urgent=True))],
                    {16835}, red=red)
    check("urgent + main red: a fix in CI keeps main against a non-fix urgent PR", h == 15991, f"holder={h}")
    # Item 6: the main-red guard itself, with a NON-fix holder (no fix pre-emption can mask its absence).
    out = []
    h, _t = reserve([("pending", holder), ("green", view(16835, "old-urgent", urgent=True))], {16835}, red=red,
                    preempted=out)
    check("urgent + main red: a non-fix urgent PR does not pre-empt a non-fix holder on a red main",
          h == 16760 and out == [], f"holder={h} preempted={out}")

    class _Gh:
        def __init__(self):
            self.updates, self.merges, self.statuses, self.comments = [], [], [], []

        def app_statuses(self, _sha):
            return {}

        def checks(self, _sha):
            return {}

        def update_branch(self, n, _head):
            self.updates.append(n)
            return True

        def main_sha(self):
            return "b"

        def merge(self, n, _head):
            self.merges.append(n)
            return True

        def post_status(self, sha, state, desc, context=STATUS_CONTEXT, **_k):
            self.statuses.append((sha, context, desc))

        def comment(self, n, text):
            self.comments.append(n)

        def __getattr__(self, _name):
            return lambda *a, **k: None

    gh, summary = _Gh(), {"merged": []}
    strict = [("green", view(16001, "old-a")), ("green", view(16835, "old-urgent", urgent=True))]
    strict_lane(gh, git, "b", strict, False, False, summary, {}, {}, holder=None, timed_out=[], urgent={16835})
    check("urgent: strict lane update-branches the urgent PR ahead of an older green strict PR",
          gh.updates == [16835], f"updates={gh.updates}")
    gh, summary = _Gh(), {"merged": []}
    strict = [("green", view(16760, "old-holder")), ("green", view(16900, "old-later"))]
    strict_lane(gh, git, "b", strict, False, False, summary, {}, {}, holder=None, timed_out=[], urgent=set())
    check("urgent: once the urgent PR is done the pre-empted holder is served first again", gh.updates == [16760],
          f"updates={gh.updates}")
    gh, summary = _Gh(), {"merged": []}
    strict = [("green", view(15991, "old-fix", fix=True)), ("green", view(16835, "old-urgent", urgent=True))]
    strict_lane(gh, git, "b", strict, False, False, summary, red, {}, holder=None, timed_out=[], urgent={16835})
    check("urgent + main red: the fix is update-branched, not the non-fix urgent PR", gh.updates == [15991],
          f"updates={gh.updates}")
    strict = [("green", view(15991, "old-fix", fix=True)), ("green", view(16835, "old-uf", urgent=True, fix=True))]
    gh, summary = _Gh(), {"merged": []}
    strict_lane(gh, git, "b", strict, False, False, summary, red, {}, holder=None, timed_out=[], urgent={16835})
    check("urgent + main red: an urgent fix goes ahead of a non-urgent fix", gh.updates == [16835], f"updates={gh.updates}")

    # Admission: owner-applied, capped per UTC day from authoritative events, fail closed.
    def ev(actor, at, n=1, kind="labeled", name=URGENT_LABEL):
        return {"event": kind, "actor": {"login": actor}, "label": {"name": name}, "created_at": at,
                "issue": {"number": n}}
    o = "JiRaska"
    own = [ev(o, f"{day}T10:00:00Z")]
    check("urgent: owner-applied label granted today is admitted",
          urgent_refusal(1, own, o, {1: f"{day}T10:00:00Z"}, 2, day) is None)
    bot = own + [ev("some-agent[bot]", f"{day}T11:00:00Z")]
    check("urgent: a label (re)applied by anyone but the owner is refused",
          "not the repo owner" in (urgent_refusal(1, bot, o, {1: f"{day}T10:00:00Z"}, 2, day) or ""))
    check("urgent: unreadable label events fail closed", urgent_refusal(1, None, o, {1: day}, 2, day) is not None)
    check("urgent: no label event at all fails closed", urgent_refusal(1, [], o, {}, 2, day) is not None)
    check("urgent: an incomplete grant enumeration fails closed", urgent_refusal(1, own, o, None, 2, day) is not None)
    check("urgent: an enumeration missing the PR's own grant fails closed", urgent_refusal(1, own, o, {}, 2, day) is not None)
    repo_events = [ev(o, f"{day}T08:00:00Z", 1), ev(o, f"{day}T09:00:00Z", 2), ev(o, f"{day}T10:00:00Z", 3),
                   ev(o, f"{yday}T23:00:00Z", 4), ev("intruder", f"{day}T07:00:00Z", 5)]
    g = urgent_grants(repo_events, o, day)
    check("urgent: grants count only the owner's events on this UTC day", g == {1: f"{day}T08:00:00Z",
          2: f"{day}T09:00:00Z", 3: f"{day}T10:00:00Z"}, str(g))
    check("urgent: within the daily cap is admitted", urgent_refusal(2, [repo_events[1]], o, g, 2, day) is None)
    check("urgent: the third owner grant of the UTC day is refused (cap 2)",
          "cap" in (urgent_refusal(3, [repo_events[2]], o, g, 2, day) or ""))
    # Bypass 1 (review of #16856): remove-and-relabel. #1's label was REMOVED after its grant; a search over
    # current labels no longer sees it, yet it was spent: #3 must still be the third grant.
    relabel = [ev(o, f"{day}T08:00:00Z", 1), ev(o, f"{day}T08:30:00Z", 1, kind="unlabeled"),
               ev(o, f"{day}T09:00:00Z", 2), ev(o, f"{day}T10:00:00Z", 3)]
    g2 = urgent_grants(relabel, o, day)
    check("urgent: removing the label after its grant does not uncount it (third grant still refused)",
          "cap" in (urgent_refusal(3, [relabel[3]], o, g2, 2, day) or ""), str(g2))
    check("urgent: re-applying the label to the same PR counts once",
          urgent_grants(relabel + [ev(o, f"{day}T11:00:00Z", 1)], o, day)[1] == f"{day}T08:00:00Z")
    # Bypass 2: a grant made yesterday never carries into today uncounted.
    two_days = {**g, 4: f"{yday}T23:00:00Z"}   # even an enumeration that reached back into yesterday
    check("urgent: a grant from yesterday is not admitted today (2-day window bypass)",
          "not today" in (urgent_refusal(4, [repo_events[3]], o, two_days, 2, day) or ""))

    # Bypass 3 (search-index lag) and the fail-closed reads: the real GitHub methods, API stubbed.
    saved_api = globals()["api"]
    calls: list = []
    pages: dict = {}

    def fake_api(method, path, body=None, **_k):
        calls.append(path)
        for prefix, resp in pages.items():
            if prefix in path:
                return resp(path) if callable(resp) else resp
        return 404, {}
    globals()["api"] = fake_api
    try:
        ghr = GitHub.__new__(GitHub)
        ghr.repo = "JiRaska/r"
        pages.clear()
        pages["/issues/events?"] = (200, repo_events[:3] + [ev(o, f"{yday}T01:00:00Z", 9)])
        pages["/search/"] = (200, {"total_count": 0, "items": [], "incomplete_results": False})
        got = ghr.urgent_grants_today(day, o)
        check("urgent: today's grants come from repository events, never the search index (lag bypass)",
              got == g and not any("/search/" in c for c in calls), f"got={got} calls={calls}")
        pages["/issues/3/events"] = (200, [repo_events[2]])
        strict3 = [("green", view(3, "old-3", urgent=True))]
        check("urgent: with the search index empty, the third grant is still refused end to end",
              urgent_prs(ghr, "JiRaska/r", strict3, 2, now=now) == set())
        pages.clear()
        pages["/issues/events?"] = (500, {})
        check("urgent: unreadable repository events fail closed", ghr.urgent_grants_today(day, o) is None)
        pages["/issues/events?"] = (200, {"message": "not a list"})
        check("urgent: a non-list events answer fails closed", ghr.urgent_grants_today(day, o) is None)
        pages["/issues/events?"] = (200, [ev(o, f"{day}T12:00:00Z", 7)] * 100)
        check("urgent: events that never reach back before today fail closed (incomplete enumeration)",
              ghr.urgent_grants_today(day, o) is None)
        pages.clear()
        pages["/issues/5/events"] = (500, {})
        check("urgent: unreadable PR events fail closed", ghr.issue_events(5) is None)
        pages["/issues/5/events"] = (200, {"message": "x"})
        check("urgent: a non-list PR events answer fails closed", ghr.issue_events(5) is None)
        pages["/issues/5/events"] = (200, [ev(o, f"{day}T12:00:00Z", 5)] * 100)
        check("urgent: more PR events than can be read whole fail closed", ghr.issue_events(5) is None)
    finally:
        globals()["api"] = saved_api

    # Starvation (review of #16856, item 4): an urgent PR that cannot progress stops outranking the lanes.
    def clocked(n, head, since):
        return view(n, head, urgent=True, app={URGENT_CLOCK_CONTEXT: ("success", f"urgent: since {int(since)}")})
    gh = _Gh()
    stale = [("green", clocked(16835, "cur-u", now - URGENT_PATIENCE_S - 1))]
    kept = urgent_expire(gh, stale, {16835}, now, False)
    check("urgent: green and outranking the lanes past URGENT_PATIENCE_S on one head drops its urgency",
          kept == set() and any(c == URGENT_DROPPED_CONTEXT for _s, c, _d in gh.statuses) and gh.comments == [16835],
          f"kept={kept} statuses={gh.statuses} comments={gh.comments}")
    check("urgent: a dropped head is no longer urgent (no API read either)",
          urgent_prs(None, "JiRaska/r", stale, 2, now=now) == set())
    gh = _Gh()
    check("urgent: within patience the urgent PR stays urgent",
          urgent_expire(gh, [("green", clocked(16835, "cur-u", now - 60))], {16835}, now, False) == {16835}
          and gh.statuses == [])
    gh = _Gh()
    fresh = [("green", view(16835, "cur-u", urgent=True))]
    urgent_stamp(gh, fresh, 16835, now, False)
    check("urgent: the clock starts the first tick the PR outranks the lanes",
          [c for _s, c, _d in gh.statuses] == [URGENT_CLOCK_CONTEXT] and urgent_clock(fresh[0][1]) == int(now),
          str(gh.statuses))
    urgent_stamp(gh, fresh, 16835, now + 600, False)
    check("urgent: the clock is never restarted on the same head", len(gh.statuses) == 1, str(gh.statuses))
    cur, behind, conf = view(16835, "cur-u", urgent=True), view(16835, "old-u", urgent=True), view(16835, "conf-u", urgent=True)
    check("urgent_now: an up-to-date green urgent PR outranks nothing while a carrier is in flight",
          urgent_pick(git, "b", [("green", cur)], {16835}, None, False, True) is None)
    check("urgent_now: a behind green urgent PR is servable (update-branch) with a carrier in flight",
          urgent_pick(git, "b", [("green", behind)], {16835}, None, False, True) == 16835)
    check("urgent_now: a conflicting urgent PR outranks nothing",
          urgent_pick(git, "b", [("green", conf)], {16835}, None, False, False) is None)
    check("urgent_now: nothing outranked on a red main or under a holder",
          urgent_pick(git, "b", [("green", behind)], {16835}, None, True, False) is None
          and urgent_pick(git, "b", [("green", behind)], {16835}, 16760, False, False) is None)
    check("urgent_now: a PR not admitted outranks nothing", urgent_pick(git, "b", [("green", behind)], set(), None, False, False) is None)
    # Item 6: urgent_now suppresses the train's and the fast lane's turns, and mode_settle wires it so.
    check("urgent_now: a servable urgent PR clears the train/fast-lane yield", urgent_yield("train's turn", 16835) is None)
    check("urgent_now: no urgent PR keeps the yield", urgent_yield("train's turn", None) == "train's turn")
    gh, summary = _Gh(), {"merged": []}
    strict = [("green", view(16835, "old-urgent", urgent=True))]
    strict_lane(gh, git, "b", strict, False, False, summary, {}, {}, holder=None, timed_out=[],
                yield_why=urgent_yield("train's turn after a strict merge", 16835), urgent={16835})
    check("urgent_now: under a train turn the urgent PR is still update-branched this tick", gh.updates == [16835],
          f"updates={gh.updates}")
    src = inspect.getsource(mode_settle)
    check("urgent_now: mode_settle applies urgent_yield and skips the fast-lane turn and strict carrier for it",
          "yield_why = urgent_yield(yield_why, urgent_now)" in src
          and "not main_red and urgent_now is None:" in src and "and urgent_now is None and not main_red" in src
          and "post_urgent_marks(gh, strict, preempted, shadow)" in src
          and "urgent_expire(gh, strict, urgent_prs(" in src)
    # Item 6: the marker-posting path.
    gh = _Gh()
    st = [("pending", view(16760, "cur-holder")), ("pending", view(16761, "cur-m", marked=True))]
    m = post_urgent_marks(gh, st, [16760, 16761], False)
    check("urgent: the pre-empted head is marked once (and an already-marked head is not re-marked)",
          m == [16760] and [(s_, c) for s_, c, _d in gh.statuses] == [("cur-holder", URGENT_PREEMPT_CONTEXT)]
          and URGENT_PREEMPT_CONTEXT in st[0][1]["app"], f"{m} {gh.statuses}")
    gh = _Gh()
    check("urgent: shadow posts no marker", post_urgent_marks(gh, [("pending", view(1, "cur-x"))], [1], True) == []
          and gh.statuses == [])


def train_turn_main_red_self_test(check) -> None:
    """The train's turn after a strict merge, with a red main and without (2026-11-13: fixes #15991/#15987
    waited ~2 h behind "train's turn" while no train could be built over the red main)."""
    saved = globals()["strict_merge_since_train"]
    globals()["strict_merge_since_train"] = lambda *_a, **_k: 1000
    try:
        git = lambda *_a, **_k: subprocess.CompletedProcess([], 0, stdout="1000\n", stderr="")
        waiting = [object()]
        green = train_turn(None, git, "b", waiting, False, now=1001)
        red = train_turn(None, git, "b", waiting, False, now=1001, main_red={"Validate manifests": "failure"})
        red_carrier = train_turn(None, git, "b", waiting, True, now=1001, main_red={"Validate manifests": "failure"})
    finally:
        globals()["strict_merge_since_train"] = saved
    check("train's turn: green main, strict merge just landed, a train candidate waits -> the train goes next",
          bool(green) and "train's turn" in green, f"{green!r}")
    check("train's turn: red main -> no turn, the strict lane serves the fix at once",
          red is None, f"{red!r}")
    check("train's turn: red main with an open carrier -> the carrier still keeps its turn",
          red_carrier == "a train carrier is open over main", f"{red_carrier!r}")
    settle_src = inspect.getsource(mode_settle)
    call = settle_src[settle_src.find("train_turn("):][:400]
    check("train's turn: settle hands main_red to train_turn (the call site is the fix as much as the rule)",
          "main_red=main_red" in call.split("\n\n")[0], call[:200])


def train_turn_fairness_self_test(check) -> None:
    """Lane fairness under a steady strict queue (2026-11-14, 15:40-19:30Z): a fast-lane merge landing
    after a strict merge must not end the train's turn, or the strict lane builds its next carrier over
    waiting train candidates every time. Drives train_turn on a fake first-parent history."""
    class FakeGh:
        def __init__(self, lanes):   # sha -> (pr number, App status description on its head)
            self.lanes = lanes
        def pr(self, n):
            return {"head": {"sha": f"h{n}"}}
        def app_statuses(self, head):
            desc = next((d for n, d in self.lanes.values() if f"h{n}" == head), "")
            return {STATUS_CONTEXT: ("success", desc)}

    def fake_git(history, times):   # history: first-parent shas, newest first
        def git(*args, **_k):
            out = ""
            if args[0] == "rev-list":
                cap = next((int(a.split("=")[1]) for a in args if a.startswith("--max-count=")), len(history))
                out = "\n".join(history[:cap])
            elif args[0] == "show" and args[-1] in times:
                fmt = args[2]
                out = times[args[-1]][0] if fmt == "--format=%s" else str(times[args[-1]][1])
            return subprocess.CompletedProcess(list(args), 0, stdout=out + "\n", stderr="")
        return git

    strict, fast, train = "strict lane: verified on strict carrier #9 over main x", "fast lane: disjoint", "verified on train over main y"
    times = {"m3": ("feat(a): fast (#3)", 1900), "m2": ("ci(b): strict (#2)", 1000), "m1": ("feat(c): train (#1)", 500),
             "m4": ("chore(d): deploy (#4)", 1950)}
    lanes = {"m3": (3, fast), "m2": (2, strict), "m1": (1, train), "m4": (4, "")}
    waiting = [object()]
    _MERGE_LANE.clear()
    # Strict merge, then a fast merge and a bot merge on top: the train still owns the turn.
    after_fast = train_turn(FakeGh(lanes), fake_git(["m4", "m3", "m2", "m1"], times), "m4", waiting, False, now=1100)
    check("lane fairness: fast/bot merges after a strict merge do not end the train's turn (steady strict queue)",
          bool(after_fast) and "train's turn" in after_fast, f"{after_fast!r}")
    # Bounded: past TRAIN_TURN_S from that strict merge the strict lane proceeds.
    expired = train_turn(FakeGh(lanes), fake_git(["m4", "m3", "m2", "m1"], times), "m4", waiting, False,
                         now=1000 + TRAIN_TURN_S + 1)
    check("lane fairness: the train's turn still expires TRAIN_TURN_S after the strict merge", expired is None, f"{expired!r}")
    # A train merge after the strict merge = the train had its turn.
    trained = train_turn(FakeGh(lanes), fake_git(["m1", "m2"], times), "m1", waiting, False, now=1100)
    check("lane fairness: a train merge since the strict merge ends the turn", trained is None, f"{trained!r}")
    # Negative: no train candidates waiting -> strict proceeds unchanged.
    idle = train_turn(FakeGh(lanes), fake_git(["m2", "m1"], times), "m2", [], False, now=1100)
    check("lane fairness: no train candidates -> the strict lane proceeds", idle is None, f"{idle!r}")
    # Unchanged: main's head is the strict merge itself.
    direct = train_turn(FakeGh(lanes), fake_git(["m2", "m1"], times), "m2", waiting, False, now=1100)
    check("lane fairness: main's head a strict merge, candidates waiting -> the train's turn", bool(direct), f"{direct!r}")
    # Depth exceeded: the strict merge lies beyond TRAIN_TURN_DEPTH -> old behaviour (no turn).
    deep = [f"o{i}" for i in range(TRAIN_TURN_DEPTH)] + ["m2"]
    dtimes = {**times, **{f"o{i}": (f"chore(x): bot (#{50 + i})", 1050) for i in range(TRAIN_TURN_DEPTH)}}
    dlanes = {**lanes, **{f"o{i}": (50 + i, "") for i in range(TRAIN_TURN_DEPTH)}}
    _MERGE_LANE.clear()
    beyond = train_turn(FakeGh(dlanes), fake_git(deep, dtimes), "o0", waiting, False, now=1100)
    check("lane fairness: strict merge beyond TRAIN_TURN_DEPTH -> no turn (old behaviour)", beyond is None, f"{beyond!r}")

    class FailingGh(FakeGh):   # a non-200 PR read: get() raises SystemExit
        def pr(self, n):
            if n == 3:
                raise SystemExit("::error::GET /pulls/3 -> 502")
            return super().pr(n)
    _MERGE_LANE.clear()
    try:
        failed = train_turn(FailingGh(lanes), fake_git(["m3", "m2", "m1"], times), "m3", waiting, False, now=1100)
    except SystemExit as e:
        failed = f"aborted: {e}"
    check("lane fairness: a failed PR read is stepped over, never a tick abort", bool(failed) and "train's turn" in failed,
          f"{failed!r}")
    check("lane fairness: a failed read is not memoised", "m3" not in _MERGE_LANE, str(_MERGE_LANE))
    reads: list = []

    class CountingGh(FakeGh):
        def pr(self, n):
            reads.append(n)
            return super().pr(n)
    _MERGE_LANE.clear()
    g = fake_git(["m3", "m2", "m1"], times)
    train_turn(CountingGh(lanes), g, "m3", waiting, False, now=1100)
    train_turn(CountingGh(lanes), g, "m3", waiting, False, now=1100)
    check("lane fairness: a merged commit's lane is read once (memoised by sha)", reads == [3, 2], str(reads))
    _MERGE_LANE.clear()


def train_turn(gh, git, base: str, train_waiting: list, carrier_open: bool, now: float | None = None,
               main_red: dict | None = None) -> str | None:
    """Why the strict lane must not START a reservation (update-branch) this tick, or None. Lane
    fairness (ADR-0343): (1) an open carrier is the train's in-flight turn — a reservation started
    under it holds the carrier once green and then voids it by merging (#13529, 2026-10-21); (2) right
    after a strict-lane merge, while train candidates wait, the next turn is the train's, bounded by
    TRAIN_TURN_S. Either ends by itself: the carrier settles, or a train merges (main's head is no
    longer a strict merge), or the turn expires. A reservation already running is never affected."""
    if carrier_open:
        return "a train carrier is open over main"
    if main_red:
        # No train is built over a red main (plan_train serves only fixes), so this turn would hold the
        # strict lane that serves the fix for TRAIN_TURN_S with nobody using it.
        return None
    if not train_waiting:
        return None
    now = time.time() if now is None else now
    ct = strict_merge_since_train(gh, git, base, now=now)
    if ct is None or now - ct > TRAIN_TURN_S:
        return None
    return f"train's turn after a strict-lane merge ({len(train_waiting)} train candidate(s) waiting)"


_MERGE_LANE: dict[str, str] = {}   # sha -> lane; a merged commit's lane never changes (failed reads not kept)


def merge_lane(gh, git, sha: str) -> str:
    """Which lane put `sha` on main: "strict" (the App's `strict lane:` status on the PR head), "train"
    (`verified on train`), or "other" (a fast-lane, bot or native auto-merge squash). Unreadable = other.
    A non-200 PR or status read is "other" too (stepped over), never a tick abort; a quota/transient
    ApiAbort still propagates exactly as for every other read in the tick."""
    if sha in _MERGE_LANE:
        return _MERGE_LANE[sha]
    m = SQUASH_PR_RE.search(git("show", "-s", "--format=%s", sha, check=False).stdout.strip())
    if not m:
        _MERGE_LANE[sha] = "other"
        return "other"
    try:
        head = gh.pr(int(m.group(1)))["head"]["sha"]
        desc = gh.app_statuses(head).get(STATUS_CONTEXT, ("", ""))[1]
    except (KeyError, TypeError, ValueError, SystemExit):
        return "other"
    lane = "strict" if desc.startswith("strict lane:") else "train" if desc.startswith("verified on train") else "other"
    _MERGE_LANE[sha] = lane
    return lane


def strict_merge_since_train(gh, git, base: str, depth: int | None = None, now: float | None = None) -> int | None:
    """Committer time of the newest strict-lane merge on main's first-parent chain with no train merge
    after it, or None. Fast-lane and bot merges are stepped over: they move main but are not the train's
    turn, so they must not end it (2026-11-14: fast #16034 landed after strict #16173, main's head was no
    longer a strict merge, and the next tick built strict carrier #16176 over four waiting candidates).
    The walk stops, with no API read, at the first commit older than TRAIN_TURN_S (no turn could be open
    from it) and after `depth` commits (TRAIN_TURN_DEPTH); nothing strict within that = no turn owed."""
    depth = TRAIN_TURN_DEPTH if depth is None else depth
    now = time.time() if now is None else now
    shas = git("rev-list", "--first-parent", f"--max-count={depth}", base, check=False).stdout.split()
    for sha in shas:
        ct = git("show", "-s", "--format=%ct", sha, check=False).stdout.strip()
        if not ct.isdigit() or now - int(ct) > TRAIN_TURN_S:
            return None
        lane = merge_lane(gh, git, sha)
        if lane == "train":
            return None
        if lane == "strict":
            return int(ct)
    return None


def latest_ci_activity(check_runs: list, load_runs, now: float) -> float | None:
    """Newest started_at/completed_at of any check run (epoch; GitHub stamps these, so unlike the
    committer time they cannot be author-dated). When that is older than RESERVATION_STALL_S (or there
    is none), `load_runs()` — the head's workflow runs — is read: any run still queued or in progress
    (LIVE_RUN_STATUSES) is activity NOW (#14302), since nested reusable-workflow jobs register no check
    run until their caller starts. Nothing live: the check-run stamp stands (None when none started)."""
    stamps = [c.get(k) for c in check_runs for k in ("started_at", "completed_at")]
    epochs = [datetime.datetime.fromisoformat(t.replace("Z", "+00:00")).timestamp() for t in stamps if t]
    last = max(epochs) if epochs else None
    if last is not None and now - last <= RESERVATION_STALL_S:
        return last
    if any(r.get("status") in LIVE_RUN_STATUSES for r in load_runs()):
        return now
    return last

def fast_turn(gh, git, base: str, fast_unposted: list, reservation_ended: bool, shadow: bool,
              now: float | None = None) -> str | None:
    """Why the strict lane must not START a reservation this tick because the FAST lane is owed its turn
    (ADR-0360), or None. Owed when green fast-lane PRs wait that were never posted and the last
    reservation over this main ENDED — main's head is a strict-lane merge, or a reservation over it was
    released (`reservation_ended`: stall or ceiling). The turn opens with an App marker on main's head
    and lasts at most FAST_TURN_S from it; it ends early when every waiting fast PR has been posted or
    when a fast merge moves main (the new head is neither strict nor released over). A marker that
    cannot be written opens no turn (today's behaviour), and shadow never writes one."""
    if shadow or not fast_unposted:
        return None
    if not (reservation_ended or last_merge_was_strict(gh, git, base)):
        return None
    now = time.time() if now is None else now
    state, desc = gh.app_statuses(base).get(FAST_TURN_CONTEXT, ("", ""))
    m = re.fullmatch(r"opened (\d+)", desc or "") if state == "success" else None
    if m is None:
        try:
            gh.post_status(base, "success", f"opened {int(now)}", context=FAST_TURN_CONTEXT)
        except (SystemExit, Exception) as e:   # noqa: BLE001 - fail toward today's behaviour, never abort settle
            log(f"::warning::fast turn marker on main {base[:12]} not written ({e}) — no fast turn")
            return None
        opened = int(now)
    else:
        opened = int(m.group(1))
    if now - opened > FAST_TURN_S:
        return None
    return f"fast lane's turn after a reservation ended ({len(fast_unposted)} fast-lane PR(s) waiting)"


def reservation_expired(git, head: str, now: float, activity=None, green: bool = False) -> str | None:
    """Why the reservation on `head` is over, or None while its CI is live (ADR-0343, #13400).
    Expired when the head is future-dated (the committer time is author-supplied, #13485), older
    than RESERVATION_CEILING_S, or idle: nothing on it started or completed for RESERVATION_STALL_S.
    The idle clock starts at the committer time, so a CI that never starts after update-branch is
    a stall too. `activity(head)` = newest check-run started_at/completed_at (epoch) or None.
    The stall rule applies only while CI is PENDING: a `green` head is finished, not stalled, and
    merges this tick (#13608 was released ~15 min after going green). The ceiling bounds a CI that
    never finishes, so it too applies only while NOT green, with GREEN_HOLDER_CAP_S as the bound for a green one (#14624: starved ticks carried a green,
    up-to-date holder past 240 min and it was released, discarding ~3h of finished CI). `green` is
    strict_lane_state's verdict on THIS head and strict_reservation only asks for a head that contains
    live main; the merge itself (strict_lane) re-checks main, source intent and pins the head. A green
    head keeps the future-stamp guard."""
    ct = git("show", "-s", "--format=%ct", head, check=False).stdout.strip()
    if not ct.isdigit() or now < int(ct):
        return "head committed in the future"
    if not green and now - int(ct) > RESERVATION_CEILING_S:
        return f"> {RESERVATION_CEILING_S // 60} min ceiling"
    if green and now - int(ct) > GREEN_HOLDER_CAP_S:
        # A green holder is exempt from the ceiling, not from a bound: one whose merge is refused every
        # tick (ruleset, hook, auto-merge) must not hold main forever.
        return f"green but unmerged > {GREEN_HOLDER_CAP_S // 60} min hard cap"
    last = int(ct)
    seen = activity(head) if activity else None
    if seen is not None:
        last = max(last, min(seen, now))
    if not green and now - last > RESERVATION_STALL_S:
        return f"CI stalled: nothing started or completed for > {RESERVATION_STALL_S // 60} min"
    return None


def deferral_used(gh, git, head: str) -> bool:
    """The strict head, or the head it was update-branched from (first parent), already yielded."""
    parents = git("rev-list", "--parents", "-n", "1", head, check=False).stdout.split()
    return any(gh.app_statuses(sha).get(DEFER_CONTEXT, ("", ""))[0] == "success" for sha in [head] + parents[1:2])


def deferral_state(gh, git, strict: list, holder: int) -> str | None:
    """Bounded deferral (ADR-0343, #13400) for the reservation holder: "open" — its CI is still
    RUNNING and it never yielded, so ONE carrier may be built under it; "granted" — a carrier was
    published under it (DEFER_CONTEXT on THIS head), so that green carrier may merge past it; None —
    held. A VERIFIED green carrier is held only for a GREEN, up-to-date holder that did NOT defer to
    it (no DEFER_CONTEXT on that head), and only one tick per holder head (CARRIER_YIELD_CONTEXT):
    that holder merges first. Past a running holder, a "granted" one, or a green one that already had
    its tick, it merges before strict_lane runs (green carrier first, #13400). Its merge puts the head behind main and its
    update-branch inherits the record through the first parent: after that one yield no further
    carrier is built under it, so the strict PR has priority until it merges or fails."""
    view = next((v for st, v in strict if v["number"] == holder and st == "pending"), None)
    if view is None:
        return None
    head = view["head_sha"]
    if gh.app_statuses(head).get(DEFER_CONTEXT, ("", ""))[0] == "success":
        return "granted"
    return None if deferral_used(gh, git, head) else "open"


def update_opens_deferral(gh, git, strict: list, n: int) -> bool:
    """The strict PR `n` was update-branched this tick: may a carrier be built under its new head? Only
    when the head it was updated FROM never yielded (deferral_used: that head or its first parent). The
    new head's first parent is that head, so this is exactly deferral_state's "open" one tick early."""
    view = next((v for _st, v in strict if v["number"] == n), None)
    return view is not None and not deferral_used(gh, git, view["head_sha"])


def record_deferral(gh, git, repo: str, base: str, carrier_branch: str) -> list[int]:
    """Publish: a carrier published while an armed PR's up-to-date head is still running CI consumes
    that head's one deferral. Read from live data (head contains live main, a required context still
    pending); settle opened the window and judges the carrier against the record."""
    required = [c for c in gh.required() if c != STATUS_CONTEXT]
    out = []
    for p in gh.open_prs():
        if is_carrier(p, repo) or not p.get("auto_merge") or p.get("draft"):
            continue
        n, head = p["number"], p["head"]["sha"]
        checks = gh.checks(head)
        if not any(checks.get(c, None) is None for c in required) or any(
                checks.get(c) == "failure" for c in required):
            continue
        git("fetch", "-q", "origin", f"+{gh.head_refspec(n)}:refs/merge-train/pr-{n}", check=False)
        if git("merge-base", "--is-ancestor", base, head, check=False).returncode != 0 or deferral_used(gh, git, head):
            continue
        gh.post_status(head, "success", f"strict lane: yielded once to carrier {carrier_branch}; priority from here",
                       context=DEFER_CONTEXT)
        log(f"#{n:>6} strict    deferral recorded: carrier {carrier_branch} published during its CI")
        out.append(n)
    return out


# --------------------------------------------------------------------------- speculative stacking
def stack_target_problem(gh, git, base: str, n: int, head: str, main_red: dict | None = None) -> str | None:
    """Why the train carrier may NOT be stacked over strict PR `n`'s head `head`, or None. Read from live
    data by settle (opening the window) and again by publish (acting on it): open, armed, not a draft,
    still at `head`, the head contains live main, its CI is RUNNING with nothing failed, never released,
    never stacked on before (STACK_CONTEXT in any state), and main is not red."""
    if not SHA_RE.fullmatch(head or ""):
        return "holder head is not a full sha"
    pr = gh.pr(n)
    if (pr.get("state") != "open" or pr.get("draft") or not pr.get("auto_merge")
            or (pr.get("head") or {}).get("sha") != head):
        return "holder is not open and armed at this head"
    if git("fetch", "-q", "origin", f"+{gh.head_refspec(n)}:refs/merge-train/stack-holder", check=False).returncode != 0:
        return "holder head could not be fetched"
    if git("rev-parse", "refs/merge-train/stack-holder", check=False).stdout.strip() != head:
        return "holder head moved"
    if git("merge-base", "--is-ancestor", base, head, check=False).returncode != 0:
        return "holder head is behind main"
    apps = gh.app_statuses(head)
    if STACK_CONTEXT in apps:
        return "a carrier was already stacked on this head"
    if RELEASED_CONTEXT in apps:
        return "holder reservation was released on this head"
    required = [c for c in gh.required() if c != STATUS_CONTEXT]
    checks = gh.checks(head)
    if any(checks.get(c) not in (None, "success") for c in required):
        return "holder is red"
    if all(checks.get(c) == "success" for c in required):
        return "holder CI is not running"
    if main_red is None:
        main_red = main_red_contexts(gh, git, gh.required(), base)
    if main_red:
        return "main is red"
    return None


def restack_chain(git, base: str, head: str, tip: str) -> tuple[str, str]:
    """Re-apply publish's own verified chain base..tip onto `head` (which contains `base`), execution-free:
    each step is `git merge-tree --merge-base <prev> <stacked prev> <commit>`. -> (stacked tip, its tree).
    Raises Reject (never a member fault): a regeneration commit (computed over main, not over head), a
    conflict with the holder, a member already contained in the holder, or a new symlink/gitlink."""
    chain = git("rev-list", "--reverse", "--first-parent", f"{base}..{tip}").stdout.split()
    if not chain:
        raise Reject("nothing to stack", member_fault=False)
    prev, own = base, head
    for c in chain:
        msg = git("log", "-1", "--format=%B", c).stdout.rstrip("\n") + "\n"
        if not OWN_MEMBER_RE.fullmatch(msg):
            raise Reject("a stacked carrier never carries a regeneration commit", member_fault=False)
        r = git("merge-tree", "--write-tree", "--merge-base", prev, own, c, check=False)
        if r.returncode != 0 or not r.stdout.split():
            raise Reject(f"member commit {c[:12]} does not apply cleanly over the holder", member_fault=False)
        tree = r.stdout.split()[0]
        if tree == git.tree(own):
            raise Reject(f"member commit {c[:12]} is empty over the holder", member_fault=False)
        own = git("commit-tree", tree, "-p", own, "-m", msg.rstrip("\n")).stdout.strip()
        prev = c
    if git.special_entries(own) - git.special_entries(head):
        raise Reject("stacked tree contains a symlink/gitlink the holder does not", member_fault=False)
    return own, git.tree(own)


def stacked_squash_mismatch(gh, git, main: str, members: list[tuple[int, str]], steps: list[str]) -> str | None:
    """Why the squash merges GitHub will make would NOT reproduce the verified stacked trees, or None.
    Execution-free: member i's squash over the tree before it is `git merge-tree --write-tree <before> <head>`
    (git's own merge base, as GitHub's), required equal to tree(steps[i]); `main` is the first `before`, each
    later one the previous verified step. Any fetch or merge-tree failure is a mismatch (fail closed)."""
    before = main
    if len(members) != len(steps):
        return "member count does not match the stacked chain"
    for (n, head), step in zip(members, steps, strict=True):
        ref = f"refs/merge-train/stack-member-{n}"
        if (git("fetch", "-q", "origin", f"+{gh.head_refspec(n)}:{ref}", check=False).returncode != 0
                or git("rev-parse", ref, check=False).stdout.strip() != head):
            return f"#{n}'s head could not be read at {head[:12]}"
        r = git("merge-tree", "--write-tree", before, head, check=False)
        tree = r.stdout.split()[0] if r.returncode == 0 and r.stdout.split() else ""
        if not tree or tree != git.tree(step):
            return f"#{n}'s squash over {before[:12]} is not the verified stacked tree"
        before = step
    return None


def stack_verdict(gh, git, p: dict, live_main: str) -> tuple[str, str]:
    """Is carrier `p` stacked over a strict holder, and where does that holder stand? -> (kind, detail):
    ("none", "") not a stacked carrier (judged as before); ("merged", h) the holder merged and main's
    tree IS h's tree, so the carrier verifies main-after-H and is judged like a carrier over main;
    ("wait", why) the holder has no verdict yet — never merged, never blamed, whatever the carrier's CI
    says; ("void", why) the holder failed, moved, closed or was released — closed, nobody blamed;
    ("reject", why) main moved to a tree that is not h's — closed, nobody blamed (as "main moved")."""
    branch, sha = p["head"]["ref"], p["head"]["sha"]
    if not TRAIN_BRANCH_RE.fullmatch(branch):
        return "none", ""
    # Classified by publish's marker on the carrier's OWN head, read from the API before any git read:
    # an unreadable branch then makes a stacked carrier wait (fail closed), never judged as an ordinary one.
    tstate, tdesc = gh.app_statuses(sha).get(STACK_CONTEXT, ("", ""))
    tm = STACK_TIP_RE.fullmatch(tdesc or "") if tstate == "success" else None
    if tm is None:
        return "none", ""
    h, n = tm.group(1), int(tm.group(2))
    age = carrier_age_s(p)
    if age is not None and age > RESERVATION_CEILING_S:
        return "void", f"stacked {age // 60:.0f} min, past the {RESERVATION_CEILING_S // 60} min reservation ceiling"
    if git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/merge-train/stack", check=False).returncode != 0:
        return "wait", "carrier branch could not be read"
    chain = parse_own_chain(git, sha) if git("rev-parse", "refs/merge-train/stack", check=False).stdout.strip() == sha else None
    if chain is None or chain[0] != h:
        return "void", "carrier head is not publish's stacked chain over the recorded holder head"
    state, desc = gh.app_statuses(h).get(STACK_CONTEXT, ("", ""))
    m = STACK_DESC_RE.fullmatch(desc or "")
    if state != "success" or not m or m.group(1) != branch or int(m.group(2)) != n:
        return "void", "holder head carries no matching stacking record"
    pr = gh.pr(n)
    tree_main, tree_h = git.tree(live_main), git.tree(h)
    if pr.get("merged_at") and tree_main and tree_main == tree_h:
        return "merged", h
    if pr.get("merged_at") or pr.get("state") != "open":
        if pr.get("merged_at"):
            return "reject", f"holder #{n} merged but main's tree is not its verified head's tree"
        return "void", f"holder #{n} closed unmerged"
    if (pr.get("head") or {}).get("sha") != h:
        return "void", f"holder #{n} head moved"
    if pr.get("draft") or not pr.get("auto_merge"):
        return "void", f"holder #{n} disarmed or a draft"
    if git("merge-base", "--is-ancestor", live_main, h, check=False).returncode != 0:
        return "void", f"main moved under holder #{n}"
    if RELEASED_CONTEXT in gh.app_statuses(h):
        return "void", f"holder #{n} reservation released"
    required = [c for c in gh.required() if c != STATUS_CONTEXT]
    checks = gh.checks(h)
    if any(checks.get(c) not in (None, "success") for c in required):
        return "void", f"holder #{n} is red"
    return "wait", f"holder #{n} has no verdict yet"


def breakage_dirs(gh, git, base: str, main_red: dict[str, str], cache: dict | None = None) -> set[str] | None:
    """The directories main changed where each main-red context turned red: the diff from the newest
    first-parent commit main's own CI judged green on that context to the oldest one after it judged
    red. None when any context has no such pair inside STALE_RED_WALK (relevance unknown, so nothing
    is re-ranked). Read from main's CI verdicts and git only."""
    if not main_red:
        return None
    walk = git("rev-list", "--first-parent", f"--max-count={STALE_RED_WALK}", base, check=False).stdout.split()
    out: set[str] = set()
    for ctx in main_red:
        first_red = green = None
        for c in walk:
            if cache is not None and c in cache:
                res = cache[c]
            else:
                res = gh.checks(c) or {}
                if cache is not None:
                    cache[c] = res
            v = res.get(ctx)
            if v == "failure":
                first_red = c
            elif v == "success":
                green = c
                break
        if not (first_red and green):
            return None
        names = git("diff", "--name-only", "-z", green, first_red, check=False).stdout
        out |= {posixpath.dirname(f) for f in zpaths(names)}
    return out or None


def relevant_fixes(strict: list, fixes: dict | None, dirs: set[str] | None) -> set[int]:
    """Fixes (green in `fixes`, or a combined head in CI carrying the `fix` marker) whose own changed
    files share a directory with what broke main (breakage_dirs). A fix claim is evidence that the PR's
    CI went green where main's is red; it is not evidence that the PR repairs anything — #16583 and
    #16602 (perf baselines) each merged as a "fix" for a stale-ADR-registry red and left main red,
    while #16690 (the regenerated ADR files) waited hours behind them. Rank only: empty when unknown."""
    if not dirs:
        return set()
    out: set[int] = set()
    for state, view in strict:
        n = view["number"]
        if n in (fixes or {}) or (view.get("fix") and state == "pending"):
            if {posixpath.dirname(f) for f in view.get("files") or []} & dirs:
                out.add(n)
    return out


def served_relevant_fixes(gh, git, base: str, strict: list, main_red: dict[str, str], cache: dict | None = None) -> set[int]:
    """relevant_fixes limited to fixes that can be served over this main (preempting_fixes): a relevant
    fix that conflicts or was refused must not hold every other PR for nobody. Empty on a green main."""
    if not main_red:
        return set()
    fixes = strict_fixes(gh, git, base, strict, main_red, cache)
    return relevant_fixes(strict, fixes, breakage_dirs(gh, git, base, main_red, cache)) & preempting_fixes(base, strict, fixes)


def preempting_fixes(base: str, strict: list, fixes: dict | None) -> set[int]:
    """Fixes that pre-empt a non-fix strict reservation on a red main (ADR-0343 amendment 2026-11-14):
    every green fix (`fixes`, strict_fixes) plus every fix whose COMBINED head is in CI (fix_head_state's
    `fix` marker: strict_fixes lists only green PRs, so a lone fix would lose main the moment its own CI
    started). A green fix that cannot be served over THIS main — the App already told it conflicts or
    that update-branch was refused, on this head over this main — pre-empts nothing: it would only free
    main for nobody. Read from App statuses already in the view; no git, no API."""
    out: set[int] = set()
    for state, view in strict:
        n = view["number"]
        if view.get("fix") and state == "pending":
            out.add(n)
        elif n in (fixes or {}):
            told = (view.get("app") or {}).get(NOTICE_CONTEXT, ("", ""))[1]
            if not told.startswith((f"{CONFLICT_PREFIX}{base[:12]}", f"{REFUSED_PREFIX}{base[:12]}")):
                out.add(n)
    return out


def strict_reservation(git, base: str, strict: list, shadow: bool = False, now: float | None = None,
                       fixes: dict | None = None, activity=None,
                       relevant: set[int] | None = None, urgent: set[int] | None = None,
                       preempted: list | None = None, main_red: bool = False) -> tuple[int | None, list[int]]:
    """(holder, timed_out). The holder is the oldest strict-lane PR whose head already contains live
    main and whose CI is still running with nothing failed — or has just gone green, so it merges this
    tick: main is reserved for it, so neither the
    fast lane nor a train nor another strict-lane update may move or contend for main until it
    settles (merged, failed, or timed out). A green holder that cannot merge (merge refused) is
    bounded by the ceiling, never by the stall rule. A reservation whose CI stalled, or that passed the ceiling
    (reservation_expired), is released and listed in timed_out.
    Main red (ADR-0343): a "waiting" PR never holds (it cannot go green until main is fixed). A FIX
    (`fixes`) holds only once its combined head contains live main, like every other PR — first, as
    strict_lane serves it first; behind main it holds nothing, since it never merges from there."""
    now = time.time() if now is None else now
    holder, timed_out = None, []
    fixes = fixes or {}
    holder_state = None
    pre = preempting_fixes(base, strict, fixes)
    relevant = relevant or set()
    urgent = set() if main_red else (urgent or set())   # main red: fixes only; urgent waits for green main
    ordered = sorted(strict, key=lambda sv: 0 if sv[1]["number"] in relevant
                     else 1 if sv[1]["number"] in fixes or sv[1]["number"] in pre
                     else 2 if sv[1]["number"] in urgent else 3)
    # An urgent PR whose up-to-date head is in CI holds main; a head that yielded to an urgent PR then waits
    # without holding and is never timed out for it (never blamed).
    # Only an urgent head that can actually HOLD main counts: up to date, in CI, not released earlier
    # (RELEASED_CONTEXT) and not released now (reservation_expired). Otherwise a stalled urgent PR would
    # keep the head that yielded to it waiting on every tick while nobody holds main (re-review of #16856).
    urgent_running = any(st == "pending" and v["number"] in urgent
                         and RELEASED_CONTEXT not in (v.get("app") or {})
                         and git("merge-base", "--is-ancestor", base, v["head_sha"], check=False).returncode == 0
                         and reservation_expired(git, v["head_sha"], now, activity) is None
                         for st, v in strict)
    for state, view in ordered:
        n, head = view["number"], view["head_sha"]
        if state not in ("pending", "green"):
            continue
        if git("merge-base", "--is-ancestor", base, head, check=False).returncode != 0:
            continue
        if state == "green" and shadow:
            continue  # shadow never merges it, so it must not hold anything
        if (state == "pending" and urgent_running and n not in urgent
                and URGENT_PREEMPT_CONTEXT in (view.get("app") or {})):
            log(f"#{n:>6} strict    yielded main to an urgent PR on this head: waits, not blamed")
            continue
        if state == "pending" and RELEASED_CONTEXT in (view.get("app") or {}):
            # Cooldown (#14302): this head already timed out once. Its CI may resume, but re-reserving
            # it on the next tick starved every other strict PR and the fast lane. It may still merge
            # once GREEN; a new head (update-branch) reserves afresh.
            log(f"#{n:>6} strict    reservation released earlier on this head: not reserved again")
            timed_out.append(n)
            continue
        why = reservation_expired(git, head, now, activity, green=state == "green")
        if why:
            log(f"#{n:>6} strict    reservation timed out ({why}): released, back of the queue")
            timed_out.append(n)
        elif holder is None:
            holder = n
            holder_state = state
        elif (state == "pending" and holder in urgent and n not in urgent and n not in fixes
                and URGENT_PREEMPT_CONTEXT not in (view.get("app") or {}) and preempted is not None):
            preempted.append(n)   # an up-to-date urgent head in CI displaced this one: recorded, once per head
    # Main-red fix pre-emption (ADR-0343 amendment 2026-11-14): a non-fix reservation whose CI is still
    # RUNNING does not hold main while a green fix waits. Since no train moves on a red main, holding it
    # for a strict PR's 30-60 min CI (re-run each time main moves) left the fix — the one PR that can turn
    # main green — waiting behind a reservation that only exists because main moved (#15991 behind
    # #16005/#16009, #16096 behind #15976). A GREEN holder merges this tick and is never interrupted; the
    # pre-empted PR keeps its CI and regains main once main is green (it is behind then, so re-updated).
    if holder is not None and pre and holder not in pre and holder not in fixes and holder_state == "pending":
        log(f"#{holder:>6} strict    reservation pre-empted: main is red and fix "
            f"{', '.join(f'#{f}' for f in sorted(pre))} is served first; main returns once green")
        holder = None
    # A fix whose diff touches what broke main (relevant_fixes) also pre-empts a running reservation of a
    # fix that does not: #16586 (perf) held main for ~1 h as a "fix in CI" while #16690 (the ADR regen) waited.
    elif (holder is not None and holder_state == "pending" and holder not in relevant
            and relevant & pre):
        log(f"#{holder:>6} strict    reservation pre-empted: main is red and fix "
            f"{', '.join(f'#{f}' for f in sorted(relevant & pre))} touches what broke it; main returns once green")
        holder = None
    # Urgent pre-emption (ADR-0343 amendment 2026-11-19): a non-urgent holder whose CI is still RUNNING yields
    # main to an admitted, GREEN urgent PR the lane can serve over this main — once per holder head. A green
    # holder merges this tick and is never interrupted. Main red: no urgent pre-emption (urgent is empty).
    elif (holder is not None and holder_state == "pending" and holder not in urgent and holder not in fixes
            and holder not in pre):
        ready = sorted(v["number"] for st, v in strict
                       if st == "green" and v["number"] in urgent and urgent_servable(git, base, v))
        hview = next((v for _st, v in strict if v["number"] == holder), {})
        if ready and URGENT_PREEMPT_CONTEXT in (hview.get("app") or {}):
            log(f"#{holder:>6} strict    keeps main: already pre-empted once by an urgent PR on this head "
                f"(#{ready[0]} waits)")
        elif ready:
            log(f"#{holder:>6} strict    reservation pre-empted by urgent #{ready[0]}: not blamed, served "
                f"first again once it is done")
            if preempted is not None:
                preempted.append(holder)
            holder = None
    return holder, timed_out


def stale_red_candidate(pr: dict, member_required: list[str], checks: dict[str, str | None]) -> list[str]:
    """The required contexts (merge-train aside) that are FAILURE on a same-repo PR that agent-pr-guard
    did not refuse. Empty = not a stale-red candidate. live_candidates only ever passes armed, non-draft
    PRs here; attribution to main is decided later, against main's own CI."""
    if not pr.get("same_repo", True):
        return []
    for name, state in checks.items():
        if GUARD_CONTEXT_HINT in name and state not in OK_STATES and state is not None:
            return []
    return [c for c in member_required if c != STATUS_CONTEXT and checks.get(c) == "failure"]


def main_ci_result(gh, git, ctx: str, sha: str, cache: dict | None = None, depth: int = STALE_RED_WALK) -> tuple[str, str] | None:
    """main's own CI verdict for `ctx` at `sha`: the push run's result on that commit, or on the nearest
    first-parent ancestor that has a completed one. (commit, conclusion) or None."""
    walk = git("rev-list", "--first-parent", f"--max-count={depth}", sha, check=False).stdout.split()
    for c in walk:
        if cache is not None and c in cache:
            res = cache[c]
        else:
            res = gh.checks(c)
            if cache is not None:
                cache[c] = res
        if res.get(ctx) is not None and res[ctx] not in INCONCLUSIVE_STATES:   # a cancelled run says nothing about main
            return c, res[ctx]
    return None


def stale_red_refresh(gh, git, base: str, red: list, shadow: bool, summary: dict) -> None:
    """Stale-red refresh (ADR-0343): an armed PR left red only because MAIN was red when its CI ran gets
    ONE update-branch once main is green again. Every failing required context must have failed on main
    at the PR's merge-base (or its nearest ancestor with a result) and be green on the current tip; and
    the PR must be behind main. After the refresh its merge-base IS the fixed main, so a PR still red
    then fails the attribution test and is never refreshed again — no loop. Oldest first, at most
    STALE_RED_CAP per tick. Git queries and the API only; no PR code runs."""
    summary.setdefault("refreshed", [])
    cache: dict = {}
    for view, failing in red:
        if len(summary["refreshed"]) >= STALE_RED_CAP:
            break
        n, head = view["number"], view["head_sha"]
        if git("merge-base", "--is-ancestor", base, head, check=False).returncode == 0:
            log(f"#{n:>6} stale-red not behind main — red on its own merits")
            continue
        mb = git("merge-base", head, base, check=False).stdout.strip()
        if not mb:
            continue
        why = None
        for ctx in failing:
            at_base = main_ci_result(gh, git, ctx, mb, cache)
            if not at_base or at_base[1] != "failure":
                why = f"{ctx} was not red on main at its base {mb[:12]} — its own defect"
                break
            at_tip = main_ci_result(gh, git, ctx, base, cache)   # one walk per tick, not one per PR
            if not at_tip or at_tip[1] not in OK_STATES:
                why = f"{ctx} is not green on main yet — no point refreshing"
                break
        if why:
            log(f"#{n:>6} stale-red skip: {why}")
            continue
        msg = f"stale-red refresh: {', '.join(failing)} was red on main {mb[:12]}, green on {base[:12]}"
        if shadow:
            log(f"#{n:>6} {msg} (shadow: no update)")
            continue
        ok = gh.update_branch(n, head)
        log(f"#{n:>6} {msg}: update-branch {'requested' if ok else 'refused'}")
        if ok:
            summary["refreshed"].append(n)


FIX_JOB_OK = frozenset({"success", "skipped", "neutral"})
NOT_FIX_KEY = ("not_fix",)   # cache slot: PR number -> why a green strict PR is not a main-red fix


def fix_job_evidence(main_jobs: dict[str, str | None] | None, head_jobs: dict[str, str | None] | None) -> str | None:
    """Why a PR head does NOT prove it fixes a main-red context, or None when it does. `main_jobs` is
    main's red run for that context, `head_jobs` the PR head's run for it (GitHub.ctx_jobs). Every job
    that failed on main must have RUN and succeeded on the head: path-scoped CI skips jobs, and a
    skipped job leaves an aggregate context (Validate manifests) green without testing the breakage
    (2026-11-13: #16005 touched only merge-train files, skipped Admin UI, and took the fix slot from
    the real fix). Fails closed: no job record on either side, or a main run with no failed job, is
    no evidence. A job red on main for ANOTHER context also has to pass — over-strict, never loose.
    A cancelled or timed-out job counts as failed too: a leaf that hung on main still fails the
    aggregate, and exempting it would let a head that SKIPPED the leaf read as the fix — the very hole
    this closes. Never treat a non-OK main job as inconclusive here."""
    if not main_jobs:
        return "no job record for main's red run"
    failed = sorted(n for n, c in main_jobs.items() if c is not None and c not in FIX_JOB_OK)
    if not failed:
        return "main's red run names no failed job"
    if not head_jobs:
        return "no job record on the head"
    missing = [f"{n} ({head_jobs.get(n) or 'absent'})" for n in failed if head_jobs.get(n) not in OK_STATES]
    return f"did not run green on the head: {', '.join(missing)}" if missing else None


def pin_changes(diff: str | None) -> tuple[list[tuple[str, str, str]], str | None]:
    """([(service, new tag, new ref)], why-not) of a `git diff -U0` text. Parsed by structure, never by
    line prefix: a file block's header runs from `diff --git` to its first `@@`, and only `index`,
    `--- a/` and `+++ b/` may appear there (a new, deleted, renamed, copied, mode-changed or binary file
    refuses). Inside a hunk every `-`/`+` line is CONTENT — an added `++x` or a removed `---` YAML
    separator is a changed line like any other, and must be an image pin. Each hunk must replace pins
    one for one, and a new pin must keep the replaced line's indentation and exact registry/repository:
    only the tag and digest may change."""
    if diff is None:
        return [], "diff unreadable"
    out: list[tuple[str, str, str]] = []
    state, rem, add = "none", [], []

    def close() -> str | None:
        if len(rem) != len(add):
            return "a hunk does not replace image pins one for one"
        for r, a in zip(rem, add, strict=True):
            if (r.group(1), r.group(2)) != (a.group(1), a.group(2)):
                return f"a pin changes its registry or repository ({r.group(2)} -> {a.group(2)})"
            out.append((a.group(3), a.group(4), a.group(2)))
        rem.clear()
        add.clear()
        return None

    for line in diff.splitlines():
        if line.startswith("diff --git "):
            why = close()
            if why:
                return [], why
            state = "header"
            continue
        if state == "header":
            if line.startswith("@@ "):
                state = "hunk"
            elif not (line.startswith("index ") or line.startswith("--- a/") or line.startswith("+++ b/")):
                return [], f"not a plain modification of an existing file: {line[:60]!r}"
            continue
        if state != "hunk":
            return [], f"unparseable diff line: {line[:60]!r}"
        if line.startswith("@@ "):
            why = close()
            if why:
                return [], why
            continue
        if line.startswith("\\"):
            continue   # "\ No newline at end of file"
        if not line.startswith(("+", "-")):
            return [], f"unexpected diff line: {line[:60]!r}"
        m = PIN_LINE_RE.fullmatch(line[1:])
        if not m:
            return [], f"changes a line that is not an image pin: {line[:60]!r}"
        (add if line[0] == "+" else rem).append(m)
    why = close()
    if why:
        return [], why
    if not out:
        return [], "changes no image pin"
    return out, None


def deploy_fix_refusal(view: dict, ctx: str, main_jobs: dict[str, str | None] | None,
                       entries: list[tuple[str, str, str, str]] | None, diff: str | None, run: dict | None,
                       run_jobs: dict[str, str | None] | None, src_on_main: bool, label_why: str | None,
                       commits: list[dict] | None = None, label_at: str | None = None) -> str | None:
    """Why `view` may NOT claim the fix slot for `ctx` as an auto-deploy gitops PR (see DEPLOY_FIX_LABEL),
    or None when it may. Pure: every input was read by deploy_fix_claim from git or the API. `entries` are
    (status, old mode, new mode, path) of base...head; `commits` the head's commits since the merge-base
    (GitHub.compare_commits); `label_at` the owner's latest label event time.

    Trust anchor: the run publishes its built digests nowhere this script can read, so the pins are not
    cross-checked against the build. What ties the pins to the run is that every commit is the App's —
    authored by it and committed by it or by GitHub on its behalf (`web-flow`, which is how the API
    commits of auto-deploy and the train's own update-branch merges are committed), with a signature
    GitHub verified — and that the owner's label is newer than every non-merge commit, so a push after
    the label withdraws the grant."""
    if view.get("author") != BOT_LOGIN:
        return f"author {view.get('author') or 'unknown'} is not {BOT_LOGIN}"
    m = DEPLOY_BRANCH_RE.fullmatch(view.get("head_ref") or "")
    if not m:
        return "head branch is not an auto-deploy gitops branch"
    src, run_id = m.group(1), int(m.group(2))
    if not entries:
        return "changed files unreadable"
    for status, old_mode, new_mode, path in entries:
        if status != "M" or old_mode != "100644" or new_mode != "100644":
            return f"{path}: {status} {old_mode}->{new_mode} is not a plain modification of a regular file"
        if unsafe_path(path) or not path.startswith(GITOPS_PIN_PREFIX) or not path.endswith(".yaml"):
            return f"changes {path}, not a gitops image-pin file"
    pins, why = pin_changes(diff)
    if why:
        return why
    stale = [f"{s}:{t}" for s, t, _r in pins if not t.endswith(f"-{src[:8]}")]
    if stale:
        return f"pin {stale[0]} was not built from the run's source {src[:12]} (a carried or foreign pin)"
    if not commits:
        return "the head's commits are unreadable"
    for c in commits:
        # A merge commit (two parents) may also be the train's own update-branch merge, authored by the
        # branch-updater App (#16947); its content is still bounded by the pin-only base...head diff above.
        authors = (BOT_LOGIN, BRANCH_UPDATER_LOGIN) if c.get("parents") == 2 else (BOT_LOGIN,)
        if not (c.get("author") in authors and c.get("committer") in (BOT_LOGIN, "web-flow") and c.get("verified") is True):
            return (f"commit {str(c.get('sha'))[:12]} is not the App's verified commit "
                    f"(author {c.get('author')}, committer {c.get('committer')}, verified {c.get('verified')})")
    if not isinstance(run, dict):
        return f"auto-deploy run {run_id} unreadable"
    if (run.get("id") != run_id or run.get("path") != AUTO_DEPLOY_WORKFLOW or run.get("head_sha") != src
            or run.get("head_branch") != "main"):
        return f"run {run_id} is not {AUTO_DEPLOY_WORKFLOW} over main at {src[:12]}"
    if not src_on_main:
        return f"the run's source {src[:12]} is not on main"
    missing = [j for j in DEPLOY_REQUIRED_JOBS if (run_jobs or {}).get(j) != "success"]
    if missing:
        return f"run {run_id} job `{missing[0]}` did not succeed ({(run_jobs or {}).get(missing[0]) or 'absent'})"
    if not main_jobs:
        return "no job record for main's red run"
    failed = sorted(n for n, c in main_jobs.items() if c is not None and c not in FIX_JOB_OK and n != ctx)
    if not failed:
        return "main's red run names no failed job besides the aggregate"
    other = [n for n in failed if not CONTRACT_JOB_RE.fullmatch(n)]
    if other:
        return f"main is red on `{other[0]}`, not a contract job: a deploy cannot fix it"
    if label_why:
        return label_why
    pushed = [str(c.get("date") or "") for c in commits if c.get("parents") != 2]
    if not label_at or not pushed or any(not ISO_Z_RE.fullmatch(d) for d in pushed + [label_at]):
        return "label or commit times unreadable"
    if label_at <= max(pushed):
        return f"{DEPLOY_FIX_LABEL} was applied ({label_at}) before the last commit ({max(pushed)}): re-apply it"
    return None


def deploy_fix_claim(gh, git, base: str, ctx: str, main_commit: str, view: dict, cache: dict | None,
                     now: float | None = None) -> str | None:
    """None = `view`'s head claims `ctx` as an auto-deploy fix (deploy_fix_refusal). The cheap refusals
    (author, label, branch) cost no API read; the rest is read once per head and context per tick."""
    if view.get("author") != BOT_LOGIN:
        return deploy_fix_refusal(view, ctx, None, None, None, None, None, False, None)
    if DEPLOY_FIX_LABEL not in (view.get("labels") or []):
        return f"no {DEPLOY_FIX_LABEL} label"
    m = DEPLOY_BRANCH_RE.fullmatch(view.get("head_ref") or "")
    head = view.get("head_sha") or ""
    if not m or not SHA_RE.fullmatch(head):
        return deploy_fix_refusal({**view, "head_ref": ""}, ctx, None, None, None, None, None, False, None)
    key = ("deploy_fix", view.get("number"), head, ctx, main_commit)
    if cache is not None and key in cache:
        return cache[key]
    src, run_id = m.group(1), int(m.group(2))
    r = git("diff", "-U0", "--no-color", "--no-ext-diff", "--no-renames", "--no-textconv", f"{base}...{head}", check=False)
    diff = r.stdout if r.returncode == 0 else None
    entries = [(c.status, c.old_mode, c.new_mode, p) for c in changed_entries(git, f"{base}...{head}") for p in c.paths]
    src_on_main = git("merge-base", "--is-ancestor", src, base, check=False).returncode == 0
    mb = git("merge-base", base, head, check=False).stdout.strip()
    commits = gh.compare_commits(mb, head) if SHA_RE.fullmatch(mb) else None
    owner = (getattr(gh, "repo", "") or "").split("/", 1)[0]
    day = time.strftime("%Y-%m-%d", time.gmtime(time.time() if now is None else now))
    n = view.get("number")
    label_why, label_at = "repository owner or PR number unknown", None
    if owner and isinstance(n, int):
        events = gh.issue_events(n)
        label_at, _ = urgent_grant(events, owner, DEPLOY_FIX_LABEL)
        label_why = urgent_refusal(n, events, owner, gh.urgent_grants_today(day, owner, DEPLOY_FIX_LABEL),
                                   DEPLOY_FIX_DAILY_CAP, day, label=DEPLOY_FIX_LABEL)
    why = deploy_fix_refusal(view, ctx, cached_ctx_jobs(gh, main_commit, ctx, cache), entries, diff,
                             gh.workflow_run(run_id), gh.run_jobs(run_id), src_on_main, label_why, commits, label_at)
    if cache is not None:
        cache[key] = why
    return why


def claim_evidence(gh, git, base: str, ctx: str, main_commit: str, view: dict, cache: dict | None,
                   now: float | None = None) -> str | None:
    """fix_evidence, or — for an App-authored auto-deploy PR only — the deploy fix claim (#16943). The
    deploy path is consulted only after the job rule refused, and its refusal is appended to that reason
    when the PR carries the label, so a refused deploy fix says why."""
    head = view["head_sha"]
    why = fix_evidence(gh, git, base, ctx, main_commit, head, cache)
    if not why or view.get("author") != BOT_LOGIN or DEPLOY_FIX_LABEL not in (view.get("labels") or []):
        return why
    dwhy = deploy_fix_claim(gh, git, base, ctx, main_commit, view, cache, now=now)
    if dwhy:
        return f"{why}; deploy fix refused: {dwhy}"
    if cache is not None:
        cache[(FIX_STRENGTH_KEY, head, ctx)] = (FIX_JOB_LEVEL, "deploy fix (can-i-deploy passed, owner-labelled)")
    log(f"#{view.get('number', 0):>6} deploy fix for {ctx}: auto-deploy pins, can-i-deploy green, {DEPLOY_FIX_LABEL}")
    return None


def note_not_fix(cache: dict | None, view: dict, why: str) -> None:
    """Record why a green strict PR was refused as a main-red fix: settle copies the slot into
    summary["not_fix"], so a real fix refused (a renamed or restructured job) is visible to a human."""
    log(f"#{view.get('number', 0):>6} not a fix: {why}")
    if cache is not None and view.get("number") is not None:
        cache.setdefault(NOT_FIX_KEY, {})[view["number"]] = why
        if view.get("head_sha"):
            cache.setdefault(NOT_FIX_HEAD_KEY, {})[view["number"]] = view["head_sha"]


def publish_fix_claims(gh, base: str, not_fix: dict[int, str], heads: dict[int, str], shadow: bool) -> list[int]:
    """Refusal visibility (review LOW of #16760): the reason a fix claim was refused reaches the PR as the
    App's `merge-train/fix-claim` status on the refused head — until now it lived only in the settle log
    and summary["not_fix"]. A status, not a comment: one GET (the App's own statuses on the head) and a
    POST only when the description changed, against a comment's list + create/update, and no thread
    noise. State `failure` like `merge-train/notice`: never required, so it blocks nothing. The
    description names the main it was judged against, so a stale one reads as stale. NEVER read back
    for any decision: fix evidence is re-derived every tick. Shadow posts nothing."""
    posted: list[int] = []
    for n, why in sorted(not_fix.items()):
        head = heads.get(n)
        if not head or not SHA_RE.fullmatch(head):
            continue
        desc = f"not a fix over main {base[:12]}: {why}"[:140]
        if gh.app_statuses(head).get(FIX_CLAIM_CONTEXT) == ("failure", desc):
            continue   # already says exactly this: idempotent
        if shadow:
            log(f"#{n:>6} fix-claim status (shadow, not posted): {desc}")
            continue
        gh.post_status(head, "failure", desc, context=FIX_CLAIM_CONTEXT)
        posted.append(n)
    return posted


def cached_ctx_jobs(gh, sha: str, ctx: str, cache: dict | None) -> dict[str, str | None] | None:
    key = ("ctx_jobs", sha, ctx)
    if cache is not None and key in cache:
        return cache[key]
    out = gh.ctx_jobs(sha, ctx)
    if cache is not None:
        cache[key] = out
    return out


def cached_gate_records(gh, sha: str, ctx: str, slugs: list[str], cache: dict | None) -> dict[str, list | None] | None:
    """gh.gate_shard_records once per tick per (main commit, shard set): the aggregate `Validate manifests` and
    every red `gates (<slug>)` context name the same run, so they share the read."""
    key = ("gate_records", sha, tuple(sorted(set(slugs))) if slugs is not None else ("*",))
    if cache is not None and key in cache:
        return cache[key]
    out = gh.gate_shard_records(sha, ctx, slugs)
    if cache is not None:
        cache[key] = out
    return out


def cached_text(git, rev: str, path: str, cache: dict | None) -> str | None:
    """`git show rev:path` once per tick (None = absent): fix_contexts runs two or three times per head and
    tick (promotion, then strict_fixes in the reservation and in the strict lane), and each run read the
    head's gates.yaml again — one spawn each, identical inputs."""
    key = ("text", rev, path)
    if cache is not None and key in cache:
        return cache[key]
    r = git("show", f"{rev}:{path}", check=False)
    out = r.stdout if r.returncode == 0 else None
    if cache is not None:
        cache[key] = out
    return out


def cached_changes(git, base: str, head: str, cache: dict | None) -> list:
    """changed_entries(base...head) once per tick per head: every context of a claim and the dependency walk
    read the same change set (one `git diff` spawn, not one per context)."""
    key = ("changes", base, head)
    if cache is not None and key in cache:
        return cache[key]
    out = changed_entries(git, f"{base}...{head}")
    if cache is not None:
        cache[key] = out
    return out


def fix_evidence(gh, git, base: str, ctx: str, main_commit: str, head: str, cache: dict | None) -> str | None:
    """Why `head` does NOT prove it fixes `ctx`, red on main at `main_commit`, or None when it does:
    fix_job_evidence (every job red on main ran green on the head), then selftest_skip_refusal (a red
    gate SELF-TEST on main must have RUN on the head, not been skipped by run-gates' input gating). The
    second read costs API only when a gate shard failed on main, and is cached per main commit; the
    head's changed set is the pull request's own side (`base...head`, what run-gates judged) and the
    declaration is the head's own gates.yaml (what its runner read)."""
    main_jobs = cached_ctx_jobs(gh, main_commit, ctx, cache)
    why = fix_job_evidence(main_jobs, cached_ctx_jobs(gh, head, ctx, cache))
    if why:
        return why
    failed = sorted(n for n, c in (main_jobs or {}).items() if c is not None and c not in FIX_JOB_OK)
    slugs = [m.group(1) for n in failed for m in [GATE_SHARD_JOB_RE.fullmatch(n)] if m]
    if not slugs:
        # No gate shard red on main: the job is the unit of evidence; nothing finer exists to verify.
        if cache is not None:
            cache[(FIX_STRENGTH_KEY, head, ctx)] = (FIX_JOB_LEVEL, "job-level (no gate red on main)")
        return None
    gates_text = cached_text(git, head, GATES_YAML, cache)
    declared = parse_selftest_inputs(gates_text) if gates_text is not None else None
    changes = cached_changes(git, base, head, cache)
    head_files = list(dict.fromkeys(p for c in changes for p in c.paths))
    main_records = cached_gate_records(gh, main_commit, ctx, slugs, cache)
    why = selftest_skip_refusal(main_jobs, main_records, head_files, declared)
    if why:
        return why
    # Gate-level evidence: the gate red on main should be `ok` somewhere in the head's own gate results
    # (all shards: a gate may move), not skipped inside a green shard job — a full-fleet CI run of an
    # unrelated PR passes the job rule for every job. Skipped/absent caps the strength; red refuses.
    # A head that changes the JUDGE — any gate script or helper, workflow, action, or the gate manifest,
    # baselines and measurements — cannot be verified BY that judge: its green may be the edit talking.
    # Refused outright, never capped: such a fix is merged by a human. A prefix rule, deliberately: a
    # dependency parser read run-gates.py itself as unknown and refused every gate-shard fix claim.
    touched = sorted(f for f in head_files if f.startswith(FIX_JUDGE_PREFIXES) or f in FIX_JUDGE_FILES)
    if touched:
        return (f"the head changes the judge ({touched[0]}): a fix claim may not edit CI gates, scripts, workflows "
                "or actions — its own green cannot verify a fix; it is merged by a human")
    # ...and whatever the RED gates' own entries name in run/selftest — scripts outside .github/ included —
    # read from BOTH the base's and the head's gates.yaml, so a head cannot rename its way out. Not their
    # selftest_inputs (subjects, not judge). A path named only by a gate green on main does not refuse.
    red_ids = {str(r.get("id")) for recs in (main_records or {}).values() if isinstance(recs, list)
               for r in recs if isinstance(r, dict) and r.get("status") in RED_GATE_STATES}
    named_files, named_dirs = set(), set()
    for text in (cached_text(git, base, GATES_YAML, cache), gates_text):
        if text:
            fs, ds = gate_named_paths(text, red_ids)
            named_files |= fs
            named_dirs |= ds
    hit = sorted(f for f in head_files if f in named_files or f.startswith(tuple(named_dirs)))
    if hit:
        return (f"the head changes {hit[0]}, which a gate red on main names in its run/selftest: its own "
                "green cannot verify a fix; it is merged by a human")
    # Head artifacts count only for the BASE shard set with a green `gates (<slug>)` job behind each.
    head_records = trusted_head_records(cached_gate_records(gh, head, ctx, None, cache), main_jobs,
                                        cached_ctx_jobs(gh, head, ctx, cache))
    why, level, word = gate_level_evidence(main_records, head_records)
    if cache is not None:
        cache[(FIX_STRENGTH_KEY, head, ctx)] = (level, word)
    return why


def fix_contexts(gh, git, base: str, view: dict, main_red: dict[str, str], cache: dict | None = None,
                 head_checks: dict[str, str | None] | None = None, record: bool = True) -> list[str]:
    """The main-red contexts this green PR demonstrably fixes: red in main's CI at the PR's own
    merge-base (or nearest ancestor with a verdict), and every job that failed in that red run ran
    green on the PR head (fix_job_evidence). A PR that went green over a base that was still green
    proves nothing about the breakage and is NOT a fix; nor is one whose CI skipped the failing job.
    `head_checks`, when given, are the head's verdicts: a context not green there is dropped before any
    job list is read (the job evidence costs two API reads per head and context). `record` False keeps a
    refusal out of summary["not_fix"] (a train candidate that is not a fix just stays a candidate)."""
    mb = git("merge-base", view["head_sha"], base, check=False).stdout.strip()
    if not mb:
        return []
    out = []
    if cache is not None and ("extra_gates", base) in cache:
        extra = cache[("extra_gates", base)]
    else:
        extra = train_extra_gates(git, base) or {}   # one rules.yaml read per tick, not one per claim
        if cache is not None:
            cache[("extra_gates", base)] = extra
    for ctx in sorted(main_red):
        if ctx in extra and gh.extra_checks(view["head_sha"], {ctx: extra[ctx]}).get(ctx) not in OK_STATES:
            continue   # an extra gate is not required: only its own pinned GREEN on the head proves a fix
        if head_checks is not None and head_checks.get(ctx) not in OK_STATES:
            continue
        at_base = main_ci_result(gh, git, ctx, mb, cache)
        if not at_base or at_base[1] != "failure":
            continue
        why = claim_evidence(gh, git, base, ctx, at_base[0], view, cache)
        if why:
            note_not_fix(cache if record else None, view, f"{ctx} {why}")
            continue
        out.append(ctx)
    return out


def masked_no_worse(gh, ctx: str, head: str, main_commit: str, cache: dict | None) -> bool:
    """Whether `head`, red on `ctx` like main at `main_commit`, fails no job for it that main did not:
    the head's failing jobs for the context are a subset of main's. Unreadable on either side = False
    (no masking without evidence)."""
    mj, hj = cached_ctx_jobs(gh, main_commit, ctx, cache), cached_ctx_jobs(gh, head, ctx, cache)
    if not mj or not hj:
        return False
    def failing(jobs):
        return {n for n, v in jobs.items() if v is not None and v not in FIX_JOB_OK}
    fh = failing(hj)
    # A head red on the context with NO failing job is inconsistent evidence (an empty set is a subset
    # of anything): it never masks the context as success.
    return bool(fh) and fh <= failing(mj)


def fix_head_state(gh, git, base: str, view: dict, member: list[str], checks: dict[str, str | None],
                   app: dict | None, modes: list[str], main_red: dict[str, str] | None,
                   cache: dict | None = None, extra: dict[str, str] | None = None) -> tuple[str | None, list[str], str]:
    """(state, fix set, why) for a fix PR whose head is red ONLY where main is (ADR-0343, update then
    verify). A fix is never merged untested against main: strict_lane update-branches it, and only the
    COMBINED head may merge. The fix set is what the PR claimed before that update — fix_contexts of the
    first parent of its update-branch merge (or of the head itself while it is still behind), each
    green there. On the head being judged, every context in the fix set must be green; every other
    required context green, or `failure` on main too (no worse than main); anything else refuses.
    Everything else in `qualifies` (state, draft, fork, agent-pr-guard, merge-train failure) still
    applies. Returns (None, [], why) when the PR is not such a fix; strict_lane_state then decides."""
    if not main_red:
        return None, [], "main is green"
    if any(unsafe_path(f) for f in view.get("files") or []) or any(m in SPECIAL_MODES for m in modes):
        return None, [], "unsafe path or mode"
    head = view["head_sha"]
    claim_from = head
    if git("merge-base", "--is-ancestor", base, head, check=False).returncode == 0:
        parents = git("rev-list", "--parents", "-n", "1", head, check=False).stdout.split()
        if len(parents) != 3 or git("merge-base", "--is-ancestor", base, parents[1], check=False).returncode == 0:
            return None, [], "up to date, and not the update of a fix behind main"
        claim_from = parents[1]
    claim_checks = checks if claim_from == head else (pinned_checks(gh, claim_from, extra) if extra else gh.checks(claim_from))
    claimed = fix_contexts(gh, git, base, {**view, "head_sha": claim_from}, main_red, cache, head_checks=claim_checks)
    if not claimed:
        return None, [], "claims no main-red context"
    # An unclaimed context red on main AND on the head is masked only when the head is independently no
    # worse there: every job it fails for that context failed on main too (masked_no_worse). A job-level
    # fix for one context can therefore never hide a breakage of its own under another main-red context.
    masked = {c: ("success" if c in main_red and c not in claimed and v == "failure"
                  and masked_no_worse(gh, c, head, main_red[c], cache) else v) for c, v in checks.items()}
    ok, why = qualifies(view, member, masked, app, untrainable=lambda _f: False, extra=extra)
    if ok and claim_from != head:
        # The combined head is what merges: it must have run the failing jobs too, not only the claim.
        mb = git("merge-base", claim_from, base, check=False).stdout.strip()
        for c in claimed:
            at_base = main_ci_result(gh, git, c, mb, cache) if mb else None
            why = (claim_evidence(gh, git, base, c, at_base[0], {**view, "head_sha": head}, cache)
                   if at_base else "no main verdict at the claim's base")
            if why:
                note_not_fix(cache, view, f"combined head: {c} {why}")
                return None, [], f"combined head: {c} {why}"
    if ok:
        return "green", claimed, f"fix for {', '.join(claimed)} red on main {base[:12]}"
    if why.startswith(("required context pending", "required context never reported", "extra gate pending")) and not any(
            v is not None and v not in OK_STATES for c, v in masked.items() if c in member):
        return "pending", claimed, why
    return None, [], why


def strict_lane(gh, git, base: str, strict: list, carrier_in_flight: bool, shadow: bool, summary: dict,
                main_red: dict[str, str] | None = None, cache: dict | None = None,
                holder: int | None = None, timed_out: list | None = None, yield_why: str | None = None,
                relevant: set[int] | None = None, urgent: set[int] | None = None) -> None:
    """Manual-lane PRs merge exactly as strict up-to-date allowed: CI green on a head that already
    contains live main. Oldest first. Up to date + green -> status + merge pinned to that head; up to
    date + CI running -> main is RESERVED (in_flight, so no train is built under it); green but
    behind -> update-branch for the oldest one only, and none while another is reserved, so CI is never
    flooded. Nothing here executes PR code: ancestry is a git query, the rest is the API.

    Main red (ADR-0343, main-red awareness): a PR whose only failures are red on main too is
    "waiting" — skipped, never reserving. No update-branch is issued onto a red main: it could only
    manufacture main-caused red. A green PR that was red-based on a main-red context is the FIX: it
    is ranked first and update-branched like any other strict PR, holding the reservation while CI runs
    on the combined head; it merges only that head, verified by fix_head_state, pinned to its sha."""
    summary.setdefault("strict", [])
    summary.setdefault("updated", [])
    summary.setdefault("waiting", [])
    main_red = main_red or {}
    fixes: dict[int, list[str]] = {}
    for state, view in strict:
        if state == "waiting":  # never served, never reserving: logged before any merge can end the loop
            log(f"#{view['number']:>6} strict    {view.get('strict_why') or main_red_reason(list(main_red), main_red)}")
            summary["waiting"].append(view["number"])
    if main_red:
        fixes = strict_fixes(gh, git, base, strict, main_red, cache)
        # Union of #16700 and #16760: a fix that touches what broke main first (relevance), then every other
        # fix strongest evidence first, oldest within; everything else after in its existing order.
        strict = fixes_first(strict, fixes, cache, relevant)
    relevant = relevant if main_red else set()
    if urgent:
        # Urgent first within each rank: on a red main every fix still precedes it (an urgent fix leads the
        # fixes), and a non-fix urgent PR is still never updated onto a red main (below).
        strict = sorted(strict, key=lambda sv: (0 if sv[1]["number"] in (relevant or ()) else 1 if sv[1]["number"] in fixes
                                                else 2, sv[1]["number"] not in urgent))
    updated = holder is not None  # main reserved (strict_reservation): no other strict-lane action while it runs
    main_health_checked = False  # one final inventory read, shared by this strict-lane invocation
    for state, view in strict:
        n, head = view["number"], view["head_sha"]
        if holder is not None and n != holder:
            log(f"#{n:>6} strict    held: main reserved for strict-lane #{holder}")
            continue
        if state == "waiting":
            continue
        current = git("merge-base", "--is-ancestor", base, head, check=False).returncode == 0
        if current and state == "pending" and n in (timed_out or []):
            continue
        fix = fixes.get(n)
        if relevant and n not in relevant:
            # Main red and a fix that touches the breakage waits: nothing else moves main first, not even
            # another "fix" whose diff is elsewhere (#16583/#16602 merged onto red main, main stayed red).
            log(f"#{n:>6} strict    held: main is red and fix {', '.join(f'#{f}' for f in sorted(relevant))} "
                f"touches what broke it — served first")
            continue
        if fix and state == "green" and not main_health_checked:
            main_health_checked = True
            if defer_recovered_main_red(gh, base, main_red, summary):
                return
        if current and state == "pending":
            log(f"#{n:>6} strict    up to date, CI running: main reserved for it")
            summary["in_flight"] = True
            updated = True  # one strict-lane PR in progress at a time: no other update while it runs
            continue
        # Pre-empted (#13400): a head that yielded to a carrier (DEFER_CONTEXT on it) and is now behind
        # main because that carrier merged first. Its running CI can no longer merge anything, so it is
        # re-updated now rather than after that worthless CI finishes — otherwise further carriers are
        # built while it runs behind main and the one-yield bound does not hold.
        preempted = (not current and state == "pending"
                     and gh.app_statuses(head).get(DEFER_CONTEXT, ("", ""))[0] == "success")
        if state != "green" and not preempted:
            continue
        if not current:
            if main_red and not fix:
                ctxs = sorted(main_red)
                log(f"#{n:>6} strict    behind main, not updated: {main_red_reason(ctxs, main_red)}")
                continue
            if updated or shadow:
                continue
            if yield_why:
                log(f"#{n:>6} strict    behind main, not updated: {yield_why} — next tick")
                updated = True  # one log line: no younger strict PR is updated either
                continue
            # Conflict with main (#13400): decided locally by merge-tree, before any API call. A strict
            # PR that cannot be merged with main holds nothing — it is skipped, told once per head that it
            # conflicts, and the NEXT strict PR is served in this same tick. GitHub's update-branch would
            # only refuse it again: #13739 was re-requested on every tick for ~11 h (2026-10-26) while
            # the installation token ran out (403 at 16:39Z killed a deferral carrier's build).
            told = (view.get("app") or {}).get(NOTICE_CONTEXT, ("", ""))[1]
            if told.startswith(f"{REFUSED_PREFIX}{base[:12]}"):
                # Quota (#13400): GitHub already refused THIS head over THIS main and nothing changed,
                # so asking again can only be refused again. A new head or a moved main asks again.
                log(f"#{n:>6} strict    behind main {base[:12]}: update-branch already refused for this head "
                    f"over this main — not asked again, next strict PR served")
                summary.setdefault("refused", []).append(n)
                continue
            clash = conflict_paths(git, base, head)
            if clash and NOTICE_CONTEXT in (view.get("app") or {}):
                log(f"#{n:>6} strict    behind main {base[:12]}, conflicts with it on {len(clash)} path(s): "
                    f"already told on this head — next strict PR served")
                summary.setdefault("conflicts", []).append(n)
                continue
            if clash:
                log(f"#{n:>6} strict    behind main {base[:12]}, conflicts with it on {len(clash)} path(s): "
                    f"not updated, reservation released — next strict PR served")
                notice_once(gh, n, head, f"{CONFLICT_PREFIX}{base[:12]}: strict lane — merge main into the branch",
                            notice_text(STRICT_CONFLICT_COMMENT, clash))
                summary.setdefault("conflicts", []).append(n)
                continue
            # A fix too: never merged untested against main. Its combined head must verify (fix_head_state).
            ok = gh.update_branch(n, head)
            log(f"#{n:>6} strict    behind main {base[:12]}{' (fix for ' + ', '.join(fix) + ')' if fix else ''}: "
                f"update-branch {'requested' if ok else 'refused'}")
            if ok:
                updated = True
                summary["in_flight"] = True  # the reservation starts now: no train is built under it
                summary["updated"].append(n)
            else:
                summary.setdefault("refused", []).append(n)
                workflows = workflow_merge_blobs(git, base, head)
                notice_once(gh, n, head, f"{REFUSED_PREFIX}{base[:12]}: merge main into the branch",
                            notice_text(WORKFLOW_REFUSED_COMMENT, workflows, "Workflow files changed on both sides")
                            if workflows else notice_text(REFUSED_COMMENT, conflict_paths(git, base, head)))
            continue
        if carrier_in_flight:
            log(f"#{n:>6} strict    green, but a train is in flight over main — next tick")
            continue
        if shadow:
            log(f"#{n:>6} strict    green and up to date{' fix for ' + ', '.join(fix) if fix else ''} (shadow: no status, no merge)")
            continue
        if gh.main_sha() != base:
            log(f"#{n:>6} strict    main moved since it was read — next tick")
            break
        if not live_source_intent(gh, n, head):
            log(f"#{n:>6} strict    source intent or head changed — next tick")
            continue
        if fix:
            desc = f"strict lane: fix for {', '.join(fix)} red on main {base[:12]}, verified on its up-to-date head"
            log(f"#{n:>6} strict    fix for {', '.join(fix)} red on main {base[:12]}: combined head verified, merging")
        else:
            desc = f"strict lane: green on an up-to-date head over main {base[:12]}"
        gh.post_status(head, "success", desc, source_number=n)
        merged = gh.merge(n, head)
        if not merged:
            log(f"#{n:>6} strict    did not merge; stopping")
            break
        summary["strict"].append(n)
        summary["merged"].append(n)
        break  # main moved: every other strict-lane head is now behind it


# --------------------------------------------------------------------------- strict carrier (ADR-0343)
def needs_regeneration(files: list[str], fragments: list[str], outputs: list[str]) -> str | None:
    """Why a member cannot ride a strict carrier without a regeneration commit (which a strict carrier
    never carries): it touches a regen-inventory INPUT (same `frag in path` test as regen-derived.sh)
    or a declared DERIVED OUTPUT. Two such members each regenerated for their own change are jointly
    stale, so a batch of them would be red together and green alone forever; they take today's lane,
    where main's own gates prove the combined head."""
    for f in files:
        for frag in fragments:
            if frag in f:
                return f"{f} (regen input {frag})"
        for g in outputs:
            if glob_match(g, f):
                return f"{f} (derived output {g})"
    return None


def member_paths(git, base: str, head: str) -> set[str] | None:
    """The disjoint_key of every path a member changes, read from the TREES (merge-base with main..head, no rename
    detection, so a rename reports both names). None when git cannot say: the member then shares
    nothing (fail closed)."""
    mb = git("merge-base", base, head, check=False)
    if mb.returncode != 0 or not mb.stdout.strip():
        return None
    r = git("diff-tree", "-r", "--no-renames", "--name-only", mb.stdout.strip(), head, check=False)
    if r.returncode != 0:
        return None
    return {disjoint_key(ln) for ln in r.stdout.splitlines() if ln}


ANALYSIS_MODULE_RE = re.compile(r"libs|detekt|ktlint|lint|rule|governance|auditor|scanner|arch|contract|infra|test")
_SHAREABLE_MODULES: dict[str, frozenset[str]] = {}


def shareable_modules(git, base: str) -> frozenset[str]:
    """Top-level `openbank-*` modules whose code may share a strict carrier: a LEAF (no `*.gradle.kts`
    outside settings depends on it via `project(":<name>")`, so its code compiles into nobody's build or
    analysis) whose name marks no library, analysis, rule, governance or test module, and that is neither
    end of a cross-module TEST read (a test under */src/test/ naming `../openbank-<m>` or `"openbank-<m>/`:
    the reading module's tests judge <m>'s code, so neither may share). One ls-tree and two git greps per
    base, memoised; a git error shares nothing."""
    if base not in _SHAREABLE_MODULES:
        tops = git("ls-tree", "-d", "--name-only", base, check=False)
        deps = git("grep", "-h", "-o", "-E", r'project\("?:[A-Za-z0-9_-]+', base, "--", "*.gradle.kts",
                   ":(exclude)settings.gradle.kts", check=False)
        # ANY `openbank-<m>` token in a test that names another EXISTING top-level module counts as a read
        # (security review: not only the `../openbank-<m>` and `"openbank-<m>/` shapes).
        reads = git("grep", "-z", "-o", "-E", r'openbank-[a-z0-9-]+', base, "--", TEST_SOURCE_PATHSPEC, check=False)
        # Fail closed on any OTHER way a test can leave its module (#16290 follow-up review): walking up
        # with parentFile (AuditResourceSecurityTest, InitiatorScopesTest), a ".." path segment, the
        # Gradle root or user.dir. The target cannot be read off such a line, so the READER is excluded:
        # it then rides alone, and a reader riding alone is never batched with what it reads.
        climbs = git("grep", "-z", "-l", "-i", "-E", TEST_LEAVE_RE, base, "--", TEST_SOURCE_PATHSPEC, check=False)
        if (tops.returncode != 0 or deps.returncode not in (0, 1) or reads.returncode not in (0, 1)
                or climbs.returncode not in (0, 1)):
            _SHAREABLE_MODULES[base] = frozenset()
        else:
            used = {ln.rsplit(":", 1)[-1] for ln in deps.stdout.splitlines()}
            top_set = set(tops.stdout.splitlines())
            # -z: `<base>:<path>NUL<match>` per line, so a path containing ':' cannot shift the fields. Anything
            # that does not parse to exactly that, with a match that IS a module token, shares nothing.
            unparsed, prefix = False, f"{base}:"
            for ln in reads.stdout.splitlines():
                left, sep, match = ln.partition("\0")
                if not sep or not left.startswith(prefix) or not re.fullmatch(r"openbank-[a-z0-9-]+", match):
                    unparsed = True
                    break
                reader = left[len(prefix):].split("/", 1)[0]
                if match in top_set and reader != match:
                    used |= {reader, match}
            for rec in climbs.stdout.split("\0"):
                rec = rec.strip("\n")
                if not rec:
                    continue
                if not rec.startswith(prefix):
                    unparsed = True
                    break
                used.add(rec[len(prefix):].split("/", 1)[0])
            if unparsed:
                used |= set(top_set)
            _SHAREABLE_MODULES[base] = frozenset(
                m for m in tops.stdout.splitlines()
                if m.startswith("openbank-") and m not in used and not ANALYSIS_MODULE_RE.search(m[len("openbank-"):]))
    return _SHAREABLE_MODULES[base]


def config_judge_path(path: str, refs=None, modules: frozenset[str] = frozenset()) -> bool:
    """A judge path (judge_path) that may configure a VERDICT, so it rides alone: every judge path
    except the SHAREABLE_JUDGE_RE allow-list inside a shareable module (`modules`, shareable_modules;
    empty = no module shares) — fail closed. `.github/` never qualifies."""
    if not judge_path(path, refs):
        return False
    if path.startswith(".github/") or not SHAREABLE_JUDGE_RE.fullmatch(path):
        return True
    return path.split("/", 1)[0] not in modules


# `\b` is NOT portable: git grep -E on macOS (BSD regex) silently matches nothing for `\.parent\b`.
TEST_LEAVE_RE = r'"\.\.|\.\./|parentFile|\.parent([^A-Za-z0-9_]|$)|rootDir|rootProject|projectDir|user\.dir'
TEST_CLIMB_RE = TEST_LEAVE_RE + r'|openbank-[a-z0-9-]+'
# Every test-shaped source set: src/test, src/integrationTest, src/testFixtures, src/e2eTest, ...
TEST_SOURCE_PATHSPEC = "*/src/*[Tt]est*/*"
TEST_SOURCE_RE = re.compile(r"(^|/)src/[A-Za-z0-9_]*[Tt]est[A-Za-z0-9_]*/")


def member_test_reaches_out(git, head: str, files: list[str]) -> bool:
    """A member whose OWN changed tests (on its head) leave their module rides alone: a climb, a `..`
    segment, the Gradle root, or any `openbank-<m>` token other than the test's own module. The base-tree
    scan in shareable_modules cannot see a cross-module read the member itself adds (security review of
    the #16290 follow-up). A git error counts as reaching out (fail closed)."""
    tests = [f for f in files if TEST_SOURCE_RE.search(f)]
    if not tests:
        return False
    r = git("grep", "-o", "-I", "-E", TEST_CLIMB_RE, head, "--", *tests, check=False)
    if r.returncode not in (0, 1):
        return True
    for ln in r.stdout.splitlines():           # <head>:<path>:<match>
        parts = ln.split(":", 2)
        if len(parts) != 3:
            return True
        own, match = parts[1].split("/", 1)[0], parts[2]
        if not match.startswith("openbank-") or match != own:
            return True
    return False


def disjoint_key(path: str) -> str:
    """What two members of a judge carrier may not share: the whole path under `.github/` (non-judge
    scripts are compared file by file), otherwise the top-level MODULE, so no diff-scoped gate can pair
    one member's companion file with another member's code in the same module."""
    return path if path.startswith(".github/") else path.split("/", 1)[0]


_TRAIN_CODE: dict[str, frozenset[str]] = {}


def train_code_paths(git, base: str) -> frozenset[str]:
    """The train's OWN code over `base`, derived, never hand-listed: every `.github/scripts` or
    `.github/workflows` file named merge-train* / merge_train* (its script, carrier library, workflow,
    stall watch and tests) plus every module under `.github/scripts` that merge-train.py imports. One
    `git ls-tree` and one `git show` per base, memoised. A member touching any of it rides alone: it
    decides how the next ticks settle, bisect and blame."""
    if base not in _TRAIN_CODE:
        listed = git("ls-tree", "-r", "--name-only", base, "--", ".github/scripts", ".github/workflows", check=False)
        names = set(listed.stdout.splitlines()) if listed.returncode == 0 else set()
        own = {n for n in names if TRAIN_CODE_RE.fullmatch(n)}
        src = git("show", f"{base}:.github/scripts/merge-train.py", check=False).stdout
        for m in re.finditer(r"^\s*(?:from|import)\s+([A-Za-z_][A-Za-z0-9_]*)", src, re.MULTILINE):
            mod = f".github/scripts/{m.group(1)}.py"
            if mod in names:
                own.add(mod)
        _TRAIN_CODE[base] = frozenset(own)
    return _TRAIN_CODE[base]


def build_strict_carrier(git, base: str, views: list[dict], cap: int, judge_is, fragments: list[str],
                         outputs: list[str], judge_cap: int = STRICT_JUDGE_BATCH_CAP_DEFAULT,
                         alone_is=None, member_alone=None) -> tuple[str, list[tuple[int, str]]] | None:
    """Execution-free: `git merge-tree --write-tree` of each green, behind-main strict head onto settle's
    OWN chain over live main (commit-tree with the train's member message, so parse_own_chain and
    merge_train_carrier read it exactly like a train). No generator runs, no regeneration commit exists,
    nothing from a PR is checked out. Returns (tip, [(number, head)]) with at least two members, or None:
    fewer than two apply (today's update-branch path), or the batch is REFUSED — a gates.yaml whose
    `- id:` set after the merge is not the union of main's and every member's (an id lost in the merge
    would retire a gate for the members riding with it) is skipped — it rides alone or takes today's
    lane; merge-tree failing to decide refuses the batch. A member that configures a verdict or is the
    train's own code (`alone_is`: config_judge_path, train_code_paths), or any judge member at
    judge_cap 1, rides ALONE: when it is the oldest eligible member it is the whole carrier, otherwise
    it waits for the next one. Any other JUDGE member (judge_is) shares a carrier only under DISJOINT
    batching (ADR-0343 amendment 2026-11-15): once a carrier holds one, every member's changed path set
    must be disjoint from every other member's, and the carrier holds at most `judge_cap` members.

    A member that can only take the update-branch lane (it needs regeneration, or changes a workflow,
    which the App's token cannot push to a carrier branch) is skipped behind members already applied,
    but when it is FIRST in line no carrier is built this tick: `views` is in serving order (expedited,
    then oldest), and carriers built around it would overtake it until the eligible set drained."""
    own, own_tree = base, git.tree(base)
    base_special = git.special_entries(base)
    gates_union = gate_ids(git("show", f"{base}:{GATES_YAML}", check=False).stdout)
    applied: list[tuple[int, str]] = []
    members: list[Member] = []
    sizes: dict[int, int | None] = {}
    alone = False
    has_judge = False
    paths: dict[int, set[str] | None] = {}
    for view in views:
        n, head, files = view["number"], view["head_sha"], view.get("files") or []
        if alone or len(applied) >= cap or (has_judge and len(applied) >= judge_cap):
            log(f"#{n:>6} strict    waits: strict carrier full "
                f"({'a judge member rides alone' if alone else judge_cap if has_judge else cap})")
            continue
        why = needs_regeneration(files, fragments, outputs)
        if why:
            log(f"#{n:>6} strict    not batched: needs regeneration — {why}; today's lane serves it")
            if not applied:
                return None   # first in line: no carrier overtakes it (see the docstring)
            continue
        is_judge = any(judge_is(f) for f in files)
        alone_of = alone_is if alone_is is not None else judge_is
        rides_alone = is_judge and (judge_cap < 2 or any(alone_of(f) for f in files)
                                    or (member_alone is not None and member_alone(head, files)))
        if rides_alone and applied:
            log(f"#{n:>6} strict    waits: changes what configures a verdict (a workflow, action, checker, gate or "
                f"rule declaration, build configuration, the train's own code) — it rides alone, after the members ahead of it")
            continue
        if applied and (is_judge or has_judge):
            # Disjoint batching: this member and every member already applied must share no path.
            mine = member_paths(git, base, head)
            if len(applied) >= judge_cap:
                log(f"#{n:>6} strict    waits: a carrier with a judge member holds at most {judge_cap}")
                continue
            if mine is None or any(paths.get(a) is None for a, _ in applied):
                log(f"#{n:>6} strict    not batched: its changed paths cannot be read — a judge carrier shares nothing")
                continue
            shared = sorted(set().union(*[mine & paths[a] for a, _ in applied]))
            if not shared and not has_judge:
                # The FIRST judge member joins non-judge members, which may overlap each other (allowed
                # without a judge): the whole carrier must become pairwise disjoint, or it waits.
                seen: set[str] = set()
                for a, _ in applied:
                    shared += sorted(seen & paths[a])
                    seen |= paths[a]
            if shared:
                log(f"#{n:>6} strict    not batched: shares {shared[:3]} with the members ahead of it, and a carrier "
                    f"with a judge member needs disjoint members — next strict carrier")
                continue
            paths[n] = mine
        r = git("merge-tree", "--write-tree", own, head, check=False)
        if r.returncode == 1:
            log(f"#{n:>6} strict    not batched: conflicts with the members ahead of it — next strict carrier")
            continue
        if r.returncode != 0 or not r.stdout.split():
            log(f"::warning::strict carrier refused: merge-tree failed for #{n} (rc={r.returncode})")
            return None
        tree = r.stdout.split()[0]
        if tree == own_tree:
            log(f"#{n:>6} strict    not batched: no-op over the members ahead of it")
            continue
        # Read from the trees, not the PR's file list: a rename reports only its new name there, and
        # what GitHub refuses is any change under the directory in the pushed commit.
        if git("diff-tree", "-r", "--no-renames", "--name-only", own_tree, tree, "--", WORKFLOWS_DIR, check=False).stdout.strip():
            log(f"#{n:>6} strict    not batched: changes {WORKFLOWS_DIR}, which the App may not push — today's lane serves it")
            if not applied:
                return None   # first in line: no carrier overtakes it (see the docstring)
            continue
        if git.special_entries(tree) - base_special:
            log(f"#{n:>6} strict    not batched: adds a symlink or gitlink — never a strict carrier")
            continue
        m = Member(n, view.get("title", ""), view.get("body", ""), head, view.get("head_ref", ""),
                   view.get("created_at", ""), ref=head, files=files)
        sizes[n] = bisect_size(view.get("app") or {})
        if len(applied) + 1 > batch_cap(members + [m], sizes, cap):
            log(f"#{n:>6} strict    waits: bisect cap of the members ahead of it")
            continue
        if GATES_YAML in files:
            gates_union |= gate_ids(git("show", f"{head}:{GATES_YAML}", check=False).stdout)
            merged = gate_ids(git("show", f"{tree}:{GATES_YAML}", check=False).stdout)
            if merged != gates_union:
                lost = sorted(gates_union - merged)
                log(f"#{n:>6} strict    not batched: {GATES_YAML} after merging it lacks gate id(s) {lost[:5]} "
                    f"present in main or a member — a gate retired in the merge; today's lane serves it")
                gates_union -= gate_ids(git("show", f"{head}:{GATES_YAML}", check=False).stdout) - merged
                continue
        own = git("commit-tree", tree, "-p", own, "-m", own_member_message(n, head)).stdout.strip()
        own_tree = tree
        applied.append((n, head))
        members.append(m)
        if n not in paths:
            paths[n] = member_paths(git, base, head)
        if rides_alone:
            alone = True
        if is_judge:
            has_judge = True
    # One member alone rides only as a JUDGE member or mid-bisect (it carries a `bisect size`): the
    # carrier over main is then the verdict that names a culprit or clears it, exactly as a one-member
    # train. Otherwise one green strict PR takes today's update-branch path, where its own CI already
    # answers the question.
    if len(applied) < 2 and not (applied and (alone or has_judge or sizes.get(applied[0][0]))):
        return None
    return own, applied


def strict_batch_views(gh, git, base: str, strict: list, fixes: dict, summary: dict) -> list[dict]:
    """Green strict-lane views that are BEHIND main and may ride a strict carrier: not a main-red fix
    (served alone), not already told that this head conflicts with main (and told once if it does)."""
    out = []
    for state, view in strict:
        n, head = view["number"], view["head_sha"]
        if state != "green" or n in fixes:
            continue
        if RELEASED_CONTEXT in (view.get("app") or {}):
            log(f"#{n:>6} strict    not batched: a strict carrier timed out on this head — update-branch lane")
            if not out:
                return []   # first in line: same no-overtaking rule as build_strict_carrier
            continue
        if git("merge-base", "--is-ancestor", base, head, check=False).returncode == 0:
            continue   # current: strict_lane merges it this tick, main moves — no carrier under it
        clash = conflict_paths(git, base, head)
        if clash:
            if NOTICE_CONTEXT not in (view.get("app") or {}):
                notice_once(gh, n, head, f"{CONFLICT_PREFIX}{base[:12]}: strict lane — merge main into the branch",
                            notice_text(STRICT_CONFLICT_COMMENT, clash))
            log(f"#{n:>6} strict    not batched: conflicts with main {base[:12]} on {len(clash)} path(s)")
            summary.setdefault("conflicts", []).append(n)
            continue
        out.append(view)
    return out


def publish_strict_carrier(gh, git, base: str, tip: str, applied: list[tuple[int, str]], run_id: str,
                           attempt: str) -> int | None:
    """Push settle's own chain to train/strict-<run>-<attempt>, record its tree, open the carrier."""
    for n, head in applied:
        if not live_source_intent(gh, n, head):
            log(f"::notice::#{n} source intent or head changed — strict carrier not published")
            return None
    branch = strict_train_branch(run_id, attempt)
    try:
        Pusher(git, branch, gh.remote).push(tip)
    except subprocess.CalledProcessError as e:
        # A refused push must not end the tick: the train and fast lanes are served by this same run.
        log(f"::warning::strict carrier not published: push refused (rc={e.returncode}) — update-branch lane this tick")
        return None
    gh.post_status(tip, "success", f"tree={git.tree(tip)}", context=RECORD_CONTEXT)
    carrier = gh.create_carrier(branch)
    if carrier is None:
        Pusher(git, branch, gh.remote).delete()
        return None
    log(f"published strict carrier #{carrier} ({branch}) over {base[:12]}: members {[n for n, _ in applied]}")
    return carrier


def close_strict_carrier(gh, git, summary: dict, carrier: int, branch: str, tag: str) -> None:
    summary.setdefault("strict_carriers", []).append((carrier, tag))
    gh.close_carrier(carrier)
    Pusher(git, branch, gh.remote).delete()


def judge_strict_carriers(gh, git, repo: str, base: str, required: list[str], main_red: dict[str, str],
                          shadow: bool, summary: dict) -> tuple[bool, bool]:
    """Settle every open strict carrier like one strict PR: (open_after, acted). A green one merges its
    members in order, each pinned to its verified head with the strict-lane status; a red one of N > 1
    halves (bisect sizes on the members), of one member names the culprit; pending holds the strict
    reservation until its CI stalls or passes the ceiling (reservation_expired on the carrier head,
    committed by settle at publish time), then closes with no verdict and halves; inconclusive is re-run
    once; main moved means rejected (rebuilt this tick). Nothing from a member is ever executed here."""
    train_required = [c for c in required if c != STATUS_CONTEXT and c not in TREE_INDEPENDENT_CONTEXTS]
    open_after, acted = False, False
    for p in [p for p in gh.open_prs() if is_strict_carrier(p, repo)]:
        sha, branch, carrier = p["head"]["sha"], p["head"]["ref"], p["number"]

        extra = train_extra_gates(git, base)
        if extra is None:
            open_after = True
            continue
        got = git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/merge-train/strict-settle", check=False).returncode == 0
        fetched = git("rev-parse", "refs/merge-train/strict-settle", check=False).stdout.strip() if got else ""
        checks = pinned_checks(gh, sha, extra)
        if any(checks.get(g) in EXTRA_GATE_NA_STATES for g in extra):
            checks = own_workflow_checks(checks, extra, changed_paths(git, f"{base}...{sha}") if fetched == sha else None)
        failing, pending, inconclusive = classify_carrier(checks, carrier_contexts(train_required, extra, checks))
        main_only = [c for c in failing if c in main_red]
        failing = [c for c in failing if c not in main_red]
        if failing:
            only_inconclusive, why = gh.failures_inconclusive(sha, failing)
            if only_inconclusive:
                log(f"strict carrier #{carrier}: {', '.join(failing)} red only for inconclusive gates ({why})")
                failing, inconclusive = [], sorted(set(inconclusive) | set(failing))
        chain = parse_own_chain(git, sha) if fetched == sha else None
        members = chain[1] if chain else []
        if chain and git("rev-list", "--count", f"{chain[0]}..{sha}").stdout.strip() != str(len(members)):
            chain, members = None, []   # a regeneration commit (or anything else) never rides a strict carrier
        if not failing and pending:
            expired = reservation_expired(git, sha, time.time(), gh.ci_activity, green=False)
            if not expired:
                log(f"strict carrier #{carrier}: CI running — it holds the strict reservation")
                open_after = True
                summary["strict_carrier"] = carrier
                continue
            # No verdict, nobody blamed. Each member head leaves the carrier lane (RELEASED_CONTEXT, read back
            # by strict_batch_views) and takes today's update-branch path, whose stall/ceiling/cooldown rules
            # bound it there too; a pushed head rides again. Rebuilding the same carrier would only wait
            # another ceiling for a context that may never report (a member removed its producer, #14302).
            log(f"::warning::strict carrier #{carrier}: {expired} — closed with no verdict, nobody blamed; "
                f"its members take the update-branch lane on these heads")
            acted = True
            for _n, head in members:
                if RELEASED_CONTEXT not in gh.app_statuses(head):
                    gh.post_status(head, "success", f"strict lane: strict carrier #{carrier} timed out on this head; "
                                   "it rides no further strict carrier", context=RELEASED_CONTEXT)
            summary["inconclusive"].append(carrier)
            close_strict_carrier(gh, git, summary, carrier, branch, "expired")
            continue
        if not failing and inconclusive:
            if not gh.app_statuses(sha).get(RERUN_CONTEXT, ("", ""))[0] and gh.rerun_inconclusive(sha, inconclusive):
                gh.post_status(sha, "success", "rerun 1 of 1: " + ", ".join(inconclusive), context=RERUN_CONTEXT)
                log(f"strict carrier #{carrier}: inconclusive ({', '.join(inconclusive)}) — re-ran once, in flight")
                summary["rerun"].append(carrier)
                open_after = True
                continue
            log(f"::warning::strict carrier #{carrier}: still inconclusive ({', '.join(inconclusive)}) — closed with no verdict")
            acted = True
            summary["inconclusive"].append(carrier)
            close_strict_carrier(gh, git, summary, carrier, branch, "inconclusive")
            continue
        if not failing and main_only:
            log(f"::warning::strict carrier #{carrier}: red only on {', '.join(main_only)}, red on main too — no verdict")
            acted = True
            summary["inconclusive"].append(carrier)
            close_strict_carrier(gh, git, summary, carrier, branch, "main-red")
            continue
        acted = True
        rec_state, rec_desc = gh.app_statuses(sha).get(RECORD_CONTEXT, ("", ""))
        problem = None if fetched == sha else "carrier branch missing or moved under the carrier"
        problem = problem or record_problem(rec_desc if rec_state == "success" else None,
                                            BOT_LOGIN if rec_state == "success" else None, git.tree(sha))
        if not problem and chain is None:
            problem = "head is not a chain of settle's own member commits"
        live_main = gh.main_sha()
        if not problem and chain[0] != live_main:
            problem = "main moved since publish — rebuilt this tick"
        if problem:
            log(f"::warning::strict carrier #{carrier}: {problem}")
            summary["rejected"].append(carrier)
            close_strict_carrier(gh, git, summary, carrier, branch, "rejected")
            continue
        if failing:
            # No stale-culprit refresh here (contrast the train path): a strict carrier is built by merging
            # main into each member, so its members are behind main by construction and "behind" says nothing
            # about a stale verdict; a strict culprit was already judged on today's main.
            if len(members) == 1:
                n, head = members[0]
                flake = likely_flake_rerun(gh, git, sha, failing, head, chain[0], extra, inconclusive)
                if flake:
                    log(f"strict carrier #{carrier}: {flake} — re-ran once before blaming #{n}, in flight")
                    summary["rerun"].append(carrier)
                    open_after = True
                    continue
                gh.post_status(head, "failure", culprit_description(failing, chain[0]))
                gh.comment(n, CULPRIT_MESSAGE)
                summary["culprits"].append(n)
            else:
                for _n, head in members:
                    gh.post_status(head, "pending", f"bisect size {max(1, len(members) // 2)}")
                summary["bisected"].append([n for n, _ in members])
            close_strict_carrier(gh, git, summary, carrier, branch, "red")
            continue
        if shadow:
            log(f"strict carrier #{carrier}: green (shadow: no status, no merge)")
            close_strict_carrier(gh, git, summary, carrier, branch, "shadow")
            continue
        expected = live_main
        for n, head in members:
            if not live_source_intent(gh, n, head):
                log(f"#{n} source intent or head changed since the strict carrier was verified; stopping")
                break
            if gh.main_sha() != expected:
                log("main advanced by a foreign merge; stopping, the rest are rebatched")
                break
            gh.post_status(head, "success", STRICT_CARRIER_DESC.format(carrier=carrier, base=chain[0][:12]),
                           source_number=n)
            merged = gh.merge(n, head)
            if not merged:
                log(f"#{n} did not merge; stopping")
                break
            expected = merged
            summary["merged"].append(n)
            summary.setdefault("strict", []).append(n)
        else:
            # Every member merged: main's tree must now BE the carrier's tree. The members merged
            # sequentially as squashes pinned to their heads, and the carrier was built with merge-tree
            # over the same heads; the two agree unless GitHub's squash resolved something differently
            # (a rename, a mode). A mismatch is not a verdict about any member (each merged verified),
            # but it says the next carrier's base assumption does not hold: told, and no further strict
            # carrier is built this tick (the next tick reads main afresh).
            got = git("fetch", "-q", "origin", f"+refs/heads/{gh.branch}:refs/merge-train/strict-after", check=False).returncode == 0
            after = git("rev-parse", "refs/merge-train/strict-after", check=False).stdout.strip() if got else ""
            if after != expected or git.tree(after) != git.tree(sha):
                log(f"::warning::strict carrier #{carrier}: main {after[:12]} after the last merge does not carry the "
                    f"carrier's tree — no further strict carrier this tick")
                summary["strict_tree_mismatch"] = carrier
        close_strict_carrier(gh, git, summary, carrier, branch, "merged")
    return open_after, acted


def write_output(key: str, value: str) -> None:
    path = os.environ.get("GITHUB_OUTPUT")
    if path:
        with open(path, "a") as fh:
            fh.write(f"{key}={value}\n")


# --------------------------------------------------------------------------- declaration gate
TOP = [
    ("schedule", "schedule:"),
    ("manual dispatch", "workflow_dispatch:"),
    ("concurrency group", "group: merge-train"),
    ("never cancels a train in flight", "cancel-in-progress: false"),
    ("event-driven: main moved", "push:"),
    ("event-driven: a required-context producer finished", "workflow_run:"),
    # #14643: unfiltered, every PR's CI completion queued a run that replaced the one
    # pending slot before a hosted runner took it. Only carriers (train/**) and main decide anything.
    ("workflow_run debounced to carriers and main", 'branches: [main, "train/**"]'),
    ("event-driven: a PR was armed", "auto_merge_enabled"),
]
_ISOLATION = [("script from origin/main", "show origin/main:.github/scripts/merge-train.py"),
              ("isolated python", "python3 -I -S"), ("no system git config", "GIT_CONFIG_NOSYSTEM: \"1\""),
              ("no global git config", "GIT_CONFIG_GLOBAL: /dev/null"), ("no credential left", "persist-credentials: false"),
              ("mints the App token", "actions/create-github-app-token@")]
JOB_MUST = {
    "build": [("build runs build", "merge-train.py build"), ("build: no credential left", "persist-credentials: false"),
              ("build regenerates with opa", "openpolicyagent.org/downloads/"),
              ("build hands over a bundle", "actions/upload-artifact@"),
              ("build hands over its drops (data, for publish's notices)", "merge-train-bundle/drops.txt"),
              ("build reports drops", "has_drops: ${{ steps.build.outputs.has_drops }}")],
    "publish": [(f"publish: {a}", b) for a, b in _ISOLATION] + [("publish takes the bundle", "actions/download-artifact@"),
                                                              ("publish runs publish", "\" publish"),
                                                              ("publish copies the admission gate beside its script", "check-security-checklist.py merge_train_carrier.py"),
                                                              ("publish also runs on drops alone (notices)",
                                                               "needs.build.outputs.has_drops == 'true'")],
    "settle": [(f"settle: {a}", b) for a, b in _ISOLATION] + [("settle runs settle", "\" settle"),
                                                           ("settle copies the admission gate beside its script", "check-security-checklist.py merge_train_carrier.py"),
                                                           ("settle gets the App id for the ruleset guard", "GITOPS_APP_ID: ${{ secrets.GITOPS_APP_ID }}"),
                                                           # Strict carrier (ADR-0343 amendment 2026-11-05): settle names
                                                           # the carrier branch from its own run and carries the cap.
                                                           ("settle names the strict carrier from its run id", '--run-id "${{ github.run_id }}"'),
                                                           ("settle names the strict carrier from its attempt", '--attempt "${{ github.run_attempt }}"'),
                                                           ("settle carries the strict batch cap", "STRICT_BATCH_CAP: ${{ env.MERGE_TRAIN_STRICT_BATCH_CAP }}"),
                                                           # update-branch credential: a dedicated App with workflows: write,
                                                           # held in a main-only environment, narrowed at mint, optional.
                                                           ("settle runs in the main-only branch-update environment", "environment: merge-train-branch-update"),
                                                           ("settle mints the branch-updater token", "app-id: ${{ secrets.BRANCH_UPDATER_APP_ID }}"),
                                                           ("branch-updater token narrowed: contents", "permission-contents: write"),
                                                           ("branch-updater token narrowed: pull requests", "permission-pull-requests: write"),
                                                           ("branch-updater token narrowed: workflows", "permission-workflows: write"),
                                                           ("a failed branch-updater mint degrades, never fails settle", "continue-on-error: true"),
                                                           ("settle hands the branch-updater token to update-branch", "UPDATE_BRANCH_TOKEN: ${{ steps.branch_updater_token.outputs.token }}")],
}
JOB_FORBID = {
    "build": [("build must not mint the App token", "create-github-app-token"), ("build must not see App secrets", "GITOPS_APP_"),
              ("build must not see the branch-updater key", "BRANCH_UPDATER_"), ("build never gets UPDATE_BRANCH_TOKEN", "UPDATE_BRANCH_TOKEN")],
    "publish": [("publish runs no repo script", "python3 .github/"), ("publish runs no generator", "regen-derived.sh"),
                ("publish installs no opa", "openpolicyagent.org"), ("publish installs no pyyaml", "install-pyyaml"),
                ("publish must not see the branch-updater key", "BRANCH_UPDATER_"), ("publish never gets UPDATE_BRANCH_TOKEN", "UPDATE_BRANCH_TOKEN")],
    "settle": [("settle runs no repo script", "python3 .github/"), ("settle runs no generator", "regen-derived.sh"),
               ("settle takes no artifact", "download-artifact"), ("settle installs no opa", "openpolicyagent.org")],
}


def job_sections(text: str) -> dict[str, str]:
    m = re.search(r"^jobs:\s*$", text, re.MULTILINE)
    if not m:
        return {}
    parts = re.split(r"^  ([A-Za-z0-9_-]+):\s*$", text[m.end():], flags=re.MULTILINE)
    return {parts[i]: parts[i + 1] for i in range(1, len(parts) - 1, 2)}


def owner_approval_declaration_errors(text: str) -> list[str]:
    code = "\n".join(ln for ln in text.splitlines() if not ln.lstrip().startswith("#"))
    sec = job_sections(code).get("decide", "")
    guard = ("if: github.event_name == 'workflow_dispatch' && github.ref == 'refs/heads/main' "
             "&& github.actor == github.repository_owner && github.triggering_actor == github.repository_owner "
             "&& github.run_attempt == 1")
    must = [guard, "ref: main", "persist-credentials: false", "actions/create-github-app-token@",
            "show HEAD:.github/scripts/merge-train.py", "python3 -I -S", '" owner-approval',
            '--pr "$OWNER_PR" --head "$OWNER_HEAD" --decision "$OWNER_DECISION"']
    errors = [f"owner approval writer missing {needle}" for needle in must if needle not in sec]
    if "group: merge-train-owner-approval-${{ github.event_name }}-${{ github.ref }}-${{ github.actor }}-${{ inputs.pr }}" not in code or "cancel-in-progress: false" not in code:
        errors.append("owner decisions must serialize separately from untrusted PR verification")
    if sec.count("actions/checkout@") != 1 or sec.count("ref: main") != 1:
        errors.append("owner approval writer must check out main exactly once")
    for needle in (r"^[1-9][0-9]*$", r"^[0-9a-f]{40}$"):
        if needle not in sec:
            errors.append(f"owner approval writer must validate inputs with {needle}")
    if sec.index("Validate decision inputs") > sec.index("actions/checkout@"):
        errors.append("owner approval input validation must run before anything else")
    if sec.count("run:") != 4:
        errors.append("owner approval writer must have only validation, revoke-first, decision and summary commands")
    for forbidden in ("github.head_ref", "github.event.", "download-artifact", "gh pr merge", "gh pr review",
                      "contents: write", "statuses: write", "pull_request_target:"):
        if forbidden in code:
            errors.append(f"owner approval writer forbids {forbidden}")
    if "python3 .github/" in sec:
        errors.append("owner approval writer must run only its isolated main script")
    return errors


BRANCH_UPDATER_MARK = "BRANCH_UPDATER_"


def workflow_texts() -> dict[str, str]:
    d = WORKFLOW.parent
    return {f.name: f.read_text() for f in sorted(d.glob("*.y*ml"))} if d.is_dir() else {}


BRANCH_UPDATER_ENV = "merge-train-branch-update"


def branch_updater_spread_errors(texts: dict[str, str]) -> list[str]:
    """The branch-updater App key (workflows: write) may be reached from merge-train.yml ONLY.
    Its secrets are environment-scoped, so `secrets: inherit` or `toJSON(secrets)` cannot hand them to
    another job: only a job that declares the environment receives them. Two ways in, both checked —
    naming the secret, or declaring the environment (which yields it under any spelling)."""
    out = []
    for name, text in sorted(texts.items()):
        if name == WORKFLOW.name:
            continue
        if BRANCH_UPDATER_MARK in text:
            out.append(f"{name} references {BRANCH_UPDATER_MARK}* — that key belongs to merge-train.yml's settle job alone")
        if BRANCH_UPDATER_ENV in text:
            out.append(f"{name} names the {BRANCH_UPDATER_ENV} environment — a job declaring it receives the branch-updater key")
    return out


def check_declaration() -> int:
    if not WORKFLOW.exists():
        print(f"::error::{WORKFLOW} missing")
        print("SUBJECTS=0")
        return 1
    text = WORKFLOW.read_text()
    code = "\n".join(ln for ln in text.splitlines() if not ln.lstrip().startswith("#"))
    jobs = job_sections(code)
    fails = [label for label, needle in TOP if needle not in code]
    if not re.search(r'^\s*MERGE_TRAIN_SHADOW: "(true|false)"\s*$', code, re.MULTILINE):
        fails.append('MERGE_TRAIN_SHADOW must be declared as "true" or "false"')
    # The strict batch cap is the rollback switch of the strict carrier: declared, a positive integer.
    if not re.search(r'^\s*MERGE_TRAIN_STRICT_BATCH_CAP: "[1-9][0-9]*"\s*$', code, re.MULTILINE):
        fails.append('MERGE_TRAIN_STRICT_BATCH_CAP must be declared as a positive integer ("1" = no strict carrier)')
    # Speculative stacking's rollback switch: declared outright, carried by settle, its window handed to publish.
    if not re.search(r'^\s*MERGE_TRAIN_SPECULATIVE_STACK: "(true|false)"\s*$', code, re.MULTILINE):
        fails.append('MERGE_TRAIN_SPECULATIVE_STACK must be declared as "true" or "false" ("false" = no stacking)')
    if "SPECULATIVE_STACK: ${{ env.MERGE_TRAIN_SPECULATIVE_STACK }}" not in jobs.get("settle", ""):
        fails.append("settle must carry MERGE_TRAIN_SPECULATIVE_STACK")
    if "STACK_HEAD: ${{ needs.settle.outputs.stack_head }}" not in jobs.get("publish", ""):
        fails.append("publish must receive settle's stacking window (stack_pr / stack_head)")
    # Expedite lane's rollback switch and cap: declared outright, carried by settle, its window handed on.
    if not re.search(r'^\s*MERGE_TRAIN_EXPEDITE_LANE: "(true|false)"\s*$', code, re.MULTILINE):
        fails.append('MERGE_TRAIN_EXPEDITE_LANE must be declared as "true" or "false" ("false" = no expedite lane)')
    if not re.search(r'^\s*MERGE_TRAIN_EXPEDITE_DAILY_CAP: "[1-9][0-9]*"\s*$', code, re.MULTILINE):
        fails.append("MERGE_TRAIN_EXPEDITE_DAILY_CAP must be declared as a positive integer")
    if "EXPEDITE_LANE: ${{ env.MERGE_TRAIN_EXPEDITE_LANE }}" not in jobs.get("settle", ""):
        fails.append("settle must carry MERGE_TRAIN_EXPEDITE_LANE")
    for job in ("build", "publish"):
        if "EXPEDITE_PR: ${{ needs.settle.outputs.expedite_pr }}" not in jobs.get(job, ""):
            fails.append(f"{job} must receive settle's expedite window (expedite_pr)")
    if not re.search(r'^\s*MERGE_TRAIN_URGENT_DAILY_CAP: "[1-9][0-9]*"\s*$', code, re.MULTILINE):
        fails.append("MERGE_TRAIN_URGENT_DAILY_CAP must be declared as a positive integer")
    if "URGENT_DAILY_CAP: ${{ env.MERGE_TRAIN_URGENT_DAILY_CAP }}" not in jobs.get("settle", ""):
        fails.append("settle must carry MERGE_TRAIN_URGENT_DAILY_CAP")
    if "EXPEDITE_DAILY_CAP: ${{ env.MERGE_TRAIN_EXPEDITE_DAILY_CAP }}" not in jobs.get("publish", ""):
        fails.append("publish must carry MERGE_TRAIN_EXPEDITE_DAILY_CAP (it re-checks the cap live)")
    # The safety is a runtime property: settle must consult the live ruleset before merging, whatever the flag says.
    guard_src = inspect.getsource(mode_settle)
    if "gh.merge_guard()" not in guard_src or inspect.getsource(ruleset_guard).count("integration_id") < 1:
        fails.append("settle must gate merging on the live ruleset (merge_guard / ruleset_guard)")
    # The event-driven triggers (push, workflow_run, pull_request_target) carry no authority only while
    # nothing reads their payload and nothing checks out anything but main.
    if "github.event." in code or "github.head_ref" in code:
        fails.append("no job may read the event payload (github.event.* / github.head_ref): triggers carry no authority")
    if code.count("actions/checkout@") != len(re.findall(r"^\s+ref: main\s*$", code, re.MULTILINE)):
        fails.append("every actions/checkout must pin `ref: main` (pull_request_target/workflow_run run with secrets)")
    # Line-anchored: the branch-updater mint's `permission-contents: write` narrows an App token, not GITHUB_TOKEN.
    if re.search(r"^\s*contents:\s*write\b", code, re.MULTILINE):
        fails.append("GITHUB_TOKEN must stay read-only (writes use the App token)")
    for job in JOB_MUST:
        sec = jobs.get(job)
        if sec is None:
            fails.append(f"job `{job}` missing")
            continue
        fails += [label for label, needle in JOB_MUST[job] if needle not in sec]
        fails += [label for label, needle in JOB_FORBID[job] if needle in sec]
    rules = pathlib.Path(RULES_FILE)
    if not parse_extra_gates(rules.read_text() if rules.exists() else ""):
        fails.append(f"{RULES_FILE}: merge_train.extra_gates must declare at least one check (parsed as empty)")
    fails += branch_updater_spread_errors(workflow_texts())
    fails += owner_approval_declaration_errors(OWNER_APPROVAL_WORKFLOW.read_text() if OWNER_APPROVAL_WORKFLOW.exists() else "")
    for f in fails:
        print(f"::error::merge-train.yml declaration: {f}")
    n = len(TOP) + 8 + sum(len(v) for v in JOB_MUST.values()) + sum(len(v) for v in JOB_FORBID.values())
    print(f"SUBJECTS={n}")
    print("merge-train declaration OK" if not fails else f"{len(fails)} declaration failure(s)")
    return 1 if fails else 0


# --------------------------------------------------------------------------- self-test
@contextlib.contextmanager
def _synthetic_clock(epoch: int = 1767225600):
    """Keep synthetic git commits and ticks on one explicit clock, independent of suite duration.

    Reservation scenarios advance tick time explicitly relative to their commit; elapsed runner
    time is not modeled CI inactivity. Production clocks and commit environments are unchanged.
    """
    original_time, original_env = time.time, base_env

    def dated_env():
        env = original_env()
        env.update({"GIT_AUTHOR_DATE": f"{epoch} +0000", "GIT_COMMITTER_DATE": f"{epoch} +0000"})
        return env

    time.time = lambda: epoch
    globals()["base_env"] = dated_env
    try:
        yield
    finally:
        time.time = original_time
        globals()["base_env"] = original_env


SYN_GENERATOR = ".github/scripts/regen.py"
SYN_GENERATOR_SRC = (
    "import json,os,pathlib\n"
    "os.makedirs('derived',exist_ok=True)\n"
    "pathlib.Path('derived/index.txt').write_text('\\n'.join(sorted(os.listdir('services')))+'\\n')\n"
    "pathlib.Path(os.environ.get('PROBE_OUT') or os.devnull).write_text("
    "json.dumps({'GH_TOKEN': os.environ.get('GH_TOKEN',''), 'UPDATE_BRANCH_TOKEN': os.environ.get('UPDATE_BRANCH_TOKEN',''), "
    "'keys': sorted(os.environ)}))\n"
    # Like regen-derived.sh's run_bundles: execute every bundle generator, at ANY depth.
    "import fnmatch,subprocess\n"
    "for r,_,fs in os.walk('openbank-infra/gitops'):\n"
    "    for f in fs:\n"
    "        if fnmatch.fnmatch(f,'gen-*opa-bundle*.sh'): subprocess.run(['bash',os.path.join(r,f)])\n"
)
SYN_RULES = ("merge_train:\n  extra_gates:\n    - {workflow: .github/workflows/security.yml, check: Trivy}\n"
             "money_path_services:\n  - paysvc\n")
SYN_REQUIRED = ["gates (data)", "Validate manifests", "derived", "issue-hygiene", STATUS_CONTEXT]
# The GENERATORS fragments make docs/, services/, count.txt and bad.txt protected, so PRs touching
# them ride trains (as real inventory sources do) instead of the fast lane; svc/ stays fast-lane.
SYN_INVENTORY = ('GENERATORS=(\n  "syn|python3 x|services/ docs/ count.txt bad.txt"\n)\n'
                 'DERIVED_OUTPUTS=(\n  "derived/*"\n)\n'
                 "  done < <(find openbank-infra/gitops -name 'gen-*opa-bundle*.sh' | sort)\n")
SYN_DEEP_GENERATOR = "openbank-infra/gitops/a/b/c/d/gen-x-opa-bundle.sh"
SYN_HEREDOC_SCRIPT = "openbank-infra/gitops/p/gen-p-opa-bundle.sh"
SYN_NEWLINE_GENERATOR = "openbank-infra/gitops/x/gen-a\nb-opa-bundle.sh"
SYN_SHADOW_MODULE = "openbank-infra/gitops/p/yaml.py"
SYN_BASELINE = ".github/scripts/x-baseline.txt"     # gate-input data inside a generator overlay root
SYN_GATE_CODE = ".github/scripts/check-k.py"        # reviewed gate code: rides a train, never with a regen commit
SYN_MAIN_GATE_CODE = ".github/scripts/check-m.py"   # gate code main already carries
SYN_GATES_YAML = "gates:\n  - id: g-one\n    run: true\n  - id: g-two\n    run: true\n"


class FakeGitHub:
    """A GitHub stand-in over a synthetic origin: PRs are local branches, CI is ci.py on train heads
    (PR heads report green, as their own CI did), merges are squashes onto origin's main."""

    def __init__(self, origin: str, scratch: str):
        self.origin, self.scratch, self.branch, self.run_url, self.remote = origin, scratch, "main", "http://run", origin
        self.repo = "o/r"
        self.prs: dict[int, dict] = {}
        self.statuses: dict[str, list[tuple[str, str, str, str]]] = {}
        self.comments: list[tuple[int, str]] = []
        self.merged: list[int] = []
        self.carriers: dict[int, dict] = {}
        self._ci: dict[str, dict] = {}
        self.foreign_after_merge: str | None = None
        self.refuse_merge: set[int] = set()
        self.head_checks: dict[str, dict] = {}   # PR head sha -> check overrides (red, pending, guard)
        self.jobs: dict[str, dict] = {}          # sha -> job overrides for ctx_jobs (job name -> conclusion)
        self.head_jobs: dict = {}                # job overrides on EVERY PR head (claim and combined)
        self.gate_records_by: dict = {}          # (sha, slug) -> --json records of a red shard; default: content
        self.pending_shas: set[str] = set()      # carrier heads whose CI is still running
        self.updates: list[int] = []             # update-branch calls, in order
        self.update_refuse = False               # True: update-branch answers as GitHub does on a refusal
        self.notice_times: dict[str, str] = {}   # head -> when its notice was posted (statuses here have no clock)
        self.stuck_open: tuple = (None, None)    # the tracking issue: (number, body)
        self.stuck_writes: list = []             # tracking-issue writes; None is a close
        self.carrier_override: dict = {}         # carrier (train head) check overrides, e.g. cancelled
        self.main_override: dict = {}            # main tip check overrides, kept apart from carriers
        self.reruns: list[tuple[str, list[str]]] = []
        self.rerun_ok = True
        self.on_rerun = None                     # callable run after a rerun request (the rerun's outcome)
        self.main_sequence: dict[str, list] = {}  # main sha -> successive check overrides, one per read
        self.pinned: dict[str, dict[str, list]] = {}  # sha -> extra gate -> states of runs from the pinned workflow
        self.xgate_unfinished: set[str] = set()   # heads whose pinned workflow has not completed (absent = pending)
        self.gate_records: dict[str, list] = {}  # shard slug -> run-gates --json records of the carrier's CI
        self.inconclusive_reads = 0
        self.activity: dict[str, float] = {}   # sha -> newest check-run start/finish (ci_activity)
        # The live ruleset as the settle guard sees it: merge-train pinned to the App, strict off.
        self.app_id, self.rs_checks, self.rs_strict = "4242", [{"context": STATUS_CONTEXT, "integration_id": 4242}], False

    def merge_guard(self):
        return ruleset_guard([{"type": "required_status_checks", "parameters": {
            "strict_required_status_checks_policy": self.rs_strict, "required_status_checks": self.rs_checks}}], self.app_id)

    _READS = frozenset({"rev-parse", "log", "show", "cat-file", "rev-list", "ls-tree", "merge-base", "diff"})

    def g(self, *a, check=True):
        if next((x for x in a if not x.startswith("-")), None) not in self._READS:
            self._main = None   # anything that can move main (update-ref, merge, reset, commit, checkout) drops the cache
        return sh(["git", "-c", "core.hooksPath=/dev/null", *a], cwd=self.origin, check=check, env=base_env())

    def add_pr(self, n: int, branch: str, created: str):
        self.prs[n] = {"number": n, "state": "open", "draft": False, "auto_merge": {"x": 1}, "title": branch, "body": "",
                       "created_at": created, "user": {"login": "someone"},
                       "head": {"ref": branch, "sha": self.g("rev-parse", branch).stdout.strip(), "repo": {"full_name": "o/r"}},
                       "base": {"ref": self.branch, "repo": {"full_name": self.repo}}}

    def head_refspec(self, n): return f"refs/heads/{self.prs[n]['head']['ref']}"
    def required(self): return list(SYN_REQUIRED)
    def main_sha(self):
        # Semantically "live main NOW", re-read by production code before every merge; the fixture's
        # main moves only through g() above, which drops the cache. 1,216 of the self-test's spawns
        # were this one command (measured 2026-11-03).
        if getattr(self, "_main", None) is None:
            self._main = self.g("rev-parse", "main").stdout.strip()
        return self._main
    def open_prs(self): return [p for p in list(self.prs.values()) + list(self.carriers.values()) if p["state"] == "open"]
    def pr(self, n): return self.prs[n]

    def checks(self, sha):
        if sha in self.pending_shas:
            out = {c: None for c in SYN_REQUIRED[:4]}
        elif any(p["head"]["sha"] == sha for p in self.prs.values()):
            out = {**{c: "success" for c in SYN_REQUIRED[:4]}, **self.head_checks.get(sha, {})}
        else:
            if sha not in self._ci:
                wt = tempfile.mkdtemp(dir=self.scratch)
                self.g("worktree", "add", "-q", "--detach", wt, sha)
                r = subprocess.run([sys.executable, "ci.py"], cwd=wt, text=True, capture_output=True)
                failing = [c for c in r.stdout.strip().split(",") if c]
                self.g("worktree", "remove", "--force", wt)
                self._ci[sha] = {**{c: ("failure" if c in failing else "success") for c in SYN_REQUIRED[:3]}, "issue-hygiene": "success"}
            # carrier_override models a carrier's CI and main_override main's tip, which is read too
            # (main_red_contexts, #13517): one shared override made every red-carrier fixture "red on main".
            override = self.main_override if sha == self.main_sha() else self.carrier_override
            out = {**self._ci[sha], **override, **self.head_checks.get(sha, {})}
            if self.main_sequence.get(sha):            # main CI finishing mid-tick: next read differs
                out.update(self.main_sequence[sha].pop(0))
        for ctx, state, _desc, _creator in reversed(self.statuses.get(sha, [])):
            out.setdefault(ctx, None if state == "pending" else state)
        return {c: v for c, v in out.items() if v != "absent"}   # "absent": the context never reported

    def ci_activity(self, sha):
        return self.activity.get(sha)

    def ctx_jobs(self, sha, ctx):
        """The context is its own (only) job unless a fixture names the jobs of its run."""
        v = self.checks(sha).get(ctx, "absent")
        if v == "absent":
            v = self.extra_checks(sha, {ctx: ""}).get(ctx)
        out = {ctx: v}
        if any(p["head"]["sha"] == sha for p in self.prs.values()):
            out.update(self.head_jobs)
        return {**out, **self.jobs.get(sha, {})}

    def gate_shard_records(self, sha, ctx, slugs):
        """On main a red shard failed for CONTENT unless a fixture says otherwise (today's conclusive
        verdict); on a PR head the artifact is unreadable unless a fixture supplies it (the job rule stands)."""
        head = any(p["head"]["sha"] == sha for p in self.prs.values())
        if slugs is None:   # every shard the fixture supplied for this sha; a head with none is unreadable
            known = {s for h, s in self.gate_records_by if h == sha}
            return {s: self.gate_records_by[(sha, s)] for s in sorted(known)} if known or not head else None
        return {s: self.gate_records_by.get((sha, s), None if head else [{"id": s, "status": "failed", "failure_kind": "content"}])
                for s in slugs}

    def extra_checks(self, sha, gates):
        """Pinned runs: `self.pinned[sha]` = {name: [states]} from the declared workflow; with none set, a
        head's Trivy override stands for one pinned run (an unpinned spoof lives only in checks())."""
        if sha in self.pinned:
            return {n: extra_verdict(v) for n, v in self.pinned[sha].items() if n in gates}
        plain = dict(self.head_checks.get(sha, {}))   # not self.checks(): status reads are counted by tests
        if not any(p["head"]["sha"] == sha for p in self.prs.values()):
            plain = {**self.carrier_override, **plain}
        return {n: plain.get(n, "skipped") for n in gates if n in plain or sha not in self.xgate_unfinished}

    def app_statuses(self, sha):
        out = {}
        for ctx, state, desc, creator in reversed(self.statuses.get(sha, [])):
            if creator == BOT_LOGIN:
                out.setdefault(ctx, (state, desc))
        return out

    def app_status_latest(self, sha, context):
        seqs = self.__dict__.get("_seq", {}).get(sha, [])
        rows = self.statuses.get(sha, [])
        for i in range(len(rows) - 1, -1, -1):
            ctx, state, desc, creator = rows[i]
            if ctx == context and creator == BOT_LOGIN:
                return (seqs[i] if i < len(seqs) else 0), state, desc
        return None

    def post_status(self, sha, state, description, context=STATUS_CONTEXT, creator=BOT_LOGIN, *, source_number=None):
        self.statuses.setdefault(sha, []).append((context, state, description, creator))
        seq = self.__dict__.setdefault("_seq", {})
        self.__dict__["_n"] = self.__dict__.get("_n", 0) + 1
        seq[sha] = seq.get(sha, [])[:len(self.statuses[sha]) - 1] + [self._n]

    def comment(self, n, text): self.comments.append((n, text))

    def merge(self, n, head):
        if self.prs[n]["head"]["sha"] != head or n in self.refuse_merge:
            return None
        self.g("checkout", "-q", "-f", "main")
        if self.g("merge", "--squash", head, check=False).returncode != 0:
            self.g("merge", "--abort", check=False)
            self.g("reset", "-q", "--hard")
            return None
        self.g("commit", "-q", "-m", f"#{n}")
        sha = self.main_sha()
        self.prs[n]["state"] = "closed"
        self.prs[n]["merged_at"] = "2026-01-01T00:00:00Z"
        self.prs[n]["merged"], self.prs[n]["merge_commit_sha"] = True, sha
        self.merged.append(n)
        if self.foreign_after_merge:
            p = pathlib.Path(self.origin, self.foreign_after_merge)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("foreign\n")
            self.g("add", "-A")
            self.g("commit", "-q", "-m", "foreign")
            self.foreign_after_merge = None
        return sha

    def failures_inconclusive(self, sha, failing):
        self.inconclusive_reads += 1
        return gate_failures_inconclusive(list(failing), self.gate_records)

    def rerun_inconclusive(self, sha, contexts):
        self.reruns.append((sha, list(contexts)))
        if self.rerun_ok and self.on_rerun:
            self.on_rerun()
        return self.rerun_ok

    def update_branch(self, n, head):
        p = self.prs[n]
        if self.update_refuse or p["head"]["sha"] != head:
            return False
        # A fresh branch, so the fixture branch itself stays as cut for later cases.
        br = f"{p['head']['ref']}-upd{len(self.updates)}"
        self.g("checkout", "-q", "-f", "-B", br, head)
        self.g("merge", "-q", "--no-edit", "main")
        self.g("checkout", "-q", "-f", "main")
        p["head"]["ref"], p["head"]["sha"] = br, self.g("rev-parse", br).stdout.strip()
        self.updates.append(n)
        return True

    def notice_since(self, sha):
        return self.notice_times.get(sha)

    def stuck_issue(self):
        return self.stuck_open

    def save_stuck_issue(self, number, body):
        self.stuck_writes.append(body)
        self.stuck_open = (number or 777, body)

    def close_stuck_issue(self, number):
        self.stuck_writes.append(None)
        self.stuck_open = (None, None)

    def create_carrier(self, branch, expedite=False):
        n = 9000 + len(self.carriers)
        self.carriers[n] = {"number": n, "state": "open", "draft": True, "user": {"login": BOT_LOGIN}, "created_at": "",
                            "expedite": expedite,
                            "head": {"ref": branch, "sha": self.g("rev-parse", branch).stdout.strip(), "repo": {"full_name": "o/r"}}}
        return n

    def close_carrier(self, n): self.carriers[n]["state"] = "closed"

    def expedite_carriers_today(self, day):
        if getattr(self, "expedite_unreadable", False):
            return None
        return getattr(self, "expedite_used", 0) + sum(1 for c in self.carriers.values() if c.get("expedite"))


class HttpFixture:
    """The GitHub REST API as `GitHub` sees it, served from a FakeGitHub: patched in place of
    urllib.request.urlopen, so the REAL GitHub class, api() and its retry policy run. `faults` is a list
    of [predicate(method, path), (code, headers) | "reset" | "incomplete", times] — `times` None = every attempt."""

    def __init__(self, fake, faults=None):
        self.fake, self.faults, self.calls = fake, [list(f) for f in (faults or [])], []
        self.after: list[list] = []   # [predicate(method, path), action(), times]: state drifting mid-tick

    def sync_refs(self):
        for n, p in self.fake.prs.items():
            if p["state"] == "open":
                self.fake.g("update-ref", f"refs/pull/{n}/head", p["head"]["sha"])

    def __call__(self, req, timeout=None):
        import email.message
        import urllib.parse
        method, path = req.get_method(), req.full_url[len(API):]
        self.calls.append((method, path))
        for f in self.faults:
            if f[2] != 0 and f[0](method, path):
                if f[2] is not None:
                    f[2] -= 1
                if f[1] == "reset":
                    raise ConnectionResetError("connection reset by peer")
                if f[1] == "incomplete":
                    raise http.client.IncompleteRead(b"{", 99)
                code, hdrs = f[1]
                h = email.message.Message()
                for k, v in hdrs.items():
                    h[k] = v
                raise urllib.error.HTTPError(req.full_url, code, "fault", h, io.BytesIO(b'{"message": "fault"}'))
        u = urllib.parse.urlsplit(path)
        page = int(urllib.parse.parse_qs(u.query).get("page", ["1"])[0])
        rest = u.path.split("/", 4)[4]
        body = json.loads(req.data) if req.data else None
        code, out = self.route(method, rest, u.query, body, page)
        for a in self.after:
            if a[2] != 0 and a[0](method, path):
                a[2] -= 1
                a[1]()
        if code >= 400:
            raise urllib.error.HTTPError(req.full_url, code, "no", email.message.Message(), io.BytesIO(b"{}"))
        raw = json.dumps(out).encode()

        class _R:
            status, headers = code, {}

            def read(self):
                return raw

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False
        return _R()

    def route(self, method, rest, query, body, page):
        fk = self.fake
        pg = (lambda items: items if page == 1 else [])
        every = list(fk.prs.values()) + list(fk.carriers.values())
        m = re.fullmatch(r"commits/([0-9a-f]{40})/(check-runs|status|statuses)", rest)
        if method == "GET" and rest.startswith("rules/branches/"):
            return 200, [{"type": "required_status_checks", "parameters": {
                "strict_required_status_checks_policy": fk.rs_strict,
                "required_status_checks": [{"context": c, "integration_id": 4242 if c == STATUS_CONTEXT else None}
                                           for c in SYN_REQUIRED]}}]
        if method == "GET" and rest == "git/ref/heads/main":
            return 200, {"object": {"sha": fk.main_sha()}}
        if method == "GET" and rest == "pulls":
            return 200, pg([{**p, "user": p.get("user") or {"login": "someone"}} for p in fk.open_prs()])
        if method == "GET" and re.fullmatch(r"pulls/[0-9]+", rest):
            n = int(rest.split("/")[1])
            return 200, next(p for p in every if p["number"] == n)
        if method == "GET" and m and m.group(2) == "check-runs":
            ci = {c: v for c, v in fk.checks(m.group(1)).items() if c not in {x[0] for x in fk.statuses.get(m.group(1), [])}}
            return 200, {"check_runs": pg([{"id": i + 1, "name": c, "status": "in_progress" if v is None else "completed",
                                            "conclusion": v, "app": {"slug": "fixture"},
                                            "started_at": "2026-01-01T00:00:00Z"} for i, (c, v) in enumerate(sorted(ci.items()))])}
        if method == "GET" and m and m.group(2) == "status":
            return 200, {"statuses": []}
        if method == "GET" and m:
            return 200, pg([{"id": i + 1, "context": c, "state": st, "description": d, "creator": {"login": who}}
                            for i, (c, st, d, who) in enumerate(fk.statuses.get(m.group(1), []))])
        if method == "GET" and rest == "actions/runs":
            sha = re.search(r"head_sha=([0-9a-f]{40})", query).group(1)
            return 200, {"workflow_runs": pg([{"head_sha": sha, "path": ".github/workflows/security.yml",
                                               "status": "completed", "conclusion": "success"}])}
        if method == "POST" and rest.startswith("statuses/"):
            fk.post_status(rest.split("/")[1], body["state"], body["description"], context=body["context"])
            return 201, {}
        if method == "POST" and re.fullmatch(r"issues/[0-9]+/comments", rest):
            fk.comment(int(rest.split("/")[1]), body["body"])
            return 201, {}
        if method == "POST" and re.fullmatch(r"issues/[0-9]+/labels", rest):
            return 200, []
        if method == "PUT" and rest.endswith("/update-branch"):
            ok = fk.update_branch(int(rest.split("/")[1]), body["expected_head_sha"])
            self.sync_refs()
            return (202, {}) if ok else (422, {})
        if method == "PUT" and rest.endswith("/merge"):
            sha = fk.merge(int(rest.split("/")[1]), body["sha"])
            return 200, {"merged": bool(sha), "sha": sha}
        if method == "POST" and rest == "pulls":
            n = fk.create_carrier(body["head"])
            fk.carriers[n]["head"]["repo"] = {"full_name": "o/r"}
            return 201, {"number": n}
        if method == "PATCH" and re.fullmatch(r"pulls/[0-9]+", rest):
            fk.close_carrier(int(rest.split("/")[1]))
            return 200, {}
        return 404, {}


def _synthetic_origin(root: str) -> None:
    env = base_env()

    def g(*a):
        return subprocess.run(["git", *a], cwd=root, text=True, capture_output=True, check=True, env=env)

    def w(rel, text):
        p = pathlib.Path(root, rel)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)

    os.makedirs(root)
    g("init", "-q", "-b", "main")
    # A fixture origin is cloned repeatedly while it is still being committed to. Git's detached auto-gc
    # (triggered by those commits) packs and prunes loose objects in the background, so a concurrent
    # `git clone` copying them fails with "failed to copy file ... No such file or directory". Never auto-gc.
    g("config", "gc.auto", "0")
    g("config", "maintenance.auto", "false")
    w("services/s1.txt", "s1\n")
    w("count.txt", "1\n")
    w(RULES_FILE, SYN_RULES)
    w(SYN_GENERATOR, SYN_GENERATOR_SRC)
    w(REGEN_INVENTORY, SYN_INVENTORY)
    w(SYN_BASELINE, "base\n")
    w(SYN_MAIN_GATE_CODE, "main\n")
    w(GATES_YAML, SYN_GATES_YAML)
    w(".github/workflows/ci.yml", 'on: push\njobs:\n  g:\n    steps:\n      - run: python3 .github/scripts/run-gates.py\n'
                                  '      - run: bash "$DIR/foo.sh"\n')
    w(".github/scripts/run-gates.py", "print('gates')\n")
    w(".github/scripts/lib/foo.sh", "echo foo\n")
    w("openbank-svc/README.md", "a leaf module: no build file depends on it\n")   # shareable_modules
    w("openbank-mco/README.md", "leaf module\n")
    w("openbank-mjred/README.md", "leaf module\n")
    w("openbank-ms1/README.md", "leaf module\n")
    w("openbank-ms2/README.md", "leaf module\n")
    w("openbank-mca/README.md", "leaf module\n")
    w("openbank-mcb/README.md", "leaf module\n")
    w("openbank-mread/src/test/kotlin/PinTest.kt", 'val src = File("../openbank-mtarget/src/main/kotlin/Pin.kt")\n')
    w("openbank-mtarget/src/main/kotlin/Pin.kt", "// read by openbank-mread's test\n")
    w("openbank-mwalk/src/test/kotlin/WalkTest.kt",
      'val root = generateSequence(File("").absoluteFile) { it.parentFile }.first { File(it, "openbank-mwt").isDirectory }\n')
    w("openbank-mwt/src/main/kotlin/W.kt", "// read by openbank-mwalk's test, which climbs to the root to find it\n")
    # A test whose FILE NAME contains ':' reads another module: a ':'-split parser shifts the fields and misses it.
    w("openbank-mcolr/src/test/kotlin/Pin:Test.kt", 'val f = File("../openbank-mcolt/src/main/kotlin/C.kt")\n')
    w("openbank-mcolt/src/main/kotlin/C.kt", "// read by a test whose name contains a colon\n")
    w("openbank-libs-detekt-rules/README.md", "custom detekt rules: checkers written in Kotlin\n")
    w("openbank-svc/build.gradle.kts", 'dependencies { detektPlugins(project(":openbank-libs-detekt-rules")) }\n')
    w("ci.py", "import os,sys\nfail=[]\n"
               "if int(open('count.txt').read()) != len(os.listdir('services')): fail.append('gates (data)')\n"
               "if os.path.exists('bad.txt'): fail.append('Validate manifests')\n"
               "rg=open('.github/scripts/run-gates.py').read()\n"
               "if os.path.exists('.github/scripts/bad.py') and 'relax' not in rg and not os.path.exists("
               "'openbank-libs-detekt-rules/src/main/kotlin/Relax.kt'): fail.append('gates (data)')\n"
               "if os.path.exists('openbank-svc/src/main/kotlin/Money.kt') and not os.path.exists('docs/threat-models/svc.md'):\n"
               "    fail.append('Validate manifests')\n"
               "if 'tighten' in rg and os.path.exists('openbank-mco/src/main/kotlin/co.kt'): fail.append('gates (data)')\n"
               "if os.path.exists('openbank-mca/src/main/kotlin/ca.kt') and os.path.exists('openbank-mcb/src/main/kotlin/cb.kt'): fail.append('gates (data)')\n"
               "want='\\n'.join(sorted(os.listdir('services')))+'\\n'\n"
               "if not os.path.exists('derived/index.txt') or open('derived/index.txt').read()!=want: fail.append('derived')\n"
               "print(','.join(fail)); sys.exit(1 if fail else 0)\n")
    # Like payments/gen-vop-opa-bundle.sh: heredoc python run from the script's own directory.
    w(SYN_HEREDOC_SCRIPT, 'cd "$(dirname "$0")"\npython3 - <<\'PY\'\ntry:\n    import yaml  # noqa\nexcept ImportError:\n    pass\nPY\n')
    subprocess.run([sys.executable, SYN_GENERATOR], cwd=root, check=True, env=env)
    g("add", "-A")
    g("commit", "-q", "-m", "base")

    def pr(name, edits, link=None):
        g("checkout", "-q", "-b", name, "main")
        for rel, text in edits.items():
            w(rel, text)
        if link:
            os.symlink(link[1], os.path.join(root, link[0]))
        g("add", "-A")
        g("commit", "-q", "-m", name)
        g("checkout", "-q", "main")

    pr("pA", {"services/a.txt": "a\n", "count.txt": "2\n"})
    pr("pB", {"services/b.txt": "b\n", "count.txt": "2\n"})
    pr("p1", {"docs/one.md": "1\n"})
    pr("p2", {"docs/two.md": "2\n"})
    pr("p3", {"bad.txt": "x\n"})
    pr("p4", {"docs/four.md": "4\n"})
    # Train members (protected build-logic/) that touch NO generator input: a re-derived train may carry them.
    pr("pE1", {"build-logic/e1.txt": "1\n"})
    pr("pE2", {"build-logic/e2.txt": "2\n"})
    pr("pE3", {"build-logic/e3.txt": "3\n"})
    pr("pR", {"services/r.txt": "r\n", "count.txt": "2\n"})
    pr("pL", {"docs/l.md": "l\n"}, link=("docs-link", "/etc/passwd"))
    pr("pG", {SYN_GENERATOR: "import os,pathlib\npathlib.Path('leaked.txt').write_text(os.environ.get('GH_TOKEN','none'))\n"})
    pr("pW", {".github/workflows/w.yml": "on: push\n"})
    pr("pW2", {".github/scripts/two.py": "print(2)\n"})
    pr("pS", {".github/scripts/check-s.py": "print(1)\n"}, link=("docs-s-link", "/etc/passwd"))
    # #13400: gate code (a check script) rides a train; next to a member that needs
    # regeneration it must not share one (the regeneration is proven by main's gates only).
    pr("pK", {SYN_GATE_CODE: "print('k')\n"})
    pr("pM", {SYN_MAIN_GATE_CODE: "member\n"})   # modifies a check script main already has
    pr("pX", {"docs/adr/0001-x.md": "x\n"})
    pr("pF", {"svc/fast.txt": "f\n"})
    pr("pT", {SYN_BASELINE: "loosened\n"})
    # Review 6: a generator whose NAME carries a newline, and a module shadowing `yaml` next to the
    # heredoc script. Each leaves a marker if it is ever executed.
    pr("pN", {SYN_NEWLINE_GENERATOR: f"touch {os.path.join(os.path.dirname(root), 'newline-gen-ran')}\n", "docs/n.md": "n\n"})
    pr("pQ", {"docs/q\nr.md": "q\n"})
    # Review 7: rename a gate script to a harmless-looking path; with rename detection git reports
    # only the NEW name, hiding that the generator runner's inventory was deleted.
    g("checkout", "-q", "-b", "pV", "main")
    os.makedirs(os.path.join(root, "docs"), exist_ok=True)
    g("mv", REGEN_INVENTORY, "docs/x.md")
    g("commit", "-q", "-m", "pV")
    g("checkout", "-q", "main")
    pr("pY", {SYN_SHADOW_MODULE: f"open({os.path.join(os.path.dirname(root), 'shadow-ran')!r}, 'w').write('x')\n",
              "docs/y.md": "y\n"})
    # A bundle generator deeper than any fixed-depth glob reaches; it would leave a marker if run.
    pr("pD", {SYN_DEEP_GENERATOR: f"touch {os.path.join(os.path.dirname(root), 'deep-generator-ran')}\n",
              "docs/d.md": "d\n"})
    # Strict carrier (ADR-0343 amendment 2026-11-05): every one of these is strict-lane (an executable
    # `.github/` path). pJ1 edits the train's own script and leaves a marker if it is ever EXECUTED.
    # Judge members (ride alone): the train's own script (leaves a marker if EXECUTED), a workflow, gates.yaml.
    pr("pJ1", {".github/scripts/merge-train.py": f"open({os.path.join(os.path.dirname(root), 'strict-member-ran')!r}, 'w').write('ran')\n"})
    pr("pJ2", {".github/workflows/merge-train.yml": "name: train\n"})
    pr("pGY", {GATES_YAML: "gates:\n  - id: g-one\n    run: true\n"})                  # retires g-two
    # adds g-three AND edits g-one, so it is not a pure append and still takes the strict lane
    pr("pGA", {GATES_YAML: SYN_GATES_YAML.replace("run: true", "run: 'true'", 1) + "  - id: g-three\n    run: true\n"})
    pr("pGP", {GATES_YAML: SYN_GATES_YAML + "  - id: g-four\n    run: python3 .github/scripts/check-g-four.py\n"})      # a pure append
    # Non-judge strict members (plain scripts under .github/scripts): batched together.
    pr("pP1", {".github/scripts/p1.py": "print(1)\n"})
    pr("pP2", {".github/scripts/p2.py": "print(2)\n"})
    pr("pPc", {".github/scripts/two.py": "print('conflict')\n"})                      # conflicts with pW2
    pr("pPR", {".github/scripts/p4.py": "print(4)\n", "docs/w3.md": "w3\n"})          # docs/ is a regen input
    pr("pPx", {".github/scripts/q\nr.py": "print(0)\n"})                              # control character
    pr("pPbad", {".github/scripts/bad.py": "print('bad')\n"})                         # red in CI (ci.py)
    # Referenced scripts ride alone: named by path in a workflow, or by bare basename only.
    pr("pRG", {".github/scripts/run-gates.py": "print('gates2')\n"})
    pr("pFoo", {".github/scripts/lib/foo.sh": "echo foo2\n"})
    # Disjoint judge batching (ADR-0343 amendment 2026-11-15): judge members with pairwise disjoint paths.
    pr("pCO", {".github/scripts/p5.py": "print(5)\n", "openbank-mco/src/main/kotlin/co.kt": "c\n"})            # judge (svc/), disjoint
    pr("pJbad", {".github/scripts/bad.py": "print('bad')\n", "openbank-mjred/src/main/kotlin/jred.kt": "x\n"})    # judge (svc/), red in CI
    pr("pS1", {".github/scripts/p6.py": "print(6)\n", "openbank-ms1/src/main/kotlin/s1.kt": "1\n"})              # judge (svc/), disjoint
    pr("pS2", {".github/scripts/p7.py": "print(7)\n", "openbank-ms2/src/main/kotlin/s2.kt": "2\n"})              # judge (svc/), disjoint
    # Two judge members that share ONE path (an identical new file: merge-tree merges them cleanly).
    pr("pO1", {".github/scripts/o1.py": "print('o1')\n", "openbank-svc/src/main/kotlin/shared.kt": "s\n"})
    pr("pO2", {".github/scripts/o2.py": "print('o2')\n", "openbank-svc/src/main/kotlin/shared.kt": "s\n"})
    # Configuration judges (ride alone): a checker relaxed so bad.py passes, or tightened so co.txt fails.
    pr("pRelax", {".github/scripts/run-gates.py": "print('relax')\n"})
    pr("pTight", {".github/scripts/run-gates.py": "print('tighten')\n"})
    # Second re-review of #16290: verdict configuration written as Kotlin or Markdown.
    pr("pDet", {".github/scripts/pd.py": "print('d')\n",
                "openbank-libs-detekt-rules/src/main/kotlin/Relax.kt": "// relaxes the rule bad.py violates\n"})
    pr("pMoney", {".github/scripts/pm.py": "print('m')\n", "openbank-svc/src/main/kotlin/Money.kt": "// money path\n"})
    pr("pTM", {".github/scripts/pt.py": "print('t')\n", "docs/threat-models/svc.md": "# threat model\n"})
    # Cross-module test read: openbank-mread's test pins openbank-mtarget's source.
    pr("pPinT", {".github/scripts/pq.py": "print('q')\n", "openbank-mtarget/src/main/kotlin/Pin.kt": "// changed\n"})
    pr("pPinR", {".github/scripts/pr2.py": "print('r')\n", "openbank-mread/src/test/kotlin/PinTest.kt": "// relaxed\n"})
    pr("pWT", {".github/scripts/pw.py": "print('w')\n", "openbank-mwt/src/main/kotlin/W.kt": "// changed\n"})
    # Adds, in a SHAREABLE module, a test reading another module: invisible to the base-tree scan.
    # Adds a `.parent` climb (no parentFile, no "..") in a SHAREABLE module, and an integrationTest reading out.
    pr("pAddP", {".github/scripts/pa3.py": "print('a3')\n",
                 "openbank-ms2/src/test/kotlin/RootTest.kt":
                     'val r = Paths.get("").toAbsolutePath().parent.parent.resolve("build-logic")\n'})
    pr("pAddI", {".github/scripts/pa4.py": "print('a4')\n",
                 "openbank-mca/src/integrationTest/kotlin/ReadIT.kt": 'val f = File("../openbank-mcb/x")\n'})
    pr("pAddR", {".github/scripts/pa2.py": "print('a2')\n",
                 "openbank-ms1/src/test/kotlin/NewPinTest.kt": 'val f = File("../openbank-mco/src/main/kotlin/co.kt")\n'})
    pr("pWR", {".github/scripts/pw2.py": "print('w2')\n", "openbank-mwalk/src/test/kotlin/WalkTest.kt": "// relaxed\n"})
    # Companion in the SAME module: code in src/main, a test in src/test.
    pr("pCompA", {".github/scripts/pa.py": "print('a')\n", "openbank-svc/src/main/kotlin/A.kt": "// a\n"})
    pr("pCompB", {".github/scripts/pb.py": "print('b')\n", "openbank-svc/src/test/kotlin/ATest.kt": "// a test\n"})
    # Each green alone, red only together (ci.py): a carrier with no culprit in either half.
    pr("pCA", {".github/scripts/p8.py": "print(8)\n", "openbank-mca/src/main/kotlin/ca.kt": "a\n"})
    pr("pCB", {".github/scripts/p9.py": "print(9)\n", "openbank-mcb/src/main/kotlin/cb.kt": "b\n"})


def _pack_synthetic_origin(root: str) -> None:
    # Bootstrap once, before any clones exist. Keep even unreachable objects: later fixture
    # mutations still use ordinary independent local clones, with auto-gc disabled throughout.
    sh(["git", "repack", "-a", "-d", "--keep-unreachable", "--no-cruft", "--threads=1"],
       cwd=root, env=base_env())


def _clone_synthetic_origin(origin: str, destination: str) -> subprocess.CompletedProcess:
    return sh(["git", "clone", "-q", "--branch", "main", origin, destination], env=base_env(), check=False)


def packed_fixture_self_test(check) -> None:
    """Packing changes representation only, including old packed unreachable objects."""
    with tempfile.TemporaryDirectory() as root:
        origin = os.path.join(root, "origin")
        os.mkdir(origin)
        git = Git(origin)
        git("init", "-q", "-b", "main")
        git("config", "gc.auto", "0")
        git("config", "maintenance.auto", "false")
        tracked = pathlib.Path(origin, "tracked.txt")
        tracked.write_text("base\n")
        git("add", "tracked.txt"); git("commit", "-q", "-m", "base")
        payload = pathlib.Path(root, "unreachable.txt")
        payload.write_text("packed unreachable\0payload\n")
        packed = git("hash-object", "-w", str(payload)).stdout.strip()
        git("update-ref", "refs/tags/fixture-blob", packed)
        git("repack", "-a", "-d", "--no-cruft", "--threads=1")
        git("update-ref", "-d", "refs/tags/fixture-blob")
        objects = pathlib.Path(origin, ".git", "objects")
        check("fixture pack: old unreachable blob starts packed-only",
              not (objects / packed[:2] / packed[2:]).exists())
        payload.write_text("loose unreachable\0payload\n")
        loose = git("hash-object", "-w", str(payload)).stdout.strip()
        check("fixture pack: new unreachable blob starts loose",
              (objects / loose[:2] / loose[2:]).is_file())
        tracked.write_text("reachable loose commit\n")
        git("add", "tracked.txt"); git("commit", "-q", "-m", "reachable loose")

        def inventory():
            # Tree objects contain raw binary ids; compare the complete byte stream without decoding.
            SPAWNS[0] += 1
            return subprocess.run(["git", "cat-file", "--batch-all-objects", "--batch"],
                                  cwd=origin, env=base_env(), capture_output=True, check=True).stdout

        def state(directory):
            d = pathlib.Path(directory)
            return tuple((d / rel).read_bytes() for rel in (".git/HEAD", ".git/index", "tracked.txt"))

        # Distinct staged and unstaged states must survive packing too.
        tracked.write_text("staged only\n")
        git("add", "tracked.txt")
        tracked.write_text("unstaged only\n")
        before_objects = inventory()
        before_refs = git("for-each-ref", "--format=%(refname)%00%(objectname)").stdout
        before_state = state(origin)
        before_loose = len(list(objects.glob("[0-9a-f][0-9a-f]/*")))
        _pack_synthetic_origin(origin)
        check("fixture pack: all object ids, types, sizes and contents unchanged", inventory() == before_objects)
        check("fixture pack: all refs unchanged",
              git("for-each-ref", "--format=%(refname)%00%(objectname)").stdout == before_refs)
        check("fixture pack: HEAD, index and worktree unchanged", state(origin) == before_state)
        check("fixture pack: redundant loose copies removed and pack created",
              len(list(objects.glob("[0-9a-f][0-9a-f]/*"))) < before_loose
              and bool(list((objects / "pack").glob("*.pack"))))
        for oid, expected in ((packed, "packed unreachable\0payload\n"),
                              (loose, "loose unreachable\0payload\n")):
            check("fixture pack: unreachable content retained " + oid[:8],
                  git("cat-file", "blob", oid).stdout == expected)

        first, peer = os.path.join(root, "first"), os.path.join(root, "peer")
        for clone in (first, peer):
            result = _clone_synthetic_origin(origin, clone)
            if result.returncode:
                raise RuntimeError("self-test packed fixture: clone failed: " + result.stderr[-400:])
        first_git, peer_git = Git(first), Git(peer)
        peer_state = state(peer)
        origin_head = git("rev-parse", "HEAD").stdout.strip()
        peer_head = peer_git("rev-parse", "HEAD").stdout.strip()
        pathlib.Path(first, "tracked.txt").write_text("first clone only\n")
        first_git("add", "tracked.txt"); first_git("commit", "-q", "-m", "first only")
        first_head = first_git("rev-parse", "HEAD").stdout.strip()
        check("fixture clone: peer and origin refs, index and worktree isolated",
              git("rev-parse", "HEAD").stdout.strip() == origin_head
              and peer_git("rev-parse", "HEAD").stdout.strip() == peer_head
              and state(origin) == before_state and state(peer) == peer_state)
        check("fixture clone: clone-only object absent from peer and origin",
              git("cat-file", "-e", first_head, check=False).returncode != 0
              and peer_git("cat-file", "-e", first_head, check=False).returncode != 0)
        tracked.write_text("future origin only\n")
        git("add", "tracked.txt"); git("commit", "-q", "-m", "future origin")
        future = git("rev-parse", "HEAD").stdout.strip()
        future_blob = git("rev-parse", "HEAD:tracked.txt").stdout.strip()
        check("fixture clone: future origin commit and blob absent before fetch",
              all(peer_git("cat-file", "-e", oid, check=False).returncode != 0 for oid in (future, future_blob))
              and peer_git("rev-parse", "origin/main").stdout.strip() == origin_head)
        peer_git("fetch", "-q", "origin", "main")
        check("fixture clone: future objects arrive only after fetch",
              all(peer_git("cat-file", "-e", oid, check=False).returncode == 0 for oid in (future, future_blob))
              and peer_git("rev-parse", "origin/main").stdout.strip() == future)
        check("fixture clone: fetch leaves local HEAD, index and worktree unchanged",
              peer_git("rev-parse", "HEAD").stdout.strip() == peer_head and state(peer) == peer_state)
        check("fixture clone: no alternates in origin or either clone",
              not any(pathlib.Path(d, ".git/objects/info/alternates").exists() for d in (origin, first, peer)))


def git_memo_self_test(check) -> None:
    """The Git memo serves only answers that are pure functions of immutable shas.

    Negative cases first: a worktree-reading `diff <sha>` must NOT be served from the memo after the
    worktree changes, and index/worktree flags, pathspecs, symbolic refs and short shas never form a
    key. Then the positive case, so a memo that quietly stopped caching is noticed too."""
    with tempfile.TemporaryDirectory() as d:
        git = Git(d)
        git("init", "-q", "-b", "main")
        pathlib.Path(d, "f.txt").write_text("one\n")
        git("add", "f.txt"); git("commit", "-q", "-m", "one")
        a = git("rev-parse", "HEAD").stdout.strip()
        pathlib.Path(d, "f.txt").write_text("two\n")
        git("add", "f.txt"); git("commit", "-q", "-m", "two")
        b = git("rev-parse", "HEAD").stdout.strip()
        # 1. diff <sha> reads the worktree: never memoised, so a worktree change is seen.
        first = git("diff", a).stdout
        pathlib.Path(d, "f.txt").write_text("three\n")
        second = git("diff", a).stdout
        check("git memo: `diff <sha>` (worktree) is re-read after the worktree changes", first != second,
              "a worktree-reading diff was served from the memo")
        check("git memo: `diff <sha>` forms no key", git._memo_key(("diff", a)) is None)
        for shape in (("diff", "--cached", a, b), ("diff", "--staged", a, b), ("diff", "--no-index", a, b),
                      ("diff", a, b, "--", "f.txt"), ("diff", a[:12], b), ("diff", "main", b), ("diff", a, "HEAD"),
                      ("merge-base", a), ("diff-tree", a), ("rev-parse", "HEAD"), ("show", "main:f.txt"),
                      ("log", "-1", "origin/main")):
            check(f"git memo: {' '.join(shape)} forms no key", git._memo_key(shape) is None)
        # 2. index-reading diff with two shas and --cached: still re-read after `git add`.
        pathlib.Path(d, "f.txt").write_text("four\n")
        before = git("diff", "--cached", a).stdout
        git("add", "f.txt")
        after = git("diff", "--cached", a).stdout
        check("git memo: `diff --cached` is re-read after the index changes", before != after)
        git("reset", "-q", "--hard", b)
        # 3. pure shapes ARE memoised, and a write clears them.
        for shape in (("diff", "--stat", a, b), ("diff", "--raw", "-z", f"{a}..{b}"), ("rev-list", f"{a}..{b}"),
                      ("show", "-s", "--format=%H", b), ("rev-parse", f"{b}^{{tree}}"), ("merge-base", a, b),
                      ("show", f"{b}:f.txt"), ("ls-tree", "-r", b), ("cat-file", "-e", f"{b}^{{commit}}")):
            check(f"git memo: {' '.join(shape)} forms a key", git._memo_key(shape) is not None)
        git("diff", "--stat", a, b)
        n = SPAWNS[0]
        git("diff", "--stat", a, b)
        check("git memo: a pure two-sha diff is served from the memo (no spawn)", SPAWNS[0] == n)
        git("checkout", "-q", "--detach", a)
        git("diff", "--stat", a, b)
        check("git memo: a write clears the memo (spawn again)", SPAWNS[0] == n + 2)
        r = git("show", "-s", "--format=%H", "0" * 40, check=False)
        check("git memo: a failing read is not cached", r.returncode != 0 and ("show", "-s", "--format=%H", "0" * 40) not in git._memo)


def retry_planner_self_test(check) -> None:
    """Exercise the real GitHub adapter and HTTP transport scope, without live API access."""
    import copy

    sha, prefix = "a" * 40, "/repos/x/y/actions"
    checks = [{"name": "gates (data)", "id": 901,
               "details_url": "https://github.com/x/y/actions/runs/123/job/501"},
              {"name": "Validate manifests", "id": 902,
               "details_url": "https://github.com/x/y/actions/runs/123/job/502"}]
    run = {"id": 123, "path": ".github/workflows/ci.yml", "head_sha": sha,
           "run_attempt": 2, "status": "completed", "conclusion": "failure"}
    def job(job_id, name, conclusion="success", attempt=2):
        return {"id": job_id, "name": name, "status": "completed", "conclusion": conclusion,
                "run_id": 123, "run_attempt": attempt}
    jobs = [job(500, "Receive trusted ruleset evidence"), job(501, "gates (data)", "failure"),
            job(502, "Validate manifests", "failure"), job(503, "UI build", attempt=1)]
    saved = (_http_open, _api_sleep, os.environ.get("GH_TOKEN"), _api_slept[0], dict(_GET_MEMO))
    receiver_post, full_post, failed_post = (f"{prefix}/jobs/500/rerun", f"{prefix}/runs/123/rerun",
                                            f"{prefix}/runs/123/rerun-failed-jobs")

    def exercise(label, *, metadata=None, listing=None, check_runs=None, want=None,
                 read_error=None, post_error=None, extra_run=False):
        metadata = copy.deepcopy(run if metadata is None else metadata)
        listing = copy.deepcopy(jobs if listing is None else listing)
        check_runs = copy.deepcopy(checks if check_runs is None else check_runs)
        if extra_run:
            check_runs.append({"name": "other", "id": 903,
                               "details_url": "https://github.com/x/y/actions/runs/124/job/600"})
        calls = []
        def http(req, timeout):
            parsed = urllib.parse.urlsplit(req.full_url)
            path, query = parsed.path, urllib.parse.parse_qs(parsed.query)
            calls.append((req.method, path, query))
            if req.method == "POST":
                if post_error:
                    raise urllib.error.HTTPError(req.full_url, post_error, "fixture write refused", {}, io.BytesIO(b"fixture"))
                return 201, b"{}", {}
            if req.method != "GET":
                raise AssertionError(f"unexpected method {req.method}")
            if read_error and read_error in path:
                raise urllib.error.HTTPError(req.full_url, 403, "fixture read refused", {}, io.BytesIO(b"fixture"))
            if path == f"/repos/x/y/commits/{sha}/check-runs":
                data = {"check_runs": check_runs}
            elif path == f"{prefix}/runs/123":
                data = metadata
            elif path == f"{prefix}/runs/124":
                data = {}  # An unreadable second plan must not cause the first write.
            elif path == f"{prefix}/runs/123/jobs":
                if query.get("filter") != ["latest"]:
                    raise AssertionError("job listing must request latest results")
                offset = (int(query.get("page", ["1"])[0]) - 1) * 100
                data = {"jobs": listing[offset:offset + 100]}
            else:
                raise AssertionError(f"unexpected read {path}")
            return 200, json.dumps(data).encode(), {}
        globals()["_http_open"] = http
        globals()["_api_sleep"] = lambda seconds: (_ for _ in ()).throw(AssertionError("no retries expected"))
        _GET_MEMO.clear()
        _api_slept[0] = 0
        os.environ["GH_TOKEN"] = "offline-fixture"
        result, error = None, None
        try:
            result = GitHub("x/y", "main", "offline://fixture").rerun_inconclusive(
                sha, [item["name"] for item in checks] + (["other"] if extra_run else []))
        except (ApiAbort, SystemExit) as exc:
            error = type(exc).__name__
        posts = [path for method, path, _ in calls if method == "POST"]
        if want is None:
            ok = not posts and result is not True
        elif post_error:
            ok = posts == [want] and result is not True
        else:
            ok = posts == [want] and result is True and error is None
        check(f"retry planner: {label}", ok, f"result={result} error={error} posts={posts} calls={calls}")
        return calls

    try:
        exercise("current receiver refreshes its descendants once", want=receiver_post)
        inherited = copy.deepcopy(jobs)
        inherited[0]["run_attempt"] = 1
        exercise("old successful receiver requires one full CI run", listing=inherited, want=full_post)
        exercise("absent current receiver requires one full CI run", listing=jobs[1:], want=full_post)
        outside = copy.deepcopy(jobs)
        outside[-1].update(conclusion="cancelled", run_attempt=2)
        exercise("cancelled job outside receiver descendants requires full CI", listing=outside, want=full_post)
        exercise("unrelated workflow keeps failed-only", metadata={**run, "path": ".github/workflows/security.yml"},
                 want=failed_post)
        exercise("workflow ref suffix still identifies actual CI", metadata={**run, "path": run["path"] + "@refs/pull/1/merge"},
                 want=receiver_post)
        for label, metadata in [("missing metadata", {}), ("wrong source", {**run, "head_sha": "b" * 40}),
                                ("nonterminal run", {**run, "status": "in_progress"}),
                                ("invalid attempt", {**run, "run_attempt": 0}),
                                ("boolean attempt", {**run, "run_attempt": True}),
                                ("unknown workflow", {**run, "path": ""})]:
            exercise(label, metadata=metadata)
        exercise("missing requested check", check_runs=checks[:1])
        exercise("run read denied", read_error="/runs/123")
        exercise("job read denied", read_error="/jobs")
        exercise("empty job evidence", listing=[])
        exercise("ambiguous receiver", listing=jobs + [job(600, "Receive trusted ruleset evidence")])
        future = copy.deepcopy(jobs)
        future[0]["run_attempt"] = 3
        exercise("attempt advanced during read", listing=future)
        exercise("unreadable later run causes no earlier write", extra_run=True)
        for code in (403, 500):
            exercise(f"receiver POST {code} never falls back to another write", want=receiver_post, post_error=code)
        paged = [job(1000 + n, f"green-{n}") for n in range(100)] + jobs
        calls = exercise("receiver on second page is found", listing=paged, want=receiver_post)
        check("retry planner: jobs fully paginated", any(path.endswith("/jobs") and query.get("page") == ["2"]
                                                       for _, path, query in calls), str(calls))
        workflow = pathlib.Path(".github/workflows/ci.yml").read_text()
        check("retry planner: current CI declares the selected receiver and direct gate dependency",
              "name: Receive trusted ruleset evidence" in workflow
              and "needs: [agent-admission, ruleset-evidence]" in workflow
              and "needs: [agent-admission, ruleset-evidence, gates, changes-ui, ui-build, ui-coverage, ui-rbac-contract]" in workflow)
    finally:
        globals()["_http_open"], globals()["_api_sleep"] = saved[:2]
        if saved[2] is None:
            os.environ.pop("GH_TOKEN", None)
        else:
            os.environ["GH_TOKEN"] = saved[2]
        _api_slept[0] = saved[3]
        _GET_MEMO.clear()
        _GET_MEMO.update(saved[4])


# Measured 2026-11-03 with the Git memo and the fixture's main_sha cache: 12,792 spawns over 461 cases
# (18,534 before). ~9 % headroom for the cases in flight (#14685 adds admission cases). A new case may
# raise it, with its own `spawns=` measurement, in the same PR. The number is the control: it fails
# before the shard's time budget does, and it fails the same way on a fast machine as on a slow one.
# 2026-11-05 (#14888): the eleven strict-carrier cases drive ~35 more settle ticks over the fixture
# (a carrier is built, judged and rebuilt per tick): spawns=14,920 over 568 cases, measured on this
# PR's full run; the ceiling moves to 15,500 (~4 % headroom), still well under the 18,534 that first
# overran the shard budget. Re-review of #14891 (judge-alone sequences, the inverse-rule ticks, the
# post-merge tree check): spawns=15,550 at 594 cases before trimming two no-op ticks; ceiling 15,800.
# Strict carrier serving order, workflow members and the refused push: spawns=15,928 at 605 cases; ceiling 16,200.
# 2026-11-09 (#15254 shape): the stale-culprit refresh cases add an up-to-date culprit drain and the
# refused-update path, the one-refresh-per-lineage drain and the multi-member carrier case: baseline
# spawns=16,105 at 653 cases, 16,995 at 659 (measured on this PR's full run); ceiling 17,400 (~2.4 %).
# Speculative stacking (2026-11-09): the S1-S10 cases drive ~20 more settle/build/publish ticks. Measured on
# the same machine, same day: origin/main 16,105 spawns at 653 cases, this change 17,286 at 671 (+1,181);
# ceiling 17,800 (~3 % headroom), under the 18,534 that first overran the shard budget.
# Both merged (#15400 over #15374): stacking cases plus the stale-culprit refresh cases: spawns=18,176 at
# 677 cases, measured on the merged tree; ceiling 18,600 (~2.3 %).
# Likely-flake rerun before a lone-member blame (#15420): three fast-carrier cases and one extra settle
# each in five existing culprit cases: spawns=16,663 at 670 cases, measured locally; ceiling 17,000.
# Both merged (#15430 over #15374): each lone culprit carrier is re-run once before its blame, plus the
# first-parent lineage case: spawns=18,070 at 678 cases, measured on the merged tree; ceiling 18,500 (~2.4 %).
# All three merged (#15430 over #15400 + #15374): spawns=19,251 at 696 cases, measured on the merged tree;
# ceiling 19,700 (~2.3 %).
# #15827 (moved member re-derived in publish, fast path held under a carrier, strict-ready hold): 12 cases,
# ~6 more ticks: spawns=19,929 at 708 cases, measured locally on 2026-11-12; ceiling 20,400 (~2.4 %).
# Expedite lane (ADR-0343 amendment 2026-11-13): eleven cases E1-E11, ~17 more ticks: spawns=21,143 at 720 cases,
# measured locally on 2026-11-13; ceiling 21,400 (~1.2 %).
# Main-red fix job evidence (#16013): two fix_behind cases: spawns=21,402 at 761 cases, measured by the train
# over main on 2026-11-14; ceiling 21,800 (~1.9 %).
# Its refinements (refusal in the summary, timed-out main jobs): spawns=21,445 at 764 cases, measured on the
# merged tree on 2026-11-14; ceiling 21,900 (~2.1 %).
# Disjoint judge batching (ADR-0343 amendment 2026-11-15): cases (16)-(19) plus the judge-cap-1 control of (2),
# ~20 more ticks: spawns=22,621 at 800 cases, measured locally on 2026-11-15; after its review (configuration
# judges ride alone; cases (18b), (20), (21)) spawns=23,697 at 819 cases; after the second re-review (leaf modules,
# module-disjoint, cases (22)-(24)) spawns=24,247 at 847 cases, measured locally; ceiling 24,800 (~2.3 %).
# Cross-module test reads (#16357, cases (25)-(28)): spawns=24,949 at 855 cases, measured locally on 2026-11-15;
# ceiling 25,500 (~2.2 %).
SELF_TEST_SPAWN_CEILING = 25500

# A green carrier and a green, up-to-date strict holder cannot both keep their verification: whichever
# merges first moves main under the other. Strict first voids the carrier (rebuild ~50 min, measured
# carrier #15368: published 10:11Z, green ~11:00Z, voided by #15295's 11:01Z merge, rebuilt as #15369);
# carrier first pushes the holder behind main (update-branch + ~1.5 h of full CI, #14191 / #14183).
# In PR-minutes that is N members x ~50 against 1 holder x ~90, so the holder goes first only for a
# carrier of ONE member; any larger green carrier merges first and the holder is update-branched with
# its deferral record, exactly as on the green-carrier-first path that already existed.
STRICT_FIRST_MAX_MEMBERS = 1



def branch_updater_self_test(check) -> None:
    """update-branch credential choice (dedicated App with `workflows`, else GH_TOKEN) and the key-spread guard."""
    saved = (globals()["_http_open"], os.environ.get("GH_TOKEN"), os.environ.get("UPDATE_BRANCH_TOKEN"), dict(_GET_MEMO))
    seen: list[tuple[str, str]] = []

    def fake_open(req, timeout):
        seen.append((req.get_method(), req.get_header("Authorization") or ""))
        return 202, b"{}", {}
    globals()["_http_open"] = fake_open
    try:
        gh = GitHub("o/r", "main", "")
        os.environ["GH_TOKEN"] = "ghs_GITOPS_FIXTURE"
        os.environ["UPDATE_BRANCH_TOKEN"] = "ghs_UPDATER_FIXTURE"
        ok = gh.update_branch(7, "a" * 40)
        check("update-branch: the dedicated branch-updater token is used when set",
              ok and seen[-1:] == [("PUT", "Bearer ghs_UPDATER_FIXTURE")], str(seen))
        os.environ["UPDATE_BRANCH_TOKEN"] = ""
        ok = gh.update_branch(7, "a" * 40)
        check("update-branch: an empty branch-updater token (mint failed) falls back to GH_TOKEN",
              ok and seen[-1:] == [("PUT", "Bearer ghs_GITOPS_FIXTURE")], str(seen))
        os.environ["UPDATE_BRANCH_TOKEN"] = "ghs_UPDATER_FIXTURE"
        api("GET", "/repos/o/r/pulls/7")
        check("update-branch token: no other call carries it", seen[-1:] == [("GET", "Bearer ghs_GITOPS_FIXTURE")], str(seen))
        env = generator_env()
        check("generator env: UPDATE_BRANCH_TOKEN is stripped like GH_TOKEN",
              "UPDATE_BRANCH_TOKEN" not in env and not any("TOKEN" in k for k in env), str(sorted(env)))
    finally:
        globals()["_http_open"] = saved[0]
        for k, v in (("GH_TOKEN", saved[1]), ("UPDATE_BRANCH_TOKEN", saved[2])):
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        _GET_MEMO.clear()
        _GET_MEMO.update(saved[3])
    wf = "jobs:\n  settle:\n    steps:\n      - with:\n          app-id: ${{ secrets.BRANCH_UPDATER_APP_ID }}\n"
    check("key spread: BRANCH_UPDATER_ only in merge-train.yml is clean",
          branch_updater_spread_errors({"merge-train.yml": wf, "ci.yml": "jobs: {}\n"}) == [])
    check("key spread: BRANCH_UPDATER_ in another workflow fails (must-fail)",
          len(branch_updater_spread_errors({"merge-train.yml": wf, "deploy.yml": wf})) == 1)
    check("key spread: another workflow declaring the environment fails, under any secret spelling",
          len(branch_updater_spread_errors({"merge-train.yml": wf,
                                            "x.yml": "jobs:\n  j:\n    environment: merge-train-branch-update\n"
                                                     "    steps:\n      - run: echo '${{ toJSON(secrets) }}'\n"})) == 1)
    check("key spread: the real tree is clean", branch_updater_spread_errors(workflow_texts()) == [],
          str(branch_updater_spread_errors(workflow_texts())))


def prefetch_self_test(check) -> None:
    """GraphQL check prefetch: seeds the exact REST memo keys from one query, so checks() sends no REST;
    an incomplete head, a GraphQL error or a deciding() read all fall back to live REST."""
    saved = (globals()["_http_open"], os.environ.get("GH_TOKEN"), dict(_GET_MEMO), dict(API_STATS))
    a, b = "a" * 40, "b" * 40
    seen: list[str] = []
    gql = {"mode": "ok"}

    def commit(sha, more=False):
        return {"oid": sha, "checkSuites": {"pageInfo": {"hasNextPage": False}, "nodes": [
            {"app": {"slug": "github-actions"}, "checkRuns": {"pageInfo": {"hasNextPage": more}, "nodes": [
                {"databaseId": 11, "name": "Validate manifests", "status": "COMPLETED", "conclusion": "SUCCESS",
                 "detailsUrl": "https://github.com/o/r/actions/runs/5/job/6", "url": "https://github.com/o/r/runs/11",
                 "startedAt": "2026-11-14T10:00:00Z", "completedAt": "2026-11-14T10:05:00Z"},
                {"databaseId": 12, "name": "Gitleaks", "status": "IN_PROGRESS", "conclusion": None,
                 "detailsUrl": None, "url": None, "startedAt": "2026-11-14T10:01:00Z", "completedAt": None}]}}]},
            "status": {"state": "PENDING", "contexts": [
                {"context": "merge-train", "state": "PENDING", "description": "queued", "targetUrl": None,
                 "createdAt": "2026-11-14T10:02:00Z", "creator": {"login": "x"}}]}}

    def fake_open(req, timeout):
        path = req.full_url[len(API):]
        seen.append(f"{req.get_method()} {path.split('?')[0]}")
        if path == "/graphql":
            gql.setdefault("queried", []).append(sorted(x for x in (a, b) if x in (req.data or b"").decode()))
            if gql["mode"] == "error":
                return 200, json.dumps({"errors": [{"message": "boom"}]}).encode(), {}
            if gql["mode"] == "partial":
                return 200, json.dumps({"data": {"repository": {"c0": commit(a), "c1": None}}, "errors": [
                    {"type": "RESOURCE_LIMITS_EXCEEDED", "path": ["repository", "c0", "checkSuites"]}]}).encode(), {}
            return 200, json.dumps({"data": {"repository": {"c0": commit(a), "c1": commit(b, more=True)}}}).encode(), {}
        if "/pulls?" in path:
            return 200, json.dumps([{"number": 1, "head": {"sha": a}}, {"number": 2, "head": {"sha": b}}]).encode(), {}
        if path.endswith("/status"):
            return 200, json.dumps({"state": "pending", "statuses": [
                {"id": 1, "context": "merge-train", "state": "pending"}]}).encode(), {}
        return 200, json.dumps({"total_count": 2, "check_runs": [
            {"id": 11, "name": "Validate manifests", "status": "completed", "conclusion": "success"},
            {"id": 12, "name": "Gitleaks", "status": "in_progress", "conclusion": None}]}).encode(), {}
    globals()["_http_open"] = fake_open
    try:
        os.environ["GH_TOKEN"] = "ghs_FIXTURE"
        gh = GitHub("o/r", "main", "")
        want = {"Validate manifests": "success", "Gitleaks": None, "merge-train": None}
        _GET_MEMO.clear()
        with planning_reads():
            gh.open_prs()
            seen.clear()
            got_a = gh.checks(a)
            rest_a = list(seen)
            got_b = gh.checks(b)
        check("prefetch: a complete head is served from the GraphQL batch with no REST call",
              got_a == want and rest_a == [], f"{got_a} {rest_a}")
        check("prefetch: a head with a further page falls back to REST and reads the same verdicts",
              got_b == want and any("/commits/" + b in x for x in seen), f"{got_b} {seen}")
        with planning_reads():
            gh.open_prs()
            gql["queried"] = []
            gh.open_prs()
            gh.open_prs()
            again = list(gql["queried"])
        check("prefetch: repeated open_prs() in one scope re-reads only the heads not yet seeded",
              again == [[b], [b]], str(again))
        payload = prefetch_payloads(commit(a), a)
        check("prefetch: payload carries what latest_ci_activity and extra_checks read",
              payload is not None and payload[0][0]["started_at"] == "2026-11-14T10:00:00Z"
              and payload[0][0]["app"]["slug"] == "github-actions" and "/actions/runs/5/" in payload[0][0]["details_url"],
              str(payload))
        _GET_MEMO.clear()
        seen.clear()
        with planning_reads():
            gh.open_prs()
            with deciding():
                gh.checks(a)
        check("prefetch: a deciding() read never uses the seeded payload (goes live)",
              any(x.endswith(f"/commits/{a}/status") for x in seen), str(seen))
        _GET_MEMO.clear()
        gql["mode"] = "error"
        seen.clear()
        with planning_reads():
            gh.open_prs()
            got = gh.checks(a)
        check("prefetch: a GraphQL error falls back to REST with the same verdicts",
              got == want and any(x.endswith(f"/commits/{a}/status") for x in seen), f"{got} {seen}")
        _GET_MEMO.clear()
        gql["mode"] = "partial"
        seen.clear()
        with planning_reads():
            gh.open_prs()
            got = gh.checks(a)
        check("prefetch: an alias named in a partial error is not seeded (goes to REST)",
              got == want and any(x.endswith(f"/commits/{a}/status") for x in seen), f"{got} {seen}")
        _GET_MEMO.clear()
        gql["mode"] = "ok"
        seen.clear()
        gh.open_prs()
        check("prefetch: outside planning_reads() no GraphQL query is sent", "POST /graphql" not in seen, str(seen))
        check("prefetch: a mismatched oid is not seeded", prefetch_payloads(commit(b), a) is None)
        check("prefetch: REST pages are 100 each with a short page last (an exact multiple gets an empty one)",
              [len(x) for x in rest_pages(list(range(250)))] == [100, 100, 50]
              and [len(x) for x in rest_pages(list(range(200)))] == [100, 100, 0] and rest_pages([]) == [[]])
        paged = commit(b, more=True)
        paged["checkSuites"]["nodes"][0]["id"] = "S1"
        extra_run = {"databaseId": 13, "name": "build (x)", "status": "COMPLETED", "conclusion": "FAILURE",
                     "detailsUrl": None, "url": None, "startedAt": None, "completedAt": None}
        got = prefetch_payloads(paged, b, {"S1": [extra_run]})
        check("prefetch: a suite's follow-up pages complete the head (and a red run on page 2 is kept)",
              got is not None and [r["name"] for r in got[0]][-1] == "build (x)" and got[0][-1]["conclusion"] == "failure",
              str(got))
        check("prefetch: a suite with a further page and no follow-up stays incomplete",
              prefetch_payloads(paged, b, {}) is None)
    finally:
        globals()["_http_open"] = saved[0]
        if saved[1] is None:
            os.environ.pop("GH_TOKEN", None)
        else:
            os.environ["GH_TOKEN"] = saved[1]
        _GET_MEMO.clear()
        _GET_MEMO.update(saved[2])
        API_STATS.clear()
        API_STATS.update(saved[3])


def self_test() -> int:
    fails: list[str] = []
    last_reservation: dict = {}   # ct / now / activity of the latest reservation_at, for a failing case's message
    ran: list[str] = []

    def check(label: str, cond: bool, detail: str = "") -> None:
        ran.append(label)
        if not cond:
            fails.append(f"{label}: {detail} [clock: time.time={time.time():.0f} last_reservation={last_reservation}]")

    retry_planner_self_test(check)
    train_turn_main_red_self_test(check)
    fix_preempts_strict_self_test(check)
    urgent_strict_self_test(check)
    selftest_skip_fix_self_test(check)
    selftest_deploy_fix(check)
    gate_level_fix_self_test(check)
    train_turn_fairness_self_test(check)
    branch_updater_self_test(check)
    prefetch_self_test(check)
    git_memo_self_test(check)
    packed_fixture_self_test(check)

    freshness = subprocess.run(
        [sys.executable, ".github/scripts/test-merge-train-main-red-freshness.py"],
        text=True, capture_output=True, timeout=15,
    )
    check("main-red freshness: actual settle/strict controller regressions", freshness.returncode == 0,
          freshness.stdout + freshness.stderr)

    # ---- qualifies -----------------------------------------------------------------------
    req = ["all-green", "Gitleaks", STATUS_CONTEXT]
    green = {"all-green": "success", "Gitleaks": "success"}
    base_pr = {"draft": False, "auto_merge": {"x": 1}, "same_repo": True, "head_ref": "feat/x", "state": "open",
               "files": ["openbank-fx-service/A.kt"]}
    check("qualifies: armed + green", qualifies(base_pr, req, green)[0])
    for label, over, checks in [("closed", {"state": "closed"}, green), ("draft", {"draft": True}, green),
                                ("unarmed", {"auto_merge": None}, green), ("codex/", {"head_ref": "codex/x"}, green),
                                ("fork", {"same_repo": False}, green), ("pending", {}, {**green, "Gitleaks": None}),
                                ("failure", {}, {**green, "Gitleaks": "failure"}), ("never reported", {}, {"all-green": "success"}),
                                ("agent-pr-guard", {}, {**green, "gates / agent-pr-guard": "failure"})]:
        check(f"qualifies: {label} refused", not qualifies({**base_pr, **over}, req, checks)[0])
    check("qualifies: no required set refused", not qualifies(base_pr, [], green)[0])
    real_regen = pathlib.Path(REGEN_INVENTORY).read_text() if pathlib.Path(REGEN_INVENTORY).exists() else ""
    real_refs = referenced_tests(Git(os.getcwd()), "HEAD") if pathlib.Path(".git").exists() else {"*"}
    U = Untrainable(real_regen, real_refs)
    check("referenced tests: derived from the real tree by one git grep (never the fail-closed sentinel)",
          "*" not in real_refs and len(real_refs) > 20, str(sorted(real_refs))[:200])
    # Must-fail control for the DERIVED mechanism: a test a workflow or gates.yaml names, that the static
    # PRIVILEGED list does not carry, is strict only because of the derived set — without it, it would ride.
    derived_only = sorted(r for r in real_refs if r not in PRIVILEGED_GATE_CODE and test_code(r))
    check("referenced tests: at least one referenced test is strict by derivation alone",
          bool(derived_only) and all(U(r) for r in derived_only)
          and not any(Untrainable(real_regen)(r) for r in derived_only[:3]), str(derived_only[:3]))
    real_srefs = referenced_scripts(Git(os.getcwd()), "HEAD") if pathlib.Path(".git").exists() else ({"*"}, set())
    check("referenced scripts: derived from the real tree (never the sentinel); run-gates.py and agent-admission.py ride alone",
          "*" not in real_srefs[0] and judge_path(".github/scripts/run-gates.py", real_srefs)
          and judge_path(".github/scripts/agent-admission.py", real_srefs)
          and judge_path(".github/scripts/ensure-admin-ui-deps.sh", real_srefs)
          and judge_path(".github/scripts/provision-gradle-distribution.sh", real_srefs), str(sorted(real_srefs[0]))[:200])
    check("referenced tests: an unreadable tree fails closed (every test-shaped path strict)",
          Untrainable(real_regen, {"*"})(".github/scripts/test-foo.py") and not Untrainable(real_regen, {"*"})(".github/scripts/check-foo.py"))
    check("untrainable: main's find enumeration is parsed", (U.find_root, U.find_name) ==
          ("openbank-infra/gitops/components", "gen-*opa-bundle*.sh"), f"{U.find_root} {U.find_name}")
    for f in (".github/scripts/regen-derived.sh", ".github/workflows/ci.yml", "docs/adr/gen-index.sh", "docs/adr/lib-frontmatter.sh",
              "openbank-infra/gitops/components/x/gen-x-opa-bundle.sh",
              "openbank-infra/gitops/components/a/b/c/d/gen-x-opa-bundle.sh"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: member touching {f} is refused (manual lane)", not ok and "manual lane" in why, why)
    # Anything under .github/ that can change what EXECUTES stays in the manual lane: code of any
    # extension, workflows/actions of any extension, gates.yaml (its run commands), pip requirement
    # pins (they choose what is installed), and agent prompts (they instruct an agent holding tools).
    for f in (".github/scripts/x.py", ".github/scripts/x.js", ".github/scripts/x.cjs", ".github/scripts/x.init.gradle",
              ".github/scripts/lib/probe.sh", ".github/workflows/y.yml", ".github/workflows/notes.md",
              ".github/workflows/requirements/schemathesis.txt", ".github/actions/a/action.yml",
              ".github/actions/a/README.md", ".github/scripts/pyyaml-requirements.txt",
              ".github/agent-prompts/pr-steward.md", ".github/CODEOWNERS", ".github/labels.yml",
              ".github/scripts/noext", "docs/adr/new.sh",
              # #13400: the train's own code and everything that judges a carrier or the merge
              # machinery stays strict, as does any .github path the allow-list does not name.
              ".github/scripts/merge-train.py", ".github/scripts/merge_train_carrier.py",
              ".github/workflows/merge-train.yml", ".github/workflows/security.yml",
              ".github/scripts/check-security-checklist.py", ".github/scripts/check-api-contract.py",
              ".github/scripts/check-codeql-compile-coverage.py", ".github/scripts/check-adr-registry.sh",
              ".github/scripts/check-eu-ai-act.sh", ".github/scripts/check-x.js", ".github/scripts/check-x",
              ".github/scripts/lib/check-x.sh", ".github/scripts/sub/check-x.py", ".github/gates/other.yaml",
              ".github/gates/gates.yml", ".github/dependabot.yml", ".github/unknown.json", ".github/x/y.cfg"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: member touching {f} is refused (manual lane)", not ok and "manual lane" in why, why)
    # Prose and gate-INPUT data under .github/ ride trains (ADR-0343 §Security: a baseline is read
    # by main's gate scripts in the train's CI exactly as in the PR's own CI).
    for f in (".github/CLAUDE.md", ".github/PULL_REQUEST_TEMPLATE.md",
              ".github/scripts/configproperty-kotlin-defaults-baseline.txt",
              ".github/gates/allow-all-pdp-exceptions.txt", ".github/scripts/gh-transient-patterns.txt"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: member touching only {f} is trainable", ok and not U(f), why)
    for f in ("openbank-libs/governance/rules.yaml", "docs/adr/0343-x.md", "openbank-infra/gitops/components/x/x.yaml"):
        check(f"untrainable: data file {f} is NOT untrainable", not U(f))
    # #13400: reviewed gate code rides a train. The carrier's CI runs the COMBINED head, so a gate
    # change is judged together with the code it judges exactly as in the strict lane, and bisect
    # isolates a culprit; what it may never do is share a train with a regeneration commit.
    for f in (".github/scripts/check-x.py", ".github/scripts/check-x.sh"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: a gate-code-only member ({f}) is a train CANDIDATE", ok and not U(f) and gate_code(f), why)
        sl = strict_lane_state({**base_pr, "files": [f]}, req, green, None, U, [], None, None)
        check(f"strict lane: a gate-code-only member ({f}) is NOT in the strict lane", sl[0] is None, str(sl))
    # #13837: gates.yaml DECLARES the privileged gates' run/selftest/mode/when/budget, so no
    # gates.yaml diff rides a train: each weakening shape is refused and lands in the strict lane.
    for shape in ("run of check-adr-registry.sh pointed at a no-op", "mode flipped enforced -> advisory",
                  "when narrowed to a path no PR touches", "privileged entry deleted", "budget_seconds changed"):
        f = ".github/gates/gates.yaml"
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: gates.yaml ({shape}) is refused (strict lane)",
              not ok and "manual lane" in why and U(f) and not gate_code(f), why)
        check(f"strict lane: gates.yaml ({shape}) IS in the strict lane",
              strict_lane_state({**base_pr, "files": [f]}, req, green, None, U, [], None, None)[0] == "green")
    # ADR-0343 amendment 2026-11-14: a pure APPEND of whole new gate entries rides a train; every other
    # gates.yaml shape keeps the strict lane. Each refused shape below is one the append rule must catch.
    base_g = "# header\ngates:\n  - id: g-one\n    run: |\n      true\n  - id: g-two\n    run: true\n"
    add = "  - id: g-new\n    mode: enforced\n    run: |\n      python3 .github/scripts/check-new.py --root .\n"
    check("gates append: a new entry at the end is a pure append", gates_append_problem(base_g, base_g + add) is None)
    mid = base_g.replace("  - id: g-two", add + "  - id: g-two")
    full = base_g + ("  - id: g-full\n    name: full\n    group: lint\n    mode: enforced\n    budget_seconds: 30\n"
                     "    selftest_inputs:\n      - .github/scripts/check-full.py\n    rationale: >-\n      why it exists\n"
                     "    run: |\n      # comment\n      python3 .github/scripts/check-full.py --root .\n"
                     "    selftest: python3 .github/scripts/test-check-full.py\n")
    check("gates append: a realistic new gate (block run, selftest, inputs, rationale) is a pure append",
          gates_append_problem(base_g, full) is None, f"{gates_append_problem(base_g, full)!r}")
    check("gates append: a new entry between two entries is a pure append", gates_append_problem(base_g, mid) is None)
    refused = {
        "an existing entry edited": base_g.replace("run: true", "run: 'true # weakened'") + add,
        "an existing entry removed": base_g.replace("  - id: g-two\n    run: true\n", "") + add,
        "entries reordered": "# header\ngates:\n  - id: g-two\n    run: true\n  - id: g-one\n    run: |\n      true\n" + add,
        "the header changed": base_g.replace("# header", "# header\nother: 1") + add,
        "a new id that already exists": base_g + "  - id: g-two\n    run: false\n",
        "a new id taken on main": base_g + "  - id: g-main\n    run: true\n",
        "a new entry defining an anchor": base_g + "  - id: g-a\n    run: &r true\n",
        "a new entry starting a top-level key": base_g + "  - id: g-b\n    run: true\nother: 1\n",
        "a line appended into an existing block scalar": base_g.replace("      true\n", "      true\n      exit 0\n"),
        "no change at all": base_g,
        "a quoted id duplicating an existing one": base_g + '  - id: "g-one"\n    run: python3 .github/scripts/check-a.py\n',
        "a second id key inside the new entry": base_g + "  - id: g-c\n    id: g-one\n    run: python3 .github/scripts/check-a.py\n",
        "a free shell line in run": base_g + "  - id: g-d\n    run: |\n      printf x > .github/scripts/check-adr-registry.sh\n",
        "a chained command in run": base_g + "  - id: g-e\n    run: python3 .github/scripts/check-a.py; rm -rf .\n",
        "a redirect argument": base_g + "  - id: g-f\n    run: python3 .github/scripts/check-a.py >out\n",
        "python3 -c": base_g + "  - id: g-g\n    run: python3 -c 'print(1)'\n",
        "a non-gate script": base_g + "  - id: g-h\n    run: python3 .github/scripts/regen-helper.py\n",
        "a selftest with free shell": base_g + "  - id: g-i\n    run: python3 .github/scripts/check-a.py\n    selftest: echo ok\n",
        "an env key": base_g + "  - id: g-j\n    env: {PYTHONPATH: x}\n    run: python3 .github/scripts/check-a.py\n",
        "an unknown key": base_g + "  - id: g-k\n    requires: [g-one]\n    run: python3 .github/scripts/check-a.py\n",
        "no run at all": base_g + "  - id: g-l\n    mode: enforced\n",
        "a path walking out of .github/scripts": base_g + "  - id: g-m\n    run: python3 .github/scripts/check-x/../../workflows/x.py\n",
        "a ./ segment": base_g + "  - id: g-n\n    run: python3 .github/scripts/./check-a.py\n",
        "bash on a .py": base_g + "  - id: g-o\n    run: bash .github/scripts/check-a.py\n",
    }
    for shape, new in refused.items():
        why = gates_append_problem(base_g, new, {"g-main"})
        check(f"gates append: {shape} is refused", why is not None, f"{why!r}")
    check("gates append: a missing file on either side is refused",
          gates_append_problem(None, base_g + add) is not None and gates_append_problem(base_g, None) is not None)
    ok, why = qualifies({**base_pr, "files": [GATES_YAML], "gates_append": True}, req, green, None, U)
    check("qualifies: a pure gates.yaml append is a train CANDIDATE", ok, why)
    check("strict lane: a pure gates.yaml append is NOT in the strict lane",
          strict_lane_state({**base_pr, "files": [GATES_YAML], "gates_append": True}, req, green, None, U, [], None, None)[0] is None)
    ok, why = qualifies({**base_pr, "files": [GATES_YAML], "gates_append": False}, req, green, None, U)
    check("qualifies: a gates.yaml change that is not a pure append stays manual lane", not ok and "manual lane" in why, why)
    # ...while an unrelated (non-privileged) gate's CODE change still rides a train.
    ok, why = qualifies({**base_pr, "files": [".github/scripts/check-unrelated.py"]}, req, green, None, U)
    check("qualifies: an unrelated gate's check script still rides a train (#13837 control)", ok, why)
    # #14888: test code under .github/ rides a train as gate code; a near-miss name, a test under an
    # untrainable prefix, a requirements pin and a test that exercises the train itself stay strict.
    for f in (".github/scripts/test-foo.py", ".github/scripts/test_bar.py", ".github/scripts/tests/test_x.py",
              ".github/scripts/e2e/tests/test-deep.py", ".github/scripts/lib/thing_test.py", ".github/tests/test_y.py"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: test code {f} rides a train (#14888)", ok and gate_code(f) and test_code(f) and not U(f), why)
        check(f"strict lane: test code {f} is NOT in the strict lane (#14888)",
              strict_lane_state({**base_pr, "files": [f]}, req, green, None, U, [], None, None)[0] is None)
    for f in (".github/scripts/testing.py", ".github/scripts/contest-x.py", ".github/workflows/tests/w.yml",
              ".github/actions/tests/test_a.py", ".github/scripts/test-requirements.txt",
              # security review: a non-test file under tests/ (importable by a privileged script) stays strict
              ".github/scripts/tests/conftest.py", ".github/scripts/tests/helpers.py", ".github/scripts/tests/__init__.py",
              ".github/scripts/tests/baz.py", ".github/scripts/e2e/tests/deep.sh", ".github/scripts/test-foo.sh",
              ".github/scripts/test-issue-hygiene.mjs", ".github/scripts/tests/test_codeql_scope_classifier.py",
              ".github/scripts/test-agent-pr-review.py", ".github/scripts/test-merge-authorization-proof.py",
              # review of #14891: tests other workflows run by name stay strict
              ".github/scripts/test-rerun-flake-artifact.py", ".github/scripts/test-admin-ui-request-trace.py",
              ".github/scripts/test-agent-admission.py",
              ".github/scripts/test-merge-train-carrier-lock.py", ".github/scripts/test-merge-train-owner-approval.py",
              ".github/scripts/test-merge-train-main-red-freshness.py", ".github/scripts/e2e/merge-train-gates-yaml.test.py"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: {f} is NOT test code that rides a train (#14888 control)", not ok and "manual lane" in why, why)
    for mix in ([".github/scripts/check-x.py", ".github/workflows/ci.yml"],
                [".github/gates/gates.yaml", ".github/scripts/merge-train.py"],
                [".github/scripts/check-x.py", ".github/unknown.json"]):
        ok, why = qualifies({**base_pr, "files": mix}, req, green, None, U)
        check(f"qualifies: a member mixing gate code with {mix[1]} is refused (strict lane)",
              not ok and "manual lane" in why, why)
        check(f"strict lane: a member mixing gate code with {mix[1]} IS in the strict lane",
              strict_lane_state({**base_pr, "files": mix}, req, green, None, U, [], None, None)[0] == "green")
    # Review: gate code never rides a train next to a symlink/gitlink (the strict lane refuses
    # those outright); one such member must not drag a whole carrier into bisect. A DATA-only
    # member with a symlink still reaches publish, which halves it (pL), as before.
    ok, why = qualifies({**base_pr, "files": [".github/scripts/check-x.py", "docs/l"], "special_paths": ["docs/l"]},
                        req, green, None, U)
    check("qualifies: gate code next to a symlink/gitlink is refused on the train path", not ok and "symlink" in why, why)
    check("qualifies: a data-only member with a symlink still qualifies (publish halves it)",
          qualifies({**base_pr, "files": ["docs/l"], "special_paths": ["docs/l"]}, req, green, None, U)[0])
    # Review: files that SUPPRESS security findings stay strict, wherever they live.
    for f in (".gitleaksignore", ".gitleaks.toml", ".trivyignore", ".semgrep/rules.yml", ".semgrep.yml",
              ".github/scripts/check-ruleset-bypass-actors.py", ".github/scripts/check-branch-protection.py"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: member touching {f} is refused (strict lane)", not ok and "manual lane" in why and U(f), why)
    # Drift guard on the REAL tree: every check script the train's own workflows or the pinned
    # extra gate run, every one that judges a carrier (imports merge_train_carrier) or the merge
    # machinery, and every one that proves a DERIVED_OUTPUTS entry must be in PRIVILEGED_GATE_CODE.
    scripts = pathlib.Path(".github/scripts")
    check("privileged gate code: the drift guard runs from the repository root (it never skips silently)",
          scripts.is_dir() and pathlib.Path(".github/workflows").is_dir(), str(pathlib.Path.cwd()))
    must: set[str] = set(FRESHNESS_GATE_CODE)
    # Every workflow that mentions the train or its carrier library, plus each pinned extra gate's
    # workflow: the check scripts they run decide a train's own verdict.
    extra_wfs = {pathlib.Path(w) for w in (parse_extra_gates(pathlib.Path(RULES_FILE).read_text()) or {}).values()} \
        if pathlib.Path(RULES_FILE).exists() else set()
    test_ref = r"\.github/scripts/(?:[A-Za-z0-9_.-]+/)*(?:test[-_][A-Za-z0-9_.-]*\.py|[A-Za-z0-9_.-]+_test\.py)"
    for wf in sorted(pathlib.Path(".github/workflows").glob("*.y*ml")) if scripts.is_dir() else []:
        text = wf.read_text(errors="replace")
        if wf in extra_wfs or re.search(r"merge_train_carrier|merge-train", text):
            must |= set(re.findall(r"\.github/scripts/(?:[A-Za-z0-9_.-]+/)*check-[A-Za-z0-9_.-]+", text))
        # Any test a WORKFLOW runs by name is executed with that workflow's permissions (review of #14891:
        # auto-retry-cancelled.yml, admin-ui-deploy.yml, agent-*.yml): it stays strict, whatever the workflow.
        must |= set(re.findall(test_ref, text))
    # ...and any test gates.yaml names in a `selftest:` or `run:` field: part of a gate's own verdict.
    gates_decl = pathlib.Path(GATES_YAML)
    if gates_decl.is_file():
        must |= set(re.findall(test_ref, gates_decl.read_text(errors="replace")))
    for c in sorted([*scripts.glob("check-*"), *scripts.glob("test-*"), *scripts.glob("test_*")]) if scripts.is_dir() else []:
        if c.is_file() and re.search(r"merge_train_carrier|merge-train|bypass_actors|branches/[^/\s]*/protection|/rulesets",
                                     c.read_text(errors="replace")):
            must.add(c.as_posix())
    # A test a PRIVILEGED script names or imports is part of that script's verdict: it stays strict too.
    for priv in PRIVILEGED_GATE_CODE:
        pp = pathlib.Path(priv)
        if pp.is_file():
            must |= {m for m in re.findall(r"\.github/scripts/(?:[A-Za-z0-9_.-]+/)*(?:test[-_][A-Za-z0-9_.-]+|[A-Za-z0-9_.-]+_test\.py)",
                                           pp.read_text(errors="replace"))}
            must |= {f".github/scripts/{m}" for m in re.findall(r"with_name\('((?:test[-_][A-Za-z0-9_.-]+|[A-Za-z0-9_.-]+_test)\.py)'\)",
                                                                   pp.read_text(errors="replace"))}
    missing = sorted(m for m in must if gate_code(m) and not U(m))
    check("privileged gate code: every check script the train, its extra gate or a carrier/ruleset verdict depends on stays strict",
          scripts.is_dir() and not missing, str(missing))
    for f in ("docs/a\nb.md", "svc/tab\there.txt", "svc/esc\x1b.txt", "svc/del\x7f.txt"):
        ok, why = qualifies({**base_pr, "files": [f]}, req, green, None, U)
        check(f"qualifies: a DATA path with a control character {f!r} is refused", not ok and "control character" in why, why)
    check("untrainable: an unparsable runner fails closed (any gen-* at any depth)",
          Untrainable("")("openbank-infra/gitops/a/b/c/d/gen-x-opa-bundle.sh") and Untrainable("")("x/y/z/gen-q.py"))
    # ---- #13400: a gate red only for its budget / NOT EVALUATED is inconclusive ---------------
    def recs(*kinds):
        return [{"id": f"g{i}", "status": "failed" if k else "ok", "failure_kind": k} for i, k in enumerate(kinds)]
    for label, jobs, records, want in [
        ("budget only", ["gates (lint-x)", "Validate manifests"], {"lint-x": recs("budget", None)}, True),
        ("not evaluated + budget", ["gates (a)", "gates (b)"], {"a": recs("not_evaluated"), "b": recs("budget")}, True),
        ("content next to budget", ["gates (a)"], {"a": recs("budget", "content")}, False),
        ("unfalsified", ["gates (a)"], {"a": [{"id": "x", "status": "unfalsified", "failure_kind": "unfalsified"}]}, False),
        ("pre-#13400 record (no failure_kind)", ["gates (a)"], {"a": [{"id": "x", "status": "failed"}]}, False),
        ("artifact unreadable", ["gates (a)"], {"a": None}, False),
        ("artifact missing", ["gates (a)"], {}, False),
        ("a non-gate job failed too", ["gates (a)", "derived"], {"a": recs("budget")}, False),
        ("aggregate alone", ["Validate manifests"], {}, False),
        ("shard red with no failed record", ["gates (a)"], {"a": recs(None)}, False),
    ]:
        got, why = gate_failures_inconclusive(jobs, records)
        check(f"gate verdict: {label} -> {'inconclusive' if want else 'conclusive'}", got is want, why)

    # A GitHub rerun keeps attempt-1 artifacts under the same workflow run id. The failing
    # attempt-2 job may be a content failure even when attempt 1 wrote a budget-only verdict.
    original_api, original_paginate, original_artifact_json = api, paginate, GitHub.artifact_json
    try:
        run = 123
        attempt = 2
        artifacts = [{"id": 10, "name": "gate-results-data-a1", "expired": False}]
        jobs = [{"name": "gates (data)", "conclusion": "failure", "run_attempt": attempt}]
        def fixture_api(method, path, body=None):
            return (200, {"run_attempt": attempt}) if path.endswith(f"/actions/runs/{run}") else (404, {})
        def fixture_paginate(path, key=None):
            if path.endswith("/check-runs"):
                return [{"name": "gates (data)", "id": 20,
                         "details_url": f"https://github.com/x/y/actions/runs/{run}/job/20"}]
            if path.endswith("/jobs?filter=latest"):
                return jobs
            if path.endswith("/artifacts"):
                return artifacts
            raise AssertionError(path)
        globals()["api"], globals()["paginate"] = fixture_api, fixture_paginate
        GitHub.artifact_json = lambda self, artifact_id: [
            {"id": "g", "status": "failed", "failure_kind": "budget"}]
        gh_attempt = GitHub("x/y", "main", "")
        got, why = gh_attempt.failures_inconclusive("head", ["gates (data)"])
        check("attempt evidence: old budget artifact cannot excuse a new red shard", not got and "unreadable" in why, why)
        artifacts.append({"id": 11, "name": "gate-results-data-a2", "expired": False})
        got, why = gh_attempt.failures_inconclusive("head", ["gates (data)"])
        check("attempt evidence: exact current attempt is accepted", got and "budget" in why, why)
        jobs[0]["run_attempt"] = 1
        got, why = gh_attempt.failures_inconclusive("head", ["gates (data)"])
        check("attempt evidence: stale failing job is rejected", not got and "not from attempt" in why, why)
    finally:
        globals()["api"], globals()["paginate"] = original_api, original_paginate
        GitHub.artifact_json = original_artifact_json

    # ---- inconclusive is never red; legacy culprit marks are re-evaluated -----------------
    rq = ["gates (data)", "derived", "sec"]
    f, pnd, inc = classify_carrier({"gates (data)": "success", "derived": "success", "sec": "cancelled"}, rq)
    check("classify: a cancelled context is inconclusive, not failing", f == [] and inc == ["sec"] and pnd == [], f"{f} {inc}")
    f, pnd, inc = classify_carrier({"gates (data)": "failure", "derived": "success", "sec": "cancelled"}, rq)
    check("classify: failure + cancelled -> only the real failure is failing", f == ["gates (data)"] and inc == ["sec"], f"{f} {inc}")
    f, pnd, inc = classify_carrier({"gates (data)": "skipped", "derived": "success", "sec": "cancelled"}, rq)
    check("classify: skipped next to a cancellation is inconclusive", f == [] and set(inc) == {"gates (data)", "sec"}, f"{f} {inc}")
    f, pnd, inc = classify_carrier({"gates (data)": "skipped", "derived": "success", "sec": "success"}, rq)
    check("classify: skipped with no cancellation keeps its old meaning (failing)", f == ["gates (data)"] and inc == [], f"{f} {inc}")
    f, pnd, inc = classify_carrier({"gates (data)": "stale", "derived": None, "sec": "success"}, rq)
    check("classify: stale is inconclusive, a pending context is pending", f == [] and inc == ["gates (data)"] and pnd == ["derived"])
    check("culprit description carries the prefix and the failing contexts",
          culprit_description(["gates (data)"], "a" * 40) == "culprit: gates (data) red on a train over main aaaaaaaaaaaa")

    # ---- likely flake (#15420): one rerun before blaming a lone member green on its head and on main ----
    class _FlakeGH:
        def __init__(self, head, main, marked=False, ok=True):
            self.head, self.main, self.ok, self.reruns, self.posted = head, main, ok, [], []
            self.marks = {RERUN_CONTEXT: ("success", "rerun 1 of 1")} if marked else {}
        def app_statuses(self, sha): return self.marks if sha == "carrier" else {}
        def checks(self, sha): return self.head if sha == "head" else self.main
        def extra_checks(self, sha, gates): return {g: self.head.get(g) for g in gates} if sha == "head" else {}
        def rerun_inconclusive(self, sha, contexts):
            self.reruns.append((sha, list(contexts)))
            return self.ok
        def post_status(self, sha, state, desc, context=STATUS_CONTEXT, **_kw): self.posted.append((sha, state, context))

    class _FlakeOut:
        stdout = "m1\n"

    def flake(head, main, failing=("gates (data)",), extra=None, **kw):
        fgh = _FlakeGH(head, main, **kw)
        why = likely_flake_rerun(fgh, lambda *a, **k: _FlakeOut(), "carrier", list(failing), "head", "m1" * 20, extra)
        return why, fgh

    fgreen = {"gates (data)": "success", "Trivy": "success"}
    why, fgh = flake(fgreen, fgreen)
    check("flake: a lone member green on its head and on main -> ONE rerun of exactly the failing contexts, marked",
          why is not None and fgh.reruns == [("carrier", ["gates (data)"])]
          and fgh.posted == [("carrier", "success", RERUN_CONTEXT)], f"{why} {fgh.reruns} {fgh.posted}")
    why, fgh = flake({**fgreen, "gates (data)": "failure"}, fgreen)
    check("flake: red on the member's OWN head -> no rerun (blame as today)", why is None and fgh.reruns == [], str(fgh.reruns))
    why, fgh = flake({**fgreen, "gates (data)": None}, fgreen)
    check("flake: pending/absent on the member head is not green -> no rerun", why is None and fgh.reruns == [])
    why, fgh = flake(fgreen, {**fgreen, "gates (data)": "failure"})
    check("flake: red on main at the carrier base -> no rerun", why is None and fgh.reruns == [], str(fgh.reruns))
    why, fgh = flake(fgreen, {"Trivy": "success"})
    check("flake: no verdict on main at all -> no rerun (unknown is not green)", why is None and fgh.reruns == [])
    why, fgh = flake(fgreen, fgreen, marked=True)
    check("flake: a carrier head already re-run once (either kind) -> never a second rerun",
          why is None and fgh.reruns == [] and fgh.posted == [], str(fgh.reruns))
    why, fgh = flake(fgreen, fgreen, ok=False)
    check("flake: a refused rerun posts no marker and blames as today", why is None and fgh.posted == [], str(fgh.posted))
    why, fgh = flake(fgreen, fgreen, failing=("gates (data)", "Trivy"), extra={"Trivy": "security.yml"})
    check("flake: an extra gate is judged by its pinned run on the head", why is not None, str(why))
    why, fgh = flake({**fgreen, "Trivy": "failure"}, fgreen, failing=("Trivy",), extra={"Trivy": "security.yml"})
    check("flake: an extra gate red on the head -> no rerun", why is None and fgh.reruns == [])
    legacy = {STATUS_CONTEXT: ("failure", "isolated as the cause of a red train over main 0123456789ab")}
    check("qualifies: a LEGACY culprit mark (pre-inconclusive rule) is re-evaluated, not final",
          qualifies({**base_pr, "files": ["svc/a"]}, req, green, legacy)[0])
    check("qualifies: a new-format culprit mark is final until a push",
          not qualifies({**base_pr, "files": ["svc/a"]}, req, green,
                        {STATUS_CONTEXT: ("failure", culprit_description(["x"], "b" * 40))})[0])
    check("qualifies: a manual-lane failure stays final",
          not qualifies({**base_pr, "files": ["svc/a"]}, req, green,
                        {STATUS_CONTEXT: ("failure", "not verifiable by the merge train: manual lane")})[0])
    check("qualifies: an App failure (culprit) on the head waits for a push",
          not qualifies(base_pr, req, green, {STATUS_CONTEXT: ("failure", "x")})[0])
    for desc in (f"{CONFLICT_PREFIX}{'b' * 12}: merge main into the branch", f"{REFUSED_PREFIX}{'b' * 12}: merge main into the branch"):
        check(f"qualifies: a notice ({desc[:20]}...) is information, not a verdict: the head still qualifies",
              qualifies(base_pr, req, green, {STATUS_CONTEXT: ("failure", desc)})[0])
    check("order: oldest first", [p["number"] for p in order_candidates(
        [{"number": 9, "created_at": "2026-02"}, {"number": 3, "created_at": "2026-01"}])] == [3, 9])
    check("order: an expedited PR goes first, then oldest first", [p["number"] for p in order_candidates(
        [{"number": 9, "created_at": "2026-02"}, {"number": 3, "created_at": "2026-01"},
         {"number": 7, "created_at": "2026-03", "labels": [{"name": EXPEDITE_LABEL}]}])] == [7, 3, 9])
    check("order: another label is not priority", [p["number"] for p in order_candidates(
        [{"number": 9, "created_at": "2026-02", "labels": [{"name": "merge-priority:repair"}]},
         {"number": 3, "created_at": "2026-01"}])] == [3, 9])

    # ---- paths / fast lane / batch ---------------------------------------------------------
    check("glob: `*` does not cross `/`", glob_match("a/*-opa-bundle.yaml", "a/x-opa-bundle.yaml")
          and not glob_match("a/*-opa-bundle.yaml", "a/b/x-opa-bundle.yaml"))
    real = pathlib.Path(REGEN_INVENTORY).read_text() if pathlib.Path(REGEN_INVENTORY).exists() else ""
    outs = derived_output_patterns(real)
    check("inventory: DERIVED_OUTPUTS parsed from the real regen-derived.sh", "docs/adr/index.json" in outs, str(outs))
    check("inventory: no Rollout manifest is a derived output",
          not any(glob_match(g, "openbank-infra/gitops/components/ledger/ledger-service.yaml") for g in outs))
    frags = regen_inventory_fragments(real)
    check("fast lane: disjoint service file qualifies", fast_lane_eligible(["svc/a.kt"], ["other/x"], [], frags)[0])
    for f in ("docs/adr/0343-x.md", "openbank-fx-service/src/main/resources/openapi.yaml", ".github/x.yml",
              "build-logic/x.kts", "prompts/registry.yaml"):
        check(f"fast lane: {f} does NOT qualify", not fast_lane_eligible([f], [], [], frags)[0])
    check("fast lane: overlap with main or the batch does NOT qualify",
          not fast_lane_eligible(["a"], ["a"], [], frags)[0] and not fast_lane_eligible(["a"], [], ["a"], frags)[0])
    mk = lambda *ns: [Member(n, "", "", "a" * 40, "", "") for n in ns]  # noqa: E731
    check("batch: default size", [m.number for m in select_batch(mk(1, 2, 3), {}, 2)] == [1, 2])
    check("batch: a bisect size on an applied member caps it", batch_cap(mk(1, 2, 3, 4), {1: 2}, 8) == 2)
    # NEGATIVE first (2026-10-25, #13801..#13817): halving posted `bisect size 2` on the carrier's
    # members, but the oldest candidate (#13697, dropped by every build) carried none.
    check("batch: a bisect size on a NON-oldest applied member still caps (oldest never rides)",
          batch_cap(mk(2, 3, 4), {2: 2, 3: 2}, 8) == 2)
    check("batch: the smallest bisect size among applied members wins", batch_cap(mk(2, 3), {2: 2, 3: 1}, 8) == 1)
    # ...and a DROPPED candidate's size never counts (review of #13840): #1 carries 1 and never applies.
    check("batch: a dropped candidate's bisect size does not pin the train", batch_cap(mk(2, 3), {1: 1}, 8) == 8)
    check("batch: the window is the default size; the cap bounds APPLIED members, not candidates",
          [m.number for m in select_batch(mk(1, 2, 3, 4), {1: 2}, 3)] == [1, 2, 3])
    check("bisect status: only a pending `bisect size N` counts",
          bisect_size({STATUS_CONTEXT: ("pending", "bisect size 2")}) == 2
          and bisect_size({STATUS_CONTEXT: ("success", "bisect size 2")}) is None
          and bisect_size({STATUS_CONTEXT: ("pending", "bisect size 2; rm -rf")}) is None)

    # ---- branch names ----------------------------------------------------------------------
    check("branch: derived from the run", train_branch("123", "1") == "train/123-1")
    for hostile in ("refs/heads/main", "../x", "main", "train/1-1/../main", "train/abc-1", "train/1-1.lock", "train/-1"):
        try:
            assert_train_branch(hostile)
            refused = False
        except ValueError:
            refused = True
        check(f"branch: {hostile!r} refused", refused)
    calls: list[tuple] = []

    def rec_git(*a, check=True, auth=False):
        calls.append(a)
        return subprocess.CompletedProcess(a, 0, "", "")
    try:
        Pusher(rec_git, "refs/heads/main", "u")
        built = True
    except ValueError:
        built = False
    p_ok = Pusher(rec_git, "train/7-1", "u")
    p_ok.push("a" * 40)
    p_ok.delete()
    check("branch: only refs/heads/train/7-1 is ever pushed or deleted",
          not built and calls == [("push", "-q", "-f", "u", "a" * 40 + ":refs/heads/train/7-1"),
                                  ("push", "-q", "u", "--delete", "refs/heads/train/7-1")], str(calls))

    # ---- settle record ---------------------------------------------------------------------
    t1, t2 = "a" * 40, "b" * 40
    check("record: App record with the commit's tree is accepted", record_problem(f"tree={t1}", BOT_LOGIN, t1) is None)
    check("record: a sha whose tree differs from the record is refused",
          "not the recorded tree" in (record_problem(f"tree={t1}", BOT_LOGIN, t2) or ""))
    check("record: a record by any other creator is refused", record_problem(f"tree={t1}", "someone", t1) is not None)
    check("record: a malformed record is refused", record_problem(f"tree={t1} members=1", BOT_LOGIN, t1) is not None)
    check("comments: fixed texts carry no placeholders", "{" not in DROP_MESSAGE + CULPRIT_MESSAGE + STALE_CULPRIT_MESSAGE + MANUAL_LANE_MESSAGE
          + EXTRA_GATE_MESSAGE)

    # ---- main history API budget: use the real checks + pagination over canned GETs ---------
    history = [f"{i:040x}" for i in range(STALE_RED_WALK)]
    budget_reads: list[str] = []
    history_results: dict[str, dict] = {}
    budget_required = [f"required-{i}" for i in range(8)]
    budget_rules = "merge_train:\n  extra_gates:\n    - {workflow: .github/workflows/security.yml, check: Trivy}\n"

    def budget_git(*args, **kwargs):
        return subprocess.CompletedProcess(args, 0, "\n".join(history) if args[0] == "rev-list" else budget_rules, "")

    def budget_get(path):
        budget_reads.append(path)
        sha = path.split("/commits/", 1)[1].split("/", 1)[0]
        if "/check-runs?" in path:
            # A full page forces real paginate() to fetch the second page. Relevant contexts
            # deliberately live there, so a page-one-only optimization cannot pass this test.
            if path.endswith("page=1"):
                return {"check_runs": [{"id": i, "name": f"unrelated-{i}", "status": "completed",
                                        "conclusion": "success"} for i in range(100)]}
            return {"check_runs": [{"id": 100 + i, "name": name, "status": "completed",
                                    "conclusion": state} for i, (name, state) in
                                   enumerate(history_results.get(sha, {}).items())]}
        return {"statuses": []}

    saved_get = globals()["get"]
    try:
        globals()["get"] = budget_get
        budget_gh = GitHub("o/r", "main", "")
        got = main_red_contexts(budget_gh, budget_git, budget_required, history[0])
        check("main history: nine absent contexts fetch each commit once, including every check page",
              got == {} and len(budget_reads) == 3 * STALE_RED_WALK
              and len(set(budget_reads)) == len(budget_reads), str(len(budget_reads)))
        # Pending/cancelled results do not hide a nearest completed failure. A later historical
        # failure must not override a nearer success, and the extra gate participates too.
        history_results.update({history[0]: {"required-0": None, "Trivy": "cancelled"},
                                history[3]: {"required-0": "failure", "Trivy": "failure"},
                                history[4]: {"required-1": "success"},
                                history[6]: {"required-1": "failure"}})
        budget_reads.clear()
        supplied_cache: dict = {}
        got = main_red_contexts(budget_gh, budget_git, budget_required, history[0], supplied_cache)
        check("main history: shared reads preserve nearest completed failures and extra gates",
              got == {"required-0": history[3], "Trivy": history[3]}
              and len(budget_reads) == 3 * STALE_RED_WALK, str(got))
        check("main history: caller's initially empty cache is populated and reused",
              len(supplied_cache) == STALE_RED_WALK
              and main_red_contexts(budget_gh, budget_git, budget_required, history[0], supplied_cache) == got
              and len(budget_reads) == 3 * STALE_RED_WALK)
        history_results[history[0]] = {"required-0": "success", "Trivy": "success"}
        budget_reads.clear()
        check("main history: a new evaluation rereads mutable checks, never reuses a prior verdict",
              main_red_contexts(budget_gh, budget_git, budget_required, history[0]) == {}
              and len(budget_reads) == 3 * STALE_RED_WALK)

        def denied_get(path):
            raise SystemExit("GET denied: API rate limit exceeded")

        globals()["get"] = denied_get
        refused = False
        try:
            main_red_contexts(budget_gh, budget_git, budget_required, history[0])
        except SystemExit:
            refused = True
        check("main history: unreadable checks still abort, never become a clean verdict", refused)
    finally:
        globals()["get"] = saved_get

    # ---- extra gates (merge_train.extra_gates) -------------------------------------------------
    decl = ("a: 1\nmerge_train:\n  # why\n  extra_gates:\n    - {workflow: .github/workflows/security.yml, check: Trivy}\n"
            "    - {workflow: .github/workflows/security.yml, check: \"CodeQL\"}  # c\nnext: 2\n")
    want = {"Trivy": ".github/workflows/security.yml", "CodeQL": ".github/workflows/security.yml"}
    check("extra gates: the rules.yaml block list is parsed (name -> pinned workflow)", parse_extra_gates(decl) == want,
          str(parse_extra_gates(decl)))
    for label, text in [("absent", "a: 1\n"), ("empty", "merge_train:\n  extra_gates: []\n"),
                        ("other key only", "merge_train:\n  batch: 8\n"),
                        ("an unpinned item", "merge_train:\n  extra_gates:\n    - Trivy\n"),
                        ("one malformed item among good ones", "merge_train:\n  extra_gates:\n"
                         "    - {workflow: .github/workflows/security.yml, check: Trivy}\n    - {check: X}\n")]:
        check(f"extra gates: {label} declaration parses as None", parse_extra_gates(text) is None, str(parse_extra_gates(text)))
    xg = {"Trivy": ".github/workflows/security.yml"}
    # The REAL GitHub.extra_checks over canned API pages: a spoofed green from another app and a later
    # green from another workflow must neither mask the Security scan red nor count on their own.
    def _runs(*specs):
        return [{"id": i, "name": "Trivy", "status": "completed", "conclusion": c, "app": {"slug": slug},
                 "details_url": f"https://github.com/o/r/actions/runs/{run}/job/{i}"} for i, (c, slug, run) in enumerate(specs)]
    paths = {1: ".github/workflows/security.yml", 2: ".github/workflows/evil.yml"}
    saved_api = (globals()["paginate"], globals()["get"])
    try:
        for label, page, want in [
                ("pinned red + later spoof green (other app)", _runs(("failure", "github-actions", 1), ("success", "evil-app", 1)), "failure"),
                ("pinned red + later green (other workflow)", _runs(("failure", "github-actions", 1), ("success", "github-actions", 2)), "failure"),
                ("only a spoofed green: absent, not green", _runs(("success", "evil-app", 1), ("success", "github-actions", 2)), "absent"),
                ("pinned green", _runs(("success", "github-actions", 1)), "success")]:
            globals()["paginate"] = lambda path, key=None, _p=page: _p if key == "check_runs" else []
            globals()["get"] = lambda path: {"path": paths[int(path.rsplit("/", 1)[1])] + "@refs/heads/x"}
            got = GitHub("o/r", "main", "").extra_checks("a" * 40, {"Trivy": ".github/workflows/security.yml"})
            check(f"extra gates (GitHub.extra_checks): {label}", got.get("Trivy", "absent") == want, str(got))
        # No pinned check run: n/a ONLY when the pinned workflow has a COMPLETED run for this head.
        def _wf(*specs):
            return [{"id": 10 + i, "path": f"{p}@refs/heads/x", "status": st, "head_sha": "a" * 40,
                     "conclusion": (c[0] if c else ("success" if st == "completed" else None))}
                    for i, (p, st, *c) in enumerate(specs)]
        sec, evil = ".github/workflows/security.yml", ".github/workflows/evil.yml"
        for label, wruns, want in [
                ("absent, no workflow run at all: absent (pending)", _wf(), "absent"),
                ("absent, pinned workflow still running: absent (pending)", _wf((sec, "in_progress")), "absent"),
                ("absent, only ANOTHER workflow completed: absent (pending)", _wf((evil, "completed")), "absent"),
                ("absent, pinned run completed + a rerun queued: absent (pending)", _wf((sec, "completed"), (sec, "queued")), "absent"),
                ("absent, pinned workflow COMPLETED without the job: skipped (n/a)", _wf((sec, "completed")), "skipped"),
                # #13400 fail closed: absent is n/a ONLY over pinned runs that all concluded SUCCESS.
                ("absent, pinned run CANCELLED: pending, never n/a", _wf((sec, "completed", "cancelled")), None),
                ("absent, pinned run TIMED OUT: pending", _wf((sec, "completed", "timed_out")), None),
                ("absent, pinned run STARTUP_FAILURE: pending", _wf((sec, "completed", "startup_failure")), None),
                ("absent, pinned run ACTION_REQUIRED: pending", _wf((sec, "completed", "action_required")), None),
                ("absent, pinned run FAILED: red", _wf((sec, "completed", "failure")), "failure"),
                ("absent, one success + one failed pinned run: red", _wf((sec, "completed"), (sec, "completed", "failure")), "failure"),
                ("absent, one success + one cancelled pinned run: pending", _wf((sec, "completed"), (sec, "completed", "cancelled")), None)]:
            globals()["paginate"] = lambda path, key=None, _w=wruns: _w if key == "workflow_runs" else []
            got = GitHub("o/r", "main", "").extra_checks("a" * 40, {"Trivy": sec})
            check(f"extra gates (GitHub.extra_checks): {label}", got.get("Trivy", "absent") == want, str(got))
            if want == "skipped":
                check("extra gates: absent but the pinned run completed without it is served",
                      qualifies(base_pr, req, {**green, **got}, extra=xg)[0])
                own = {**base_pr, "files": [sec]}
                check("extra gates: absent + the PR changes the pinned workflow is RED even over a successful run",
                      qualifies(own, req, {**green, **got}, untrainable=lambda _f: False, extra=xg)
                      == (False, "extra gate red: Trivy (the PR changes the extra gate's own workflow)"),
                      str(qualifies(own, req, {**green, **got}, untrainable=lambda _f: False, extra=xg)))
                check("extra gates: strict lane refuses an absent gate whose own workflow the PR changes",
                      strict_lane_state(own, req, {**green, **got}, None, U, [], None, xg)[0] is None)
                check("extra gates: a PRESENT green gate is served though the PR changes its workflow (strict lane)",
                      strict_lane_state(own, req, {**green, "Trivy": "success"}, None, U, [], None, xg)[0] == "green")
                cks = own_workflow_checks({**green, **got}, xg, [sec, "x.kt"])
                check("extra gates: a carrier whose member changes the pinned workflow is failing on an absent gate",
                      "Trivy" in classify_carrier(cks, carrier_contexts(req, xg, cks))[0], str(cks))
                cks = own_workflow_checks({**green, **got}, xg, None)
                check("extra gates: a carrier whose diff cannot be read holds an absent gate as pending",
                      "Trivy" in classify_carrier(cks, carrier_contexts(req, xg, cks))[1], str(cks))
                cks = own_workflow_checks({**green, **got}, xg, ["x.kt"])
                check("extra gates: a carrier not touching the pinned workflow keeps the n/a",
                      "Trivy" not in sum(classify_carrier(cks, carrier_contexts(req, xg, cks)), []), str(cks))
            elif want is None:
                check(f"extra gates: {label} is not served", qualifies(base_pr, req, {**green, **got}, extra=xg)
                      == (False, "extra gate pending: Trivy"), str(qualifies(base_pr, req, {**green, **got}, extra=xg)))
            elif want == "failure":
                check(f"extra gates: {label} refuses", qualifies(base_pr, req, {**green, **got}, extra=xg)
                      == (False, "extra gate red: Trivy"))
    finally:
        globals()["paginate"], globals()["get"] = saved_api
    check("extra gates: one red pinned run beats a later green one", extra_verdict(["failure", "success"]) == "failure")
    check("extra gates: pinned running waits, skipped alone is n/a",
          extra_verdict(["success", None]) is None and extra_verdict(["skipped"]) == "skipped")
    check("extra gates: red Trivy refuses (any lane reads qualifies)",
          qualifies(base_pr, req, {**green, "Trivy": "failure"}, extra=xg) == (False, "extra gate red: Trivy"))
    check("extra gates: without the declaration a red Trivy is not judged (the negative control)",
          qualifies(base_pr, req, {**green, "Trivy": "failure"})[0])
    check("extra gates: running Trivy waits", qualifies(base_pr, req, {**green, "Trivy": None}, extra=xg)
          == (False, "extra gate pending: Trivy"))
    # Fail closed (#13400): absent on the head is PENDING — Security scan has no path filter, so "absent"
    # almost always means "not reported yet". Only GitHub.extra_checks may turn absence into n/a.
    check("extra gates: Trivy absent with no completed pinned run is PENDING, not served",
          qualifies(base_pr, req, green, extra=xg) == (False, "extra gate never reported: Trivy"))
    check("extra gates: strict lane reads an absent Trivy as pending",
          strict_lane_state({**base_pr, "files": [".github/workflows/x.yml"]}, req, green, None, U, [], None, xg)[0] == "pending")
    check("extra gates: a carrier with an absent Trivy is not judged green (pending)",
          "Trivy" in classify_carrier(green, carrier_contexts(req, xg, green))[1])
    check("extra gates: a carrier with a red Trivy is failing",
          "Trivy" in classify_carrier({**green, "Trivy": "failure"}, carrier_contexts(req, xg, {**green, "Trivy": "failure"}))[0])
    check("extra gates: skipped Trivy is not applicable", qualifies(base_pr, req, {**green, "Trivy": "skipped"}, extra=xg)[0])
    check("extra gates: green Trivy is served", qualifies(base_pr, req, {**green, "Trivy": "success"}, extra=xg)[0])
    check("extra gates: a required failure is still reported as such",
          qualifies(base_pr, req, {**green, "Gitleaks": "failure", "Trivy": "failure"}, extra=xg)[1]
          == "required context failure: Gitleaks")
    wf = {**base_pr, "files": [".github/workflows/x.yml"]}
    check("extra gates: strict lane refuses a red Trivy",
          strict_lane_state(wf, req, {**green, "Trivy": "failure"}, None, U, [], None, xg)[0] is None)
    check("extra gates: strict lane WAITS when Trivy is red on main too",
          strict_lane_state(wf, req, {**green, "Trivy": "failure"}, None, U, [], {"Trivy": "c" * 40}, xg)[0] == "waiting")
    check("extra gates: strict lane reads a running Trivy as pending",
          strict_lane_state(wf, req, {**green, "Trivy": None}, None, U, [], None, xg)[0] == "pending")

    # ---- admission prerequisites (#14684) -------------------------------------------------
    # Unit: the exit-code contract, fail closed. Every must-FAIL case comes first.
    av = {"head_sha": "a" * 40, "body": ""}
    gd = type("G", (), {"workdir": "."})()
    check("admission: gate exit 1 refuses", admission_refusal(gd, "b" * 40, av, lambda c: 1) is not None)
    for rc in (2, 124, -9):
        check(f"admission: gate exit {rc} refuses (fail closed)", admission_refusal(gd, "b" * 40, av, lambda c, rc=rc: rc) is not None)

    def boom(c):
        raise subprocess.TimeoutExpired(c, 120)
    check("admission: a gate that cannot run refuses (fail closed)", admission_refusal(gd, "b" * 40, av, boom) is not None)
    check("admission: no verified head refuses", admission_refusal(gd, "b" * 40, {"head_sha": "HEAD", "body": ""}, lambda c: 0) is not None)
    seen: list = []
    check("admission: exit 0 admits", admission_refusal(gd, "b" * 40, {**av, "body": "$(touch pwn) --self-test"},
                                                        lambda c: seen.append(c) or 0) is None)
    check("admission: the body never reaches argv", seen and not any("pwn" in a or a == "--self-test" for a in seen[0]), str(seen))
    check("admission: runs the train's own gate script, not the PR's",
          seen and seen[0][2] == str(CHECKLIST_GATE) and CHECKLIST_GATE.is_file(), str(seen))
    # Integration: the REAL gate script over a real repository, money-path vs not, body unticked vs ticked.
    with tempfile.TemporaryDirectory() as adm:
        env = base_env()

        def ag(*a):
            return subprocess.run(["git", *a], cwd=adm, text=True, capture_output=True, check=True, env=env).stdout.strip()
        ag("init", "-q", "-b", "main")
        pathlib.Path(adm, RULES_FILE).parent.mkdir(parents=True)
        pathlib.Path(adm, RULES_FILE).write_text(SYN_RULES)
        pathlib.Path(adm, "paysvc/src/main").mkdir(parents=True)
        pathlib.Path(adm, "paysvc/src/main/Pay.kt").write_text("class Pay\n")
        ag("add", "-A")
        ag("commit", "-q", "-m", "base")
        abase = ag("rev-parse", "HEAD")
        pathlib.Path(adm, "paysvc/src/main/Pay.kt").write_text("class Pay(val amount: Long)\n")
        ag("commit", "-qam", "money")
        money = ag("rev-parse", "HEAD")
        ag("checkout", "-q", abase)
        pathlib.Path(adm, "docs").mkdir()
        pathlib.Path(adm, "docs/x.md").write_text("x\n")
        ag("add", "-A")
        ag("commit", "-q", "-m", "docs")
        docs = ag("rev-parse", "HEAD")
        tpl = pathlib.Path(__file__).resolve().parents[1] / "PULL_REQUEST_TEMPLATE.md"
        section = re.search(r"## Security checklist\n.*?(?=\n## )", tpl.read_text(), re.S).group(0)
        ticked = section.replace("- [ ]", "- [x]")
        ga = Git(adm)
        cases = [
            ("money-path, no checklist section", money, "Refs #1", False),
            ("money-path, template section unticked", money, "Refs #1\n\n" + section, False),
            ("money-path, ticked boxes for the WRONG questions", money,
             "## Security checklist\n- [x] looks fine\n- [x] trust me\n", False),
            ("money-path, ticked", money, "Refs #1\n\n" + ticked, True),
            ("not money-path, no checklist", docs, "Refs #1", True),
        ]
        for label, head, body, want in cases:
            got = admission_refusal(ga, abase, {"head_sha": head, "body": body})
            check(f"admission (real gate): {label} -> {'admit' if want else 'refuse'}", (got is None) == want, str(got))

    # ---- real git, real ticks ----------------------------------------------------------------
    saved = {k: os.environ.get(k) for k in ("GH_TOKEN", "GITHUB_TOKEN", "RUNNER_TEMP", "UPDATE_BRANCH_TOKEN")}
    os.environ.update({"GH_TOKEN": "ghs_SELFTEST_MUST_NOT_LEAK", "GITHUB_TOKEN": "ghs_2", "RUNNER_TEMP": "/runner/temp",
                       "UPDATE_BRANCH_TOKEN": "ghs_UPDATER_MUST_NOT_LEAK"})
    try:
        env = generator_env()
        check("generator env: no *TOKEN*, no RUNNER_TEMP, isolated git config",
              not any("TOKEN" in k for k in env) and "RUNNER_TEMP" not in env and env["GIT_CONFIG_GLOBAL"] == os.devnull)
        with _synthetic_clock(), tempfile.TemporaryDirectory() as root:
            origin = os.path.join(root, "origin")
            _synthetic_origin(origin)
            _pack_synthetic_origin(origin)
            gh = FakeGitHub(origin, root)
            base0 = gh.main_sha()
            numbers = {"pA": 11, "pB": 12, "p1": 1, "p2": 2, "p3": 3, "p4": 4, "pR": 21, "pL": 31, "pG": 32, "pW": 35, "pD": 41,
                       "pX": 33, "pF": 34, "pW2": 36, "pS": 37, "pN": 51, "pY": 52, "pQ": 53, "pV": 61, "pT": 62, "pK": 38, "pM": 39,
                       "pJ1": 81, "pJ2": 82, "pGY": 83, "pGA": 84, "pPc": 85, "pPR": 86, "pPx": 87, "pP1": 88, "pPbad": 89, "pP2": 90, "pRG": 91, "pFoo": 92,
                       "pE1": 93, "pE2": 94, "pE3": 95, "pGP": 96,
                       "pCO": 71, "pJbad": 72, "pO1": 73, "pO2": 74, "pS1": 75, "pS2": 76, "pRelax": 77, "pTight": 78,
                       "pCA": 79, "pCB": 80, "pDet": 5, "pMoney": 6, "pTM": 7, "pCompA": 8, "pCompB": 9, "pPinT": 10, "pPinR": 13, "pWT": 14, "pWR": 15, "pAddR": 16, "pAddP": 17, "pAddI": 18}
            probe = os.path.join(root, "probe.json")
            counter = [0]

            def clone(tag):
                counter[0] += 1
                d = os.path.join(root, f"{tag}-{counter[0]}")
                r = _clone_synthetic_origin(origin, d)
                if r.returncode != 0:
                    raise RuntimeError(f"self-test fixture: git clone failed: {r.stderr.strip()[-400:]}")
                return d

            def tick(regen=None, batch_size=8):
                """settle -> build -> publish, each in its own fresh clone, as on three runners. Speculative
                stacking off (MERGE_TRAIN_SPECULATIVE_STACK=false): these cases pin the bounded deferral,
                which is exactly the rollback behaviour; stacking is exercised by stack_tick below."""
                s = mode_settle(gh, Git(clone("settle")), "o/r", False, stack=False)
                if s["in_flight"]:
                    return s, "in-flight"
                counter[0] += 1
                bdir = clone("build")
                b = TrainBuilder(bdir, regen_commands=regen or (f"{sys.executable} -I {SYN_GENERATOR}",),
                                 overlay_roots=(".github/scripts",))
                b.env["PROBE_OUT"] = probe
                out = os.path.join(root, f"bundle-{counter[0]}")
                mode_build(gh, Git(bdir), b, "o/r", out, batch_size)
                mode_notice_drops(gh, Git(clone("publish")), out)   # publish runs it first, as in main()
                return s, mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", batch_size)

            def open_only(*branches):
                for br in branches:
                    gh.add_pr(numbers[br], br, f"2026-01-{numbers[br]:02d}")

            def drain(max_ticks=12, **kw):
                for _ in range(max_ticks):
                    s, st = tick(**kw)
                    if st == "idle" and not s["in_flight"]:
                        return

            def reset():
                for p in gh.prs.values():
                    p["state"] = "closed"
                for c in gh.carriers.values():
                    c["state"] = "closed"
                gh.merged.clear()
                gh.comments.clear()
                gh.statuses.clear()
                gh.updates.clear()
                gh.g("checkout", "-q", "-f", "main")
                gh.g("reset", "-q", "--hard", base0)

            # Owner-approved codex paths use the real train/strict machinery, never a shortcut.
            gh.g("branch", "codex/owner-feature", "p1")
            gh.g("branch", "codex/owner-workflow", "pW")
            gh.add_pr(70, "codex/owner-feature", "2026-01-01")
            _, st = tick()
            check("owner: unapproved codex head creates no train", st == "idle" and not gh.merged)
            h = gh.prs[70]["head"]["sha"]
            gh.post_status(h, "success", "owner-approved PR #70", OWNER_APPROVAL_CONTEXT)
            tick()  # carrier produced while approved
            gh.post_status(h, "failure", "owner-revoked PR #70", OWNER_APPROVAL_CONTEXT)
            tick()
            check("owner: revoked codex carrier cannot merge", not gh.merged, str(gh.merged))
            reset()
            gh.add_pr(70, "codex/owner-feature", "2026-01-01")
            gh.post_status(h, "success", "owner-approved PR #70", OWNER_APPROVAL_CONTEXT)
            drain()
            check("owner: approved codex feature uses verified train", gh.merged == [70], str(gh.merged))
            reset()
            gh.add_pr(71, "codex/owner-workflow", "2026-01-01")
            h = gh.prs[71]["head"]["sha"]
            gh.post_status(h, "success", "owner-approved PR #71", OWNER_APPROVAL_CONTEXT)
            tick()
            check("owner: approved codex workflow uses strict lane", gh.merged == [71]
                  and gh.app_statuses(h).get(STATUS_CONTEXT, ("", ""))[1].startswith("strict lane:"), str(gh.merged))
            reset()

            # Every new head needs its own approval, including a pure main update. Topology still
            # bounds inherited revocations; it never grants approval. Negative cases first.
            def owner_updated(case):
                """Approve #70 on H, move main, then give the PR head H' per `case`."""
                gh.add_pr(70, "codex/owner-feature", "2026-01-01")
                h0 = gh.prs[70]["head"]["sha"]
                gh.post_status(h0, "success", "owner-approved PR #70", OWNER_APPROVAL_CONTEXT)
                wt = tempfile.mkdtemp(dir=root)
                gh.g("worktree", "add", "-q", "--detach", wt, "main")

                def wg(*a):
                    return sh(["git", "-c", "core.hooksPath=/dev/null", *a], cwd=wt, env=base_env())

                def put(rel, text):
                    pathlib.Path(wt, rel).parent.mkdir(parents=True, exist_ok=True)
                    pathlib.Path(wt, rel).write_text(text)
                    wg("add", rel)
                put("docs/one.md" if case == "conflict" else "docs/main-moved.md", "main\n")
                wg("commit", "-q", "-m", "main moves")
                moved = wg("rev-parse", "HEAD").stdout.strip()
                gh.g("update-ref", "refs/heads/main", moved)
                if case == "force-push":   # same change re-made on top of main: H is no longer an ancestor
                    put("docs/one.md", "1\n")
                    wg("commit", "-q", "-m", "p1 again")
                else:
                    wg("checkout", "-q", "--detach", h0)
                    merged = sh(["git", "-c", "core.hooksPath=/dev/null", "merge", "-q", "--no-edit", moved],
                                cwd=wt, env=base_env(), check=False)
                    if case == "conflict":   # hand-resolved: the tree is not what git computes
                        check("owner chain fixture: the conflict is real", merged.returncode != 0)
                        put("docs/one.md", "1\nmain\n")
                        wg("commit", "-q", "--no-edit")
                    if case == "smuggle":    # a clean merge amended with an edit the owner never saw
                        put("docs/smuggled.md", "x\n")
                        wg("commit", "-q", "--amend", "--no-edit")
                    if case == "extra":      # an ordinary commit after the update merge
                        put("docs/extra.md", "x\n")
                        wg("commit", "-q", "-m", "extra")
                h1 = wg("rev-parse", "HEAD").stdout.strip()
                gh.g("worktree", "remove", "--force", wt)
                gh.g("branch", "-f", "codex/owner-feature", h1)
                gh.prs[70]["head"]["sha"] = h1
                if case == "revoke":   # revoked on H after the train moved the PR to H'
                    gh.post_status(h0, "failure", "owner-revoked PR #70", OWNER_APPROVAL_CONTEXT)
                return h0, h1

            for case in ("extra", "smuggle", "conflict", "force-push", "revoke"):
                owner_updated(case)
                drain()
                check(f"owner chain: approval on H does not cover a {case} head", gh.merged == [], f"{case}: {gh.merged}")
                reset()
                gh.g("branch", "-f", "codex/owner-feature", "p1")
            h0, h1 = owner_updated("clean")
            check("owner chain: the clean update is a main-only merge of H",
                  remember_approval_chain(gh, Git(clone("chain")), gh.main_sha(), h1)[:2] == [h1, h0])
            drain()
            check("owner chain: approval on H does not cover a clean update merge with main", gh.merged == [], str(gh.merged))
            gh.post_status(h1, "success", "owner-approved PR #70", OWNER_APPROVAL_CONTEXT)
            drain()
            check("owner chain: fresh approval on updated H merges through the normal lane", gh.merged == [70], str(gh.merged))
            reset()
            gh.g("branch", "-f", "codex/owner-feature", "p1")

            # 4-PR batch, #3 bad: bisect across ticks isolates #3; 1, 2, 4 merge.
            open_only("p1", "p2", "p3", "p4")
            drain()
            check("ticks: 4-PR batch with #3 bad merges 1, 2 and 4", sorted(gh.merged) == [1, 2, 4], str(gh.merged))
            # #3 was cut from the main #1 and #2 then advanced, so its isolation is the #15254 shape: the
            # train refreshes it once instead of leaving it to wait for a push nobody knows to make.
            # The fake's own-head checks stay green after the refresh, so #3 rides again and is isolated
            # a second time; by then it is up to date, so that isolation is the ordinary culprit. One
            # refresh per behind-main isolation, never a second one on the refreshed head: no loop.
            check("ticks: #3 is the culprit, behind main -> exactly one update-branch and the stale-culprit comment",
                  (3, STALE_CULPRIT_MESSAGE) in gh.comments and gh.updates.count(3) == 1
                  and gh.app_statuses(gh.prs[3]["head"]["sha"]).get(STATUS_CONTEXT, ("",))[0] == "failure",
                  f"{gh.comments} updates={gh.updates}")
            check("ticks: every carrier was closed", all(c["state"] == "closed" for c in gh.carriers.values()))
            # Combined with the stale-culprit refresh (#15374): #3 is isolated twice — behind main, then on its
            # refreshed head — so there are TWO lone carriers, each re-run once before its blame (the rerun
            # marker is per carrier head), never two reruns of one carrier.
            check("ticks: each lone #3 carrier was re-run exactly once before its blame (#15420 + #15374)",
                  len(gh.reruns) == 2 and len({sha for sha, _ in gh.reruns}) == 2
                  and all(ctx == ["Validate manifests"] for _, ctx in gh.reruns), str(gh.reruns))
            gh.reruns.clear()
            check("ticks: the refreshed culprit, isolated again up to date, is not refreshed a second time",
                  3 not in gh.merged and gh.updates.count(3) == 1 and (3, CULPRIT_MESSAGE) in gh.comments,
                  f"merged={gh.merged} updates={gh.updates} {gh.comments}")
            reset()

            # One refresh per lineage: the same behind-main isolation, but the head already carries the
            # refresh marker (main moved again under a refreshed head). Must-FAIL case: without the
            # first-parent marker check, #3 is update-branched a second time.
            open_only("p1", "p3")   # two members suffice: #1 merges, #3 is isolated behind the main it moved
            gh.post_status(gh.prs[3]["head"]["sha"], "success", "update-branched once", context=STALE_CULPRIT_CONTEXT)
            drain()
            check("ticks: a culprit whose lineage was already refreshed is not refreshed again",
                  3 not in gh.updates and (3, CULPRIT_MESSAGE) in gh.comments
                  and (3, STALE_CULPRIT_MESSAGE) not in gh.comments, f"{gh.comments} updates={gh.updates}")
            reset()
            # ... and the marker on the head's FIRST PARENT (the head update-branch produced, then main moved
            # again): the case above marks the head itself, so it cannot see the first-parent half; this one
            # fails if the lookup reads only the head.
            open_only("p1", "p3")
            parent = gh.g("rev-parse", gh.prs[3]["head"]["sha"] + "^1").stdout.strip()
            gh.post_status(parent, "success", "update-branched once", context=STALE_CULPRIT_CONTEXT)
            drain()
            check("ticks: a culprit whose FIRST PARENT carries the refresh marker is not refreshed again",
                  3 not in gh.updates and (3, CULPRIT_MESSAGE) in gh.comments
                  and (3, STALE_CULPRIT_MESSAGE) not in gh.comments, f"{gh.comments} updates={gh.updates}")
            reset()

            # A culprit that is NOT behind main is red on its own merits: ordinary message, no update-branch.
            open_only("p3")
            drain()
            check("ticks: an up-to-date culprit gets the ordinary comment and waits for a push",
                  (3, CULPRIT_MESSAGE) in gh.comments and (3, STALE_CULPRIT_MESSAGE) not in gh.comments
                  and gh.updates == []
                  and gh.app_statuses(gh.prs[3]["head"]["sha"]).get(STATUS_CONTEXT, ("",))[0] == "failure",
                  f"{gh.comments} updates={gh.updates}")
            # Each lone #3 carrier above was re-run once (#15420) before its blame; a single rerun per carrier.
            # (The two lineage cases build byte-identical carriers, so the same sha may appear twice — once per
            # fixture reset, which clears the marker.)
            check("ticks: the three refresh-rule culprits were each re-run once before the blame",
                  len(gh.reruns) == 3 and all(ctx == ["Validate manifests"] for _, ctx in gh.reruns), str(gh.reruns))
            gh.reruns.clear()
            reset()

            def settle_once():
                return mode_settle(gh, Git(clone("settle")), "o/r", False)

            def mt_status(n):
                return gh.app_statuses(gh.prs[n]["head"]["sha"]).get(STATUS_CONTEXT, ("", ""))

            def open_carriers():
                return [c for c in gh.carriers.values() if c["state"] == "open"]

            # Fully cancelled carrier (#13452 shape): no culprit; ONE rerun, then in flight.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "cancelled", "derived": "skipped"}
            s = settle_once()
            check("cancelled: a fully cancelled carrier blames nobody, re-runs once and is in flight",
                  s["culprits"] == [] and s["bisected"] == [] and len(gh.reruns) == 1 and s["in_flight"]
                  and len(open_carriers()) == 1 and mt_status(1)[0] != "failure" and not gh.comments,
                  f"{s} reruns={gh.reruns} status={mt_status(1)}")
            check("cancelled: the rerun asked for exactly the inconclusive contexts",
                  bool(gh.reruns) and sorted(gh.reruns[0][1]) == ["derived", "gates (data)"], str(gh.reruns))
            s = settle_once()
            check("cancelled: still inconclusive after the one rerun -> closed with no verdict, no second rerun",
                  s["culprits"] == [] and s["inconclusive"] and len(gh.reruns) == 1 and not open_carriers()
                  and mt_status(1)[0] != "failure", f"{s} reruns={gh.reruns}")
            gh.carrier_override = {}
            drain()
            check("cancelled: once CI is terminal and green, the member merges", gh.merged == [1], str(gh.merged))
            gh.reruns.clear()
            reset()

            # Rerun succeeds: the next settle sees a terminal green result and merges.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "cancelled"}
            gh.on_rerun = lambda: gh.carrier_override.clear()
            settle_once()
            s = settle_once()
            gh.on_rerun = None
            check("cancelled: a rerun that finishes green merges the member, nobody blamed",
                  gh.merged == [1] and s["culprits"] == [] and len(gh.reruns) == 1, f"{s} merged={gh.merged}")
            gh.reruns.clear()
            reset()

            # Failure + cancelled mix: only the real failure blames, and the status names only it.
            open_only("p3")
            tick()
            gh.carrier_override = {"issue-hygiene": "cancelled"}
            real = [c for c in SYN_REQUIRED[:3] if gh.checks(open_carriers()[0]["head"]["sha"]).get(c) == "failure"]
            gh.carrier_override = {"derived": "cancelled"} if "derived" not in real else {"gates (data)": "cancelled"}
            s1 = settle_once()
            check("mix: green on #3's head and on main -> ONE rerun covering the red AND the cancelled context",
                  s1["culprits"] == [] and len(gh.reruns) == 1
                  and sorted(gh.reruns[0][1]) == sorted(set(real) | set(gh.carrier_override)), f"{s1} {gh.reruns}")
            s = settle_once()
            st, desc = mt_status(3)
            check("mix: a real failure next to a cancelled job still names the culprit",
                  s["culprits"] == [3] and st == "failure" and desc.startswith(CULPRIT_PREFIX) and len(gh.reruns) == 1,
                  f"{s} {st} {desc!r}")
            gh.reruns.clear()
            check("mix: the culprit status names only the really failing context(s), never the cancelled one",
                  all(c in desc for c in real) and not any(c in desc for c in gh.carrier_override), f"{desc!r} real={real}")
            gh.carrier_override = {}
            reset()

            # Likely flake (#15420, carrier #15416 blamed #15344): a lone member red on a context that is
            # green on its own head and on main gets ONE rerun, no culprit; a green rerun merges it.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "failure"}
            gh.on_rerun = lambda: gh.carrier_override.clear()
            s = settle_once()
            check("flake: a lone member green on its head and on main is re-run once, not blamed, in flight",
                  s["culprits"] == [] and s["bisected"] == [] and gh.reruns and gh.reruns[0][1] == ["gates (data)"]
                  and s["in_flight"] and len(open_carriers()) == 1 and mt_status(1)[0] != "failure" and not gh.comments,
                  f"{s} reruns={gh.reruns} status={mt_status(1)}")
            s = settle_once()
            gh.on_rerun = None
            check("flake: the rerun finishes green -> the member merges, nobody blamed",
                  gh.merged == [1] and s["culprits"] == [] and len(gh.reruns) == 1, f"{s} merged={gh.merged}")
            gh.reruns.clear()
            reset()
            # ... still red after the one rerun: the culprit, and never a second rerun.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "failure"}
            s1 = settle_once()
            s2 = settle_once()
            check("flake: still red after the one rerun -> culprit, exactly one rerun ever",
                  s1["culprits"] == [] and s2["culprits"] == [1] and len(gh.reruns) == 1 and mt_status(1)[0] == "failure"
                  and mt_status(1)[1].startswith(CULPRIT_PREFIX) and (1, CULPRIT_MESSAGE) in gh.comments,
                  f"{s1} {s2} reruns={gh.reruns} {mt_status(1)}")
            gh.carrier_override = {}
            gh.reruns.clear()
            reset()
            # ... red on the member's OWN head too: today's immediate culprit, no rerun.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "failure"}
            gh.head_checks[gh.prs[1]["head"]["sha"]] = {"gates (data)": "failure"}
            s = settle_once()
            check("flake: a context red on the member's own head -> immediate culprit, no rerun",
                  s["culprits"] == [1] and gh.reruns == [] and mt_status(1)[0] == "failure", f"{s} reruns={gh.reruns}")
            gh.carrier_override = {}
            gh.head_checks.clear()
            reset()

            # #13400 (carrier #13501 blamed #13137): gates that PASSED on content but overran their budget,
            # or were NOT EVALUATED, are inconclusive exactly like a cancelled job — never a culprit.
            for kind in ("budget", "not_evaluated"):
                open_only("p1")
                tick()
                gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure"}
                gh.gate_records = {"data": [{"id": "security-checklist-money-path", "status": "failed", "failure_kind": kind},
                                            {"id": "other", "status": "ok", "failure_kind": None}]}
                s = settle_once()
                check(f"{kind}: a carrier red only for {kind} gates blames nobody, re-runs once and is in flight",
                      s["culprits"] == [] and s["bisected"] == [] and len(gh.reruns) == 1 and s["in_flight"]
                      and mt_status(1)[0] != "failure" and not gh.comments, f"{s} reruns={gh.reruns} status={mt_status(1)}")
                s = settle_once()
                check(f"{kind}: still red the same way after the one rerun -> closed with no verdict",
                      s["culprits"] == [] and s["inconclusive"] and len(gh.reruns) == 1 and not open_carriers()
                      and mt_status(1)[0] != "failure", f"{s} reruns={gh.reruns}")
                gh.carrier_override, gh.gate_records = {}, {}
                gh.reruns.clear()
                reset()
            # Control: the same red with a CONTENT failure in the shard still names the culprit.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure"}
            gh.gate_records = {"data": [{"id": "a", "status": "failed", "failure_kind": "budget"},
                                        {"id": "b", "status": "failed", "failure_kind": "content"}]}
            # Red on #1's own head too, so the likely-flake rerun (#15420) stays out of this control.
            gh.head_checks[gh.prs[1]["head"]["sha"]] = {"gates (data)": "failure", "Validate manifests": "failure"}
            s = settle_once()
            check("budget control: a content failure next to a budget overrun is still a culprit",
                  s["culprits"] == [1] and gh.reruns == [] and mt_status(1)[0] == "failure", f"{s} {mt_status(1)}")
            gh.carrier_override, gh.gate_records = {}, {}
            gh.head_checks.clear()
            reset()
            # Control: no machine-readable verdict (artifact missing / pre-#13400 runner) stays conclusive.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "failure"}
            gh.head_checks[gh.prs[1]["head"]["sha"]] = {"gates (data)": "failure"}
            s = settle_once()
            check("budget control: a red shard with no gate-results artifact is still a culprit",
                  s["culprits"] == [1] and gh.reruns == [], str(s))
            gh.carrier_override = {}
            gh.head_checks.clear()
            reset()

            # #13400 livelock (2026-10-24): a gate whose time grows with the train overran its budget on
            # four carriers of the SAME five members. A multi-member carrier closed with no verdict for a
            # GATE reason halves the next batch — bisect statuses, no culprit, no failure on anyone.
            def bisect_of(n):
                return bisect_size(gh.app_statuses(gh.prs[n]["head"]["sha"]))

            open_only("p1", "p2", "p4")
            tick()
            gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure"}
            gh.gate_records = {"data": [{"id": "security-checklist-money-path", "status": "failed", "failure_kind": "budget"}]}
            settle_once()                       # the one rerun
            s = settle_once()                   # still budget-red: closed with no verdict
            check("budget livelock: a multi-member carrier closed for a gate budget halves the next batch",
                  s["inconclusive"] and s["culprits"] == [] and s["bisected"] == [[1, 2, 4]]
                  and [bisect_of(n) for n in (1, 2, 4)] == [1, 1, 1] and not open_carriers()
                  and not gh.comments and all(mt_status(n)[0] != "failure" for n in (1, 2, 4)),
                  f"{s} sizes={[bisect_of(n) for n in (1, 2, 4)]} comments={gh.comments}")
            gh.carrier_override, gh.gate_records = {}, {}
            _, st = tick()
            newest = max(gh.carriers.values(), key=lambda c: c["number"]) if gh.carriers else None
            check("budget livelock: the rebuilt carrier carries the halved batch, not the same five again",
                  st == "published" and newest is not None and newest["state"] == "open"
                  and len((parse_own_chain(gh.g, newest["head"]["sha"]) or ("", []))[1]) == 1,
                  f"st={st} newest={newest}")
            drain()
            check("budget livelock: once green, every member still merges through verified carriers",
                  sorted(gh.merged) == [1, 2, 4], str(gh.merged))
            gh.reruns.clear()
            reset()

            # #13400 follow-up, the REAL 2026-10-25 sequence (#13801..#13817): the OLDEST candidate is
            # dropped by every build (its squash is a no-op on main — #13697), so it never rides a carrier
            # and never receives the halving status. The cap used to be read off it alone: the halved
            # members were rebuilt into a full-size carrier again, six times in five hours.
            gh.g("checkout", "-q", "-f", "main")
            gh.g("merge", "-q", "--squash", "p1")
            subprocess.run([sys.executable, SYN_GENERATOR], cwd=origin, check=True, env=base_env())
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main already carries p1's change: p1's squash is a no-op")
            open_only("p1", "p2", "p4")
            tick()
            first = max(gh.carriers.values(), key=lambda c: c["number"]) if gh.carriers else None
            first_members = [n for n, _ in (parse_own_chain(gh.g, first["head"]["sha"]) or ("", []))[1]] if first else []
            gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure"}
            gh.gate_records = {"data": [{"id": "security-checklist-money-path", "status": "failed", "failure_kind": "budget"}]}
            settle_once()
            s = settle_once()
            gh.carrier_override, gh.gate_records = {}, {}
            _, st = tick()
            newest = max(gh.carriers.values(), key=lambda c: c["number"]) if gh.carriers else None
            rebuilt = [n for n, _ in (parse_own_chain(gh.g, newest["head"]["sha"]) or ("", []))[1]] if newest else []
            check("budget livelock (oldest never rides): halving converges although the oldest candidate "
                  "carries no bisect status",
                  first_members == [2, 4] and s["bisected"] == [[2, 4]] and bisect_of(1) is None
                  and st == "published" and newest is not first and rebuilt == [2],
                  f"first={first_members} s={s} st={st} rebuilt={rebuilt} sizes={[bisect_of(n) for n in (1, 2, 4)]}")
            drain()
            check("budget livelock (oldest never rides): both halved members still merge",
                  sorted(gh.merged) == [2, 4], str(gh.merged))
            gh.reruns.clear()
            reset()

            # Review of #13840: a DROPPED candidate carrying `bisect size 1` must not pin the train at one.
            gh.g("checkout", "-q", "-f", "main")
            gh.g("merge", "-q", "--squash", "p1")
            subprocess.run([sys.executable, SYN_GENERATOR], cwd=origin, check=True, env=base_env())
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main already carries p1's change: p1's squash is a no-op")
            open_only("p1", "p2", "p4")
            gh.post_status(gh.prs[1]["head"]["sha"], "pending", "bisect size 1")
            _, st = tick()
            newest = max(gh.carriers.values(), key=lambda c: c["number"]) if gh.carriers else None
            got = [n for n, _ in (parse_own_chain(gh.g, newest["head"]["sha"]) or ("", []))[1]] if newest else []
            check("dropped candidate's bisect size: a no-op oldest PR at size 1 does not pin the train",
                  st == "published" and got == [2, 4] and bisect_of(1) == 1, f"st={st} members={got}")
            drain()
            check("dropped candidate's bisect size: both members still merge", sorted(gh.merged) == [2, 4], str(gh.merged))
            gh.reruns.clear()
            reset()

            # EARLY close (#13400): the inconclusive gate verdict is known minutes into CI; the rest of CI
            # (~1 h on 2026-10-24) cannot change it. Closed now, halved, nobody blamed, no rerun.
            open_only("p1", "p2", "p4")
            tick()
            gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure", "derived": None}
            gh.gate_records = {"data": [{"id": "security-checklist-money-path", "status": "failed", "failure_kind": "budget"}]}
            s = settle_once()
            check("early close: an inconclusive gate shard with other CI still running closes now and halves",
                  s["inconclusive"] and s["bisected"] == [[1, 2, 4]] and s["culprits"] == [] and gh.reruns == []
                  and not open_carriers() and [bisect_of(n) for n in (1, 2, 4)] == [1, 1, 1]
                  and all(mt_status(n)[0] != "failure" for n in (1, 2, 4)) and not gh.comments,
                  f"{s} reruns={gh.reruns} sizes={[bisect_of(n) for n in (1, 2, 4)]}")
            gh.carrier_override, gh.gate_records = {}, {}
            reset()

            # A gate shard still RUNNING (pending) says nothing yet: the carrier stays in flight, untouched.
            open_only("p1", "p2", "p4")
            tick()
            gh.carrier_override = {"gates (data)": None, "Validate manifests": None, "derived": None}
            gh.gate_records = {"data": [{"id": "security-checklist-money-path", "status": "failed", "failure_kind": "budget"}]}
            s = settle_once()
            check("early close: a pending gate shard does nothing - in flight, no close, no halving",
                  s["in_flight"] and len(open_carriers()) == 1 and not s["inconclusive"] and s["bisected"] == []
                  and [bisect_of(n) for n in (1, 2, 4)] == [None] * 3, f"{s}")
            gh.carrier_override, gh.gate_records = {}, {}
            reset()

            # A REAL (content) gate FAIL with other CI running is NOT closed as no-verdict: it takes the
            # culprit/bisect path, which already acts on the first red required context (unchanged here).
            open_only("p1", "p2", "p4")
            tick()
            gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure", "derived": None}
            gh.gate_records = {"data": [{"id": "x", "status": "failed", "failure_kind": "content"}]}
            s = settle_once()
            check("early close: a real gate FAIL with CI running is never an inconclusive close",
                  not s["inconclusive"] and s["culprits"] == [] and gh.reruns == []
                  and s["bisected"] == [[1, 2, 4]], f"{s}")
            gh.carrier_override, gh.gate_records = {}, {}
            reset()

            # Single member: early close cannot change the batch, so the wait-then-rerun-once path stays.
            open_only("p1")
            tick()
            gh.carrier_override = {"gates (data)": "failure", "Validate manifests": "failure", "derived": None}
            gh.gate_records = {"data": [{"id": "security-checklist-money-path", "status": "failed", "failure_kind": "budget"}]}
            s = settle_once()
            check("early close: a single-member carrier keeps waiting (in flight, open)",
                  s["in_flight"] and len(open_carriers()) == 1 and not s["inconclusive"], f"{s}")
            gh.carrier_override, gh.gate_records = {}, {}
            gh.reruns.clear()
            reset()

            # Control: a carrier closed with no verdict only for CANCELLED jobs (transient) is not halved.
            open_only("p1", "p2", "p4")
            tick()
            gh.carrier_override = {"gates (data)": "cancelled"}
            settle_once()
            s = settle_once()
            check("budget livelock control: a cancelled-only no-verdict close leaves the batch size alone",
                  s["inconclusive"] and s["bisected"] == [] and [bisect_of(n) for n in (1, 2, 4)] == [None] * 3,
                  f"{s} sizes={[bisect_of(n) for n in (1, 2, 4)]}")
            gh.carrier_override = {}
            gh.reruns.clear()
            reset()

            # A legacy (pre-fix) culprit mark is re-evaluated: the member rides again and merges when green.
            open_only("p1")
            gh.post_status(gh.prs[1]["head"]["sha"], "failure", "isolated as the cause of a red train over main 0123456789ab")
            drain()
            check("legacy mark: a pre-fix culprit status is re-evaluated and overwritten by the next train",
                  gh.merged == [1] and mt_status(1)[0] == "success", f"{gh.merged} {mt_status(1)}")
            reset()

            # Rerun refused by the API: no verdict, nobody blamed.
            open_only("p1")
            tick()
            gh.carrier_override, gh.rerun_ok = {"gates (data)": "cancelled"}, False
            s = settle_once()
            check("cancelled: a refused rerun closes the carrier with no verdict, nobody blamed",
                  s["culprits"] == [] and s["inconclusive"] and not open_carriers() and mt_status(1)[0] != "failure", str(s))
            gh.carrier_override, gh.rerun_ok = {}, True
            gh.reruns.clear()
            reset()

            # Semantic pair green alone, red together: one merges, the other is the culprit.
            # The fake squashes the PR head, not the carrier, so main would lack the regenerated derived
            # file and read red on `derived` — and no train is built over a red main. Not under test here.
            open_only("pA", "pB")
            gh.carrier_override = gh.main_override = {"derived": "success"}
            drain()
            gh.carrier_override, gh.main_override = {}, {}
            check("semantic pair: exactly one merges, the other is the culprit",
                  gh.merged == [11] and (12, CULPRIT_MESSAGE) in gh.comments, f"{gh.merged} {gh.comments}")
            reset()

            # Regeneration: pR needs derived/index.txt regenerated; the train carries it and merges.
            open_only("pR")
            drain()
            check("regen: pR merges through a train whose regeneration commit is in the inventory", gh.merged == [21], str(gh.merged))
            rec = json.loads(pathlib.Path(probe).read_text())
            check("exfiltration probe: the generator saw no GH_TOKEN and no *TOKEN* key",
                  rec["GH_TOKEN"] == "" and not any("TOKEN" in k for k in rec["keys"]), str(rec)[:160])
            check("exfiltration probe: the generator saw no UPDATE_BRANCH_TOKEN (branch-updater App, workflows: write)",
                  rec.get("UPDATE_BRANCH_TOKEN", "missing") == "", str(rec)[:160])
            reset()

            # A baseline edit under a generator overlay root: the overlay puts main's GENERATORS
            # back, never main's copy of a trainable data file over the member's (which the regen
            # commit would then carry as a revert, and publish would reject as a non-derived path).
            open_only("pT")
            drain()
            check("baseline: a member loosening a baseline under .github/scripts rides a train and merges intact",
                  gh.merged == [62] and pathlib.Path(origin, SYN_BASELINE).read_text() == "loosened\n",
                  f"{gh.merged} {gh.comments}")
            reset()

            # A candidate turning green BETWEEN build and publish reshapes the live batch. Publish
            # takes the build's declared members (each re-checked live) instead of re-planning, so
            # a legitimate bundle is not rejected for a race (run 39139647341: #13209 went green).
            open_only("p2")
            counter[0] += 1
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",))
            out = os.path.join(root, f"bundle-{counter[0]}")
            mode_build(gh, Git(bdir), b, "o/r", out, 8)
            open_only("p1")      # older, so it sorts FIRST in the live batch
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("race: a candidate going green after build does not reject the built train",
                  st == "published", st)
            reset()
            # NEGATIVE: a declared member that is no longer a live candidate at that head.
            open_only("p1", "p2")
            counter[0] += 1
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",))
            out = os.path.join(root, f"bundle-{counter[0]}")
            mode_build(gh, Git(bdir), b, "o/r", out, 8)
            gh.prs[2]["auto_merge"] = None
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)

            def published_members():
                c = [c for c in gh.carriers.values() if c["state"] == "open"]
                return [n for n, _ in (parse_own_chain(gh.g, c[-1]["head"]["sha"]) or ("", []))[1]] if c else None
            check("race (#15827): a declared member disarmed after build is left out; the rest touches generator "
                  "inputs (docs/), so it is refused rather than published without regeneration",
                  st == "rejected" and published_members() is None, f"{st} {published_members()}")
            for c in gh.carriers.values():
                c["state"] = "closed"
            gh.prs[2]["auto_merge"] = {"x": 1}
            # NEGATIVE: a manifest naming a PR that was never a candidate (forged by the build job). It can
            # only shrink the selection: the forged entry never reaches the carrier.
            pathlib.Path(out, MANIFEST_FILE).write_text(f"1 {gh.prs[1]['head']['sha']}\n2 {gh.prs[2]['head']['sha']}\n35 {gh.g('rev-parse', 'pW').stdout.strip()}\n")
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("manifest: a member that is not a live candidate never reaches the carrier",
                  st == "rejected" and published_members() is None, f"{st} {published_members()}")
            for c in gh.carriers.values():
                c["state"] = "closed"
            pathlib.Path(out, MANIFEST_FILE).write_text(f"1 {'0' * 40}\n")
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("manifest: a member at a head other than its live head is refused", st == "rejected", st)
            pathlib.Path(out, MANIFEST_FILE).write_text("1 HEAD; rm -rf /\n")
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("manifest: a malformed line is refused", st == "rejected", st)
            pathlib.Path(out, MANIFEST_FILE).write_text(f"1 {gh.prs[1]['head']['sha']}\n2 {gh.prs[2]['head']['sha']}\n")
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 1)
            check("manifest: a declared batch over the size cap is refused", st == "rejected", st)
            os.unlink(os.path.join(out, MANIFEST_FILE))
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("manifest: a bundle with no member manifest is refused", st == "rejected", st)
            reset()

            # #15827: a batch of THREE, one member's head moves between build and publish (release-please
            # rewrites its branch after every merge to main). The other two are published THIS tick over
            # a re-derived chain. Must-FAIL case: today's publish rejected the whole batch
            # ("declared member #2 is no longer a live train candidate at that head").
            def bot_rewrite(n):
                ref = gh.prs[n]["head"]["ref"]
                old = gh.prs[n]["head"]["sha"]
                new = gh.g("commit-tree", f"{old}^{{tree}}", "-p", old, "-m", "bot rewrite").stdout.strip()
                gh.g("branch", "-f", ref, new)
                gh.prs[n]["head"]["sha"] = new
                return old

            for moved_at in ("before-plan", "at-intent"):
                open_only("pE1", "pE2", "pE3")
                counter[0] += 1
                bdir = clone("build")
                b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",))
                out = os.path.join(root, f"bundle-{counter[0]}")
                built = mode_build(gh, Git(bdir), b, "o/r", out, 8)
                if moved_at == "before-plan":
                    bot_rewrite(94)
                    st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
                else:
                    # The head moves after publish planned and verified: only live_source_intent sees it.
                    real_intent = globals()["live_source_intent"]

                    def racing_intent(g, n, head, _real=real_intent):
                        if n == 94 and gh.prs[94]["head"]["sha"] == head:
                            bot_rewrite(94)
                        return _real(g, n, head)
                    globals()["live_source_intent"] = racing_intent
                    try:
                        st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
                    finally:
                        globals()["live_source_intent"] = real_intent
                members = published_members()
                check(f"#15827 ({moved_at}): batch of 3, one head moves between build and publish -> carrier of the other 2 published this tick",
                      built == [93, 94, 95] and st == "published" and members == [93, 95], f"built={built} st={st} members={members}")
                tipc = [c for c in gh.carriers.values() if c["state"] == "open"]
                check(f"#15827 ({moved_at}): the re-derived carrier is the merge-tree of the two live heads, nothing of the moved one",
                      bool(tipc) and gh.g("cat-file", "-e", f"{tipc[-1]['head']['sha']}:build-logic/e2.txt", check=False).returncode != 0
                      and gh.g("cat-file", "-e", f"{tipc[-1]['head']['sha']}:build-logic/e3.txt", check=False).returncode == 0,
                      str(tipc[-1]["head"]["sha"] if tipc else None))
                reset()

            # NEGATIVE (#15827): a member leaves a batch whose bundle carries a regeneration commit. That
            # commit was derived WITH the member; publish runs nothing, so it is still rejected.
            open_only("p1", "pR")
            counter[0] += 1
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",))
            out = os.path.join(root, f"bundle-{counter[0]}")
            built = mode_build(gh, Git(bdir), b, "o/r", out, 8)
            bot_rewrite(1)
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("#15827: a member leaving a batch with a regeneration commit -> still rejected, nothing published",
                  st == "rejected" and not any(c["state"] == "open" for c in gh.carriers.values()), f"built={built} st={st}")
            reset()

            # NEGATIVE (review of #15882): the member that leaves touches no generator input, but the two that
            # REMAIN do (their union needs regeneration). Never published without it, whatever the bundle says.
            open_only("pE1", "p1", "pR")
            counter[0] += 1
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",))
            out = os.path.join(root, f"bundle-{counter[0]}")
            built = mode_build(gh, Git(bdir), b, "o/r", out, 8)
            bot_rewrite(93)
            st = mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)
            check("#15827: remaining members touching generator inputs -> not published without regeneration",
                  st == "rejected" and not any(c["state"] == "open" for c in gh.carriers.values()), f"built={built} st={st}")
            reset()

            # NEGATIVE: a symlink in the train tree.
            open_only("pL")
            drain()
            check("symlink: a train adding a symlink never merges; the PR gets the manual-lane comment",
                  gh.merged == [] and (31, MANUAL_LANE_MESSAGE) in gh.comments, f"{gh.merged} {gh.comments}")
            reset()

            # NEGATIVE: a regeneration commit touching a non-inventory path.
            open_only("pR")
            drain(regen=(f"{sys.executable} {SYN_GENERATOR}", f"{sys.executable} -c \"open('evil.txt','w').write('x')\""))
            check("regen outside inventory: train rejected, nothing merges", gh.merged == [] and (21, MANUAL_LANE_MESSAGE) in gh.comments,
                  f"{gh.merged} {gh.comments}")
            reset()

            # NEGATIVE: members touching a generator or a gate file never qualify.
            open_only("pG", "pW")
            carriers_before = len(gh.carriers)
            drain()
            # They may merge, but only through the strict lane (no train, nothing executed).
            check("gate-file members: never ride a train, merge only via the strict lane, nothing leaks",
                  len(gh.carriers) == carriers_before and all(gh.app_statuses(gh.g("rev-parse", b).stdout.strip()).get(STATUS_CONTEXT, ("", ""))[1]
                                          .startswith("strict lane: ") for b, n in (("pG", 32), ("pW", 35)) if n in gh.merged)
                  and not os.path.exists(os.path.join(origin, "leaked.txt")) and not gh.comments, f"{gh.merged} {gh.comments}")
            reset()

            # #13400: a gate-code-only member rides a train, and never one carrying a regeneration
            # commit. pR (older) needs regeneration, pK (check script) does not: build trains pR
            # first and defers pK WITHOUT a drop notice; pK then rides its own train.
            open_only("pR", "pK")
            # The fake merges member HEADS, not the carrier tree, so after pR main lacks the regenerated
            # file that real main would carry from the carrier: hold it green, then commit the
            # regeneration on main as the real merge would have, and let pK ride.
            gh.main_override = {"derived": "success"}
            drain()
            check("gate code: deferred while main itself would need regeneration (never mixed, never dropped)",
                  gh.merged == [21] and gh.prs[38]["state"] == "open" and not gh.comments, f"{gh.merged} {gh.comments}")
            gh.g("checkout", "-q", "-f", "main")
            subprocess.run([sys.executable, SYN_GENERATOR], cwd=origin, check=True, env=base_env())
            gh.g("add", "derived")
            gh.g("commit", "-q", "-m", "regenerated (as the carrier carried it)")
            gh.main_override = {}
            drain()
            pk_head = gh.prs[38]["head"]["sha"]
            check("gate code: a check-script PR merges through a TRAIN (not the strict lane), with no notice",
                  sorted(gh.merged) == [21, 38] and not gh.updates
                  and not gh.app_statuses(pk_head).get(STATUS_CONTEXT, ("", ""))[1].startswith("strict lane:")
                  and not gh.comments, f"{gh.merged} updates={gh.updates} {gh.comments}")
            regen_with_gate = []
            for t in gh.carriers.values():
                chain = parse_own_chain(gh.g, t["head"]["sha"])
                if chain and 38 in [n for n, _h in chain[1]]:
                    msgs = gh.g("log", "--format=%B", f"{chain[0]}..{t['head']['sha']}").stdout
                    regen_with_gate.append(OWN_REGEN_MSG.strip() in msgs)
            check("gate code: no carrier holding the gate-code member carries a regeneration commit",
                  regen_with_gate and not any(regen_with_gate), str(regen_with_gate))
            reset()
            # The publish half (the security boundary): a build that IGNORES the separation and
            # emits pK + pR + a regeneration commit is rejected; nothing merges.
            open_only("pR", "pK")
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",),
                             untrainable=Untrainable(SYN_INVENTORY))
            b.separate_gate_code = False
            b.declared_inputs = regen_inventory_fragments(SYN_INVENTORY)
            out = os.path.join(root, "bundle-gate-regen")
            mode_build(gh, Git(bdir), b, "o/r", out, 8)
            man = pathlib.Path(out, MANIFEST_FILE).read_text() if os.path.exists(os.path.join(out, MANIFEST_FILE)) else ""
            status = mode_publish(gh, Git(clone("publish")), "o/r", out, "998", "1", 8)
            check("gate code: CONTROL — with separation off, build emits both members and a regeneration commit",
                  "21 " in man and "38 " in man, man)
            check("gate code: publish rejects a train mixing gate code with a regeneration commit; nothing merges",
                  status == "rejected" and gh.merged == [], f"publish={status}")
            reset()

            # Review: a gate-code member adding a symlink never rides (qualifies refuses it), and a
            # build that forces it past qualifies is rejected by publish as the member's fault, so
            # the batch halves (bisect) instead of merging.
            open_only("pS", "p1")
            cands, _apps = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
            check("gate code + symlink: never a train candidate", [m.number for m in cands] == [1], str([m.number for m in cands]))
            # #16955: the diff-only shortcut in build/publish changes no verdict. Same queue (trainable,
            # gate-code+symlink, workflow, generator, gates.yaml members), with and without it: identical
            # candidates at identical heads, and the shortcut demonstrably skipped the per-PR reads.
            open_only("pW", "pG", "pR", "p2")
            def shortcut_run(off: bool):
                PATH_SHORTCUT_OFF[0] = off
                reads: list[str] = []
                real = gh.app_statuses
                gh.app_statuses = lambda sha: (reads.append(sha), real(sha))[1]
                try:
                    c, a = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
                finally:
                    gh.app_statuses = real
                    PATH_SHORTCUT_OFF[0] = False
                return [(m.number, m.head_sha) for m in c], sorted(a), len(reads)
            full, fast = shortcut_run(True), shortcut_run(False)
            check("diff-only shortcut: identical candidates, heads and app map with and without it (#16955)",
                  full[:2] == fast[:2] and full[0], f"full={full} fast={fast}")
            check("diff-only shortcut: CONTROL — it skipped the reads for the manual-lane PRs",
                  fast[2] < full[2], f"reads full={full[2]} fast={fast[2]}")
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(), overlay_roots=(".github/scripts",), untrainable=Untrainable(SYN_INVENTORY))
            ms = []
            for br in ("p1", "pS"):
                b.git("fetch", "-q", "origin", br)
                h = b.git("rev-parse", "FETCH_HEAD").stdout.strip()
                ms.append(Member(numbers[br], br, "", h, br, "t", ref=h))
            tip, _a, _d = b.build(base0, ms)
            pg = Git(clone("publish"))
            pg("fetch", "-q", bdir, tip)
            try:
                verify_bundle_train(pg, base0, ms, tip, ["derived/*"])
                rej = None
            except Reject as exc:
                rej = exc
            check("gate code + symlink: forced past qualifies, publish rejects it as the member's fault (bisect)",
                  rej is not None and rej.member_fault and "symlink" in str(rej), str(rej))
            reset()

            # A PR whose head ref GitHub never created (refs/pull/<n>/head absent although the branch
            # exists) made the ONE batched fetch exit 128 and crashed every settle tick, so nothing
            # merged. It must be skipped — never a candidate, never green — and the rest still ride.
            open_only("p1", "p2")
            real_refspec = gh.head_refspec
            gh.head_refspec = lambda n: "refs/pull/2/head" if n == 2 else real_refspec(n)
            try:
                crash = ""
                try:
                    cands, _apps = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
                except subprocess.CalledProcessError as exc:
                    cands, crash = [], f"crashed: {exc}"
            finally:
                gh.head_refspec = real_refspec
            check("unfetchable head ref: that PR is skipped, the tick survives, the others stay candidates",
                  not crash and [m.number for m in cands] == [1], crash or str([m.number for m in cands]))
            reset()

            # Fail-closed negatives for that fallback: a transient ls-remote failure (rc 128, not
            # rc 2 "no such ref") and a batch failure with every ref present must RAISE — an outage
            # must never read as "nothing to merge" with exit 0.
            def injected(real, fail):
                def g(*a, check=True, **kw):
                    r = fail(a)
                    if r is None:
                        return real(*a, check=check, **kw)
                    if check and r.returncode != 0:
                        raise subprocess.CalledProcessError(r.returncode, list(a), r.stdout, r.stderr)
                    return r
                return g

            def boom(rc):
                return subprocess.CompletedProcess([], rc, "", "fatal: unable to access remote")

            def nth_fetch_fails(which, ls=None):
                seen = []
                def f(a):
                    if a[0] == "fetch":
                        seen.append(1)
                        return boom(128) if len(seen) in which else None
                    if a[0] == "ls-remote" and ls and a[-1] in ls:
                        return boom(ls[a[-1]])
                    return None
                return f

            for label, fail in [
                ("ls-remote rc 128 (transient) raises, never drops the PR",
                 nth_fetch_fails({1}, {"refs/heads/p2": 128})),
                ("batch fetch failed with every ref present re-raises the fetch error",
                 nth_fetch_fails({1})),
                ("a ref present (rc 0) but the strict refetch failing raises",
                 nth_fetch_fails({1, 2}, {"refs/heads/p2": 2}))]:
                open_only("p1", "p2")
                raised = False
                try:
                    cands, _apps = live_candidates(gh, injected(Git(clone("settle")), fail), "o/r", gh.required(), base0,
                                                   Untrainable(SYN_INVENTORY))
                except subprocess.CalledProcessError:
                    raised, cands = True, []
                check(f"unfetchable head ref: {label}", raised, str([m.number for m in cands]))
                reset()

            # Review: during regeneration the generators see MAIN's copy of gate code (as of
            # generators), and the member's copy is back in the tree before anything is committed.
            gate_probe = os.path.join(root, "gate-probe.txt")
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -c \"import shutil; shutil.copy('{SYN_MAIN_GATE_CODE}', {gate_probe!r})\"",),
                             overlay_roots=(".github/scripts",), untrainable=Untrainable(SYN_INVENTORY))
            b.git("fetch", "-q", "origin", "pM")
            hm = b.git("rev-parse", "FETCH_HEAD").stdout.strip()
            tip, applied, _d = b.build(base0, [Member(39, "pM", "", hm, "pM", "t", ref=hm)])
            seen = pathlib.Path(gate_probe).read_text() if os.path.exists(gate_probe) else ""
            check("gate code: generators read main's copy during regeneration; the train keeps the member's, no regen commit",
                  applied == [39] and seen == "main\n"
                  and b.git("show", f"{tip}:{SYN_MAIN_GATE_CODE}").stdout == "member\n"
                  and b.git("log", "-1", "--format=%s", tip).stdout.strip() != REGEN_COMMIT_SUBJECT,
                  f"applied={applied} seen={seen!r}")
            reset()

            # NEGATIVE (review 5): a bundle generator deeper than any fixed glob.
            marker = os.path.join(root, "deep-generator-ran")
            open_only("pD")
            carriers_before = len(gh.carriers)
            drain()
            check("deep generator: the PR never rides a train, merges only via the strict lane, its generator never ran",
                  len(gh.carriers) == carriers_before and not os.path.exists(marker)
                  and (gh.merged == [] or gh.app_statuses(gh.g("rev-parse", "pD").stdout.strip())
                       .get(STATUS_CONTEXT, ("", ""))[1].startswith("strict lane: ")), f"{gh.merged} ran={os.path.exists(marker)}")
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} {SYN_GENERATOR}",), overlay_roots=(".github/scripts",),
                             untrainable=Untrainable(SYN_INVENTORY))
            b.git("fetch", "-q", "origin", "pD")
            head = b.git("rev-parse", "FETCH_HEAD").stdout.strip()
            _tip, applied, dropped = b.build(base0, [Member(41, "pD", "", head, "pD", "t", ref=head)])
            check("deep generator: forced past qualifies, build drops it and it still never runs",
                  applied == [] and dropped == [41] and not os.path.exists(marker), f"{applied} {dropped}")
            b.git("checkout", "-q", "-f", "--detach", head)       # the file present in the working tree
            b.declared_inputs = regen_inventory_fragments(SYN_INVENTORY)   # as mode_build sets it from main
            b.quarantine_new_executables(base0)
            b.regenerate()
            check("deep generator: quarantine removes a not-on-main executable before any generator runs",
                  b.quarantined == [SYN_DEEP_GENERATOR] and not os.path.exists(marker)
                  and os.path.exists(os.path.join(bdir, SYN_DEEP_GENERATOR)), f"{b.quarantined}")
            reset()

            # NEGATIVE (review 6a): a newline in a generator's NAME. git quotes such a path in its
            # default output, so string checks miss it while `find`/fnmatch still match it.
            nl_marker, sh_marker = os.path.join(root, "newline-gen-ran"), os.path.join(root, "shadow-ran")
            open_only("pN")
            sg = Git(clone("settle"))
            cands, _apps = live_candidates(gh, sg, "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
            check("newline path: the PR never qualifies (control character, fail closed)", all(m.number != 51 for m in cands))
            open_only("pQ")
            cands, _apps = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
            check("newline path: a DATA file with a newline is refused live too (read with -z, not split on lines)",
                  all(m.number != 53 for m in cands), str([m.number for m in cands]))
            gh.prs[53]["state"] = "closed"
            drain()
            check("newline path: nothing merges and the generator never ran", gh.merged == [] and not os.path.exists(nl_marker))
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",),
                             untrainable=Untrainable(SYN_INVENTORY))
            b.git("fetch", "-q", "origin", "pN")
            head = b.git("rev-parse", "FETCH_HEAD").stdout.strip()
            _tip, applied, dropped = b.build(base0, [Member(51, "pN", "", head, "pN", "t", ref=head)])
            check("newline path: forced past qualifies, build drops it and it still never runs",
                  applied == [] and dropped == [51] and not os.path.exists(nl_marker), f"{applied} {dropped}")
            reset()

            # NEGATIVE (review 7): renaming regen-derived.sh to docs/x.md.
            # stale-ref-ok: docs/x.md exists only inside the synthetic repository this test builds.
            sg = Git(clone("settle"))
            sg("fetch", "-q", "origin", "pV")
            rn = changed_paths(sg, f"{base0}...FETCH_HEAD")
            check("rename: changed_paths reports BOTH the deleted gate script and the new name",
                  REGEN_INVENTORY in rn and "docs/x.md" in rn, str(rn))
            open_only("pV")
            cands, _apps = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
            check("rename: a PR renaming regen-derived.sh to docs/x.md never qualifies", all(m.number != 61 for m in cands))
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(), overlay_roots=(".github/scripts",), untrainable=Untrainable(SYN_INVENTORY))
            b.git("fetch", "-q", "origin", "pV")
            hv = b.git("rev-parse", "FETCH_HEAD").stdout.strip()
            _tip, applied, dropped = b.build(base0, [Member(61, "pV", "", hv, "pV", "t", ref=hv)])
            check("rename: forced past qualifies, build's staged check drops it", applied == [] and dropped == [61], f"{applied} {dropped}")
            reset()

            # NEGATIVE (review 6b): a module shadowing `yaml` next to main's heredoc bundle script.
            def shadow_run(quarantine: bool, safepath: bool) -> bool:
                if os.path.exists(sh_marker):
                    os.unlink(sh_marker)
                d = clone("build")
                bb = TrainBuilder(d, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",),
                                  untrainable=Untrainable(SYN_INVENTORY))
                bb.declared_inputs = regen_inventory_fragments(SYN_INVENTORY)
                if not safepath:
                    bb.env.pop("PYTHONSAFEPATH", None)
                if not quarantine:
                    bb.quarantine_new_executables = lambda base: None
                bb.git("fetch", "-q", "origin", "pY")
                h = bb.git("rev-parse", "FETCH_HEAD").stdout.strip()
                bb.build(base0, [Member(52, "pY", "", h, "pY", "t", ref=h)])
                return os.path.exists(sh_marker)
            check("shadow module: CONTROL — with neither layer the shadow yaml.py IS imported", shadow_run(False, False))
            check("shadow module: PYTHONSAFEPATH alone keeps it inert", not shadow_run(False, True))
            check("shadow module: quarantine alone keeps it inert", not shadow_run(True, False))
            open_only("pY")
            drain()
            check("shadow module: through real ticks it is inert (the PR is data; the module never runs)",
                  not os.path.exists(sh_marker), str(gh.merged))
            reset()

            # Contrast: quarantining EVERY added file (not only non-inputs) hides a PR's new input
            # from the generators, so the train is wrong and main's freshness gate goes red.
            def regen_ok(keep: bool) -> bool:
                d = clone("build")
                bb = TrainBuilder(d, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",), overlay_roots=(".github/scripts",),
                                  untrainable=Untrainable(SYN_INVENTORY))
                bb.declared_inputs, bb.keep_declared_inputs = regen_inventory_fragments(SYN_INVENTORY), keep
                bb.git("fetch", "-q", "origin", "pR")
                h = bb.git("rev-parse", "FETCH_HEAD").stdout.strip()
                bb.build(base0, [Member(21, "pR", "", h, "pR", "t", ref=h)])
                return subprocess.run([sys.executable, "ci.py"], cwd=d, capture_output=True).returncode == 0
            check("quarantine: declared inputs stay visible, so a PR adding one regenerates correctly", regen_ok(True))
            check("quarantine: CONTRAST — hiding every added file makes the same train red", not regen_ok(False))

            # THE BOUNDARY: a fully compromised build emits an arbitrary bundle. Publish and settle
            # must refuse to merge every variant; the only reachable outcome is a red or wasted train.
            open_only("p1")
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(), overlay_roots=(".github/scripts",))
            b.git("fetch", "-q", "origin", "p1")
            h1 = b.git("rev-parse", "FETCH_HEAD").stdout.strip()
            honest, _a, _d = b.build(base0, [Member(1, "p1", "", h1, "p1", "t", ref=h1)])

            def commit_on(parent, edits, msg, link=None, parents=None):
                b.git("checkout", "-q", "-f", "--detach", parent)
                for rel, text in edits.items():
                    pth = pathlib.Path(bdir, rel)
                    pth.parent.mkdir(parents=True, exist_ok=True)
                    pth.write_text(text)
                if link:
                    os.symlink(link[1], os.path.join(bdir, link[0]))
                b.git("add", "-A")
                if parents:
                    tree = b.git("write-tree").stdout.strip()
                    return b.git("commit-tree", tree, *[x for q in parents for x in ("-p", q)], "-m", msg).stdout.strip()
                b.git("commit", "-q", "--allow-empty", "-m", msg)
                return b.git("rev-parse", "HEAD").stdout.strip()

            derived_now = pathlib.Path(origin, "derived/index.txt").read_text()
            variants = [
                ("a regeneration commit rewriting a non-derived file (ci.py)",
                 commit_on(honest, {"ci.py": "print('')\n"}, REGEN_COMMIT_SUBJECT), "rejected"),
                ("swapped PR content under the member's own commit",
                 commit_on(base0, {"docs/one.md": "not what the PR says\n"}, "p1"), "rejected"),
                ("an extra commit beyond the regeneration commit",
                 commit_on(commit_on(honest, {"derived/index.txt": derived_now}, REGEN_COMMIT_SUBJECT), {"docs/x.md": "x\n"}, "x"), "rejected"),
                ("a regeneration commit adding a symlink",
                 commit_on(honest, {}, REGEN_COMMIT_SUBJECT, link=("derived/link", "/etc/passwd")), "rejected"),
                ("a merge commit smuggling a second parent",
                 commit_on(honest, {}, REGEN_COMMIT_SUBJECT, parents=[honest, h1]), "rejected"),
                ("a regeneration commit with WRONG content inside the inventory",
                 commit_on(honest, {"derived/index.txt": "garbage\n"}, REGEN_COMMIT_SUBJECT), "published"),
            ]
            for i, (label, rev, want) in enumerate(variants):
                gh.statuses.clear()
                gh.comments.clear()
                for c in gh.carriers.values():
                    c["state"] = "closed"
                b.git("update-ref", BUNDLE_REF, rev)
                d = os.path.join(root, f"compromised-{i}")
                os.makedirs(d)
                b.git("bundle", "create", os.path.join(d, BUNDLE_FILE), BUNDLE_REF, f"^{base0}")
                write_manifest(os.path.join(d, MANIFEST_FILE), [Member(1, "p1", "", h1, "p1", "t")])
                status = mode_publish(gh, Git(clone("publish")), "o/r", d, str(900 + i), "1", 8)
                mode_settle(gh, Git(clone("settle")), "o/r", False)
                check(f"compromised build: {label} -> publish {want}, nothing merges",
                      status == want and gh.merged == [], f"publish={status} merged={gh.merged}")
            # ... and a train over an older main, after main moved.
            gh.statuses.clear()
            for c in gh.carriers.values():   # a lone-member red carrier above may be open on its one rerun (#15420)
                c["state"] = "closed"
            gh.reruns.clear()
            gh.g("checkout", "-q", "-f", "main")
            pathlib.Path(origin, "svc").mkdir(exist_ok=True)
            pathlib.Path(origin, "svc/later.txt").write_text("x\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main moves")
            b.git("update-ref", BUNDLE_REF, honest)
            d = os.path.join(root, "compromised-stale")
            os.makedirs(d)
            b.git("bundle", "create", os.path.join(d, BUNDLE_FILE), BUNDLE_REF, f"^{base0}")
            write_manifest(os.path.join(d, MANIFEST_FILE), [Member(1, "p1", "", h1, "p1", "t")])
            status = mode_publish(gh, Git(clone("publish")), "o/r", d, "999", "1", 8)
            check("compromised build: a train over an older main -> publish rejected, nothing merges",
                  status == "rejected" and gh.merged == [], f"publish={status}")
            reset()

            # NEGATIVE (review 5): the files API is capped at 3000; a long PR hides a path there.
            open_only("pW")
            api_calls = []
            gh.pr_files = lambda n: api_calls.append(n) or [f"svc/f{i}.txt" for i in range(3000)]
            cands, _apps = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0, Untrainable(SYN_INVENTORY))
            check("files: a 3000-entry API list hiding .github/workflows/w.yml does not admit the PR",
                  all(m.number != 35 for m in cands) and api_calls == [], f"{[m.number for m in cands]} api={api_calls}")
            del gh.pr_files
            reset()

            # Fast lane: computed live in settle. A docs/adr member is never fast-laned, and settle
            # has no input through which a stored classification could be injected.
            open_only("pF", "pX")
            sm = mode_settle(gh, Git(clone("settle")), "o/r", False)
            check("fast lane: a disjoint PR gets success from settle", 34 in sm["fast"]
                  and gh.app_statuses(gh.prs[34]["head"]["sha"]).get(STATUS_CONTEXT, ("",))[0] == "success")
            check("fast lane: a docs/adr member is not fast-laned, and settle takes no state input",
                  33 not in sm["fast"] and not gh.app_statuses(gh.prs[33]["head"]["sha"])
                  # run_id/attempt name the strict carrier branch and strict_cap bounds it; expedite/expedite_cap
                  # are the lane's switch and cap; judge_cap bounds a judge carrier; urgent_cap is the urgent
                  # path's daily cap (admission is read live): none is a classification.
                  and set(mode_settle.__code__.co_varnames[:mode_settle.__code__.co_argcount])
                  == {"gh", "git", "repo", "shadow", "run_id", "attempt", "strict_cap", "judge_cap", "stack", "expedite",
                      "expedite_cap", "urgent_cap"})
            reset()

            # Bundle verification, directly.
            open_only("p1", "p2")
            pub = Git(clone("publish"))
            base = live_base(gh, pub)
            _f, batch, _sizes = plan_batch(gh, pub, "o/r", base, 8)
            bdir = clone("build")
            b = TrainBuilder(bdir, regen_commands=(), overlay_roots=(".github/scripts",))
            for m in batch:
                b.git("fetch", "-q", "origin", f"+{gh.head_refspec(m.number)}:refs/x/{m.number}")
            tip, _applied, _d = b.build(base, batch)

            def bundle_of(rev, tag):
                b.git("update-ref", BUNDLE_REF, rev)
                path = os.path.join(root, f"{tag}.bundle")
                b.git("bundle", "create", path, BUNDLE_REF, f"^{base}")
                pub("fetch", "-q", path, f"+{BUNDLE_REF}:refs/x/{tag}")
                return pub("rev-parse", f"refs/x/{tag}").stdout.strip()

            def verdict(rev, base_=None):
                try:
                    return verify_bundle_train(pub, base_ or base, batch, rev, ["derived/*"])
                except Reject as exc:
                    return str(exc)
            v = verdict(bundle_of(tip, "honest"))
            check("bundle: an honest bundle verifies; publish pushes its OWN commits with the same tree",
                  isinstance(v, Verified) and v.applied == [1, 2] and v.tree == pub.tree(tip) and v.tip != tip, str(v))
            b.git("checkout", "-q", "-f", "--detach", f"{tip}~1")
            pathlib.Path(bdir, "docs/one.md").write_text("1\n ")
            b.git("commit", "-qam", "squash with one extra byte")
            b.git("cherry-pick", "--allow-empty", tip)
            v = verdict(bundle_of(b.git("rev-parse", "HEAD").stdout.strip(), "onebyte"))
            check("bundle: a member tree one byte off the merge-tree rebuild is rejected",
                  isinstance(v, str) and "differs from the merge-tree rebuild" in v, str(v))
            b.git("checkout", "-q", "-f", "--detach", tip)
            pathlib.Path(bdir, "docs/extra.md").write_text("x\n")
            b.git("add", "-A")
            b.git("commit", "-qm", "extra member outside the batch")
            v = verdict(bundle_of(b.git("rev-parse", "HEAD").stdout.strip(), "extra"))
            check("bundle: an extra commit outside the batch is rejected", isinstance(v, str) and "not a declared derived output" in v, str(v))
            b.git("checkout", "-q", "-f", "--detach", tip)
            os.symlink("/etc/passwd", os.path.join(bdir, "derived", "x"))
            b.git("add", "-A")
            b.git("commit", "-qm", REGEN_COMMIT_SUBJECT)
            v = verdict(bundle_of(b.git("rev-parse", "HEAD").stdout.strip(), "regenlink"))
            check("bundle: a regeneration commit adding a symlink inside the inventory is rejected",
                  isinstance(v, str) and "symlink" in v, str(v))
            gh.g("checkout", "-q", "-f", "main")
            pathlib.Path(origin, "later.txt").write_text("x\n")
            gh.g("add", "-A")
            gh.g("commit", "-qm", "later")
            live = live_base(gh, pub)
            v = verdict(pub("rev-parse", "refs/x/honest").stdout.strip(), live)
            check("bundle: a train over a stale base is rejected", isinstance(v, str) and "live base" in v, str(v))
            reset()

            # NEGATIVE: settle on a carrier head whose tree is not publish's recorded tree.
            open_only("p1")
            tick()
            carrier = next(c for c in gh.carriers.values() if c["state"] == "open")
            gh.g("checkout", "-q", "-f", "--detach", carrier["head"]["sha"])
            pathlib.Path(origin, "docs/one.md").write_text("1\nx")
            gh.g("commit", "-qam", own_member_message(1, gh.prs[1]["head"]["sha"]))
            moved = gh.g("rev-parse", "HEAD").stdout.strip()
            gh.g("update-ref", f"refs/heads/{carrier['head']['ref']}", moved)
            gh.g("checkout", "-q", "-f", "main")
            carrier["head"]["sha"] = moved
            sm = mode_settle(gh, Git(clone("settle")), "o/r", False)
            check("settle: a head whose tree is not the App-recorded tree merges nothing",
                  gh.merged == [] and carrier["number"] in sm["rejected"], f"{gh.merged} {sm}")
            # ... and a record posted by anyone but the App does not count either.
            gh.post_status(moved, "success", f"tree={Git(origin).tree(moved)}", context=RECORD_CONTEXT, creator="someone")
            gh.g("update-ref", f"refs/heads/{carrier['head']['ref']}", moved)   # settle deleted it
            carrier["state"] = "open"
            sm = mode_settle(gh, Git(clone("settle")), "o/r", False)
            check("settle: a record forged by a non-App creator merges nothing", gh.merged == [] and carrier["number"] in sm["rejected"])
            reset()

            # Shadow: statuses, no merges.
            open_only("p1")
            tick()
            mode_settle(gh, Git(clone("settle")), "o/r", True)
            check("shadow: settle posts success on the verified head and merges nothing",
                  gh.merged == [] and gh.app_statuses(gh.prs[1]["head"]["sha"]).get(STATUS_CONTEXT, ("",))[0] == "success")
            reset()

            # Phase 1 runtime guard (ADR-0343): shadow=false alone must not merge. Each negative case
            # changes ONE thing from the all-satisfied ruleset, so it cannot pass for another reason.
            def guarded(label, want_merged, **rs):
                open_only("p1")
                tick()
                gh.rs_checks, gh.rs_strict, gh.app_id = ([{"context": STATUS_CONTEXT, "integration_id": 4242}], False, "4242")
                for k, v in rs.items():
                    setattr(gh, k, v)
                mode_settle(gh, Git(clone("settle")), "o/r", False)
                st = gh.app_statuses(gh.prs[1]["head"]["sha"]).get(STATUS_CONTEXT, ("",))[0]
                check(f"phase-1 guard: {label}", (gh.merged == [1]) == want_merged and (want_merged or st == "success"),
                      f"merged={gh.merged} status={st}")
                gh.rs_checks, gh.rs_strict, gh.app_id = ([{"context": STATUS_CONTEXT, "integration_id": 4242}], False, "4242")
                reset()

            guarded("ruleset without merge-train -> no merge, status still posted", False, rs_checks=[{"context": "other", "integration_id": 4242}])
            guarded("merge-train unpinned -> no merge", False, rs_checks=[{"context": STATUS_CONTEXT}])
            guarded("merge-train pinned to another integration -> no merge", False, rs_checks=[{"context": STATUS_CONTEXT, "integration_id": 99}])
            guarded("strict still on -> no merge", False, rs_strict=True)
            guarded("GITOPS_APP_ID unset -> no merge", False, app_id="")
            guarded("pinned to the App, strict off -> merges", True)

            # A foreign merge landing during settle stops the merges after the first.
            open_only("p1", "p2")
            tick()
            gh.foreign_after_merge = "svc/foreign.txt"
            mode_settle(gh, Git(clone("settle")), "o/r", False)
            check("foreign merge mid-settle: merging stops, the rest waits for the next tick", gh.merged == [1], str(gh.merged))
            reset()

            # #16932: native auto-merge merges a carrier member just before the train's own merge call.
            def native_race(case):
                open_only("p1", "p2")
                tick()
                real = globals()["live_source_intent"]
                fired = []

                def racing(g, n, head, _real=real):
                    if n == 1 and not fired and gh.prs[1]["state"] == "open":
                        fired.append(n)
                        p = gh.prs[1]
                        if case in ("moved-open", "moved-merged"):
                            new = gh.g("commit-tree", f"{head}^{{tree}}", "-p", head, "-m", "moved").stdout.strip()
                            gh.g("branch", "-f", p["head"]["ref"], new)
                            p["head"]["sha"] = new
                        if case == "parent":   # something else lands first: merged over another main
                            gh.g("checkout", "-q", "-f", "main")
                            gh.g("commit", "-q", "--allow-empty", "-m", "foreign first")
                        if case in ("same", "moved-merged", "parent", "unmerged"):
                            gh.merge(1, p["head"]["sha"])
                        if case == "unmerged":  # closed, merged=False, though the sha is on main
                            p["merged"] = False
                        elif case == "closed":
                            p["state"] = "closed"
                        elif case == "off-main":
                            p["state"], p["merged"], p["merge_commit_sha"] = "closed", True, gh.g(
                                "commit-tree", f"{head}^{{tree}}", "-p", gh.main_sha(), "-m", "off main").stdout.strip()
                    return _real(g, n, head)
                globals()["live_source_intent"] = racing
                try:
                    s = mode_settle(gh, Git(clone("settle")), "o/r", False)
                finally:
                    globals()["live_source_intent"] = real
                merged = list(gh.merged)
                reset()
                return s, merged, bool(fired)
            s, m, fired = native_race("same")
            check("#16932: a member natively merged at the verified head -> the rest of the carrier still merges",
                  fired and m == [1, 2] and s.get("native_merged") == [1] and s["merged"] == [2], f"{fired} {m} {s.get('native_merged')}")
            s, m, fired = native_race("moved-merged")
            check("#16932 NEGATIVE: merged with a different head -> stop, nothing else merges",
                  fired and m == [1] and not s.get("native_merged"), f"{fired} {m}")
            s, m, fired = native_race("closed")
            check("#16932 NEGATIVE: closed but not merged -> stop", fired and m == [] and not s.get("native_merged"), f"{fired} {m}")
            s, m, fired = native_race("moved-open")
            check("#16932 NEGATIVE: head changed but still open -> stop", fired and m == [] and not s.get("native_merged"), f"{fired} {m}")
            s, m, fired = native_race("parent")
            check("#16932 NEGATIVE: merged over a main other than the expected one -> stop",
                  fired and m == [1] and not s.get("native_merged"), f"{fired} {m}")
            s, m, fired = native_race("unmerged")
            check("#16932 NEGATIVE: merged=False at the verified head -> stop",
                  fired and m == [1] and not s.get("native_merged"), f"{fired} {m}")
            s, m, fired = native_race("off-main")
            check("#16932 NEGATIVE: merged commit not on main -> stop", fired and m == [] and not s.get("native_merged"), f"{fired} {m}")

            # ---- strict lane (manual-lane PRs: executable .github/, generators, gates, inventory) ----
            def settle_now():
                return mode_settle(gh, Git(clone("settle")), "o/r", False)

            def strict_desc(n):
                return gh.app_statuses(gh.prs[n]["head"]["sha"]).get(STATUS_CONTEXT, ("", ""))

            # green + up to date with live main: the App posts the strict-lane status and merges it.
            open_only("pW")
            settle_now()
            st, desc = strict_desc(35)
            check("strict lane: manual-lane PR green on an up-to-date head merges with the strict-lane status",
                  gh.merged == [35] and st == "success" and desc.startswith("strict lane: green on an up-to-date head over main "),
                  f"merged={gh.merged} status={st} {desc!r}")
            reset()

            # green but BEHIND: update-branch, no merge, and only ONE manual-lane PR (the oldest) per tick.
            open_only("pW", "pW2", "p1")
            gh.prs[1]["auto_merge"] = None
            gh.merge(1, gh.prs[1]["head"]["sha"])          # main advances: pW and pW2 are now behind
            gh.merged.clear()
            s = settle_now()
            check("strict lane: green but behind gets update-branch, is not merged, one PR per tick (oldest)",
                  gh.merged == [] and gh.updates == [35] and not strict_desc(35)[0] and not strict_desc(36)[0]
                  and s.get("main_red", []) == [] and s.get("waiting", []) == [],
                  f"merged={gh.merged} updates={gh.updates} {s}")
            # The updated head runs its CI; while it does, settle reserves main (no train builds).
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            s = settle_now()
            check("strict lane: an updated head whose CI is running reserves main and is not merged",
                  s["in_flight"] and gh.merged == [] and gh.updates == [35], f"{s} merged={gh.merged} updates={gh.updates}")
            gh.head_checks.clear()
            settle_now()
            check("strict lane: once green on the updated head a later tick merges it", gh.merged == [35], str(gh.merged))
            gh.updates.clear()
            reset()

            # red manual-lane PR: nothing at all.
            open_only("pW")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"Validate manifests": "failure"}
            settle_now()
            check("strict lane: a red manual-lane PR gets no status, no update, no merge",
                  gh.merged == [] and gh.updates == [] and not strict_desc(35)[0], f"{gh.merged} {gh.updates} {strict_desc(35)}")
            gh.head_checks.clear()
            reset()

            # red ordinary PR: no strict lane (it is the train's, and red).
            open_only("p1")
            gh.head_checks[gh.prs[1]["head"]["sha"]] = {"Validate manifests": "failure"}
            settle_now()
            check("strict lane: a red non-manual-lane PR never takes the strict lane",
                  gh.merged == [] and gh.updates == [] and not strict_desc(1)[0], f"{gh.merged} {strict_desc(1)}")
            gh.head_checks.clear()
            reset()

            # agent-pr-guard refusal and a symlink: never the strict lane, even green and up to date.
            open_only("pW")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates / agent-pr-guard": "failure"}
            settle_now()
            check("strict lane: a PR refused by agent-pr-guard never takes the strict lane",
                  gh.merged == [] and gh.updates == [] and not strict_desc(35)[0], f"{gh.merged} {strict_desc(35)}")
            gh.head_checks.clear()
            reset()
            open_only("pS")
            settle_now()
            check("strict lane: a manual-lane PR adding a symlink never takes the strict lane",
                  gh.merged == [] and gh.updates == [] and not strict_desc(37)[0], f"{gh.merged} {strict_desc(37)}")
            reset()

            # A train in flight: the strict lane does not merge (the carrier's base must stay main).
            open_only("p1")
            tick()
            gh.pending_shas.update(c["head"]["sha"] for c in gh.carriers.values() if c["state"] == "open")
            open_only("pW")
            s = settle_now()
            check("strict lane: no strict-lane merge while a train is in flight",
                  s["in_flight"] and gh.merged == [] and not strict_desc(35)[0], f"{s} merged={gh.merged}")
            gh.pending_shas.clear()
            reset()

            # main moves between reading it and merging: re-checked, no merge.
            open_only("pW")
            real_main = gh.main_sha
            gh.main_sha = lambda: "f" * 40
            settle_now()
            gh.main_sha = real_main
            check("strict lane: main re-checked right before the merge; a moved main means no merge",
                  gh.merged == [], f"merged={gh.merged}")
            reset()

            # STARVATION (#13456): a strict-lane PR is updated, and while its CI runs a fast-lane PR
            # merges (GitHub auto-merge acts on the success status settle posts). The updated head is
            # behind again the moment its CI goes green, so it is re-updated — forever. The
            # reservation must hold the fast lane and train merges, not only other strict updates.
            def automerge_fast(s):
                for n in s["fast"]:
                    if gh.prs[n]["state"] == "open":
                        gh.merge(n, gh.prs[n]["head"]["sha"])

            gh.updates.clear()
            open_only("pW", "p1")
            gh.prs[1]["auto_merge"] = None
            gh.merge(1, gh.prs[1]["head"]["sha"])          # main advances: pW is behind
            gh.merged.clear()
            settle_now()                                   # tick 1: pW updated
            open_only("pF")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            s = settle_now()                               # tick 2: pW's CI runs; pF is fast-eligible
            automerge_fast(s)
            check("reservation: while the reserved head's CI runs the fast lane is held, main does not move",
                  s["in_flight"] and s["fast"] == [] and 34 not in gh.merged
                  and not gh.app_statuses(gh.prs[34]["head"]["sha"]).get(STATUS_CONTEXT),
                  f"{s} merged={gh.merged}")
            gh.head_checks.clear()
            s = settle_now()                               # tick 3: pW green on its updated head
            automerge_fast(s)
            check("reservation: the reserved PR merges after its CI, updated exactly once (no starvation)",
                  35 in gh.merged and gh.updates == [35], f"merged={gh.merged} updates={gh.updates}")
            s = settle_now()                               # tick 4: the held fast-lane PR goes
            automerge_fast(s)
            check("reservation: the held fast-lane candidate waits one tick, then goes",
                  34 in gh.merged, f"{s} merged={gh.merged}")
            gh.updates.clear()
            reset()

            # Two strict-lane PRs may both be current: the older one's pending CI reserves main, so
            # the younger green one must not merge and invalidate that CI. Regression for #13500.
            open_only("pW", "pW2")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            s = settle_now()
            check("reservation: a green strict PR cannot merge past another strict PR's pending reservation",
                  s["in_flight"] and gh.merged == [] and not strict_desc(36)[0],
                  f"{s} merged={gh.merged} #36={strict_desc(36)}")
            gh.head_checks.clear()
            s = settle_now()
            check("reservation: the strict reservation holder gets served before the younger green PR",
                  gh.merged == [35], f"{s} merged={gh.merged}")
            reset()

            # ---- STRICT CARRIER (ADR-0343 amendment 2026-11-05) ------------------------------------
            # Green strict-lane PRs BEHIND main ride one execution-free carrier built by settle; each
            # case names what a missing control would let through. The fixture CI (ci.py) judges the
            # carrier head exactly as it judges a train carrier; PR heads report green on their own.
            # Non-judge members: pW2 (36), pP1 (88), pP2 (90); judge members ride alone: pJ1/pJ2/pGY/pGA.
            def settle_strict(cap=8, judge_cap=STRICT_JUDGE_BATCH_CAP_DEFAULT):
                counter[0] += 1
                return mode_settle(gh, Git(clone("settle")), "o/r", False, run_id=str(counter[0]), attempt="1",
                                   strict_cap=cap, judge_cap=judge_cap)

            def strict_open():
                return [c for c in gh.carriers.values()
                        if c["state"] == "open" and STRICT_TRAIN_BRANCH_RE.fullmatch(c["head"]["ref"])]

            def advance_main():
                """A foreign merge: every strict PR cut from base0 is now behind main."""
                open_only("p1")
                gh.prs[1]["auto_merge"] = None
                gh.merge(1, gh.prs[1]["head"]["sha"])
                gh.merged.clear()
                gh.updates.clear()

            def carrier_members(c):
                ch = parse_own_chain(Git(origin), c["head"]["sha"])
                return [n for n, _ in ch[1]] if ch else None

            def sc_desc(n):
                return gh.app_statuses(gh.prs[n]["head"]["sha"]).get(STATUS_CONTEXT, ("", ""))

            # (1) batching on/off: two green strict PRs behind main and ONE slot. Cap 1 = today's behaviour
            # (update-branch of the oldest, no carrier); cap 8 = one strict carrier carrying both, no
            # update-branch, main reserved; the next tick merges both pinned with the carrier status.
            open_only("pW2", "pP1", "pF")
            advance_main()
            s = settle_strict(cap=1)
            check("strict carrier (1): cap 1 keeps today's behaviour — update-branch of the oldest, no strict carrier",
                  gh.updates == [36] and not strict_open() and gh.merged == [] and "strict_carrier" not in s,
                  f"updates={gh.updates} open={len(strict_open())} {s}")
            reset()
            open_only("pW2", "pP1", "pF")
            advance_main()
            s = settle_strict(cap=8)
            c1 = strict_open()
            check("strict carrier (1): cap 8 batches both behind-main strict PRs into one carrier, no update-branch, main reserved",
                  len(c1) == 1 and carrier_members(c1[0]) == [36, 88] and gh.updates == [] and gh.merged == []
                  and s["in_flight"] and s.get("strict_batch") == [36, 88] and s["fast"] == [],
                  f"open={len(c1)} members={[carrier_members(c) for c in c1]} updates={gh.updates} {s}")
            check("strict carrier (1): the carrier branch is train/strict-<run>-<attempt>, built by settle with its own commits only",
                  bool(c1) and STRICT_TRAIN_BRANCH_RE.fullmatch(c1[0]["head"]["ref"]) is not None
                  and gh.g("rev-list", "--count", f"main..{c1[0]['head']['sha']}").stdout.strip() == "2"
                  and gh.app_statuses(c1[0]["head"]["sha"]).get(RECORD_CONTEXT, ("",))[0] == "success",
                  f"{[c['head']['ref'] for c in c1]}")
            s = settle_strict(cap=8)
            check("strict carrier (1): green carrier — both members merge individually, pinned, with the strict-carrier status; "
                  "main's tree after the last merge is the carrier's tree",
                  gh.merged == [36, 88] and not strict_open() and "strict_tree_mismatch" not in s
                  and all(sc_desc(n)[0] == "success" and sc_desc(n)[1].startswith("strict lane: verified on strict carrier #")
                          for n in (36, 88)) and gh.updates == [],
                  f"merged={gh.merged} {sc_desc(36)} {sc_desc(88)} {s}")
            check("strict carrier (1): main's head is a strict merge (TRAIN_TURN / FAST_TURN semantics kept)",
                  last_merge_was_strict(gh, Git(origin), gh.main_sha()))
            s = settle_strict(cap=8)
            check("strict carrier (1): the held fast-lane PR goes once the strict lane is free",
                  s["fast"] == [34], str(s))
            reset()

            # (2) a JUDGE member (workflow, action, gates.yaml, rules.yaml, CODEOWNERS, privileged or train code)
            # rides ALONE: never with another member, oldest first.
            open_only("pW2", "pP1", "pJ1", "pJ2")
            advance_main()
            batches = [settle_strict(cap=8).get("strict_batch") for _ in range(3)]
            check("strict carrier (2): judge members never share a carrier — non-judge pair first, then each judge member "
                  "alone; a workflow member (the App cannot push it) takes update-branch instead",
                  batches == [[36, 88], [81], None] and gh.merged == [36, 88, 81] and gh.updates == [82],
                  f"batches={batches} merged={gh.merged} updates={gh.updates}")
            syn_refs = referenced_scripts(Git(origin), gh.main_sha())
            for f in (".github/workflows/ci.yml", ".github/workflows/_service-ci.yml", ".github/actions/x/action.yml",
                      ".github/gates/gates.yaml", "openbank-libs/governance/rules.yaml", ".github/CODEOWNERS",
                      ".github/scripts/merge-train.py", ".github/scripts/check-adr-registry.sh", ".github/workflows/security.yml",
                      "docs/x.md", "openbank-libs/x.kt",                       # inverse rule: not under .github/scripts
                      ".github/scripts/run-gates.py", ".github/scripts/lib/foo.sh"):   # named by path / bare basename
                check(f"judge_path: {f} rides alone", judge_path(f, syn_refs))
            for f in (".github/scripts/two.py", ".github/scripts/check-unrelated.py", ".github/scripts/lib/x.sh"):
                check(f"judge_path: {f} may be batched (unreferenced, under .github/scripts)", not judge_path(f, syn_refs))
            check("judge_path: no reference set (or the error sentinel) batches nothing — fail closed",
                  judge_path(".github/scripts/two.py", None) and judge_path(".github/scripts/two.py", ({"*"}, set())))
            # Live ticks: run-gates.py (named by path) and lib/foo.sh (named only by bare basename) are judge
            # members. At judge cap 1 each rides alone (the rule before 2026-11-15, still the rollback); at the
            # default cap they share one carrier with the unreferenced pW2/pP1, every member path-disjoint.
            reset()
            open_only("pW2", "pP1", "pRG", "pFoo")
            advance_main()
            batches2 = [settle_strict(cap=8, judge_cap=1).get("strict_batch") for _ in range(3)]
            check("strict carrier (2): judge cap 1 — a script a workflow names by path or bare basename rides alone",
                  batches2 == [[36, 88], [91], [92]] and gh.merged == [36, 88, 91],
                  f"batches={batches2} merged={gh.merged}")
            reset()
            open_only("pW2", "pP1", "pRG", "pFoo")
            advance_main()
            batches2 = [settle_strict(cap=8).get("strict_batch") for _ in range(3)]
            check("strict carrier (2): at the default judge cap a CHECKER a workflow names still rides alone "
                  "(configuration judge)", batches2 == [[36, 88], [91], [92]] and gh.merged == [36, 88, 91],
                  f"batches={batches2} merged={gh.merged}")
            reset()
            syn_main = gh.main_sha()
            syn_mods = shareable_modules(Git(origin), syn_main)
            check("shareable_modules: the synthetic leaf module shares", "openbank-svc" in syn_mods, str(sorted(syn_mods)))
            check("shareable_modules: both ends of a cross-module test read are NOT shareable",
                  not ({"openbank-mread", "openbank-mtarget"} & syn_mods), str(sorted(syn_mods)))
            check("shareable_modules: a read from a test whose path contains ':' still excludes both ends (NUL-separated parse)",
                  not ({"openbank-mcolr", "openbank-mcolt"} & syn_mods), str(sorted(syn_mods)))
            check("shareable_modules: a module whose test climbs out with parentFile is NOT shareable (target unknown: "
                  "the reader rides alone)", "openbank-mwalk" not in syn_mods, str(sorted(syn_mods)))
            for f in ("build-logic/src/main/kotlin/X.kt", "openbank-libs-detekt-rules/src/main/kotlin/X.kt",
                      "openbank-libs-runtime/src/main/kotlin/X.kt", "openbank-arch-tests/src/test/kotlin/X.kt",
                      "openbank-other/src/main/kotlin/X.kt"):            # not a shareable module of this tree
                check(f"config_judge_path: {f} (module consumed by builds or analysis) rides alone",
                      config_judge_path(f, syn_refs, syn_mods))
            real_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            real_mods = shareable_modules(Git(real_root), "HEAD")
            check("shareable_modules: on the real tree the libs, detekt rules and consumed services are NOT shareable; "
                  "a leaf service is",
                  "openbank-ap2-service" in real_mods
                  and not ({"openbank-libs-detekt-rules", "openbank-libs-runtime", "openbank-libs-testing",
                            "openbank-client-transaction", "openbank-card-processing-service",
                            "openbank-ledger-service", "openbank-infra", "openbank-contracts",
                            "openbank-campaign-service", "openbank-consent-service", "openbank-aml-service",
                            "openbank-audit-service", "openbank-domestic-payment", "openbank-billing-service",
                            "openbank-finrep-service", "openbank-vop-service"} & real_mods),
                  str(sorted(real_mods)))
            for f in (".github/scripts/run-gates.py", ".github/scripts/lib/foo.sh", ".github/workflows/ci.yml",
                      GATES_YAML, "openbank-libs/governance/rules.yaml", ".github/actions/x/action.yml",
                      "build-logic/x.kts", "svc/build.gradle.kts", "svc/detekt-baseline.xml", "openbank-x/package.json",
                      ".gitleaksignore", ".semgrep.yml", ".semgrep/rules/x.yml", ".trivyignore", ".editorconfig",
                      "svc/src/main/resources/application.yaml", "svc/src/test/resources/x.json", "svc/x.txt",
                      "openbank-x/src/main/kotlin/../x.kt", "a/.hidden/src/main/kotlin/X.kt", "docs/adr/x.yaml", "Makefile",
                      "docs/x.md", "docs/threat-models/svc.md", "openbank-svc/src/test/kotlin/XTest.kt",
                      "openbank-svc/src/integrationTest/kotlin/XIT.kt", "openbank-svc/src/testFixtures/kotlin/F.kt",
                      "openbank-svc/src/e2e/kotlin/E.kt", "openbank-svc/src/main/resources/x.kt", "docs/adr/0001-x.md", "buildSrc/src/main/kotlin/X.kt",
                      "build-logic/src/test/kotlin/XTest.kt", "openbank-libs/src/test/kotlin/ArchTest.kt"):
                check(f"config_judge_path: {f} configures a verdict — rides alone", config_judge_path(f, syn_refs, syn_mods))
            for f in ("openbank-mco/src/main/kotlin/co.kt", "openbank-svc/src/main/kotlin/com/x/X.kt",
                      ".github/scripts/two.py"):
                check(f"config_judge_path: {f} is not verdict configuration", not config_judge_path(f, syn_refs, syn_mods))
            own_syn = train_code_paths(Git(origin), syn_main)
            check("train_code_paths: the name rule matches the train's files and nothing else; no checker is train code",
                  all(TRAIN_CODE_RE.fullmatch(f) for f in (".github/scripts/merge-train.py", ".github/scripts/merge_train_carrier.py",
                                                           ".github/workflows/merge-train.yml", ".github/scripts/test-merge-train-x.py"))
                  and not any(TRAIN_CODE_RE.fullmatch(f) for f in (".github/scripts/run-gates.py", "docs/merge-train.md",
                                                                   ".github/scripts/lib/merge-train.py"))
                  and ".github/scripts/run-gates.py" not in own_syn, str(sorted(own_syn)))
            own_real = train_code_paths(Git(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))), "HEAD")
            check("train_code_paths: on the real tree it finds the carrier library, the stall watch and the tests",
                  {".github/scripts/merge-train.py", ".github/scripts/merge_train_carrier.py",
                   ".github/scripts/merge-train-stall-watch.py", ".github/workflows/merge-train.yml"} <= own_real,
                  str(sorted(own_real)))

            # ---- DISJOINT JUDGE BATCHING (ADR-0343 amendment 2026-11-15) ---------------------------------
            # (16) three judge members that configure no verdict, pairwise disjoint, form ONE carrier (before
            # the amendment each rode alone: three carriers, ~3 x 30-40 min); the carrier merges all three.
            open_only("pCO", "pS1", "pS2")
            advance_main()
            s1 = settle_strict(cap=8)
            c16 = strict_open()
            s2 = settle_strict(cap=8)
            check("strict carrier (16): three disjoint judge members form one strict carrier and all merge",
                  s1.get("strict_batch") == [71, 75, 76] and len(c16) == 1 and carrier_members(c16[0]) == [71, 75, 76]
                  and gh.merged == [71, 75, 76] and gh.updates == [] and "strict_tree_mismatch" not in s2,
                  f"{s1.get('strict_batch')} merged={gh.merged} updates={gh.updates} {s2}")
            reset()
            # (16b) the judge cap bounds the carrier: five disjoint members, three of them judge -> four ride.
            open_only("pW2", "pP1", "pCO", "pS1", "pS2")
            advance_main()
            s1 = settle_strict(cap=8)
            check("strict carrier (16b): a carrier holding a judge member is capped at 4 — the fifth waits",
                  s1.get("strict_batch") == [36, 71, 75, 76], str(s1.get("strict_batch")))
            reset()

            # (17) two judge members that share a path are NEVER batched, even though merge-tree merges them
            # cleanly (they add an identical file): each takes its own carrier.
            open_only("pO1", "pO2")
            advance_main()
            b17 = [settle_strict(cap=8).get("strict_batch") for _ in range(4)]
            check("strict carrier (17): overlapping judge members are never batched — one carrier each",
                  b17[:2] == [[73], [74]] and not any(b and len(b) > 1 for b in b17) and gh.merged == [73, 74],
                  f"batches={b17} merged={gh.merged}")
            reset()
            # (17b) a judge member sharing a path with a NON-judge member ahead of it waits, while the
            # non-judge pair DOES ride (a carrier is built: the check cannot pass on an empty tick).
            gh.g("branch", "-f", "pSh", "pW2")
            gh.g("checkout", "-q", "-f", "pSh")
            pathlib.Path(origin, ".github/scripts/o1.py").write_text("print('o1')\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "pSh: two.py + o1.py")
            gh.g("checkout", "-q", "-f", "main")
            open_only("pO1", "pP1")
            gh.add_pr(191, "pSh", "2026-01-01")
            advance_main()
            s1 = settle_strict(cap=8)
            c17 = strict_open()
            check("strict carrier (17b): a judge member sharing a path with a non-judge member ahead of it waits; "
                  "the non-judge members ride",
                  s1.get("strict_batch") == [191, 88] and len(c17) == 1 and carrier_members(c17[0]) == [191, 88],
                  f"{s1.get('strict_batch')} open={[carrier_members(c) for c in c17]}")
            reset()

            # (18) a red judge carrier: the existing halving isolates the one red member; the rest merge.
            gh.reruns.clear()
            open_only("pCO", "pJbad", "pS1", "pS2")
            advance_main()
            first = settle_strict(cap=8).get("strict_batch")
            culprits: list[int] = []
            for _ in range(10):
                s = settle_strict(cap=8)
                culprits += s["culprits"]
                if not strict_open() and 72 in culprits:
                    break
            check("strict carrier (18): a red judge carrier halves; the red member is the culprit, the others merge",
                  first == [71, 72, 75, 76] and culprits == [72] and sorted(gh.merged) == [71, 75, 76]
                  and sc_desc(72)[0] == "failure" and sc_desc(72)[1].startswith(CULPRIT_PREFIX),
                  f"first={first} culprits={culprits} merged={gh.merged} {sc_desc(72)}")
            gh.reruns.clear()
            reset()

            # (18b) RED ONLY COMBINED: each half is green alone. The first half merges; the second is rebuilt
            # over the NEW main (which now holds the first) and re-verified there — red — so it is named.
            gh.reruns.clear()
            open_only("pCA", "pCB")
            advance_main()
            first = settle_strict(cap=8).get("strict_batch")
            culprits = []
            bases: list[str] = []
            for _ in range(10):
                for c in strict_open():
                    bases.append(gh.g("rev-parse", f"{c['head']['sha']}~{len(carrier_members(c) or [])}").stdout.strip())
                s = settle_strict(cap=8)
                culprits += s["culprits"]
                if not strict_open() and culprits:
                    break
            main_now = gh.main_sha()
            ca_on_main = gh.g("cat-file", "-e", f"{main_now}:openbank-mca/src/main/kotlin/ca.kt", check=False).returncode == 0
            check("strict carrier (18b): red only combined — first half merges, second half re-verified over the new main "
                  "and named; nothing red reaches main",
                  first == [79, 80] and gh.merged == [79] and culprits == [80] and ca_on_main
                  and gh.g("cat-file", "-e", f"{main_now}:openbank-mcb/src/main/kotlin/cb.kt", check=False).returncode != 0
                  and len(set(bases)) >= 2,
                  f"first={first} merged={gh.merged} culprits={culprits} bases={[b[:8] for b in bases]}")
            gh.reruns.clear()
            reset()

            # (20) MASKING (review of #16290): an older member B red over main, a newer J relaxing the checker
            # that fails it. Batched, the carrier is green and both merge — nothing bisects a green carrier.
            # J configures a verdict, so it rides alone: B is judged under main's checker and named.
            gh.reruns.clear()
            open_only("pJbad", "pRelax")
            advance_main()
            batches20, culprits = [], []
            for _ in range(8):
                s = settle_strict(cap=8)
                batches20.append(s.get("strict_batch"))
                culprits += s["culprits"]
            check("strict carrier (20): a checker-RELAXING member never rides with the member it would mask; "
                  "the older red member is named, never merged",
                  not any(b and 72 in b and 77 in b for b in batches20) and 72 not in gh.merged and culprits == [72]
                  and 77 in gh.merged, f"batches={batches20} merged={gh.merged} culprits={culprits}")
            gh.reruns.clear()
            reset()
            # (21) TIGHTENING: J tightens the checker so that B (green alone) fails only in combination. J rides
            # alone, after B: B merges green, J is re-verified over a main holding B and named.
            open_only("pCO", "pTight")
            advance_main()
            batches21, culprits = [], []
            for _ in range(8):
                s = settle_strict(cap=8)
                batches21.append(s.get("strict_batch"))
                culprits += s["culprits"]
            check("strict carrier (21): a checker-TIGHTENING member never rides with the member it fails; the "
                  "older member merges, the tightening one is named over the new main",
                  not any(b and 71 in b and 78 in b for b in batches21) and 71 in gh.merged and 78 not in gh.merged
                  and culprits == [78], f"batches={batches21} merged={gh.merged} culprits={culprits}")
            gh.reruns.clear()
            reset()

            # (22) a RELAXING detekt rule (a checker written in Kotlin) never rides with the older member it
            # would turn green: the rule module is consumed by a build file, so it is not shareable.
            gh.reruns.clear()
            open_only("pJbad")
            gh.add_pr(numbers["pDet"], "pDet", "2026-02-05")      # NEWER than the violator, as in the review
            advance_main()
            b22, culprits = [], []
            for _ in range(8):
                s = settle_strict(cap=8)
                b22.append(s.get("strict_batch"))
                culprits += s["culprits"]
            check("strict carrier (22): a relaxing detekt-rule member never rides with the violator it would mask; "
                  "the older violator is named, never merged",
                  not any(b and 72 in b and 5 in b for b in b22) and 72 not in gh.merged and culprits == [72]
                  and 5 in gh.merged, f"batches={b22} merged={gh.merged} culprits={culprits}")
            gh.reruns.clear()
            reset()
            # (23) COMPANION FILE: money-path code without a threat model, and a member adding that threat model.
            # A carrier's diff-scoped gate reads the UNION diff, so batched the code would pass on the other
            # member's doc. Docs are not shareable (config_judge_path pins docs/threat-models above); here
            # docs/ is also a regen input, so this end-to-end case holds on either builder.
            gh.reruns.clear()
            open_only("pMoney", "pTM")
            advance_main()
            b23, culprits = [], []
            for _ in range(8):
                s = settle_strict(cap=8)
                b23.append(s.get("strict_batch"))
                culprits += s["culprits"]
            check("strict carrier (23): a companion threat model never rides with the code it would excuse",
                  not any(b and 6 in b and 7 in b for b in b23) and 6 not in gh.merged and culprits == [6]
                  and 7 in gh.merged, f"batches={b23} merged={gh.merged} culprits={culprits}")
            gh.reruns.clear()
            reset()
            # (24) companions inside ONE module (code in src/main, a test in src/test): disjoint files, same
            # module -> never batched.
            open_only("pCompA", "pCompB")
            advance_main()
            b24 = [settle_strict(cap=8).get("strict_batch") for _ in range(4)]
            check("strict carrier (24): two judge members in the same module never share a carrier",
                  not any(b and len(b) > 1 for b in b24) and sorted(gh.merged) == [8, 9], f"batches={b24} merged={gh.merged}")
            reset()

            # (25) a CROSS-MODULE TEST READ: a member relaxing the test that pins another module's source never
            # rides with a member changing that source — they are module-disjoint, yet one judges the other.
            open_only("pPinT", "pPinR")
            advance_main()
            b25 = [settle_strict(cap=8).get("strict_batch") for _ in range(4)]
            check("strict carrier (25): a member whose module's test reads another module never rides with that module",
                  not any(b and 10 in b and 13 in b for b in b25) and sorted(gh.merged) == [10, 13],
                  f"batches={b25} merged={gh.merged}")
            reset()

            # (26) a test that CLIMBS out (generateSequence { it.parentFile }) names no `../openbank-<m>`; the reader
            # must still never ride with a change to what it reads.
            open_only("pWT", "pWR")
            advance_main()
            b26 = [settle_strict(cap=8).get("strict_batch") for _ in range(4)]
            check("strict carrier (26): a member whose module's test climbs out with parentFile never shares a carrier",
                  not any(b and 14 in b and 15 in b for b in b26) and sorted(gh.merged) == [14, 15],
                  f"batches={b26} merged={gh.merged}")
            reset()

            # (27) the member ITSELF adds a cross-module reading test in a module the base tree calls shareable:
            # it rides alone, never with the module it reads.
            open_only("pCO", "pAddR")
            advance_main()
            b27 = [settle_strict(cap=8).get("strict_batch") for _ in range(4)]
            check("strict carrier (27): a member adding a test that reads another module rides alone",
                  not any(b and 71 in b and 16 in b for b in b27) and sorted(gh.merged) == [16, 71],
                  f"batches={b27} merged={gh.merged}")
            check("member_test_reaches_out: a `.parent` climb (portable regex, no \\b) and an integrationTest reading out",
                  member_test_reaches_out(Git(origin), gh.g("rev-parse", "pAddP").stdout.strip(), ["openbank-ms2/src/test/kotlin/RootTest.kt"])
                  and member_test_reaches_out(Git(origin), gh.g("rev-parse", "pAddI").stdout.strip(), ["openbank-mca/src/integrationTest/kotlin/ReadIT.kt"]))
            check("member_test_reaches_out: own-module token is fine; another module, a climb or `..` is not",
                  not member_test_reaches_out(Git(origin), gh.prs[71]["head"]["sha"], ["openbank-mco/src/main/kotlin/co.kt"])
                  and member_test_reaches_out(Git(origin), gh.prs[16]["head"]["sha"], ["openbank-ms1/src/test/kotlin/NewPinTest.kt"]))
            reset()

            # (28) a member adding a `.parent` climb rides alone, never with the module beside it.
            open_only("pCO", "pAddP")
            advance_main()
            b28 = [settle_strict(cap=8).get("strict_batch") for _ in range(4)]
            check("strict carrier (28): a member adding a `.parent.parent` climb in its test rides alone",
                  not any(b and 71 in b and 17 in b for b in b28) and sorted(gh.merged) == [17, 71],
                  f"batches={b28} merged={gh.merged}")
            reset()

            # (19) the fast lane still gets its turn: a held fast-lane PR goes once the judge carrier merged.
            open_only("pCO", "pS1", "pF")
            advance_main()
            s1 = settle_strict(cap=8)
            s2 = settle_strict(cap=8)
            s3 = settle_strict(cap=8)
            check("strict carrier (19): the fast lane is held while a judge carrier runs and served once it merged",
                  s1.get("strict_batch") == [71, 75] and s1["fast"] == [] and gh.merged == [71, 75]
                  and last_merge_was_strict(gh, Git(origin), gh.main_sha()) and s3["fast"] == [34],
                  f"{s1.get('strict_batch')} s1.fast={s1['fast']} s2.fast={s2['fast']} s3={s3} merged={gh.merged}")
            reset()

            # (3) conflicts: a member conflicting with the members ahead of it is dropped from this carrier
            # (no notice: it is not the author's fault); one conflicting with MAIN is told once and never rides.
            open_only("pW2", "pPc", "pP1")
            advance_main()
            s = settle_strict(cap=8)
            c = strict_open()
            check("strict carrier (3): a member conflicting with the members ahead of it is dropped, the rest ride",
                  len(c) == 1 and carrier_members(c[0]) == [36, 88] and 85 not in (s.get("strict_batch") or [])
                  and not any(n == 85 for n, _ in gh.comments),
                  f"members={[carrier_members(x) for x in c]} comments={[n for n, _ in gh.comments]}")
            reset()
            open_only("pW2", "pP1")
            gh.g("checkout", "-q", "-f", "main")
            pathlib.Path(origin, ".github/scripts/two.py").parent.mkdir(parents=True, exist_ok=True)
            pathlib.Path(origin, ".github/scripts/two.py").write_text("print('main')\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main edits the script pW2 edits: pW2 conflicts with main")
            s = settle_strict(cap=8)
            c = strict_open()
            check("strict carrier (3): a member conflicting with main is told once (notice) and never rides",
                  36 not in (s.get("strict_batch") or []) and NOTICE_CONTEXT in gh.app_statuses(gh.prs[36]["head"]["sha"])
                  and any(n == 36 for n, _ in gh.comments) and not any(36 in (carrier_members(x) or []) for x in c),
                  f"{s} notice={gh.app_statuses(gh.prs[36]['head']['sha']).get(NOTICE_CONTEXT)}")
            reset()

            # (4) a member removed the producer of a required context: the carrier never reports it, so it
            # never merges — pending holds the lane until the ceiling, then no verdict, nobody blamed, and
            # the members leave the carrier lane on these heads (update-branch lane).
            open_only("pW2", "pP1")
            advance_main()
            settle_strict(cap=8)
            gh.carrier_override = {"derived": "absent"}           # the context is never reported on any carrier
            s1 = settle_strict(cap=8)
            s2 = settle_strict(cap=8)
            c = strict_open()
            check("strict carrier (4): a never-reported required context keeps the carrier pending — nothing merges, no culprit",
                  len(c) == 1 and s1["in_flight"] and s2["in_flight"] and gh.merged == [] and s2["culprits"] == []
                  and gh.updates == [], f"{s1} {s2} merged={gh.merged} updates={gh.updates}")
            ct4 = int(gh.g("show", "-s", "--format=%ct", c[0]["head"]["sha"]).stdout.strip()) if c else 0
            heads4 = {n: gh.prs[n]["head"]["sha"] for n in (36, 88)}   # the heads that rode; 36's is updated below
            real_time_sc = time.time
            time.time = lambda: ct4 + RESERVATION_CEILING_S + 60
            try:
                s3 = settle_strict(cap=8)
            finally:
                time.time = real_time_sc
            check("strict carrier (4): past the ceiling the carrier closes with no verdict; members fall back to update-branch",
                  not strict_open() and gh.merged == [] and s3["culprits"] == [] and s3["bisected"] == []
                  and all(RELEASED_CONTEXT in gh.app_statuses(h) for h in heads4.values())
                  and gh.updates == [36], f"{s3} merged={gh.merged} updates={gh.updates}")
            gh.carrier_override = {}
            gh.updates.clear()
            reset()

            # (5) gates.yaml id-union guard: a member whose merge retires a gate id is skipped (it is a judge
            # member, so alone it falls to today's update-branch path); a member that only ADDS an id rides
            # alone as a judge carrier (control, must pass).
            open_only("pGY", "pW2", "pP1")
            advance_main()
            s1 = settle_strict(cap=8)                       # [36, 88]; pGY (judge) waits
            s2 = settle_strict(cap=8)                       # merged; pGY alone: id loss -> skipped -> update-branch
            check("strict carrier (5): a gates.yaml member retiring a `- id:` never rides — skipped, update-branch as today",
                  s1.get("strict_batch") == [36, 88] and gh.merged == [36, 88] and not strict_open()
                  and "strict_carrier" not in s2 and gh.updates == [83],
                  f"{s1.get('strict_batch')} merged={gh.merged} open={len(strict_open())} updates={gh.updates} {s2}")
            gh.updates.clear()
            reset()
            open_only("pGA")
            advance_main()
            s = settle_strict(cap=8)
            c = strict_open()
            merged_ids = gate_ids(gh.g("show", f"{c[0]['head']['sha']}:{GATES_YAML}").stdout) if c else set()
            check("strict carrier (5): a gates.yaml member that only adds an id rides alone (control); the merged id set is the union",
                  len(c) == 1 and carrier_members(c[0]) == [84] and merged_ids == {"g-one", "g-two", "g-three"} and gh.updates == [],
                  f"members={[carrier_members(x) for x in c]} ids={merged_ids}")
            check("gate_ids: line scan reads `- id:` entries only",
                  gate_ids(SYN_GATES_YAML + "    # - id: commented\n  - id: g-x # trailing\n") == {"g-one", "g-two", "g-x"})
            reset()

            # (6) a member whose change needs regeneration (touches a regen-inventory input or a derived
            # output) never rides a strict carrier — it keeps today's lane, where main's gates prove it.
            open_only("pW2", "pPR", "pP1")
            advance_main()
            s = settle_strict(cap=8)
            c = strict_open()
            check("strict carrier (6): a member needing regeneration is refused from the carrier; the others ride",
                  len(c) == 1 and carrier_members(c[0]) == [36, 88] and 86 not in (s.get("strict_batch") or []),
                  f"members={[carrier_members(x) for x in c]} {s}")
            check("needs_regeneration: inventory input and derived output are both refused, a plain script is not",
                  needs_regeneration(["docs/w3.md"], ["docs/"], []) is not None
                  and needs_regeneration(["derived/index.txt"], [], ["derived/*"]) is not None
                  and needs_regeneration([".github/scripts/p1.py"], ["docs/"], ["derived/*"]) is None)
            reset()

            # (7) main moved under an open strict carrier: rejected (no merge, nobody blamed) and rebuilt
            # over the new main in the same tick.
            open_only("pW2", "pP1")
            advance_main()
            settle_strict(cap=8)
            old = strict_open()[0]["number"] if strict_open() else None
            open_only("p2")
            gh.prs[2]["auto_merge"] = None
            gh.merge(2, gh.prs[2]["head"]["sha"])       # foreign merge: main moved
            gh.merged.clear()
            s = settle_strict(cap=8)
            c = strict_open()
            ch = parse_own_chain(Git(origin), c[0]["head"]["sha"]) if c else None
            check("strict carrier (7): main moved since publish — carrier rejected, nobody blamed, rebuilt over live main",
                  old in s["rejected"] and gh.merged == [] and s["culprits"] == [] and len(c) == 1
                  and c[0]["number"] != old and ch is not None and ch[0] == gh.main_sha() and ch[1] and [n for n, _ in ch[1]] == [36, 88],
                  f"{s} open={[x['number'] for x in c]}")
            reset()

            # (8) red carrier of four: halved across ticks; the innocents are rebatched and merge; the one
            # red member is isolated as the culprit on a one-member strict carrier.
            gh.reruns.clear()
            open_only("pW2", "pP1", "pPbad", "pP2")
            advance_main()
            s1 = settle_strict(cap=8)                       # carrier [36, 88, 89, 90], red
            s2 = settle_strict(cap=8)                       # judged red: bisect size 2; carrier [36, 88]
            check("strict carrier (8): a red four-member carrier halves — bisect size 2 on every member, nobody blamed",
                  s1.get("strict_batch") == [36, 88, 89, 90] and s2["bisected"] == [[36, 88, 89, 90]] and s2["culprits"] == []
                  and s2.get("strict_batch") == [36, 88] and gh.merged == [],
                  f"{s1.get('strict_batch')} {s2}")
            s3 = settle_strict(cap=8)                       # [36, 88] green: merged; carrier [89, 90]
            s4 = settle_strict(cap=8)                       # [89, 90] red: bisect 1; carrier [89]
            s5r = settle_strict(cap=8)                      # [89] red alone, green on its head and main: ONE rerun
            check("strict carrier (8): a lone member green on its head and on main is re-run once before blame (#15420)",
                  s5r["culprits"] == [] and s5r["rerun"] and len(gh.reruns) == 1 and sc_desc(89)[0] != "failure"
                  and len(strict_open()) == 1 and carrier_members(strict_open()[0]) == [89],
                  f"{s5r} reruns={gh.reruns} {sc_desc(89)}")
            s5 = settle_strict(cap=8)                       # [89] still red after the rerun: culprit; carrier [90]
            s6 = settle_strict(cap=8)                       # [90] green: merged
            check("strict carrier (8): innocents rebatched and merged, the red member isolated as the culprit",
                  gh.merged == [36, 88, 90] and s5["culprits"] == [89] and sc_desc(89)[0] == "failure" and len(gh.reruns) == 1
                  and sc_desc(89)[1].startswith(CULPRIT_PREFIX) and (89, CULPRIT_MESSAGE) in gh.comments
                  and s3.get("strict_batch") == [89, 90] and s4.get("strict_batch") == [89] and s5.get("strict_batch") == [90],
                  f"merged={gh.merged} s3={s3.get('strict_batch')} s4={s4.get('strict_batch')} s5={s5.get('strict_batch')} s6={s6}")
            s7 = settle_strict(cap=8)
            check("strict carrier (8): the culprit waits for a push — no further carrier, no update-branch",
                  not strict_open() and gh.updates == [] and 89 not in gh.merged, f"{s7} updates={gh.updates}")
            gh.reruns.clear()
            reset()

            # (9) a member's head or source intent changed while the carrier ran: not merged.
            open_only("pW2", "pP1")
            advance_main()
            settle_strict(cap=8)
            gh.g("checkout", "-q", "-f", "-B", "pW2-pushed", "pW2")
            pathlib.Path(origin, ".github/scripts/two.py").write_text("print(2)\n# pushed\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "pushed")
            gh.g("checkout", "-q", "-f", "main")
            pushed = gh.g("rev-parse", "pW2-pushed").stdout.strip()
            gh.prs[36]["head"].update(ref="pW2-pushed", sha=pushed)
            s = settle_strict(cap=8)
            c = strict_open()
            ch = parse_own_chain(Git(origin), c[0]["head"]["sha"]) if c else None
            check("strict carrier (9): a member pushed since the carrier was built is not merged (its carrier verdict is void); "
                  "the carrier is rebuilt from the NEW head",
                  gh.merged == [] and len(c) == 1 and ch is not None and ch[1] and ch[1][0] == (36, pushed),
                  f"merged={gh.merged} {s} chain={ch and ch[1]}")
            reset()
            open_only("pW2", "pP1")
            advance_main()
            settle_strict(cap=8)
            gh.prs[88]["auto_merge"] = None                 # intent changed: disarmed
            s = settle_strict(cap=8)
            check("strict carrier (9): a member disarmed since the carrier was built is not merged; the one ahead of it is "
                  "(a stop mid-loop lands a verified prefix)",
                  gh.merged == [36] and 88 not in gh.merged, f"merged={gh.merged} {s}")
            reset()

            # (10) the train's own script as a member: a judge member, it rides a strict carrier ALONE and is
            # NEVER executed by settle — the carrier is built with merge-tree/commit-tree only. Control
            # first: the member's file does leave the marker when something runs it.
            marker = os.path.join(root, "strict-member-ran")
            wt = tempfile.mkdtemp(dir=root)
            gh.g("worktree", "add", "-q", "--detach", wt, "pJ1")
            subprocess.run([sys.executable, "-I", ".github/scripts/merge-train.py"], cwd=wt, check=False, capture_output=True)
            gh.g("worktree", "remove", "--force", wt)
            check("strict carrier (10) control: the member's merge-train.py leaves its marker when executed",
                  os.path.exists(marker))
            if os.path.exists(marker):
                os.unlink(marker)
            open_only("pJ1")
            advance_main()
            s1 = settle_strict(cap=8)
            c = strict_open()
            head_in_carrier = gh.g("show", f"{c[0]['head']['sha']}:.github/scripts/merge-train.py").stdout if c else ""
            s2 = settle_strict(cap=8)
            check("strict carrier (10): a merge-train.py member rides a strict carrier alone, merges, and was never executed by settle",
                  s1.get("strict_batch") == [81] and "strict-member-ran" in head_in_carrier and gh.merged == [81]
                  and not os.path.exists(marker), f"{s1} {s2} merged={gh.merged} ran={os.path.exists(marker)}")
            reset()

            # (11) a symlink/gitlink or a control-character path never rides a strict carrier: neither enters
            # the strict list, and the builder refuses a tree that gains a special entry even when handed one.
            open_only("pW2", "pS", "pPx", "pP1")
            advance_main()
            s = settle_strict(cap=8)
            c = strict_open()
            check("strict carrier (11): a symlink member and a control-character member are never batched, updated or merged",
                  len(c) == 1 and carrier_members(c[0]) == [36, 88] and gh.updates == [] and gh.merged == []
                  and not any(n in (37, 87) for n in (s.get("strict_batch") or [])),
                  f"members={[carrier_members(x) for x in c]} {s}")
            g11 = Git(origin)
            b11 = g11("rev-parse", "main").stdout.strip()
            views11 = [{"number": 36, "head_sha": g11("rev-parse", "pW2").stdout.strip(), "files": [".github/scripts/two.py"], "app": {}},
                       {"number": 37, "head_sha": g11("rev-parse", "pS").stdout.strip(), "files": [".github/scripts/check-s.py", "docs-s-link"], "app": {}},
                       {"number": 88, "head_sha": g11("rev-parse", "pP1").stdout.strip(), "files": [".github/scripts/p1.py"], "app": {}}]
            built = build_strict_carrier(g11, b11, views11, 8, lambda _f: False, [], [])
            check("strict carrier (11): the builder itself drops a member whose tree adds a symlink (defence in depth)",
                  built is not None and [n for n, _ in built[1]] == [36, 88], str(built and built[1]))
            reset()

            # (12) after the last member merged, main's tree must be the carrier's tree. A squash that resolves
            # differently from merge-tree (simulated: each merge lands with an extra file) is told, and no further
            # strict carrier is built that tick; every member still merged verified, nobody is blamed.
            open_only("pW2", "pP1", "pP2")
            advance_main()
            settle_strict(cap=2)                            # carrier [36, 88]; pP2 waits
            real_merge = gh.merge

            def merge_with_extra(n, head):
                sha = real_merge(n, head)
                if sha is None:
                    return None
                pathlib.Path(origin, "docs", f"extra-{n}.md").write_text("x\n")
                gh.g("add", "-A")
                gh.g("commit", "-q", "--amend", "--no-edit")
                return gh.main_sha()
            gh.merge = merge_with_extra
            try:
                s = settle_strict(cap=2)
            finally:
                gh.merge = real_merge
            check("strict carrier (12): a post-merge tree mismatch is told and stops further batching this tick; members merged, nobody blamed",
                  gh.merged == [36, 88] and s.get("strict_tree_mismatch") is not None and not strict_open()
                  and s["culprits"] == [] and 90 not in (s.get("strict_batch") or []),
                  f"merged={gh.merged} {s} open={len(strict_open())}")
            reset()

            # (13) serving order: a member that can only take the update-branch lane, FIRST in line, is not
            # overtaken by a carrier (expedite is how a workflow member gets first here).
            def first_in_line_updated(name, *others):
                open_only(name, *others)
                gh.prs[numbers[name]]["labels"] = [{"name": EXPEDITE_LABEL}]
                advance_main()
                s13 = settle_strict(cap=8)
                return not strict_open() and gh.updates == [numbers[name]], f"open={len(strict_open())} updates={gh.updates} {s13}"
            ok, why = first_in_line_updated("pJ2", "pW2", "pP1")
            check("strict carrier (13): an expedited workflow member is served first, no carrier overtakes it", ok, why)
            reset()
            ok, why = first_in_line_updated("pPR", "pW2", "pP1")
            check("strict carrier (13): a first-in-line member needing regeneration is served first, no carrier overtakes it", ok, why)
            reset()
            open_only("pW2", "pP1", "pP2")      # two more behind it, or nothing could overtake it
            advance_main()
            gh.post_status(gh.prs[36]["head"]["sha"], "success", "timed out", context=RELEASED_CONTEXT)
            s = settle_strict(cap=8)
            check("strict carrier (13): a first-in-line member released from a timed-out carrier is served first",
                  not strict_open() and gh.updates == [36], f"updates={gh.updates} {s}")
            reset()

            # (14) the App's token cannot push under .github/workflows: decided from the TREES, so a rename
            # (the PR file list names only the new path) cannot slip through. Fixture origin refuses such
            # pushes the way GitHub does; a refused push of any kind must not end the tick.
            hook = pathlib.Path(origin, ".git", "hooks", "update")
            hook.parent.mkdir(exist_ok=True)
            gh.g("config", "core.hooksPath", str(hook.parent))
            hook.write_text("#!/bin/sh\ncase \"$1\" in refs/heads/train/strict-*) "
                            "[ -f \"$GIT_DIR/refuse-all\" ] && exit 1\n"
                            "[ -n \"$(git diff --name-only main \"$3\" -- .github/workflows)\" ] && exit 1;; esac\nexit 0\n")
            hook.chmod(0o755)
            try:
                open_only("pW2", "pJ2")
                advance_main()
                g14 = Git(clone("settle14"))
                b14 = gh.main_sha()
                g14("fetch", "-q", "origin", "+refs/heads/*:refs/remotes/origin/*")
                j2 = gh.prs[82]["head"]["sha"]
                tip14 = g14("commit-tree", g14("merge-tree", "--write-tree", b14, j2).stdout.split()[0], "-p", b14, "-m", "x").stdout.strip()
                refused = False
                try:
                    Pusher(g14, "train/strict-1-1", gh.remote).push(tip14)
                except subprocess.CalledProcessError:
                    refused = True
                check("strict carrier (14) control: the fixture origin refuses a workflow change on a carrier branch", refused)
                lying = [{"number": 82, "head_sha": j2, "files": [".github/scripts/renamed.py"]},
                         {"number": 36, "head_sha": gh.prs[36]["head"]["sha"], "files": [".github/scripts/two.py"]}]
                check("strict carrier (14): the workflow change is read from the trees, not the PR's file list",
                      build_strict_carrier(g14, b14, lying, 8, lambda _f: False, [], []) is None)
                pathlib.Path(origin, ".git", "refuse-all").write_text("")
                reset()
                open_only("pW2", "pP1")
                advance_main()
                s = settle_strict(cap=8)
                check("strict carrier (14): a refused push ends nothing — no carrier, and the same tick serves update-branch",
                      not strict_open() and gh.updates == [36] and "strict_carrier" not in s, f"updates={gh.updates} {s}")
            finally:
                hook.unlink()
                pathlib.Path(origin, ".git", "refuse-all").unlink(missing_ok=True)
                gh.g("config", "--unset", "core.hooksPath")
            reset()

            # (15) a member the strict lane would not serve never rides: an unapproved codex head, or a head
            # red on a required context (the unticked money-path checklist is one); revoked after the carrier
            # is built, it does not merge.
            gh.g("branch", "codex/strict-p1", "pP1")
            open_only("pW2", "pP2")
            gh.add_pr(190, "codex/strict-p1", "2026-02-01")
            advance_main()
            s = settle_strict(cap=8)
            check("strict carrier (15): an unapproved codex member never rides", s.get("strict_batch") == [36, 90], str(s))
            reset()
            open_only("pW2", "pP2", "pP1")
            gh.head_checks[gh.prs[88]["head"]["sha"]] = {"Validate manifests": "failure"}
            advance_main()
            s = settle_strict(cap=8)
            check("strict carrier (15): a member red on a required context (checklist unticked) never rides",
                  s.get("strict_batch") == [36, 90], str(s))
            gh.head_checks.clear()
            reset()
            open_only("pW2", "pP2")
            gh.add_pr(190, "codex/strict-p1", "2026-02-01")
            h190 = gh.prs[190]["head"]["sha"]
            gh.post_status(h190, "success", "owner-approved PR #190", OWNER_APPROVAL_CONTEXT)
            advance_main()
            s = settle_strict(cap=8)
            batch = s.get("strict_batch")
            gh.post_status(h190, "failure", "owner-revoked PR #190", OWNER_APPROVAL_CONTEXT)
            s = settle_strict(cap=8)
            check("strict carrier (15): an approval revoked after the carrier was built stops that member's merge",
                  batch == [36, 90, 190] and gh.merged == [36, 90] and 190 not in gh.merged, f"{batch} merged={gh.merged} {s}")
            reset()

            # GREEN CARRIER FIRST (#13400): a train whose CI went green while a strict-lane reservation
            # is active merges at once — before strict_lane runs — instead of being held and then voided
            # by the strict merge (carrier #13853 held for #13806, rebuilt as #13857; #13790 by #13679).
            # Before this rule both cases below merged the strict PR and rejected the carrier.
            open_only("p1")
            tick()
            gh.pending_shas.update(c["head"]["sha"] for c in gh.carriers.values() if c["state"] == "open")
            open_only("pW")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            gh.pending_shas.clear()                        # the train finishes green; pW still running
            s = settle_now()
            check("green carrier first: a verified green carrier merges past a running strict reservation",
                  gh.merged == [1] and not s["rejected"] and not any(c["state"] == "open" for c in gh.carriers.values()),
                  f"{s} merged={gh.merged}")
            gh.head_checks.clear()
            gh.updates.clear()
            s = settle_now()
            check("green carrier first: the pre-empted strict PR, now behind, is update-branched next tick",
                  gh.merged == [1] and gh.updates == [35], f"{s} merged={gh.merged} updates={gh.updates}")
            gh.updates.clear()
            reset()

            # GATES.YAML APPEND (ADR-0343 amendment 2026-11-14): a member that only appends a gate entry rides a
            # train carrier and merges; before the amendment it took the strict lane (update-branch, no carrier).
            open_only("pGP")
            s, st = tick()
            oc = [c for c in gh.carriers.values() if c["state"] == "open"]
            check("gates append (e2e): a pure gates.yaml append is published on a train carrier, no update-branch",
                  st == "published" and len(oc) == 1 and carrier_members(oc[0]) == [96] and gh.updates == [],
                  f"{s} st={st} carriers={[carrier_members(c) for c in oc]} updates={gh.updates}")
            s, st = tick()
            check("gates append (e2e): the carrier verifies and the append merges", 96 in gh.merged, f"{s} merged={gh.merged}")
            reset()

            # EXPEDITE LANE (ADR-0343 amendment 2026-11-13): an ordinary carrier for p1 is running; p2 carries
            # merge-priority:expedite. With the lane on, p2 rides its own one-member carrier over main, merges
            # first, and p1's carrier is rejected as "main moved" with nobody blamed.
            def exp_tick(on=True, cap=6):
                s = mode_settle(gh, Git(clone("settle")), "o/r", False, stack=False, expedite=on, expedite_cap=cap)
                if s["in_flight"]:
                    return s, "in-flight"
                counter[0] += 1
                bdir = clone("build")
                b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",),
                                 overlay_roots=(".github/scripts",))
                b.env["PROBE_OUT"] = probe
                out = os.path.join(root, f"bundle-{counter[0]}")
                w = s.get("expedite_window")
                mode_build(gh, Git(bdir), b, "o/r", out, 8, expedite=w)
                return s, mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8,
                                       expedite=w, expedite_cap=cap)

            def exp_open():
                return [c for c in gh.carriers.values() if c["state"] == "open"]

            def exp_setup(label="p2"):
                open_only("p1")
                s0, st0 = tick()
                gh.pending_shas.update(c["head"]["sha"] for c in exp_open())
                open_only("p2")
                gh.prs[numbers[label]]["labels"] = [{"name": EXPEDITE_LABEL}]
                return s0, st0

            def exp_reset():
                gh.pending_shas.clear()
                for k in ("expedite_used", "expedite_unreadable"):
                    if hasattr(gh, k):
                        delattr(gh, k)
                reset()

            hit = lambda t, d="2026-11-13", u=BOT_LOGIN: {"title": t, "created_at": f"{d}T10:00:00Z",
                                                          "user": {"login": u}, "pull_request": {}}
            good = f"{EXPEDITE_CARRIER_TITLE} train/1-1"
            counts = [count_expedite_hits({"total_count": 3, "incomplete_results": False,
                                           "items": [hit(good), hit(good, u="someone"), hit("merge-train carrier train/2-1")]},
                                          "2026-11-13"),
                      count_expedite_hits({"total_count": 1, "incomplete_results": False, "items": [hit(good, d="2026-11-12")]},
                                          "2026-11-13"),
                      count_expedite_hits({"total_count": 1, "incomplete_results": True, "items": [hit(good)]}, "2026-11-13"),
                      count_expedite_hits({"total_count": 150, "incomplete_results": False, "items": [hit(good)]}, "2026-11-13"),
                      count_expedite_hits({"message": "rate limited"}, "2026-11-13")]
            check("expedite (E0): the daily count counts only the App's expedite carriers of that day, else fails closed",
                  counts == [1, 0, None, None, None], f"{counts}")
            s0, st0 = exp_setup()
            s, st = exp_tick(on=False)
            check("expedite (E1): lane off -> the label only reorders; nothing is built beside a running carrier",
                  st0 == "published" and st == "in-flight" and not s.get("expedite_window") and len(exp_open()) == 1,
                  f"{s0} {st0} {s} {st}")
            s, st = exp_tick()
            oc = exp_open()
            ex = [c for c in oc if c.get("expedite")]
            eg = Git(clone("expchk"))
            eg("fetch", "-q", "origin", "+refs/heads/*:refs/remotes/origin/*")
            ech = parse_own_chain(eg, ex[0]["head"]["sha"]) if ex else None
            check("expedite (E2): lane on -> #2 alone on a second carrier over main, marked by the App",
                  s.get("expedite_window") == 2 and st == "published" and len(oc) == 2 and len(ex) == 1
                  and ech is not None and ech[0] == gh.main_sha() and [n for n, _ in ech[1]] == [2]
                  and gh.app_statuses(ex[0]["head"]["sha"]).get(EXPEDITE_CONTEXT, ("", ""))[0] == "success"
                  and gh.merged == [], f"{s} st={st} open={[(c['number'], c.get('expedite')) for c in oc]} chain={ech}")
            gh.pending_shas.update(c["head"]["sha"] for c in ex)                # its CI runs
            s, st = exp_tick()
            check("expedite (E3): with an expedite carrier open, no third carrier is built",
                  st == "in-flight" and len(exp_open()) == 2 and not s.get("expedite_window"), f"{s} {st}")
            gh.pending_shas.difference_update(c["head"]["sha"] for c in ex)   # the expedite carrier goes green
            s = mode_settle(gh, Git(clone("settle")), "o/r", False, stack=False, expedite=True)
            check("expedite (E4): the green expedite carrier merges first while the overtaken carrier still runs",
                  gh.merged == [2] and 1 not in gh.merged and len(exp_open()) == 1, f"{s} merged={gh.merged}")
            gh.pending_shas.clear()                                             # the overtaken carrier goes green
            s = mode_settle(gh, Git(clone("settle")), "o/r", False, stack=False, expedite=True)
            p1_blamed = (any(n == 1 for n, _ in gh.comments)
                         or gh.app_statuses(gh.prs[1]["head"]["sha"]).get(STATUS_CONTEXT, ("", ""))[0] == "failure")
            check("expedite (E5): the overtaken carrier is closed as main moved, nobody blamed, nothing bisected",
                  gh.merged == [2] and not exp_open() and not p1_blamed and not s["culprits"] and not s["bisected"],
                  f"{s} merged={gh.merged} comments={gh.comments}")
            for _ in range(6):
                s, st = exp_tick()
                if 1 in gh.merged:
                    break
                gh.pending_shas.clear()
            check("expedite (E6): the overtaken member is rebuilt and merges after the expedited one",
                  gh.merged[:2] == [2, 1], f"merged={gh.merged}")
            exp_reset()

            exp_setup()
            earlier = gh.expedite_carriers_today("")   # expedite carriers the fixture already opened today
            gh.expedite_used = 6 - earlier
            s, st = exp_tick(cap=6)
            capped = (st, s.get("expedite_window"))
            gh.expedite_used = 5 - earlier
            s, st = exp_tick(cap=6)
            check("expedite (E7): at the daily cap no expedite carrier is built; one under it, it is",
                  capped == ("in-flight", None) and s.get("expedite_window") == 2 and st == "published",
                  f"capped={capped} under={s.get('expedite_window')} {st}")
            exp_reset()

            exp_setup()
            s, st = exp_tick()                                       # the expedite carrier for #2 is published
            both = [c["number"] for c in exp_open()]
            gh.pending_shas.clear()                                  # both carriers go green in the same tick
            s = mode_settle(gh, Git(clone("settle")), "o/r", False, stack=False, expedite=True)
            p1_blamed = (any(n == 1 for n, _ in gh.comments)
                         or gh.app_statuses(gh.prs[1]["head"]["sha"]).get(STATUS_CONTEXT, ("", ""))[0] == "failure")
            check("expedite (E11): both carriers green in one tick -> the expedite one is judged first and merges",
                  st == "published" and len(both) == 2 and gh.merged == [2] and 1 not in gh.merged
                  and not exp_open() and not p1_blamed and not s["culprits"] and not s["bisected"],
                  f"{s} st={st} carriers={both} merged={gh.merged} open={exp_open()}")
            exp_reset()

            exp_setup()
            gh.expedite_unreadable = True
            s, st = exp_tick()
            check("expedite (E8): an unreadable daily count fails closed",
                  st == "in-flight" and not s.get("expedite_window") and len(exp_open()) == 1, f"{s} {st}")
            exp_reset()

            exp_setup(label="p1")                                   # the expedited PR already rides the carrier
            s, st = exp_tick()
            why9 = expedite_problem(gh, Git(clone("expchk")), "o/r", 1, 6)
            check("expedite (E9): a PR already on the running carrier gets no second one",
                  st == "in-flight" and not s.get("expedite_window") and len(exp_open()) == 1
                  and why9 is not None and "already rides" in why9, f"{s} {st} why={why9}")
            exp_reset()

            exp_setup()
            open_only("pW")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}   # a strict holder runs CI
            s, st = exp_tick()
            held = (st, s.get("expedite_window"), len([c for c in exp_open() if c.get("expedite")]))
            check("expedite (E10): never beside a running strict reservation (the holder is not pre-empted)",
                  held[1] is None and held[2] == 0, f"{s} {st} held={held}")
            gh.head_checks.clear()
            exp_reset()

            # #16874: an expedited member the build always DEFERS must not hold the expedite window forever.
            # pK (gate code) and p2 both carry the label; pK is made the oldest, and the builder defers pK's
            # one-member train every tick, exactly as TrainBuilder.build does for gate code beside a
            # regeneration commit (#13400). A main that really needs regeneration cannot stand in here: the
            # fixture's derived gate then reads main red, which closes the expedite lane before it opens.
            # Tick 1 opens the window for pK and the lane builds nothing; tick 2 passes pK over for p2, whose
            # expedite carrier is published. Without the marker tick 2 re-opens the window for pK, as it did
            # for #16807 every tick for ~6 h while #16852 (the main-red fix) waited.
            real_build = TrainBuilder.build

            def deferring_build(self, base_, members_):
                rest = [m_ for m_ in members_ if m_.number != 38]
                out_ = real_build(self, base_, rest) if rest else (base_, [], [])
                if len(rest) < len(members_):
                    self.deferred = [*getattr(self, "deferred", []), 38]
                return out_
            TrainBuilder.build = deferring_build
            exp_setup()                                              # p1's carrier runs; p2 expedited
            open_only("pK")
            gh.prs[38]["labels"] = [{"name": EXPEDITE_LABEL}]
            gh.prs[38]["created_at"] = "2025-12-01"                  # the oldest expedited candidate
            main_e12 = gh.main_sha()
            s1, st1 = exp_tick()
            pk_head = gh.prs[38]["head"]["sha"]
            mark1 = gh.app_statuses(pk_head).get(EXPEDITE_WINDOW_CONTEXT, ("", ""))
            ex1 = [c for c in exp_open() if c.get("expedite")]
            check("expedite (E12, #16874): tick 1 opens the window for the oldest expedited member; its one-member train is deferred "
                  "(not dropped, no notice), nothing is built, and the window is recorded on its head naming main",
                  s1.get("expedite_window") == 38 and st1 == "idle" and ex1 == [] and gh.prs[38]["state"] == "open"
                  and not any(n == 38 for n, _ in gh.comments) and mark1 == ("success", f"expedite window over main {main_e12}"),
                  f"{s1} st={st1} ex={len(ex1)} mark={mark1} comments={gh.comments}")
            s2, st2 = exp_tick()
            ex2 = [c for c in exp_open() if c.get("expedite")]
            check("expedite (E13, #16874): tick 2 passes the deferred holder over — the next expedited PR gets the window and its "
                  "expedite carrier is published",
                  s2.get("expedite_window") == 2 and st2 == "published" and len(ex2) == 1 and carrier_members(ex2[0]) == [2]
                  and gh.prs[38]["state"] == "open", f"{s2} st={st2} ex={[carrier_members(c) for c in ex2]}")
            check("expedite (E14, #16874): a window marker for a DIFFERENT main does not pass the head over (a moved main is a fresh attempt)",
                  expedite_window_held(gh, pk_head, main_e12) and not expedite_window_held(gh, pk_head, "0" * 40), str(mark1))
            TrainBuilder.build = real_build
            exp_reset()

            # SPECULATIVE STACKING (ADR-0343 amendment 2026-11-09): while strict holder pW (35) runs CI on an
            # up-to-date head h, the train carrier for p1 is published over h, never merged before pW, and
            # accepted after pW's merge only when main's tree is h's tree. Each case below is must-FAIL for
            # the rule it names (mutated off in a throwaway copy, see the PR).
            def stack_tick():
                s = mode_settle(gh, Git(clone("settle")), "o/r", False)
                if s["in_flight"]:
                    return s, "in-flight"
                counter[0] += 1
                bdir = clone("build")
                b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",),
                                 overlay_roots=(".github/scripts",))
                b.env["PROBE_OUT"] = probe
                out = os.path.join(root, f"bundle-{counter[0]}")
                mode_build(gh, Git(bdir), b, "o/r", out, 8)
                return s, mode_publish(gh, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8,
                                       stack=s.get("stack_window"))

            def stacked_setup():
                open_only("pW")
                h = gh.prs[35]["head"]["sha"]
                gh.head_checks[h] = {"gates (data)": None}      # holder up to date, CI running
                open_only("p1")                                  # a green train candidate
                s, st = stack_tick()
                return h, s, st

            def open_carriers():
                return [c for c in gh.carriers.values() if c["state"] == "open"]

            def stack_mark(sha):
                return gh.app_statuses(sha).get(STACK_CONTEXT, ("", ""))

            def blamed(n):
                return (any(n == c for c, _ in gh.comments)
                        or gh.app_statuses(gh.prs[n]["head"]["sha"]).get(STATUS_CONTEXT, ("", ""))[0] == "failure")

            # (S1) published over the holder head, recorded on it, no deferral consumed, nothing merged.
            h, s, st = stacked_setup()
            oc = open_carriers()
            sg = Git(clone("stackchk"))
            sg("fetch", "-q", "origin", "+refs/heads/*:refs/remotes/origin/*")
            chain = parse_own_chain(sg, oc[0]["head"]["sha"]) if oc else None
            check("stacking (S1): a running up-to-date holder + green candidate -> a carrier stacked over the holder head",
                  st == "published" and s.get("stack_window") == (35, h) and len(oc) == 1 and chain is not None
                  and chain[0] == h and [n for n, _ in chain[1]] == [1] and stack_mark(h)[0] == "success"
                  and gh.app_statuses(h).get(DEFER_CONTEXT, ("", ""))[0] != "success" and gh.merged == [],
                  f"{s} st={st} chain={chain} mark={stack_mark(h)}")
            # (S2) carrier green, holder still running: never merged before the holder.
            s = settle_now()
            check("stacking (S2): a green stacked carrier waits while its holder runs — nothing merged, carrier open",
                  gh.merged == [] and len(open_carriers()) == 1 and s["in_flight"] and not s["rejected"], f"{s} merged={gh.merged}")
            # (S3) carrier RED before the holder's verdict: no culprit, no bisect, still waiting.
            gh.carrier_override = {"gates (data)": "failure"}
            s = settle_now()
            check("stacking (S3): a red stacked carrier before the holder's verdict blames nobody and bisects nothing",
                  not s["culprits"] and not s["bisected"] and not blamed(1) and len(open_carriers()) == 1 and gh.merged == [],
                  f"{s} comments={gh.comments}")
            gh.carrier_override = {}
            # (S4) holder green but its merge refused: the carrier still waits (never before the holder).
            gh.head_checks.clear()
            gh.refuse_merge = {35}
            s = settle_now()
            check("stacking (S4): holder green but unmerged -> the green stacked carrier still does not merge",
                  gh.merged == [] and len(open_carriers()) == 1, f"{s} merged={gh.merged}")
            gh.refuse_merge = set()
            # (S5) the holder merges; main's tree == h's tree, so next tick the carrier merges WITHOUT a rebuild.
            s = settle_now()
            made = len(gh.carriers)
            ok_tree = Git(origin).tree(gh.main_sha()) == Git(origin).tree(h)
            s2 = settle_now()
            check("stacking (S5): holder merges first, then the stacked carrier's member merges on main == tree(h), no rebuild",
                  ok_tree and gh.merged == [35, 1] and len(gh.carriers) == made and not open_carriers() and not s2["rejected"],
                  f"{s} {s2} merged={gh.merged} tree_eq={ok_tree}")
            gh.head_checks.clear()
            reset()

            # #16932 NEGATIVE: a stacked member natively merged at the verified head and over the expected main,
            # but to a tree other than the verified stacked step -> not counted as merged.
            h, s, st = stacked_setup()
            gh.head_checks.clear()
            settle_now()                                       # the holder merges
            real = globals()["live_source_intent"]
            fired = []

            def stacked_racing(g, n, head, _real=real):
                if n == 1 and not fired and gh.prs[1]["state"] == "open":
                    fired.append(n)
                    m0 = gh.main_sha()
                    bad = gh.g("commit-tree", f"{m0}^{{tree}}", "-p", m0, "-m", "#1 wrong tree").stdout.strip()
                    gh.g("update-ref", "refs/heads/main", bad)
                    gh.g("checkout", "-q", "-f", "main")
                    gh.prs[1].update(state="closed", merged=True, merge_commit_sha=bad)
                return _real(g, n, head)
            globals()["live_source_intent"] = stacked_racing
            try:
                s2 = settle_now()
            finally:
                globals()["live_source_intent"] = real
            check("#16932 NEGATIVE: stacked member natively merged to a tree other than the verified step -> stop",
                  fired == [1] and not s2.get("native_merged") and 1 not in gh.merged, f"{fired} {s2.get('native_merged')} {gh.merged}")
            gh.head_checks.clear()
            reset()

            # (S6) tree mismatch: something else lands with the holder, so main's tree is not h's -> rejected,
            # nobody blamed, the member does not merge.
            h, s, st = stacked_setup()
            gh.head_checks.clear()
            gh.foreign_after_merge = "docs/foreign-stack.md"
            settle_now()
            s = settle_now()
            check("stacking (S6): main's tree differs from the holder head's -> the stacked carrier is rejected, member unmerged",
                  st == "published" and gh.merged == [35] and not open_carriers() and s["rejected"] and not blamed(1),
                  f"st={st} {s} merged={gh.merged}")
            gh.head_checks.clear()
            reset()

            # (S6b) red AFTER the holder merged with main == tree(h): still no culprit — a stacked carrier is
            # accepted green or not at all (its members were never regenerated over the holder).
            h, s, st = stacked_setup()
            gh.head_checks.clear()
            settle_now()                                     # the holder merges
            gh.carrier_override = {"gates (data)": "failure"}
            s = settle_now()
            check("stacking (S6b): a red stacked carrier over a merged holder blames nobody and bisects nothing",
                  st == "published" and gh.merged == [35] and not open_carriers() and s["inconclusive"]
                  and not s["culprits"] and not s["bisected"] and not blamed(1), f"st={st} {s} merged={gh.merged}")
            gh.carrier_override = {}
            gh.head_checks.clear()
            reset()

            # (S6c) holder DISARMED while the carrier waits: voided, not a wait forever.
            h, s, st = stacked_setup()
            gh.prs[35]["auto_merge"] = None
            s = settle_now()
            check("stacking (S6c): a holder disarmed while its stacked carrier waits voids the carrier, nobody blamed",
                  st == "published" and not open_carriers() and s["inconclusive"] and not blamed(1) and gh.merged == [],
                  f"st={st} {s}")
            gh.head_checks.clear()
            reset()

            # (S6d) the member's squash would NOT reproduce the verified stacked step (here the carrier's step
            # carries an extra file, re-recorded as if publish had pushed it): checked BEFORE any merge, so the
            # member never merges and nobody is blamed. Must-FAIL without the pre-merge check.
            h, s, st = stacked_setup()
            c = open_carriers()[0]
            tip = c["head"]["sha"]
            msg = gh.g("log", "-1", "--format=%B", tip).stdout.rstrip("\n")
            gh.g("checkout", "-q", "-f", "--detach", tip)
            pathlib.Path(origin, "docs", "unverified-extra.md").write_text("x\n")
            gh.g("add", "docs/unverified-extra.md")
            gh.g("commit", "-q", "--amend", "-m", msg)
            forged = gh.g("rev-parse", "HEAD").stdout.strip()
            gh.g("checkout", "-q", "-f", "main")
            gh.g("update-ref", f"refs/heads/{c['head']['ref']}", forged)
            c["head"]["sha"] = forged
            gh.post_status(forged, "success", f"tree={Git(origin).tree(forged)}", context=RECORD_CONTEXT)
            gh.post_status(forged, "success", f"stacked over {h} of #35", context=STACK_CONTEXT)
            gh.head_checks.clear()
            settle_now()                                     # the holder merges
            s = settle_now()
            check("stacking (S6d): a member whose squash differs from the verified stacked step is never merged",
                  st == "published" and gh.merged == [35] and not open_carriers() and s["inconclusive"]
                  and not blamed(1), f"st={st} {s} merged={gh.merged}")
            gh.head_checks.clear()
            reset()

            # (S7) holder RED: the stacked carrier is voided as inconclusive, nobody blamed.
            h, s, st = stacked_setup()
            gh.carrier_override = {"gates (data)": "failure"}
            gh.head_checks[h] = {"gates (data)": "failure"}
            s = settle_now()
            check("stacking (S7): holder red -> stacked carrier closed inconclusive, no culprit, no bisect, nothing merged",
                  st == "published" and not open_carriers() and s["inconclusive"] and not s["culprits"]
                  and not s["bisected"] and not blamed(1) and gh.merged == [], f"st={st} {s}")
            gh.carrier_override = {}
            # (S8) one stacked carrier per holder head: the same head running again opens no second window.
            gh.head_checks[h] = {"gates (data)": None}
            s = settle_now()
            check("stacking (S8): a holder head that already had a stacked carrier gets no second one",
                  "stack_window" not in s and stack_mark(h)[0] == "success", f"{s}")
            gh.statuses[h] = [r for r in gh.statuses.get(h, []) if r[0] != STACK_CONTEXT]
            s = settle_now()
            check("stacking (S8 control): the same state with the marker removed DOES open a window",
                  s.get("stack_window") == (35, h), f"{s}")
            gh.head_checks.clear()
            reset()

            # (S9) no stacking over a holder behind main, nor while main is red (direct, then through settle).
            open_only("pW")
            h = gh.prs[35]["head"]["sha"]
            gh.head_checks[h] = {"gates (data)": None}
            sg = Git(clone("stackchk"))
            behind = stack_target_problem(gh, sg, gh.g("rev-parse", "p1").stdout.strip(), 35, h, {})   # p1 is not in pW
            check("stacking (S9): a holder head that does not contain main is never stacked over",
                  behind == "holder head is behind main", str(behind))
            check("stacking (S9): no stacking while main is red",
                  stack_target_problem(gh, sg, gh.main_sha(), 35, h, {"gates (data)": "x"}) == "main is red")
            gh.head_checks.clear()
            reset()

            def stack_state():
                open_only("pW")
                hh = gh.prs[35]["head"]["sha"]
                gh.head_checks[hh] = {"gates (data)": None}
                open_only("p1")
                return hh

            # Known-positive control for every settle case below: this state DOES open a window.
            h = stack_state()
            s = settle_now()
            check("stacking (S9/S10 control): running holder + green candidate -> a stacking window, not the deferral",
                  s.get("stack_window") == (35, h) and "deferral_window" not in s, f"{s}")
            gh.head_checks.clear()
            reset()
            h = stack_state()
            gh.main_override = {"gates (data)": "failure"}
            s = settle_now()
            check("stacking (S9): main red -> settle opens no stacking window", "stack_window" not in s, f"{s}")
            gh.main_override = {}
            gh.head_checks.clear()
            reset()
            # (S10) shadow does nothing: no window, no marker; and the switch off keeps the bounded deferral.
            h = stack_state()
            s = mode_settle(gh, Git(clone("settle")), "o/r", True)
            check("stacking (S10): shadow opens no stacking window and writes no stacking marker",
                  "stack_window" not in s and not stack_mark(h)[0] and gh.merged == [], f"{s}")
            gh.head_checks.clear()
            reset()
            h = stack_state()
            s = mode_settle(gh, Git(clone("settle")), "o/r", False, stack=False)
            check("stacking (S10): MERGE_TRAIN_SPECULATIVE_STACK false -> the bounded deferral window as before",
                  "stack_window" not in s and s.get("deferral_window") == 35, f"{s}")
            gh.head_checks.clear()
            reset()

            # #15827 (b): the disjoint fast path never releases a PR while a train carrier is in flight.
            # Measured 2026-11-12: #15817 was posted "fast lane: disjoint from main ... and the batch" at
            # 10:45 under carrier #15834 (published 10:41), auto-merge merged it, and settle rejected the
            # green carrier as "main moved since publish". Must-FAIL case: without the hold, 34 is posted.
            open_only("p1")
            _, st = tick()
            gh.pending_shas.update(c["head"]["sha"] for c in gh.carriers.values() if c["state"] == "open")
            open_only("pF")
            s = settle_now()
            check("#15827 (b): a disjoint fast-lane PR is held while a train carrier is in flight",
                  st == "published" and s["fast"] == [] and 34 not in gh.merged
                  and gh.app_statuses(gh.prs[34]["head"]["sha"]).get(STATUS_CONTEXT, ("",))[0] != "success",
                  f"st={st} {s}")
            gh.pending_shas.clear()
            s = settle_now()                      # the carrier is green: it merges, nothing was moved under it
            check("#15827 (b): the carrier then merges over the main it was published on",
                  1 in gh.merged and not s["rejected"], f"{s} merged={gh.merged}")
            s = settle_now()
            check("#15827 (b): with no carrier open the fast-lane PR is released", 34 in s["fast"], str(s))
            reset()

            # #15827 (c): a strict holder GREEN on an up-to-date head that did not merge this tick (here: the
            # merge is refused once) gets ONE tick in which no fast carrier is built, so the next carrier
            # does not push it behind main and restart its full CI (#15747 was reset three times). Must-FAIL
            # case: without the hold a carrier of #1 is published this tick.
            open_only("pW")                       # strict-lane, up to date with main, green
            open_only("p1")                       # a green train candidate
            pw_head = gh.prs[35]["head"]["sha"]
            gh.refuse_merge.add(35)
            s, st = tick()
            check("#15827 (c): green up-to-date strict holder + fast candidates -> no fast carrier published that tick",
                  st == "in-flight" and s.get("strict_ready_hold") == 35
                  and not any(c["state"] == "open" for c in gh.carriers.values()) and gh.merged == [],
                  f"{s} st={st}")
            gh.refuse_merge.discard(35)
            s, st = tick()
            check("#15827 (c): the holder merges next tick, on its own un-updated head",
                  gh.merged[:1] == [35] and gh.updates == [] and gh.prs[35]["head"]["sha"] == pw_head,
                  f"{s} st={st} merged={gh.merged} updates={gh.updates}")
            reset()
            # Bounded: a holder that still cannot merge holds the fast lane ONCE per head, never twice.
            open_only("pW")
            open_only("p1")
            gh.refuse_merge.add(35)
            tick()
            s, st = tick()
            check("#15827 (c): a holder already held for once does not stall the fast lane again",
                  st == "published" and "strict_ready_hold" not in s, f"{s} st={st}")
            gh.refuse_merge.discard(35)
            reset()

            # BOUNDED STRICT DEFERRAL (#13400): a strict reservation whose CI is still running yields
            # ONCE per strict head to a carrier built from green candidates DURING that CI. The deferral
            # is recorded as DEFER_CONTEXT on the strict head when the carrier is published, and the
            # update-branch that follows the carrier's merge inherits it through its first parent.
            def deferral(sha):
                return gh.app_statuses(sha).get(DEFER_CONTEXT, ("", ""))[0]

            def running_reservation_and_green_candidate():
                open_only("pW")
                gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}   # pW up to date, CI running
                open_only("p1")                                                    # a green train candidate

            # (1) no deferral yet: a carrier is built and published, and the deferral recorded at publish.
            running_reservation_and_green_candidate()
            pw_a = gh.prs[35]["head"]["sha"]
            s, st = tick()
            check("deferral: running reservation + green candidate + no deferral -> a carrier is built",
                  st == "published" and any(c["state"] == "open" for c in gh.carriers.values())
                  and deferral(pw_a) == "success" and gh.merged == [], f"{s} st={st} defer={deferral(pw_a)!r}")
            gh.head_checks.clear()
            reset()

            # (2) a deferral already recorded for this strict head: held, no carrier.
            running_reservation_and_green_candidate()
            gh.post_status(gh.prs[35]["head"]["sha"], "success", "yielded once", context=DEFER_CONTEXT)
            s, st = tick()
            check("deferral: a strict head that already yielded once is held (no carrier built)",
                  st == "in-flight" and s["in_flight"] and not any(c["state"] == "open" for c in gh.carriers.values()),
                  f"{s} st={st}")
            gh.head_checks.clear()
            reset()

            # (3) GRANTED DEFERRAL IS HONOURED (2026-11-05): the strict head and the carrier built under
            # its CI are BOTH green in one tick. The holder yielded to THIS carrier at publish
            # (DEFER_CONTEXT on its head), so the carrier merges first and the holder is not merged on
            # this tick; it is update-branched and inherits the record, so no further carrier is built
            # under it. This is the must-FAIL case: on code where a green holder pre-empts the carrier
            # it deferred to, gh.merged == [35] and the carrier is voided by "main moved since publish".
            # Measured 2026-11-05 00:00-10:50Z: 9 carriers published, 0 train merges; each green carrier
            # (#14860 for #14831, #14871 for #14562, ...) waited one tick, lost main to the holder it had
            # been built under, and was rejected on the next tick — with 22 strict PRs queued, every
            # rebuilt carrier was built under the next reservation and lost again.
            gh.updates.clear()
            running_reservation_and_green_candidate()
            tick()
            pw_head = gh.prs[35]["head"]["sha"]
            gh.head_checks.clear()                     # pW goes green; the carrier is green as well
            s = settle_now()
            def yielded(sha):
                return gh.app_statuses(sha).get(CARRIER_YIELD_CONTEXT, ("", ""))[0]
            check("granted deferral: green holder that yielded to this carrier + green carrier -> the carrier merges, the holder does not",
                  gh.merged == [1] and 35 not in gh.merged and not s["rejected"] and deferral(pw_head) == "success",
                  f"{s} merged={gh.merged} updates={gh.updates} defer={deferral(pw_head)!r}")
            check("granted deferral: no one-tick yield is recorded on the holder head (it already yielded at publish)",
                  yielded(pw_head) != "success", f"yielded={yielded(pw_head)!r}")
            gh.updates.clear()
            reset()

            # (3-nd) GREEN HOLDER FIRST, only for a holder that did NOT defer (#14191/#14338, #14183/#14327):
            # the same two green heads, but the holder's head carries no DEFER_CONTEXT (the carrier was not
            # built under its reservation). The holder is up to date, so it merges first; the carrier
            # merging first would push it behind main and restart its full CI. The carrier merges nothing
            # this tick (it is rebuilt over the new main later). Must-FAIL case: on code where the green
            # carrier goes first unconditionally, gh.merged == [1].
            gh.updates.clear()
            running_reservation_and_green_candidate()
            tick()
            pw_head = gh.prs[35]["head"]["sha"]
            gh.statuses[pw_head] = [r for r in gh.statuses.get(pw_head, []) if r[0] != DEFER_CONTEXT]
            gh.head_checks.clear()                     # pW goes green; the carrier is green as well
            s = settle_now()
            check("green holder first (no deferral): green strict holder + green carrier -> the holder merges, the carrier does not",
                  gh.merged == [35] and 1 not in gh.merged and gh.updates == [],
                  f"{s} merged={gh.merged} updates={gh.updates}")
            check("green holder first (no deferral): the holder was merged on its own, un-updated head",
                  gh.prs[35]["head"]["sha"] == pw_head, "head moved")
            check("green holder first (no deferral): the carrier is left open and NOT in flight; the yield is recorded on the holder head",
                  not s["in_flight"] and any(c["state"] == "open" for c in gh.carriers.values()) and yielded(pw_head) == "success",
                  f"{s} yielded={yielded(pw_head)!r}")
            gh.updates.clear()
            reset()

            # (3-nm) The same two green heads, but the carrier has TWO members. Yielding would void it
            # (the holder's merge moves main and the carrier is rebuilt, #15368 -> #15369, ~50 min for every
            # member), which costs more PR-time than pushing the one holder behind main. So the carrier
            # merges first and the holder is update-branched. Must-FAIL case: with the size limit removed,
            # the holder merges alone and neither p1 nor p2 does.
            gh.updates.clear()
            open_only("pW")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            open_only("p1", "p2")
            tick()
            pw_head = gh.prs[35]["head"]["sha"]
            gh.statuses[pw_head] = [r for r in gh.statuses.get(pw_head, []) if r[0] != DEFER_CONTEXT]
            gh.head_checks.clear()
            s = settle_now()
            check("multi-member carrier first: green 2-member carrier + green holder -> the carrier merges, the holder does not",
                  sorted(gh.merged) == [1, 2] and 35 not in gh.merged and yielded(pw_head) != "success",
                  f"{s} merged={gh.merged} yielded={yielded(pw_head)!r}")
            check("multi-member carrier first: the pre-emption is recorded as the holder's one deferral (ADR-0343 bound)",
                  deferral(pw_head) == "success", f"defer={deferral(pw_head)!r}")
            gh.updates.clear()
            reset()

            # (3a) BOUNDED WAIT, and the old green-carrier-first case restored: the holder is green but
            # its merge is REFUSED on tick 1 (a stale `merge-train` success is left on it). The carrier
            # waited ONE tick; on tick 2 the holder is still green and unmerged, so the carrier merges
            # first and the stale success on the holder is withdrawn (no stall behind a stuck holder).
            gh.updates.clear()
            running_reservation_and_green_candidate()
            tick()
            pw_head = gh.prs[35]["head"]["sha"]
            gh.statuses[pw_head] = [r for r in gh.statuses.get(pw_head, []) if r[0] != DEFER_CONTEXT]  # a holder that did not defer
            gh.post_status(pw_head, "success", "strict lane: left by a refused merge")   # a stale success
            gh.head_checks.clear()
            gh.refuse_merge = {35}
            s1 = settle_now()
            check("bounded wait: tick 1 - green holder's merge refused, the carrier waited (nothing merged)",
                  gh.merged == [] and yielded(pw_head) == "success" and not s1["in_flight"], f"{s1} merged={gh.merged}")
            s = settle_now()
            check("green carrier first: holder still green and unmerged on tick 2 -> the carrier merges (wait is one tick)",
                  gh.merged == [1] and 35 not in gh.merged and not s["rejected"], f"{s} merged={gh.merged}")
            check("green carrier first: no merge-train success stands on the strict head while the carrier merges",
                  gh.app_statuses(pw_head).get(STATUS_CONTEXT, ("", ""))[0] != "success",
                  f"{gh.app_statuses(pw_head).get(STATUS_CONTEXT)}")
            gh.refuse_merge = set()
            gh.updates.clear()
            reset()

            # (3b) THE ONE-YIELD BOUND under the granted deferral: the carrier merged past the holder that
            # deferred to it (case 3). The holder is behind main, is update-branched once, its new head
            # inherits the deferral record through the first parent, so no second carrier is built while
            # its CI runs, and it merges after that one more CI cycle — the ADR-0343 bound.
            gh.updates.clear()
            running_reservation_and_green_candidate()
            tick()
            pw_head = gh.prs[35]["head"]["sha"]
            gh.head_checks.clear()                     # pW goes green; the carrier is green as well
            settle_now()                               # the carrier merges first (granted deferral)
            check("one-yield bound: the carrier merged, the deferring holder was update-branched once",
                  gh.merged == [1] and gh.updates == [35], f"merged={gh.merged} updates={gh.updates}")
            b_head = gh.prs[35]["head"]["sha"]
            if b_head == pw_head:
                settle_now()
                b_head = gh.prs[35]["head"]["sha"]
            gh.head_checks[b_head] = {"gates (data)": None}
            open_only("p2")
            _s2, st2 = tick()                          # its CI runs: no second carrier (deferral inherited)
            gh.head_checks.clear()
            s3 = settle_now()
            check("one-yield bound: strict PR is served next - updated once, merges after one more CI cycle",
                  gh.updates == [35] and st2 == "in-flight" and 35 in s3["merged"] and 2 not in gh.merged,
                  f"st2={st2} s3={s3} merged={gh.merged} updates={gh.updates}")
            gh.updates.clear()
            reset()

            # (3c) shadow mode never reaches the yield: nothing merges, no marker is posted.
            gh.updates.clear()
            running_reservation_and_green_candidate()
            tick()
            pw_head = gh.prs[35]["head"]["sha"]
            gh.head_checks.clear()
            mode_settle(gh, Git(clone("settle")), "o/r", True)
            check("shadow: a green holder + green carrier posts no yield marker and merges nothing",
                  yielded(pw_head) == "" and gh.merged == [], f"yielded={yielded(pw_head)!r} merged={gh.merged}")
            gh.updates.clear()
            reset()

            # (3b) UNVERIFIED carrier vs a green strict PR past its deferral: the strict PR waits for
            # the running carrier while it is younger than CARRIER_PRIORITY_S (it would void ~1 h of
            # CI), and is served once the carrier is older — the strict wait is bounded.
            def running_carrier_and_green_strict(age_s):
                open_only("p1")
                tick()
                for c in gh.carriers.values():
                    if c["state"] == "open":
                        gh.pending_shas.add(c["head"]["sha"])
                        c["created_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - age_s))
                open_only("pW")
                gh.post_status(gh.prs[35]["head"]["sha"], "success", "yielded once", context=DEFER_CONTEXT)
                return settle_now()

            s = running_carrier_and_green_strict(10 * 60)
            check("carrier priority: a strict PR past its deferral waits for a young running carrier",
                  gh.merged == [] and any(c["state"] == "open" for c in gh.carriers.values()),
                  f"{s} merged={gh.merged}")
            gh.pending_shas.clear()
            reset()
            s = running_carrier_and_green_strict(CARRIER_PRIORITY_S + 60)
            check("carrier priority: bounded - a carrier older than CARRIER_PRIORITY_S no longer holds the strict PR",
                  gh.merged == [35], f"{s} merged={gh.merged}")
            gh.pending_shas.clear()
            reset()

            # (4) bounded: the carrier merges past the running head A (the one deferral); A is
            # update-branched to B, B inherits the record via its first parent, no further carrier is
            # built while B's CI runs, and the strict PR merges within 2 of its CI cycles.
            gh.updates.clear()
            running_reservation_and_green_candidate()
            tick()                                     # cycle 1: A's CI runs, carrier published
            s1 = settle_now()                          # the carrier is green: it pre-empts A once
            if gh.updates != [35]:
                # Only when A was not re-updated in the carrier's own tick: wait for A's CI, then update.
                gh.head_checks.clear()                 # A's CI finishes green, now behind main
                settle_now()                           # update-branch -> B
            # Pre-empted (#13400, 2026-10-26): A yielded and fell behind main, so it is re-updated in the
            # carrier's merge tick while its now-useless CI still runs. Either way, A -> B exactly once.
            b_head = gh.prs[35]["head"]["sha"]
            gh.head_checks[b_head] = {"gates (data)": None}   # cycle 2: B's CI runs
            open_only("p2")                            # another green candidate arrives
            s2, st2 = tick()
            gh.head_checks.clear()                     # B's CI finishes green
            s3 = settle_now()
            check("deferral: one yield only - the strict PR merges within 2 CI cycles, no second carrier",
                  1 in s1["merged"] and gh.updates == [35] and st2 == "in-flight" and not deferral(b_head)
                  and 35 in s3["merged"] and 2 not in gh.merged,
                  f"s1={s1} st2={st2} s3={s3} merged={gh.merged} updates={gh.updates}")
            gh.head_checks.clear()
            gh.updates.clear()
            reset()

            # OVERLAP FROM THE UPDATE TICK (#13400), rebuilt from 2026-10-26 16:06-17:14Z: carrier #13939
            # merged 5 at 16:06, and strict #13869 / #13903 / #13922 / #13934 were update-branched one
            # per tick, each tick reporting in_flight and building nothing; carrier #13946 opened only at
            # 17:14. Each case fails on the code before this change (the update tick built no carrier).
            real_update = gh.update_branch

            def update_then_run_ci(n, head):
                ok = real_update(n, head)
                if ok:
                    gh.head_checks[gh.prs[n]["head"]["sha"]] = {"gates (data)": None}   # its CI starts
                return ok

            gh.update_branch = update_then_run_ci
            try:
                gh.updates.clear()
                gh.g("checkout", "-q", "-f", "main")
                pathlib.Path(origin, "docs").mkdir(parents=True, exist_ok=True)
                pathlib.Path(origin, "docs/main-moved.md").write_text("carrier #13939 merged\n")
                gh.g("add", "-A")
                gh.g("commit", "-q", "-m", "main moves: the strict PR is now behind it")
                open_only("pW", "p1")                    # a green strict PR behind main + a green candidate
                pw_old = gh.prs[35]["head"]["sha"]
                s, st = tick()
                pw_b = gh.prs[35]["head"]["sha"]
                carrier = next((c for c in gh.carriers.values() if c["state"] == "open"), None)
                over_same_main = carrier is not None and gh.g(
                    "merge-base", "--is-ancestor", gh.main_sha(), carrier["head"]["sha"], check=False).returncode == 0
                check("overlap: the update-branch tick builds a carrier over the SAME main while the strict CI runs",
                      gh.updates == [35] and pw_b != pw_old and st == "published" and over_same_main
                      and deferral(pw_b) == "success" and gh.merged == [],
                      f"{s} st={st} updates={gh.updates} defer={deferral(pw_b)!r} merged={gh.merged}")
                # The carrier goes green while the strict head's CI still runs: green carrier first.
                s = settle_now()
                check("overlap: green carrier first - it merges past the running strict head",
                      gh.merged == [1] and 35 not in gh.merged, f"{s} merged={gh.merged}")
                # The strict PR, now behind, is re-updated (one more CI cycle) and yields no second time.
                s = settle_now()
                pw_c = gh.prs[35]["head"]["sha"]
                open_only("p2")                          # inflow continues
                s2, st2 = tick()
                check("overlap: bounded yield - re-updated once, and no second carrier is built under it",
                      gh.updates == [35, 35] and pw_c != pw_b and st2 == "in-flight"
                      and not any(c["state"] == "open" for c in gh.carriers.values()),
                      f"s={s} st2={st2} updates={gh.updates}")
                gh.head_checks.clear()                   # its second CI cycle finishes green
                s3 = settle_now()
                check("overlap: ... so the strict PR merges after 2 CI cycles, before the next carrier",
                      35 in s3["merged"] and 2 not in gh.merged, f"s3={s3} merged={gh.merged}")
                gh.head_checks.clear()
                gh.updates.clear()
                reset()

                # A strict PR that CONFLICTS with main (#13739, refused every tick for ~11 h on 2026-10-26)
                # is never update-branched: decided locally, told once with a "conflict" notice, holds no
                # reservation, and the next strict PR is served in the same tick.
                gh.g("checkout", "-q", "-f", "main")
                pathlib.Path(origin, ".github/workflows").mkdir(parents=True, exist_ok=True)
                pathlib.Path(origin, ".github/workflows/w.yml").write_text("on: pull_request\n")
                gh.g("add", "-A")
                gh.g("commit", "-q", "-m", "main edits the workflow pW edits: pW conflicts with main")
                open_only("pW", "pW2")
                asked: list[int] = []

                def update_or_refuse(n, head):
                    asked.append(n)
                    probe_m = gh.g("merge-tree", "--write-tree", "main", head, check=False)
                    return False if probe_m.returncode == 1 else update_then_run_ci(n, head)

                gh.update_branch = update_or_refuse
                head35 = gh.prs[35]["head"]["sha"]
                s = settle_now()
                s2 = settle_now()
                told = [t for n, t in gh.comments if n == 35 and t.startswith(STRICT_CONFLICT_COMMENT)]
                st35 = gh.app_statuses(head35)
                check("conflict: a conflicting strict PR is never update-branched; the next one is, same tick",
                      35 not in asked and gh.updates == [36] and 35 in s.get("conflicts", []),
                      f"asked={asked} updates={gh.updates} s={s}")
                check("conflict: it holds no reservation - main is reserved for the next strict PR instead",
                      s2["in_flight"] and 35 not in gh.merged and gh.updates == [36], f"s2={s2} updates={gh.updates}")
                check("conflict: told ONCE per head - 'conflict' notice naming the path, marker set",
                      len(told) == 1 and "`.github/workflows/w.yml`" in told[0]
                      and st35.get(STATUS_CONTEXT, ("", ""))[1].startswith(CONFLICT_PREFIX)
                      and NOTICE_CONTEXT in st35, f"{gh.comments} {st35}")
            finally:
                del gh.update_branch                     # back to FakeGitHub.update_branch
            gh.head_checks.clear()
            gh.updates.clear()
            reset()

            # LANE FAIRNESS (ADR-0343, 2026-10-21): the strict queue never empties, so before the fix
            # every strict merge was followed at once by the next strict update-branch — main stayed
            # reserved and no train ever merged (11 carriers, 0 train merges in 12.5 h; carrier
            # #13529 was held for strict #13526 and then voided by its merge). Both cases below fail
            # on that code: (a) an open carrier gets its turn, (b) after a strict merge the train goes
            # next, bounded by TRAIN_TURN_S.
            global TRAIN_TURN_S
            open_only("pW", "pW2", "p1")
            s, st = tick()                                 # pW merges (strict); a train over it is published
            gh.pending_shas.update(c["head"]["sha"] for c in gh.carriers.values() if c["state"] == "open")
            gh.updates.clear()
            s = settle_now()                               # carrier CI running; pW2 green but behind
            check("fairness: no strict-lane update-branch while a train carrier is open",
                  gh.merged == [35] and st == "published" and gh.updates == [] and s["in_flight"],
                  f"{s} st={st} merged={gh.merged} updates={gh.updates}")
            gh.pending_shas.clear()
            s, _st = tick()                                # the carrier is green: the train merges
            check("fairness: the train carrier merges instead of being held and voided by a strict merge",
                  gh.merged == [35, 1] and not s["rejected"], f"{s} merged={gh.merged}")
            check("fairness: once the train merged, the strict lane is served again in that same tick",
                  gh.updates == [36], f"{s} updates={gh.updates}")
            gh.updates.clear()
            reset()

            open_only("pW", "pW2")
            settle_now()                                   # pW merges; pW2 is behind
            open_only("p1")                                # a train candidate is waiting, no carrier
            gh.updates.clear()
            s = settle_now()
            check("fairness: right after a strict merge a waiting train goes next (no update-branch, main free)",
                  gh.merged == [35] and gh.updates == [] and not s["in_flight"],
                  f"{s} merged={gh.merged} updates={gh.updates}")
            saved_turn = TRAIN_TURN_S
            TRAIN_TURN_S = -1
            try:
                s = settle_now()
                # The update tick also opens pW2's one deferral, since p1 waits (overlap, 2026-10-26).
                check("fairness: the train's turn is bounded — expired, the strict lane updates again",
                      gh.updates == [36] and (s["in_flight"] or s.get("deferral_window") == 36),
                      f"{s} updates={gh.updates}")
            finally:
                TRAIN_TURN_S = saved_turn
            gh.updates.clear()
            reset()

            # FAST LANE'S TURN (ADR-0360), rebuilt from 2026-11-02 18:27Z-23:59Z: strict #14595 and #14607
            # each hit the 240 min ceiling and #14644 was update-branched in the next tick, so fast PRs
            # #14523/#14610/#14620 were "held: main reserved" for 5.5 h and nothing merged. The train's
            # turn never applied: fast PRs are not train candidates. Every case below fails on the code
            # before this change (the next strict PR was update-branched at once; the fast lane got []).
            global FAST_TURN_S
            gh.update_branch = update_then_run_ci
            try:
                # (1) after a strict MERGE: pW merges; next tick pF (fast, green) goes before pW2's update.
                open_only("pW", "pW2", "pF")
                s1 = settle_now()                          # pW merges; fast held (main moved this tick)
                gh.updates.clear()
                s = settle_now()
                check("fast turn: after a strict merge, a waiting fast PR is posted before the next reservation",
                      gh.merged == [35] and 34 in s["fast"] and gh.updates == [] and not s["in_flight"],
                      f"{s1} {s} merged={gh.merged} updates={gh.updates}")
                fm = gh.main_sha()
                check("fast turn: the turn is recorded by the App on main's head",
                      gh.app_statuses(fm).get(FAST_TURN_CONTEXT, ("", ""))[1].startswith("opened "),
                      str(gh.app_statuses(fm)))
                # the fast PR merges (auto-merge on the posted status): main's head is now a fast merge,
                # so the turn is over and the strict lane is served in that same tick — no second turn.
                gh.merge(34, gh.prs[34]["head"]["sha"])
                open_only("p1")
                gh.prs[1]["auto_merge"] = None             # not a candidate: only the strict lane remains
                s = settle_now()
                check("fast turn: one turn per reservation end — after the fast merge the strict lane updates",
                      gh.updates == [36] and s["in_flight"], f"{s} updates={gh.updates}")
                gh.updates.clear()
                reset()

                # (2) after a reservation RELEASED at the ceiling (no merge): the 2026-11-02 shape.
                open_only("pW", "pW2", "pF")
                pathlib.Path(origin, "docs").mkdir(parents=True, exist_ok=True)
                pathlib.Path(origin, "docs/moved.md").write_text("m\n")
                gh.g("add", "-A")
                gh.g("commit", "-q", "-m", "main moves: every strict PR is behind")
                gh.g("checkout", "-q", "-f", "-B", "pW-cur", "pW")
                gh.g("merge", "-q", "--no-edit", "main")
                gh.g("checkout", "-q", "-f", "main")
                cur = gh.g("rev-parse", "pW-cur").stdout.strip()
                gh.prs[35]["head"].update(ref="pW-cur", sha=cur)
                gh.head_checks[cur] = {"gates (data)": None}           # its CI never finished
                ct = int(gh.g("show", "-s", "--format=%ct", cur).stdout.strip())
                gh.activity[cur] = ct + RESERVATION_CEILING_S          # still trickling: only the ceiling ends it
                gh.updates.clear()
                real_time_ft = time.time
                time.time = lambda: ct + RESERVATION_CEILING_S + 60
                try:
                    s = settle_now()
                    check("fast turn: a reservation released at the ceiling gives the fast lane its turn first",
                          s.get("timed_out") == [35] and 34 in s["fast"] and gh.updates == [],
                          f"{s} updates={gh.updates}")
                    saved_ft = FAST_TURN_S
                    FAST_TURN_S = -1
                    try:
                        s = settle_now()
                        check("fast turn: bounded — expired, the next strict PR is update-branched",
                              gh.updates == [36], f"{s} updates={gh.updates}")
                    finally:
                        FAST_TURN_S = saved_ft
                finally:
                    time.time = real_time_ft
                    gh.head_checks.clear()
                    gh.activity.clear()
                gh.updates.clear()
                reset()

                # (3) a running reservation is never affected: the fast lane stays held under it.
                open_only("pW", "pW2", "pF")
                settle_now()                                # pW merges
                gh.prs[34]["state"] = "closed"              # no fast PR waits: no turn, pW2 is updated
                gh.updates.clear()
                s = settle_now()
                gh.prs[34]["state"] = "open"                # a fast PR arrives during pW2's reservation
                s2 = settle_now()
                check("fast turn: no fast PR waiting -> no turn; one arriving under a running reservation is held",
                      gh.updates == [36] and s2["in_flight"] and s2["fast"] == [], f"{s} {s2} updates={gh.updates}")
                gh.updates.clear()
                reset()
            finally:
                del gh.update_branch

            # PROGRESS-BASED RESERVATION (#13400): the reservation ends when the holder's CI STALLS or
            # passes the ceiling, never because it is slow. #13204 lapsed at 64 min on three heads
            # whose Services CI was green at 67.8 min, and was update-branched again each time.
            real_time = time.time

            def reservation_at(offset_s, last_activity_ago_s=None, checks=None):
                """Settle with the clock `offset_s` past the reserved head's commit; its newest check-run
                activity `last_activity_ago_s` before that (None: no check run ever started). `checks`
                overrides the head's required contexts (default: one still pending)."""
                open_only("pW", "pF")
                head = gh.prs[35]["head"]["sha"]
                gh.head_checks[head] = {"gates (data)": None} if checks is None else checks
                ct = int(gh.g("show", "-s", "--format=%ct", head).stdout.strip())
                if last_activity_ago_s is not None:
                    gh.activity[head] = ct + offset_s - last_activity_ago_s
                last_reservation.update(ct=ct, now=ct + offset_s, activity=gh.activity.get(head))
                time.time = lambda: ct + offset_s
                try:
                    return settle_now()
                finally:
                    time.time = real_time
                    gh.head_checks.clear()
                    gh.activity.clear()

            # (a) slow but live: 90 min in, a job finished 2 min ago — main stays reserved.
            s = reservation_at(90 * 60, 2 * 60)
            check("reservation: slow but progressing CI (90 min, last job 2 min ago) keeps main reserved",
                  s["in_flight"] and s["fast"] == [] and not s.get("timed_out"), str(s))
            reset()
            # (b) stalled: 20 min in, nothing started or finished since the update-branch.
            s = reservation_at(RESERVATION_STALL_S + 5 * 60)
            check("reservation: stalled CI (nothing started or completed in the stall window) times out",
                  34 in s["fast"] and s.get("timed_out") == [35], str(s))
            reset()
            # (b') stalled after progress: jobs ran, then nothing for longer than the window.
            s = reservation_at(40 * 60, RESERVATION_STALL_S + 60)
            check("reservation: CI that progressed and then stalled times out",
                  34 in s["fast"] and s.get("timed_out") == [35], str(s))
            reset()
            # (c) the hard ceiling bounds a CI that keeps trickling forever.
            s = reservation_at(RESERVATION_CEILING_S + 60, 60)
            check("reservation: past the hard ceiling the reservation times out even while CI progresses",
                  34 in s["fast"] and s.get("timed_out") == [35], str(s))
            reset()
            # (d) a future-dated head still holds nothing, even with live CI activity (#13485).
            s = reservation_at(-3600, -3600 - 60)
            check("reservation: a head committed in the future times out even with live CI activity",
                  34 in s["fast"] and s.get("timed_out") == [35], str(s))
            reset()
            # The pin is live: a fresh fixture head carries exactly the pinned instant, so the default
            # clock sees it as age 0 whatever the suite's real duration. If git ignored the pinned date
            # (or a read bypassed it) the head would be stale or future-dated and every holder would
            # time out. `open_only` cuts the heads, so measure one.
            open_only("pW", "pF")
            ct_pin = int(gh.g("show", "-s", "--format=%ct", gh.prs[35]["head"]["sha"]).stdout.strip())
            check("clock pin: a fixture head is stamped with the pinned instant (age 0 on the default clock)",
                  ct_pin == int(time.time()), f"head ct={ct_pin} time.time={time.time():.0f}")
            reset()

            # GREEN IS DONE, NOT STALLED: #13608 went green ~05:50Z, nothing ran after it, and the next tick
            # read the silence as a stall and released a mergeable holder to the back of the queue.
            # (e) green, last check activity 20 min ago: merged this tick, not released.
            gh.merged.clear()
            s = reservation_at(30 * 60, RESERVATION_STALL_S + 5 * 60, checks={})
            check("reservation: a GREEN holder idle past the stall window is merged, not released (#13608)",
                  gh.merged == [35] and not s.get("timed_out"), f"{s} merged={gh.merged}")
            gh.merged.clear()
            reset()
            # GREEN PAST THE CEILING (#14624, 2026-11-03): starved ticks carried a fully green, up-to-date
            # holder past the ceiling and it was released instead of merged. Green is checked first.
            # (e2) green on an up-to-date head, past the ceiling: merged, not released.
            gh.merged.clear()
            s = reservation_at(RESERVATION_CEILING_S + 60, 60, checks={})
            check("reservation: a GREEN up-to-date holder past the ceiling is merged, not released",
                  gh.merged == [35] and not s.get("timed_out"), f"{s} merged={gh.merged}")
            gh.merged.clear()
            reset()
            # (e3) NOT green (pending) past the ceiling: still released.
            s = reservation_at(RESERVATION_CEILING_S + 60, 60)
            check("reservation: a PENDING holder past the ceiling is still released",
                  s.get("timed_out") == [35] and 35 not in gh.merged, f"{s} merged={gh.merged}")
            reset()
            # (e4) green but BEHIND main, past the ceiling: never merged from there (it is updated instead).
            open_only("pW", "pF")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {}
            main_advance = pathlib.Path(origin, "svc", "advance.txt")
            main_advance.parent.mkdir(parents=True, exist_ok=True)
            main_advance.write_text("advance\n")
            gh.g("checkout", "-q", "-f", "main")
            gh.g("add", "svc/advance.txt")
            gh.g("-c", "user.email=t@t", "-c", "user.name=t", "commit", "-q", "-m", "advance main")
            ct_b = int(gh.g("show", "-s", "--format=%ct", gh.prs[35]["head"]["sha"]).stdout.strip())
            time.time = lambda: ct_b + RESERVATION_CEILING_S + 60
            try:
                s = settle_now()
            finally:
                time.time = real_time
                gh.head_checks.clear()
            check("reservation: a GREEN holder BEHIND main past the ceiling is not merged",
                  35 not in gh.merged, f"{s} merged={gh.merged}")
            gh.updates.clear()
            reset()
            # (d) green, merge refused every tick, past the hard cap: released (bounded escape).
            open_only("pW", "pF")
            gh.refuse_merge.add(35)
            s = reservation_at(GREEN_HOLDER_CAP_S + 60, 60, checks={})
            check("reservation: a GREEN holder whose merge is refused every tick is released past the hard cap",
                  s.get("timed_out") == [35] and 35 not in gh.merged, f"{s} merged={gh.merged}")
            gh.refuse_merge.clear()
            reset()
            # (f) pending, no activity for 20 min: still a stall.
            s = reservation_at(30 * 60, RESERVATION_STALL_S + 5 * 60)
            check("reservation: a PENDING holder idle past the stall window is released (stall)",
                  s.get("timed_out") == [35] and 35 not in gh.merged, f"{s} merged={gh.merged}")
            reset()
            # (g) pending with recent activity: kept.
            s = reservation_at(30 * 60, 60)
            check("reservation: a PENDING holder with recent activity keeps main reserved",
                  s["in_flight"] and not s.get("timed_out") and 35 not in gh.merged, str(s))
            reset()
            # (h) red: the failure path, never reported as a stall and never holding main.
            s = reservation_at(30 * 60, RESERVATION_STALL_S + 5 * 60, checks={"gates (data)": "failure"})
            check("reservation: a RED holder takes the failure path, not the stall path",
                  not s.get("timed_out") and 35 not in gh.merged and 34 in s["fast"], f"{s} merged={gh.merged}")
            reset()
            # #14302 COOLDOWN: a head whose reservation timed out does not reserve main again when its CI
            # resumes. #14187 timed out at 13:33Z and was re-reserved as soon as a job started, so the
            # next strict PR and the fast lane stayed held. Tick 1 stalls; tick 2 shows fresh activity.
            s1 = reservation_at(RESERVATION_STALL_S + 5 * 60)
            marked = RELEASED_CONTEXT in gh.app_statuses(gh.prs[35]["head"]["sha"])
            s2 = reservation_at(30 * 60, 60)
            check("reservation cooldown: a timed-out head is marked and NOT re-reserved when its CI resumes",
                  s1.get("timed_out") == [35] and marked and not s2["in_flight"] and 34 in s2["fast"]
                  and s2.get("timed_out") == [35], f"marked={marked} s1={s1} s2={s2}")
            reset()

            # #14302 QUEUED CI IS CI: nested reusable-workflow contexts register no check run until their
            # caller starts. latest_ci_activity feeds reservation_expired's stall clock.
            t0 = 1_800_000_000.0
            stale = [{"started_at": datetime.datetime.fromtimestamp(t0 - RESERVATION_STALL_S - 300, datetime.timezone.utc)
                      .strftime("%Y-%m-%dT%H:%M:%SZ")}]
            act = latest_ci_activity([], lambda: [{"status": "queued"}], t0)
            check("stall clock: a head whose only CI is a QUEUED workflow run is active (no timeout)",
                  act is not None and t0 - act <= RESERVATION_STALL_S, f"activity={act}")
            act = latest_ci_activity(stale, lambda: [{"status": "in_progress"}], t0)
            check("stall clock: stale check runs + an IN-PROGRESS workflow run is active (no timeout)",
                  act is not None and t0 - act <= RESERVATION_STALL_S, f"activity={act}")
            act = latest_ci_activity(stale, lambda: [{"status": "completed"}, {"status": "waiting"}], t0)
            check("stall clock: stale check runs and nothing queued or running still times out",
                  act is not None and t0 - act > RESERVATION_STALL_S, f"activity={act}")
            check("stall clock: no check run and no live workflow run is no activity at all",
                  latest_ci_activity([], lambda: [], t0) is None)
            fresh = [{"started_at": datetime.datetime.fromtimestamp(t0 - 60, datetime.timezone.utc)
                      .strftime("%Y-%m-%dT%H:%M:%SZ")}]

            def no_read():
                raise AssertionError("workflow runs read although a check run is fresh")
            try:
                act, ok = latest_ci_activity(fresh, no_read, t0), True
            except AssertionError:
                act, ok = None, False
            check("stall clock: a fresh check run costs no workflow-runs read (API budget)",
                  ok and act == t0 - 60, f"activity={act}")

            # #13485: what #13500 left open; both cases fail on the code before it.
            # (a) right after update-branch nothing has REPORTED yet; that head must still hold main.
            open_only("pW", "pF")
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {c: "absent" for c in SYN_REQUIRED[:4]}
            s = settle_now()
            check("reservation: a head whose CI has not reported yet still holds main (fast lane held)",
                  s["in_flight"] and s["fast"] == [], str(s))
            gh.head_checks.clear()
            reset()

            # (b) the committer time is the author's: a head dated in the future holds nothing.
            real_time = time.time
            time.time = lambda: real_time() - 3600
            try:
                open_only("pW", "pF")
                gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
                s = settle_now()
            finally:
                time.time = real_time
                gh.head_checks.clear()
            check("reservation timeout: a head committed in the future holds no reservation",
                  34 in s["fast"] and s.get("timed_out") == [35], str(s))
            reset()

            # ---- main-red awareness: the strict lane never deadlocks behind a PR red only because main is ----
            MR = "Validate manifests"

            def main_breaks(base_red=False):
                """Advance main by one commit whose own CI is red on MR (and base0 too, if base_red), so
                every fixture PR is behind a red main tip."""
                if base_red:
                    gh.head_checks[base0] = {MR: "failure"}
                pathlib.Path(origin, "svc", "break.txt").parent.mkdir(parents=True, exist_ok=True)
                pathlib.Path(origin, "svc", "break.txt").write_text("break\n")
                gh.g("add", "-A")
                gh.g("commit", "-q", "-m", "break main")
                gh.head_checks[gh.main_sha()] = {MR: "failure"}

            def main_red_done():
                gh.head_checks.clear()
                gh.jobs.clear()
                gh.head_jobs.clear()
                gh.updates.clear()
                reset()

            # The production deadlock: an older manual-lane PR red only on the main-red context (one
            # context still running), a newer green PR cut from the red main that fixes it. The fix
            # merges first; the old PR is skipped and reserves nothing.
            # A fix behind main is never merged untested against main (#13517 merged it without update):
            # it is update-branched first, holds main while CI runs on the COMBINED head, and merges only
            # once that head verifies — fix set green, every other context green or red on main too.
            def fix_behind(combined=None, main_also_red=(), fix="pW2", fix_head=None, tamper=None):
                """pW (#35, red on MR) + the fix `fix` (default pW2 #36, green over base0 red on MR) behind
                a red main. Settles once (update-branch), gives the combined head `combined` checks (None =
                still running), settles again. Returns (first settle, second settle). `fix_head`: checks
                on the fix's own head before the update; `tamper(pr)`: edits the fix PR before settling."""
                fn = numbers[fix]
                open_only("pW", fix)
                if tamper:
                    tamper(gh.prs[fn])
                main_breaks(base_red=True)
                for c in main_also_red:
                    gh.head_checks[gh.main_sha()][c] = "failure"
                gh.head_checks[gh.prs[35]["head"]["sha"]] = {MR: "failure", "gates (data)": None}
                if fix_head is not None:
                    gh.head_checks[gh.prs[fn]["head"]["sha"]] = fix_head
                first = settle_now()
                if gh.updates != [fn]:
                    return first, None
                if combined is None:
                    gh.pending_shas.add(gh.prs[fn]["head"]["sha"])
                else:
                    gh.head_checks[gh.prs[fn]["head"]["sha"]] = combined
                return first, settle_now()

            s1, s2 = fix_behind(None)
            check("main red: a fix behind main is update-branched, not merged, and holds main while its combined CI runs",
                  gh.merged == [] and gh.updates == [36] and s1["in_flight"] and s1.get("waiting", []) == [35]
                  and s1.get("main_red", []) == [MR] and s2 is not None and s2["in_flight"] and gh.merged == [],
                  f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            gh.pending_shas.clear()
            main_red_done()

            s1, s2 = fix_behind({MR: "failure"})
            check("main red: a combined fix head red on the fix context is not merged",
                  gh.merged == [] and s2 is not None and not s2["in_flight"], f"merged={gh.merged} {s2}")
            main_red_done()

            s1, s2 = fix_behind({MR: "success", "gates (data)": "failure"}, main_also_red=("gates (data)",))
            check("main red: a combined fix head red only on a context main is red on too merges, pinned to that head",
                  gh.merged == [36] and strict_desc(36)[1].startswith("strict lane: fix for Validate manifests")
                  and "verified on its up-to-date head" in strict_desc(36)[1],
                  f"merged={gh.merged} {s2} status={strict_desc(36)}")
            main_red_done()

            s1, s2 = fix_behind({MR: "success", "derived": "failure"})
            check("main red: a combined fix head with a NEW red context is not merged",
                  gh.merged == [] and s2 is not None and not s2["in_flight"], f"merged={gh.merged} {s2}")
            main_red_done()

            s1, s2 = fix_behind({})
            check("main red: a combined fix head green everywhere merges",
                  gh.merged == [36] and s1.get("waiting", []) == [35], f"merged={gh.merged} {s1} {s2}")
            main_red_done()

            # 2026-11-13: main red on MR because a LEAF job (Admin UI) failed. A PR whose path-scoped CI
            # SKIPPED that job reads MR green but tested nothing: not a fix, so no update and no slot.
            def leaf_red(head_ui):
                def tamper(_p):
                    gh.jobs[base0] = {"Admin UI": "failure"}
                    gh.head_jobs["Admin UI"] = head_ui
                return tamper
            s1, s2 = fix_behind({}, tamper=leaf_red("skipped"))
            check("main red on a leaf job: a PR that SKIPPED the failing job is not a fix (no update, no merge)",
                  gh.updates == [] and gh.merged == [] and not s1["in_flight"] and s2 is None,
                  f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            check("main red on a leaf job: the refused fix and its reason reach the settle summary",
                  "Admin UI (skipped)" in (s1.get("not_fix") or {}).get(36, ""), str(s1.get("not_fix")))
            main_red_done()
            s1, s2 = fix_behind({}, tamper=leaf_red("success"))
            check("main red on a leaf job: a PR that RAN the failing job green is the fix (updated, merged)",
                  gh.updates == [36] and gh.merged == [36], f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            main_red_done()
            check("fix evidence: a job skipped on the head, or no job record, is never evidence",
                  fix_job_evidence({"A": "failure", MR: "failure"}, {"A": "skipped", MR: "success"}) is not None
                  and fix_job_evidence(None, {MR: "success"}) is not None
                  and fix_job_evidence({MR: "failure"}, None) is not None
                  and fix_job_evidence({MR: "success"}, {MR: "success"}) is not None
                  and fix_job_evidence({"A": "failure", MR: "failure"}, {"A": "success", MR: "success"}) is None)
            # A leaf that TIMED OUT (or was cancelled) on main still failed the aggregate: a head that skipped
            # it is no fix, exactly like a leaf that failed outright (#16005's hole through another door).
            check("fix evidence: a cancelled or timed-out main job is a failure the head must clear",
                  fix_job_evidence({"A": "timed_out", MR: "failure"}, {"A": "skipped", MR: "success"}) is not None
                  and fix_job_evidence({"A": "cancelled", MR: "failure"}, {"A": "skipped", MR: "success"}) is not None
                  and fix_job_evidence({"A": "timed_out", MR: "failure"}, {"A": "success", MR: "success"}) is None)
            s1, s2 = fix_behind({}, tamper=lambda _p: (gh.jobs.update({base0: {"Admin UI": "timed_out"}}),
                                                       gh.head_jobs.update({"Admin UI": "skipped"})))
            check("main red with a TIMED-OUT leaf beside the failed aggregate: a head that skipped it is REFUSED",
                  gh.updates == [] and gh.merged == [] and "Admin UI (skipped)" in (s1.get("not_fix") or {}).get(36, ""),
                  f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            main_red_done()
            # Main red on a gate SELF-TEST (unfalsified): a head whose shard job ran green without that
            # self-test is no fix (2026-11-17, #16627/#16644 over event-contract-code-agreement). The
            # synthetic gates.yaml declares g-one and g-two with no inputs (their self-tests always run)
            # and no g-nine; the fixture's shard records default to a content failure.
            unf = lambda gid: [{"id": gid, "status": "unfalsified", "failure_kind": "unfalsified"}]   # noqa: E731
            def shard_red(records):
                return lambda _p: (gh.jobs.update({base0: {"gates (data)": "failure"}}),
                                   gh.head_jobs.update({"gates (data)": "success"}),
                                   gh.gate_records_by.update({(base0, "data"): records}))
            # Fix PRs here edit docs (pX #33), not .github/scripts/: a fix claim may not edit the judge (prefix rule).
            s1, s2 = fix_behind({}, fix="pX", tamper=shard_red(unf("g-nine")))
            # pX is a promoted train candidate: promote_fixes judges it with record=False (a candidate that is not
            # a fix just stays a candidate), so the refusal shows as "not served", never as a not_fix reason.
            check("main red on an UNFALSIFIED gate the head does not declare: a head green on the shard is REFUSED (not served)",
                  gh.updates == [] and gh.merged == [] and 33 not in (s1.get("not_fix") or {}),
                  f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            gh.gate_records_by.clear()
            main_red_done()
            s1, s2 = fix_behind({}, fix="pX", tamper=shard_red(unf("g-one")))
            check("main red on an UNFALSIFIED gate whose self-test always runs on a PR: the green head is the fix",
                  gh.updates == [33] and gh.merged == [33], f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            gh.gate_records_by.clear()
            main_red_done()
            s1, s2 = fix_behind({}, fix="pX", tamper=shard_red([{"id": "g-one", "status": "failed", "failure_kind": "content"}]))
            check("main red on a gate shard for CONTENT: a head green on the shard is the fix, as before",
                  gh.updates == [33] and gh.merged == [33], f"merged={gh.merged} updates={gh.updates} {s1} {s2}")
            gh.gate_records_by.clear()
            main_red_done()
            # Gate-level evidence and evidence-first ordering (2026-11-18): two green strict-lane fixes
            # behind a main red on the content of gate g-one in shard `data`: pX (#33, docs, older) and pF
            # (#34, svc, newer) — both outside the judge trees, so the prefix rule lets them claim. Each case
            # names what the HEAD's gate results say about g-one.
            def two_fixes(rec33, rec34, slug33="data"):
                open_only("pW", "pX", "pF")
                main_breaks(base_red=True)
                gh.jobs[base0] = {"gates (data)": "failure", "gates (kotlin)": "success"}   # both shards exist on the base run
                gh.head_jobs.update({"gates (data)": "success", "gates (kotlin)": "success"})
                gh.head_checks[gh.prs[35]["head"]["sha"]] = {MR: "failure", "gates (data)": None}
                gh.gate_records_by[(base0, "data")] = [{"id": "g-one", "status": "failed", "failure_kind": "content"}]
                for n, rec, slug in ((33, rec33, slug33), (34, rec34, "data")):
                    if rec is not None:
                        gh.gate_records_by[(gh.prs[n]["head"]["sha"], slug)] = rec
                s = settle_now()
                out = (list(gh.updates), dict(s.get("not_fix") or {}))
                gh.gate_records_by.clear()
                main_red_done()
                return out
            g_ok = [{"id": "g-one", "status": "ok"}]
            g_skipped = [{"id": "g-one", "status": "skipped"}]
            g_red = [{"id": "g-one", "status": "failed", "failure_kind": "content"}]
            updates, not_fix = two_fixes(g_skipped, g_ok)
            check("#16690 shape: the older full-fleet head that SKIPPED the red gate is only job-level; the head that passed it is served first",
                  updates == [34] and 33 not in not_fix, f"updates={updates} not_fix={not_fix}")
            updates, not_fix = two_fixes(None, g_ok)
            check("evidence first: a newer gate-verified fix is update-branched before an older job-level one (artifacts unreadable)",
                  updates == [34] and 33 not in not_fix, f"updates={updates} not_fix={not_fix}")
            updates, not_fix = two_fixes(g_ok, None, slug33="kotlin")
            check("moved shard: the red gate ok in ANOTHER shard of the older head verifies it, and it is served first",
                  updates == [33], f"updates={updates} not_fix={not_fix}")
            updates, not_fix = two_fixes(g_red, g_ok)
            check("a head on which the red gate is still red is not a fix: the other head is served, this one never (promoted "
                  "candidates are refused silently, record=False)", updates == [34] and 33 not in updates, f"updates={updates} not_fix={not_fix}")
            updates, not_fix = two_fixes(g_ok, g_ok)
            check("equal evidence: the older fix is served first", updates == [33], f"updates={updates} not_fix={not_fix}")
            updates, not_fix = two_fixes(None, None)
            check("both heads unreadable: the job rule stands and age decides, as before", updates == [33], f"updates={updates}")
            # And the fixture's own strict-lane "fix" PRs, which edit .github/scripts/, are now refused by the prefix rule.
            open_only("pW", "pW2")
            main_breaks(base_red=True)
            gh.jobs[base0] = {"gates (data)": "failure"}
            gh.head_jobs["gates (data)"] = "success"
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {MR: "failure", "gates (data)": None}
            s = settle_now()
            check("judge prefix (e2e): a green PR editing .github/scripts/ is refused as a fix on a red gate shard, not update-branched",
                  gh.updates == [] and "changes the judge (.github/scripts/two.py)" in (s.get("not_fix") or {}).get(36, ""),
                  f"updates={gh.updates} not_fix={s.get('not_fix')}")
            gh.gate_records_by.clear()
            main_red_done()
            # Judge change: a fix candidate that edits a workflow is refused outright (security review).
            open_only("pW", "pJ2")
            main_breaks(base_red=True)
            gh.jobs[base0] = {"gates (data)": "failure"}
            gh.head_jobs["gates (data)"] = "success"
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {MR: "failure", "gates (data)": None}
            s = settle_now()
            check("judge change: a green PR editing .github/workflows/ is refused as a fix, not update-branched",
                  gh.updates == [] and "changes the judge" in (s.get("not_fix") or {}).get(82, ""), f"updates={gh.updates} not_fix={s.get('not_fix')}")
            h82 = gh.prs[82]["head"]["sha"]
            claims = [st for st in gh.statuses.get(h82, []) if st[0] == FIX_CLAIM_CONTEXT]
            check("refusal visibility (e2e): the refused head carries ONE merge-train/fix-claim status naming the reason and main",
                  len(claims) == 1 and claims[0][1] == "failure" and "changes the judge" in claims[0][2] and "over main" in claims[0][2]
                  and s.get("fix_claim_posted") == [82], f"{claims} {s.get('fix_claim_posted')}")
            # The same refusal again (what the next tick would publish, without spending a whole fixture tick
            # on it: the self-test budgets subprocess spawns): nothing more is posted.
            again = publish_fix_claims(gh, gh.main_sha(), dict(s.get("not_fix") or {}), {82: h82}, shadow=False)
            claims = [st for st in gh.statuses.get(h82, []) if st[0] == FIX_CLAIM_CONTEXT]
            check("refusal visibility (e2e): publishing the same refusal again over the same main posts nothing more",
                  len(claims) == 1 and again == [], f"{claims} {again}")
            gh.gate_records_by.clear()
            main_red_done()
            # Independent masking: an unclaimed context red on main may be masked on the combined head only
            # when the head fails no job for it that main did not.
            s1, s2 = fix_behind({MR: "success", "gates (data)": "failure"}, main_also_red=("gates (data)",),
                                tamper=lambda _p: gh.head_jobs.update({"Admin UI": "failure"}))
            check("masking: a combined head that fails an EXTRA job under an unclaimed main-red context is not merged",
                  gh.updates == [36] and gh.merged == [], f"merged={gh.merged} updates={gh.updates} {s2}")
            main_red_done()

            # The fix path takes manual-lane paths exactly as the strict lane does (pW2 touches
            # .github/scripts — the merge above), and refuses everything strict_lane_state refuses.
            for label, kw in [
                    ("adds a symlink", {"fix": "pS"}),
                    ("is a draft", {"tamper": lambda p: p.update(draft=True)}),
                    ("is from a fork", {"tamper": lambda p: p["head"].update(repo={"full_name": "fork/r"})}),
                    ("is refused by agent-pr-guard", {"fix_head": {"gates / agent-pr-guard": "failure"}})]:
                s1, s2 = fix_behind({}, **kw)
                fn = numbers[kw.get("fix", "pW2")]
                check(f"main red: a fix that {label} is neither updated nor merged",
                      gh.merged == [] and fn not in gh.updates and not strict_desc(fn)[0],
                      f"merged={gh.merged} updates={gh.updates} {s1} {s2} status={strict_desc(fn)}")
                main_red_done()
            def no_git(*_a, **_k):
                raise AssertionError("fix_head_state reached git for an unsafe path")
            try:
                ctl = fix_head_state(gh, no_git, "b", {"files": ["a\nb"], "head_sha": "h"}, [MR], {}, None, [],
                                     {MR: "m"})
            except AssertionError as e:
                ctl = (e,)
            check("fix path: a control-character path is refused before any git call", ctl[0] is None, str(ctl))

            # Main red: a green PR whose CI ran over a GREEN base is not a fix — no update-branch onto
            # the red tip (it would only manufacture main-caused red), and no merge.
            open_only("pW", "pW2")
            main_breaks()
            s = settle_now()
            check("main red: no update-branch and no merge for a green PR that is not the fix",
                  gh.updates == [] and gh.merged == [] and s["updated"] == [] and s.get("main_red", []) == [MR],
                  f"merged={gh.merged} updates={gh.updates} {s}")
            main_red_done()

            # A PR red on its OWN context (not red on main) is judged as before: no lane, no wait.
            open_only("pW")
            main_breaks()
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": "failure", MR: "failure"}
            s = settle_now()
            check("main red: a PR also red on a context main is green on is not 'waiting' and gets nothing",
                  gh.updates == [] and gh.merged == [] and s.get("waiting", []) == [] and not strict_desc(35)[0],
                  f"merged={gh.merged} updates={gh.updates} {s}")
            main_red_done()
            open_only("pW")
            main_breaks()
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            gh.g("checkout", "-q", "-f", "-B", "pW-cur", "pW")
            gh.g("merge", "-q", "--no-edit", "main")
            gh.g("checkout", "-q", "-f", "main")
            gh.prs[35]["head"].update(ref="pW-cur", sha=gh.g("rev-parse", "pW-cur").stdout.strip())
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {"gates (data)": None}
            s = settle_now()
            check("main red: an up-to-date PR with CI still running and no failure still reserves main",
                  s["in_flight"] and gh.merged == [] and s.get("waiting", []) == [], f"{s} merged={gh.merged}")
            main_red_done()

            # ---- main red x reservation ----
            def reservation_now():
                sg = Git(clone("settle"))
                base, _rt, strict, _red, _c, _a, mr, mc = settle_view(gh, sg, "o/r", gh.required())
                return strict_reservation(sg, base, strict, fixes=strict_fixes(gh, sg, base, strict, mr, mc))

            # A main-red "waiting" PR, even up to date with CI still running, never holds main: the fast
            # lane is not held for a PR that cannot go green until main is fixed.
            open_only("pW", "pF")
            main_breaks(base_red=True)
            gh.g("checkout", "-q", "-f", "-B", "pW-cur", "pW")
            gh.g("merge", "-q", "--no-edit", "main")
            gh.g("checkout", "-q", "-f", "main")
            gh.prs[35]["head"].update(ref="pW-cur", sha=gh.g("rev-parse", "pW-cur").stdout.strip())
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {MR: "failure", "gates (data)": None}
            holder, _to = reservation_now()
            s = settle_now()
            # pF's own CI ran green over base0, which is red here: by fix_contexts it is a FIX, so it is served
            # first in its own right (every lane, ADR-0343): behind main, it is update-branched (update then
            # verify) — what matters is that the waiting PR holds nothing.
            check("main red x reservation: a waiting PR is never the holder; the fast lane is not held for it",
                  holder != 35 and s.get("waiting", []) == [35]
                  and (34 in s["fast"] or 34 in gh.merged or s["updated"] == [34]) and s["updated"] in ([], [34]),
                  f"holder={holder} {s}")
            main_red_done()

            # The FIX behind a red main holds nothing until updated; once its combined head contains main
            # it is the holder: no fast-lane status and no train merge may move main under it.
            open_only("pW", "pW2", "pF")
            main_breaks(base_red=True)
            gh.head_checks[gh.prs[35]["head"]["sha"]] = {MR: "failure", "gates (data)": None}
            before, _to = reservation_now()
            s1 = settle_now()
            # pW2 (#36) and pF (#34) are both fixes of equal, job-level evidence: the OLDER one, pF, is served
            # first (strongest evidence, then age — fixes_first); it used to be pW2 only because strict-lane
            # entries preceded promoted candidates in list order.
            gh.pending_shas.add(gh.prs[34]["head"]["sha"])
            holder, _to = reservation_now()
            s = settle_now()
            check("main red x reservation: the updated fix is the holder while its combined CI runs; the fast lane waits",
                  before is None and gh.updates == [34] and holder == 34 and gh.merged == [] and s1["fast"] == []
                  and s["fast"] == [] and s["in_flight"], f"before={before} holder={holder} merged={gh.merged} {s1} {s}")
            gh.pending_shas.clear()
            main_red_done()

            # ---- main red x EVERY lane: a fix is served first even when it is not manual-lane ----
            def main_breaks_on_content():
                """main gains bad.txt, so its own CI (ci.py) is red on MR; returns a NON-manual-lane fix PR
                (#70) cut from that red tip that deletes it — green over a base red on MR."""
                pathlib.Path(origin, "bad.txt").write_text("x\n")
                gh.g("add", "-A")
                gh.g("commit", "-q", "-m", "break main (content)")
                gh.g("checkout", "-q", "-f", "-B", "pZ", "main")
                gh.g("rm", "-q", "bad.txt")
                gh.g("commit", "-q", "-m", "pZ: fix main")
                gh.g("checkout", "-q", "-f", "main")
                gh.add_pr(70, "pZ", "2026-01-70")

            open_only("p1")
            main_breaks_on_content()
            s = settle_now()
            # pZ is cut from the red tip itself, so its merge-base IS live main: its own CI already tested
            # exactly what merges, and no update is needed (the one case a fix merges as it stands).
            check("main red, any lane: a non-manual-lane fix already up to date merges first, alone, verified",
                  gh.merged == [70] and gh.updates == [] and 1 not in gh.merged and 70 in s["strict"]
                  and "verified on its up-to-date head" in strict_desc(70)[1],
                  f"merged={gh.merged} updates={gh.updates} {s} status={strict_desc(70)}")
            main_red_done()

            open_only("p1")
            main_breaks_on_content()
            _f, train, _z = plan_train(gh, Git(clone("plan")), "o/r", gh.main_sha())
            check("main red, any lane: no train is planned over a red main (it could only come back red)",
                  train == [], str([m.number for m in train]))
            main_red_done()

            # A train over a red main that is red ONLY on the main-red context blames nobody. The train is
            # built while main still reads green (main CI not reported yet), then main's red verdict lands.
            open_only("p1")
            pathlib.Path(origin, "bad.txt").write_text("x\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "break main (content)")
            gh.head_checks[gh.main_sha()] = {MR: "success"}
            tick()
            gh.head_checks.clear()
            s = settle_now()
            check("main red: a train red only on a main-red context names no culprit and bisects nothing",
                  s["culprits"] == [] and s["bisected"] == [] and s["inconclusive"] and mt_status(1)[0] != "failure"
                  and not gh.comments and not open_carriers(), f"{s} status={mt_status(1)} comments={gh.comments}")
            main_red_done()

            # ... but a context main is GREEN on still blames, naming only that context.
            open_only("p3", "p1")
            pathlib.Path(origin, "services", "z.txt").write_text("z\n")   # count.txt now wrong: gates (data) red
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "break main (data)")
            gh.head_checks[gh.main_sha()] = {"gates (data)": "success", "derived": "success"}
            gh.prs[3]["created_at"] = "2026-01-00"
            tick(batch_size=1)
            gh.head_checks.clear()
            gh.reruns.clear()
            s1 = settle_now()
            check("main red: the lone member is re-run once first, and only on the context main is green on (#15420)",
                  s1["culprits"] == [] and len(gh.reruns) == 1 and "gates (data)" not in gh.reruns[0][1], f"{s1} {gh.reruns}")
            gh.update_refuse = True   # the refusal path: a behind-main culprit whose update-branch fails
            s = settle_now()
            gh.update_refuse = False
            check("main red: a refused update-branch leaves the ordinary culprit comment and no refresh",
                  (3, CULPRIT_MESSAGE) in gh.comments and (3, STALE_CULPRIT_MESSAGE) not in gh.comments
                  and 3 not in s["refreshed"], f"{s} {gh.comments}")
            check("main red: a context main is green on still names the culprit, and only that context",
                  s["culprits"] == [3] and mt_status(3)[1].startswith(CULPRIT_PREFIX + "Validate manifests red")
                  and "gates (data)" not in mt_status(3)[1] and len(gh.reruns) == 1, f"{s} status={mt_status(3)}")
            gh.reruns.clear()
            main_red_done()

            # Every open PR leaves a decision line, armed or not (a disarmed fix was invisible in the log).
            open_only("p1", "p2")
            gh.prs[1]["auto_merge"] = None
            gh.prs[2]["draft"] = True
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                settle_now()
            check("settle log: a disarmed and a draft PR each get a decision line",
                  "#     1 skip      auto-merge not armed" in buf.getvalue() and "#     2 skip      draft" in buf.getvalue(),
                  buf.getvalue()[-400:])
            reset()

            # ---- stale-red refresh: PRs left red by a red MAIN get one update-branch once main is green ----
            VM = "Validate manifests"

            def stale_red(*branches, base_red=True, tip_red=False, behind=True):
                """Open `branches` red on VM; main at their base red on VM (or not); main then gets a
                fix commit (unless not behind) whose own CI is green on VM (or still red)."""
                gh.updates.clear()
                gh.head_checks.clear()
                open_only(*branches)
                if base_red:
                    gh.head_checks[base0] = {VM: "failure"}
                if behind:
                    pathlib.Path(origin, "svc", "fix.txt").parent.mkdir(parents=True, exist_ok=True)
                    pathlib.Path(origin, "svc", "fix.txt").write_text("fix\n")
                    gh.g("add", "-A")
                    gh.g("commit", "-q", "-m", "fix main")
                    if tip_red:
                        gh.head_checks[gh.main_sha()] = {VM: "failure"}
                for br in branches:
                    gh.head_checks[gh.prs[numbers[br]]["head"]["sha"]] = {VM: "failure"}

            def stale_done():
                gh.head_checks.clear()
                gh.main_sequence.clear()
                gh.updates.clear()
                reset()

            stale_red("p1")
            s = settle_now()
            check("stale-red: red on a context main was red on at its base, green on the tip -> refreshed",
                  gh.updates == [1] and s["refreshed"] == [1] and gh.merged == [], f"updates={gh.updates} {s}")
            # After the refresh its base contains the fixed main; still red -> never refreshed again.
            gh.head_checks[gh.prs[1]["head"]["sha"]] = {VM: "failure"}
            gh.updates.clear()
            s = settle_now()
            check("stale-red: a refreshed PR still red is not refreshed again (no loop)",
                  gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p1", base_red=False)
            s = settle_now()
            check("stale-red: red on a context that was green on main at its base -> NOT refreshed (own defect)",
                  gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            # Not behind: main's CI for the tip finishes mid-tick (a re-run of the failed job going
            # green), so one read says red and the next green. Only the behind test stops it.
            stale_red("p1", behind=False)
            gh.main_sequence[base0] = [{VM: "failure"}, {VM: "success"}]
            s = settle_now()
            check("stale-red: red but not behind main -> NOT refreshed",
                  gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p4", "p2", "p1")
            s = settle_now()
            check("stale-red: three eligible PRs -> only 2 refreshed, oldest first",
                  gh.updates == [1, 2] and s["refreshed"] == [1, 2], f"updates={gh.updates} {s}")
            stale_done()

            # The green candidate cap must not hide a later red PR from the independent stale-red
            # scan. Reuse one verified tree for these synthetic PRs; the status result is sequenced
            # per API read so the first 64 qualify and the 65th is stale-red.
            saved_prs, old_checks = gh.prs, gh.checks
            gh.prs = {}
            shared_head = gh.g("rev-parse", "p1").stdout.strip()
            for i in range(65):
                n = 1000 + i
                gh.prs[n] = {"number": n, "state": "open", "draft": False, "auto_merge": {"x": 1},
                             "title": f"p{n}", "body": "", "created_at": f"{i:03d}",
                             "user": {"login": "someone"},
                             "head": {"ref": "p1", "sha": shared_head, "repo": {"full_name": "o/r"}}}
            reads = [0]

            def sequenced_checks(sha):
                reads[0] += 1
                result = {c: "success" for c in SYN_REQUIRED[:4]}
                if reads[0] == 65:
                    result["Validate manifests"] = "failure"
                return result

            gh.checks = sequenced_checks
            red = []
            cands, _apps = live_candidates(gh, Git(clone("settle")), "o/r", gh.required(), base0,
                                           Untrainable(SYN_INVENTORY), red=red)
            check("stale-red: a later red PR is inspected after the 64-green candidate cap",
                  len(cands) == 64 and reads[0] == 65 and len(red) == 1 and red[0][0]["number"] == 1064,
                  f"candidates={len(cands)} status_reads={reads[0]} red={[x[0]['number'] for x in red]}")
            gh.prs, gh.checks = saved_prs, old_checks

            stale_red("p1", tip_red=True)
            s = settle_now()
            check("stale-red: main tip still red on that context -> NOT refreshed",
                  gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p1")
            gh.prs[1]["auto_merge"] = None
            s = settle_now()
            check("stale-red: a disarmed PR is NOT refreshed", gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p1")
            gh.prs[1]["draft"] = True
            s = settle_now()
            check("stale-red: a draft PR is NOT refreshed", gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p1")
            gh.head_checks[gh.prs[1]["head"]["sha"]]["gates / agent-pr-guard"] = "failure"
            s = settle_now()
            check("stale-red: a PR agent-pr-guard refused is NOT refreshed",
                  gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p1")
            gh.prs[1]["head"]["repo"] = {"full_name": "fork/r"}
            s = settle_now()
            check("stale-red: a fork PR is NOT refreshed", gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            stale_red("p1")
            s = mode_settle(gh, Git(clone("settle")), "o/r", True)
            check("stale-red: shadow settle refreshes nothing", gh.updates == [] and s["refreshed"] == [], f"updates={gh.updates} {s}")
            stale_done()

            # ---- extra gates, end to end: the declaration lives on main, every lane reads it ----
            def declare_extra_gates():
                p = pathlib.Path(origin, RULES_FILE)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(SYN_RULES)
                gh.g("add", "-A")
                gh.g("commit", "-q", "-m", "declare extra gates", check=False)  # already declared by the fixture

            def extra_done():
                gh.head_checks.clear()
                gh.carrier_override = {}
                gh.updates.clear()
                reset()

            def trivy(n, state):
                gh.head_checks.setdefault(gh.prs[n]["head"]["sha"], {})["Trivy"] = state

            # Red Trivy: never merged, in any lane (train/fast: p1, p2; strict: pW); told once per head.
            declare_extra_gates()
            carriers_before = len(gh.carriers)
            open_only("p1", "p2", "pW")
            for n in (1, 2, 35):
                trivy(n, "failure")
            drain(max_ticks=4)
            s = settle_once()
            told = [n for n, t in gh.comments if t == EXTRA_GATE_MESSAGE]
            check("extra gate red: an armed PR is never merged in any lane",
                  gh.merged == [] and gh.updates == [] and s["fast"] == [] and len(gh.carriers) == carriers_before,
                  f"merged={gh.merged} updates={gh.updates} carriers={len(gh.carriers) - carriers_before} {s}")
            check("extra gate red: the author is told once per head, the PR stays armed",
                  sorted(told) == [1, 2, 35] and all(gh.prs[n]["auto_merge"] for n in (1, 2, 35)), str(gh.comments))
            # A new head that turns the scan green is served without anyone re-arming it.
            trivy(1, "success")
            drain(max_ticks=4)
            check("extra gate red -> green on the same armed PR: served", 1 in gh.merged and 2 not in gh.merged,
                  str(gh.merged))
            extra_done()

            declare_extra_gates()
            open_only("p1")
            trivy(1, None)
            s = settle_once()
            _f, train, _z = plan_train(gh, Git(clone("plan")), "o/r", gh.main_sha())
            check("extra gate pending: waits (no fast lane, no train, no comment)",
                  gh.merged == [] and s["fast"] == [] and train == [] and not gh.comments, f"{s} {gh.comments}")
            extra_done()

            declare_extra_gates()
            open_only("p1")
            drain(max_ticks=4)
            check("extra gate not triggered on the head: served", gh.merged == [1] and not gh.comments,
                  f"{gh.merged} {gh.comments}")
            extra_done()

            # Carrier judged on the extra gate: red on the carrier with main green is a culprit (control) ...
            declare_extra_gates()
            open_only("p1", "p3")
            tick()
            gh.carrier_override = {"Trivy": "failure"}
            gh.head_checks[gh.main_sha()] = {"Trivy": "success"}   # main green: the override is the carrier's alone
            s = settle_once()
            check("extra gate on a carrier: red with main green is a verdict (bisect / culprit)",
                  gh.merged == [] and (s["bisected"] or s["culprits"]), str(s))
            extra_done()
            # ... and red on main too blames nobody: no verdict, no culprit, nothing merged.
            declare_extra_gates()
            open_only("p1")
            tick()
            gh.carrier_override = {"Trivy": "failure"}
            gh.head_checks[gh.main_sha()] = {"Trivy": "failure"}
            s = settle_once()
            check("extra gate red on main: the carrier blames nobody and nothing merges",
                  gh.merged == [] and not s["culprits"] and not s["bisected"] and s["inconclusive"]
                  and CULPRIT_MESSAGE not in [t for _n, t in gh.comments]
                  and mt_status(1)[0] != "failure", f"{s} {gh.comments} {mt_status(1)}")
            check("extra gate red on main: it reads as main red", "Trivy" in s["main_red"], str(s))
            extra_done()

            # Spoofing: a same-name GREEN Trivy from another app/workflow next to a pinned RED one.
            open_only("p1", "pW")
            for n in (1, 35):
                sha = gh.prs[n]["head"]["sha"]
                gh.head_checks[sha] = {"Trivy": "success"}            # the latest same-name run: spoofed green
                gh.pinned[sha] = {"Trivy": ["failure", "success"]}    # Security scan's own runs: one red
            drain(max_ticks=4)
            check("extra gate spoof: a green same-name run from another source cannot mask the pinned red",
                  gh.merged == [] and gh.updates == [], f"merged={gh.merged} updates={gh.updates}")
            gh.pinned.clear()
            extra_done()

            # Fail closed: declaration absent or unparseable on main -> nothing is served, nothing judged.
            for label, text in [("absent", None), ("unparseable", "merge_train:\n  extra_gates:\n    - Trivy\n")]:
                p = pathlib.Path(origin, RULES_FILE)
                if text is None:
                    gh.g("rm", "-q", RULES_FILE)
                else:
                    p.write_text(text)
                    gh.g("add", "-A")
                gh.g("commit", "-q", "-m", f"declaration {label}")
                open_only("p1", "pW")
                drain(max_ticks=3)
                _f, train, _z = plan_train(gh, Git(clone("plan")), "o/r", gh.main_sha())
                check(f"extra gate declaration {label}: no PR is served in any lane",
                      gh.merged == [] and gh.updates == [] and train == [] and _f == [],
                      f"merged={gh.merged} updates={gh.updates} train={[m.number for m in train]}")
                extra_done()
            # ---- notices (#13400): conflict-with-main drops and refused update-branch, once per head ----
            reset()
            gh.updates.clear()
            gh.g("checkout", "-q", "-f", "main")
            for rel, text in (("services/a.txt", "main-a\n"), ("count.txt", "2\n")):
                pathlib.Path(origin, rel).write_text(text)
            subprocess.run([sys.executable, SYN_GENERATOR], cwd=origin, check=True, env=base_env())
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main adds services/a.txt: pA now conflicts with main itself")
            open_only("pA")
            old_head = gh.prs[11]["head"]["sha"]
            for _ in range(3):
                tick()
            told = [t for n, t in gh.comments if n == 11 and t.startswith(CONFLICT_COMMENT)]
            st = mt_status(11)
            mt_posts = [x for x in gh.statuses.get(old_head, []) if x[0] == STATUS_CONTEXT]
            check("notice: a candidate conflicting with main gets ONE merge-train failure naming main",
                  st[0] == "failure" and st[1] == f"{CONFLICT_PREFIX}{gh.main_sha()[:12]}: merge main into the branch"
                  and len(mt_posts) == 1, f"{st} {mt_posts}")
            check("notice: ... and ONE comment listing the conflicting path, nothing repeated over 3 ticks",
                  len(told) == 1 and "`services/a.txt`" in told[0] and "`count.txt`" not in told[0]
                  and NOTICE_CONTEXT in gh.app_statuses(old_head), f"{gh.comments}")
            check("notice: no merge decision changed (nothing merged, no carrier for it)", gh.merged == [], str(gh.merged))
            # A new head (main merged in, conflict resolved) starts clean and is served.
            gh.g("checkout", "-q", "-b", "pA-fixed", "pA")
            pathlib.Path(origin, "services/a.txt").write_text("main-a\n")
            pathlib.Path(origin, "a-resolved.md").write_text("still has a change of its own\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "resolve")
            gh.g("checkout", "-q", "-f", "main")
            gh.prs[11]["head"].update(ref="pA-fixed", sha=gh.g("rev-parse", "pA-fixed").stdout.strip())
            check("notice: a new head carries none of it", not gh.app_statuses(gh.prs[11]["head"]["sha"]))
            drain(max_ticks=4)
            check("notice: a new head clears it — served, not told again",
                  gh.merged == [11] and len([1 for n, t in gh.comments if n == 11 and t.startswith(CONFLICT_COMMENT)]) == 1,
                  f"merged={gh.merged} {gh.comments}")
            gh.g("branch", "-q", "-D", "pA-fixed")
            reset()

            # Strict lane: a green manual-lane PR behind main whose update-branch GitHub refuses.
            gh.g("checkout", "-q", "-f", "main")
            pathlib.Path(origin, "docs/moved.md").parent.mkdir(parents=True, exist_ok=True)
            pathlib.Path(origin, "docs/moved.md").write_text("m\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main moves")
            open_only("pW")
            refused: list[int] = []
            gh.update_branch = lambda n, head: refused.append(n) and False
            try:
                for _ in range(3):
                    settle_once()
            finally:
                del gh.update_branch
            head35 = gh.prs[35]["head"]["sha"]
            told = [t for n, t in gh.comments if n == 35 and t.startswith(REFUSED_COMMENT)]
            # Quota (#13400): refused for THIS head over THIS main is not asked again until either moves.
            check("notice: a refused update-branch is asked once per (head, main), not every tick",
                  refused == [35] and gh.merged == [], f"{refused} {gh.merged}")
            check("notice: a refused update-branch is told ONCE per head (status + comment + marker)",
                  len(told) == 1 and mt_status(35)[1].startswith(REFUSED_PREFIX)
                  and len([x for x in gh.statuses.get(head35, []) if x[0] == STATUS_CONTEXT]) == 1
                  and NOTICE_CONTEXT in gh.app_statuses(head35), f"{gh.comments} {gh.statuses.get(head35)}")
            check("notice: a refused head is reported in every settle summary, not only the tick it was told",
                  35 in settle_once().get("refused", []), "not in the summary")
            # Stuck reporting: the clock is the notice's; the negative cases are the ones that stay silent.
            gh.notice_times[head35] = "2026-11-05T00:00:00Z"
            t0 = datetime.datetime(2026, 11, 5, tzinfo=datetime.timezone.utc).timestamp()
            quiet: dict = {}
            report_stuck(gh, False, quiet, stuck_prs(gh, "o/r", now=t0 + STUCK_AFTER_S - 1))
            check("stuck: a notice younger than the threshold opens no issue",
                  quiet["stuck"] == [] and gh.stuck_writes == [], f"{quiet} {gh.stuck_writes}")
            loud: dict = {}
            report_stuck(gh, True, loud, stuck_prs(gh, "o/r", now=t0 + STUCK_AFTER_S))
            check("stuck: shadow reports in the summary and writes nothing",
                  loud["stuck"] == [35] and gh.stuck_writes == [], f"{loud} {gh.stuck_writes}")
            for _ in range(3):
                report_stuck(gh, False, loud, stuck_prs(gh, "o/r", now=t0 + STUCK_AFTER_S + 60))
            check("stuck: an aged notice opens ONE issue naming the PR, and later ticks do not rewrite it",
                  len(gh.stuck_writes) == 1 and "#35:" in gh.stuck_writes[0], f"{gh.stuck_writes}")
            gh.prs[35]["auto_merge"] = None
            report_stuck(gh, False, loud, stuck_prs(gh, "o/r", now=t0 + STUCK_AFTER_S + 60))
            check("stuck: a disarmed PR is not stuck, and the emptied issue is closed",
                  gh.stuck_writes[-1] is None and gh.stuck_open == (None, None), f"{gh.stuck_writes}")
            bot = {"login": BOT_LOGIN}
            row = lambda i, ctx, state, who=bot: {"id": i, "context": ctx, "state": state, "creator": who,
                                                  "created_at": f"t{i}"}
            check("stuck: notice_since reads the App's notice, and only while merge-train has not gone green",
                  notice_since([row(1, STATUS_CONTEXT, "failure"), row(2, NOTICE_CONTEXT, "failure")]) == "t2"
                  and notice_since([row(2, NOTICE_CONTEXT, "failure"), row(3, STATUS_CONTEXT, "success")]) is None
                  and notice_since([row(1, NOTICE_CONTEXT, "failure", {"login": "someone"})]) is None, "")
            # Workflow refusal: real git. Three of the 2026-11-05 shapes; only the first creates a new blob.
            wg = Git(clone("wf"))
            wfp = pathlib.Path(wg.workdir, ".github/workflows/both.yml")
            wfp.parent.mkdir(parents=True, exist_ok=True)
            wfp.write_text("a\n\n\n\n\n\nz\n")
            pathlib.Path(wg.workdir, ".github/workflows/one.yml").write_text("x\n")
            ident = ("-c", "user.name=t", "-c", "user.email=t@t")
            def wf_commit(name, *edits):
                for f, text in edits:
                    pathlib.Path(wg.workdir, f).write_text(text)
                wg(*ident, "add", "-A")
                wg(*ident, "commit", "-q", "-m", name)
                return wg("rev-parse", "HEAD").stdout.strip()
            w0 = wf_commit("wf base")
            both, one = ".github/workflows/both.yml", ".github/workflows/one.yml"
            wmain = wf_commit("main", (both, "A\n\n\n\n\n\nz\n"))
            wg("checkout", "-q", w0)
            wsame = wf_commit("same file, other hunk", (both, "a\n\n\n\n\n\nZ\n"))
            wg("checkout", "-q", w0)
            wother = wf_commit("different workflow file", (one, "y\n"))
            wg("checkout", "-q", w0)
            wclash = wf_commit("same line", (both, "B\n\n\n\n\n\nz\n"))
            check("workflow refusal: the same file edited on both sides is a blob the App would create",
                  workflow_merge_blobs(wg, wmain, wsame) == [both], f"{workflow_merge_blobs(wg, wmain, wsame)}")
            check("workflow refusal: different workflow files on each side create none (these were served)",
                  workflow_merge_blobs(wg, wmain, wother) == [], f"{workflow_merge_blobs(wg, wmain, wother)}")
            check("workflow refusal: a real conflict is not this class",
                  workflow_merge_blobs(wg, wmain, wclash) == [], f"{workflow_merge_blobs(wg, wmain, wclash)}")
            # The comment names the cause: a refused head whose merge creates a workflow blob.
            reset()
            pathlib.Path(origin, "main-moves-again.txt").write_text("x\n")
            gh.g("add", "-A")
            gh.g("commit", "-q", "-m", "main moves again")
            open_only("pW")
            saved_blobs = globals()["workflow_merge_blobs"]
            globals()["workflow_merge_blobs"] = lambda *_: [both]
            gh.update_branch = lambda n, head: False
            try:
                settle_once()
            finally:
                del gh.update_branch
                globals()["workflow_merge_blobs"] = saved_blobs
            told = [t for n, t in gh.comments if t.startswith(WORKFLOW_REFUSED_COMMENT)]
            check("notice: a workflow refusal says so and names the file, not the generic refusal text",
                  len(told) == 1 and f"`{both}`" in told[0], f"{gh.comments[-1:]}")
            gh.updates.clear()
            reset()
            # ---- GitHub API (#13400): transient failures never kill a tick's carrier; quota is not burnt ----
            # The REAL GitHub class and api() over HttpFixture (urllib.request.urlopen patched). Rebuilt
            # from 2026-10-26: publish died on a check-runs GET 503 at 16:33Z, build on the installation's
            # primary quota (403) at 16:39Z — each a lost carrier and a red run, no member at fault.
            reset()
            gh.updates.clear()
            saved_http = (urllib.request.urlopen, globals()["_api_sleep"], os.environ.get("GITOPS_APP_ID"))
            slept: list[float] = []
            os.environ["GITOPS_APP_ID"] = "4242"
            globals()["_api_sleep"] = slept.append

            def with_http(faults=None):
                fx = HttpFixture(gh, faults)
                fx.sync_refs()
                urllib.request.urlopen = fx
                _GET_MEMO.clear()
                _api_slept[0] = 0.0
                slept.clear()
                real = GitHub("o/r", "main", "http://run")
                real.remote = origin
                return fx, real

            def writes(fx):
                # POST /graphql here is only the read-only check prefetch (api(..., graphql_read=True)).
                return [c for c in fx.calls if c[0] != "GET" and not (c[0] == "POST" and c[1] == "/graphql")]

            def check_runs_get(method, path):
                return method == "GET" and "/check-runs" in path

            def real_tick(real, fx):
                """build -> publish with the real GitHub class, each guarded as main() guards it."""
                counter[0] += 1
                bdir = clone("build")
                out = os.path.join(root, f"bundle-http-{counter[0]}")
                b = TrainBuilder(bdir, regen_commands=(f"{sys.executable} -I {SYN_GENERATOR}",),
                                 overlay_roots=(".github/scripts",))
                rc_b = guard_api("build", lambda: (mode_build(real, Git(bdir), b, "o/r", out, 8), 0)[1])
                fx.sync_refs()
                got = []
                rc_p = guard_api("publish", lambda: got.append(
                    mode_publish(real, Git(clone("publish")), "o/r", out, str(counter[0]), "1", 8)) or 0)
                return rc_b, rc_p, (got[0] if got else None)

            try:
                # (a) a 503 on a check-runs GET, then success: retried with backoff, the carrier is published.
                open_only("p1")
                try:
                    fx, real = with_http([[check_runs_get, (503, {}), 1]])
                    rc_b, rc_p, st = real_tick(real, fx)
                    ok = rc_b == 0 and rc_p == 0 and st == "published" and slept == [API_BACKOFF_BASE_S]
                    detail = f"rc={rc_b},{rc_p} st={st} slept={slept}"
                except BaseException as exc:          # the code before this change: SystemExit on the 503
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("api: a 503 then a success is retried with backoff and the carrier is published", ok, detail)
                reset()

                # (b) 503 on every attempt: the tick aborts cleanly, nobody blamed, nothing posted.
                open_only("p1")
                try:
                    fx, real = with_http([[check_runs_get, (503, {}), None]])
                    rc_b, rc_p, st = real_tick(real, fx)
                    tries = len([c for c in fx.calls if check_runs_get(*c)])
                    ok = (rc_b == 0 and rc_p == 0 and st is None and not writes(fx) and not gh.statuses
                          and not gh.comments and not any(c["state"] == "open" for c in gh.carriers.values())
                          and 2 <= tries <= 2 * API_RETRY_ATTEMPTS and sum(slept) <= API_RETRY_BUDGET_S)
                    detail = f"rc={rc_b},{rc_p} st={st} tries={tries} writes={writes(fx)} statuses={gh.statuses}"
                except BaseException as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("api: 503 on every attempt aborts the tick with no member fault (no status, comment, carrier)",
                      ok, detail)
                reset()

                # (c) primary quota exhausted: ONE request, no retry, no bisect or halving, the reset time logged.
                open_only("p1")
                try:
                    fx, real = with_http([[lambda m, p: m == "GET", (403, {"x-ratelimit-remaining": "0",
                                                                           "x-ratelimit-reset": str(int(time.time()) + 3600)}), None]])
                    err = None
                    try:
                        api("GET", "/repos/o/r/pulls?state=open&base=main")
                    except ApiAbort as exc:
                        err = exc
                    n_after_one = len(fx.calls)
                    rc_b, rc_p, st = real_tick(real, fx)
                    ok = (err is not None and err.kind == "quota" and "01:00:00Z" in err.detail and n_after_one == 1
                          and not slept and rc_b == 0 and rc_p == 0 and not writes(fx) and not gh.statuses)
                    detail = f"err={err!r} calls={len(fx.calls)} slept={slept} rc={rc_b},{rc_p} statuses={gh.statuses}"
                except BaseException as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("api: primary quota exhaustion aborts at once - no retry, no bisect, reset time logged", ok, detail)
                reset()

                # (d) auth errors are never retried and stay fail-closed: 401, and 403 without a rate-limit signal.
                for code, hdrs in ((401, {}), (403, {}), (422, {})):
                    try:
                        fx, real = with_http([[lambda m, p: True, (code, hdrs), None]])
                        got = api("GET", "/repos/o/r/pulls/1")
                        try:
                            get("/repos/o/r/pulls/1")
                            closed = False
                        except SystemExit:
                            closed = True
                        ok = got[0] == code and closed and len(fx.calls) == 2 and not slept
                        detail = f"got={got[0]} closed={closed} calls={len(fx.calls)} slept={slept}"
                    except BaseException as exc:
                        ok, detail = False, f"{type(exc).__name__}: {exc}"
                    check(f"api: a {code} is never retried and fails closed", ok, detail)

                # (e) secondary rate limit with Retry-After and a connection reset are retried (GET only);
                # a transient failure on a WRITE is never retried — it aborts the tick.
                try:
                    fx, real = with_http([[lambda m, p: True, (403, {"retry-after": "7"}), 1],
                                          [lambda m, p: True, "reset", 1]])
                    got = api("GET", "/repos/o/r/git/ref/heads/main")
                    ok = got[0] == 200 and slept == [7.0, API_BACKOFF_BASE_S * 2] and len(fx.calls) == 3
                    fx, real = with_http([[lambda m, p: m == "POST", (503, {}), None]])
                    try:
                        api("POST", f"/repos/o/r/statuses/{'a' * 40}", {"state": "success", "context": "x", "description": ""})
                        ok = False
                    except ApiAbort:
                        ok = ok and len(fx.calls) == 1
                    detail = f"slept={slept} calls={fx.calls}"
                except BaseException as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("api: Retry-After and a reset are retried on a GET; a write is never retried", ok, detail)

                # (e1) a body cut off mid-read (IncompleteRead) is retried on a GET; a write is not.
                try:
                    fx, real = with_http([[lambda m, p: True, "incomplete", 1]])
                    got = api("GET", "/repos/o/r/git/ref/heads/main")
                    ok = got[0] == 200 and slept == [API_BACKOFF_BASE_S] and len(fx.calls) == 2
                    fx, real = with_http([[lambda m, p: m == "POST", "incomplete", None]])
                    try:
                        api("POST", f"/repos/o/r/statuses/{'a' * 40}", {"state": "success", "context": "x", "description": ""})
                        ok = False
                    except ApiAbort:
                        ok = ok and len(fx.calls) == 1
                    detail = f"slept={slept} calls={fx.calls}"
                except BaseException as exc:          # the code before this change: IncompleteRead escapes api()
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("api: an IncompleteRead is retried on a GET; a write is never retried", ok, detail)

                # (e2) a bare 500 is transient (run 41640891760: check-runs page 2 -> 500 killed the tick).
                # Stubbed at _http_open: 500 then 200 succeeds; 500 always raises ApiAbort after
                # API_RETRY_ATTEMPTS; 404 is returned at once; a page-2 failure never yields a partial list.
                def stub_http(script):
                    calls: list[str] = []

                    def http(req, timeout):
                        calls.append(req.full_url)
                        out = script(len(calls), req.full_url)
                        if isinstance(out, int):
                            raise urllib.error.HTTPError(req.full_url, out, "x", {}, io.BytesIO(b"boom"))
                        return 200, json.dumps(out).encode(), {}
                    return http, calls

                saved_open = globals()["_http_open"]
                try:
                    slept.clear()
                    _api_slept[0] = 0.0
                    http, calls = stub_http(lambda n, u: 500 if n == 1 else {"ok": 1})
                    globals()["_http_open"] = http
                    got = api("GET", "/repos/o/r/pulls/1")
                    check("api: a 500 then a 200 is retried and succeeds",
                          got == (200, {"ok": 1}) and len(calls) == 2 and len(slept) == 1, f"{got} {calls} {slept}")

                    slept.clear()
                    _api_slept[0] = 0.0
                    http, calls = stub_http(lambda n, u: 500)
                    globals()["_http_open"] = http
                    try:
                        api("GET", "/repos/o/r/pulls/1")
                        raised = False
                    except ApiAbort:
                        raised = True
                    check("api: a 500 on every attempt raises ApiAbort after API_RETRY_ATTEMPTS (fail closed)",
                          raised and len(calls) == API_RETRY_ATTEMPTS and sum(slept) <= API_RETRY_BUDGET_S,
                          f"raised={raised} calls={len(calls)} slept={slept}")

                    slept.clear()
                    _api_slept[0] = 0.0
                    http, calls = stub_http(lambda n, u: 404)
                    globals()["_http_open"] = http
                    got = api("GET", "/repos/o/r/pulls/9")
                    check("api: a 404 is not retried", got[0] == 404 and len(calls) == 1 and not slept, f"{got} {calls}")

                    slept.clear()
                    _api_slept[0] = 0.0
                    full = {"check_runs": [{"n": i} for i in range(100)]}
                    http, calls = stub_http(lambda n, u: full if u.endswith("&page=1") else 500)
                    globals()["_http_open"] = http
                    try:
                        part = paginate("/repos/o/r/commits/" + "a" * 40 + "/check-runs", "check_runs")
                    except ApiAbort:
                        part = None
                    check("api: a page-2 failure raises and never returns a partial check-run list",
                          part is None and len([u for u in calls if u.endswith("&page=2")]) == API_RETRY_ATTEMPTS,
                          f"part={part and len(part)} calls={len(calls)}")
                finally:
                    globals()["_http_open"] = saved_open
                reset()

                # (f) quota: a steady-state settle tick asks nothing twice (#13739 shape: a strict PR whose
                # update-branch is refused, next to an idle candidate). Counted on the fixture.
                open_only("pW", "p1")
                fx, real = with_http()
                refuse = lambda n, head: False      # noqa: E731 — GitHub refuses, no conflict merge-tree sees
                gh.update_branch = refuse
                try:
                    gh.g("checkout", "-q", "-f", "main")
                    pathlib.Path(origin, "docs").mkdir(parents=True, exist_ok=True)
                    pathlib.Path(origin, "docs/quota.md").write_text("main moves\n")
                    gh.g("add", "-A")
                    gh.g("commit", "-q", "-m", "main moves under the strict PR")
                    per_tick = []
                    for _ in range(3):
                        before = len(fx.calls)
                        _GET_MEMO.clear()
                        mode_settle(real, Git(clone("settle")), "o/r", False)
                        per_tick.append(fx.calls[before:])
                finally:
                    del gh.update_branch
                steady = per_tick[-1]
                dup = sorted({c for c in steady if c[0] == "GET" and steady.count(c) > 1})
                upd = [c for c in steady if c[1].endswith("/update-branch")]
                log(f"api: settle calls per tick on the fixture: {[len(t) for t in per_tick]}")
                # The planning reads (a sha's check-runs/statuses/workflow runs) are read once per tick;
                # the ruleset and the open-PR list are re-read live outside planning (cache safety).
                check("api: a steady-state tick re-asks no refused update-branch and repeats no planning read",
                      not upd and not [c for c in dup if "/commits/" in c[1] or "/actions/runs" in c[1]],
                      f"per_tick={[len(t) for t in per_tick]} update={upd} dup={dup[:6]}")
                reset()

                # CACHE SAFETY (#13988 review): planning reads may be memoised, a write's verdict never.
                # Each case drifts state AFTER the tick's planning read and BEFORE its write.
                def drift_after_first(fx, pred, action):
                    fx.after.append([pred, action, 1])

                def head_runs(sha):
                    return lambda m, p: m == "GET" and f"/commits/{sha}/check-runs" in p

                # (g) a strict head green when planned turns red before its merge: no merge.
                open_only("pW")
                fx, real = with_http()
                hw = gh.prs[35]["head"]["sha"]
                drift_after_first(fx, head_runs(hw), lambda: gh.head_checks.__setitem__(hw, {"gates (data)": "failure"}))
                try:
                    mode_settle(real, Git(clone("settle")), "o/r", False)
                    ok, detail = 35 not in gh.merged, f"merged={gh.merged}"
                except BaseException as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("cache safety: a check-run green at planning and red at merge time means no merge", ok, detail)
                gh.head_checks.clear()
                reset()

                # (h) a fast-lane candidate whose required context is revoked between plan and the
                # status post: no `merge-train` success is posted on it.
                open_only("pF")
                fx, real = with_http()
                hf = gh.prs[34]["head"]["sha"]
                drift_after_first(fx, head_runs(hf), lambda: gh.head_checks.__setitem__(hf, {"Validate manifests": "failure"}))
                try:
                    mode_settle(real, Git(clone("settle")), "o/r", False)
                    st = gh.app_statuses(hf).get(STATUS_CONTEXT, ("", ""))
                    ok, detail = st[0] != "success", f"{st}"
                except BaseException as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                check("cache safety: a status revoked between plan and status-post means no success status", ok, detail)
                gh.head_checks.clear()
                reset()

                # (i) the ruleset turns strict up-to-date back on between the guard's read and the merge.
                open_only("pW")
                fx, real = with_http()
                drift_after_first(fx, lambda m, p: m == "GET" and "/rules/branches/" in p,
                                  lambda: setattr(gh, "rs_strict", True))
                try:
                    mode_settle(real, Git(clone("settle")), "o/r", False)
                    ok, detail = 35 not in gh.merged, f"merged={gh.merged}"
                except BaseException as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                finally:
                    gh.rs_strict = False
                check("cache safety: a ruleset change between plan and merge means the guard refuses", ok, detail)
                reset()
            finally:
                urllib.request.urlopen, globals()["_api_sleep"] = saved_http[0], saved_http[1]
                if saved_http[2] is None:
                    os.environ.pop("GITOPS_APP_ID", None)
                else:
                    os.environ["GITOPS_APP_ID"] = saved_http[2]
                _GET_MEMO.clear()
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
    check(f"spawn budget: the self-test issued {SPAWNS[0]} subprocess spawns, ceiling {SELF_TEST_SPAWN_CEILING}",
          SPAWNS[0] <= SELF_TEST_SPAWN_CEILING,
          "spawn count is wall time on ubuntu-latest (~5 ms each); batch or memoise the new calls, or raise the "
          "ceiling in the same PR with the measurement that justifies it")
    for f in fails:
        print(f"  [FAIL] {f}")
    print(f"spawns={SPAWNS[0]}")
    print(f"SUBJECTS={len(ran)}")
    print(f"merge-train self-test: {len(ran)} cases, {len(fails)} failed")
    return 1 if fails else 0


# --------------------------------------------------------------------------- main
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("mode", nargs="?", choices=["build", "publish", "settle", "owner-approval", "owner-status"])
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--check-declaration", action="store_true")
    ap.add_argument("--repo", default=os.environ.get("GITHUB_REPOSITORY", ""))
    ap.add_argument("--branch", default="main")
    ap.add_argument("--batch-size", type=int, default=int(os.environ.get("TRAIN_BATCH_SIZE", "16")))
    ap.add_argument("--strict-batch-cap", type=int,
                    default=int(os.environ.get("STRICT_BATCH_CAP", str(STRICT_BATCH_CAP_DEFAULT))),
                    help="settle: members per strict carrier (1 = no strict carrier, update-branch as before)")
    ap.add_argument("--strict-judge-batch-cap", type=int,
                    default=int(os.environ.get("MERGE_TRAIN_STRICT_JUDGE_BATCH_CAP", str(STRICT_JUDGE_BATCH_CAP_DEFAULT))),
                    help="settle: members per strict carrier holding a judge member, all path-disjoint "
                         "(1 = a judge member rides alone, as before)")
    ap.add_argument("--speculative-stack", choices=["true", "false"],
                    default=os.environ.get("SPECULATIVE_STACK", "true" if SPECULATIVE_STACK_DEFAULT else "false"),
                    help="settle: open a speculative-stacking window over a running strict holder")
    ap.add_argument("--stack-pr", default=os.environ.get("STACK_PR", ""),
                    help="publish: settle's stacking window, holder PR number (re-validated live)")
    ap.add_argument("--stack-head", default=os.environ.get("STACK_HEAD", ""),
                    help="publish: settle's stacking window, holder head sha (re-validated live)")
    ap.add_argument("--expedite-lane", choices=["true", "false"],
                    default=os.environ.get("EXPEDITE_LANE", "true" if EXPEDITE_LANE_DEFAULT else "false"),
                    help="settle: open an expedite window beside one running carrier (ADR-0343 amendment 2026-11-13)")
    ap.add_argument("--expedite-cap", type=int,
                    default=int(os.environ.get("EXPEDITE_DAILY_CAP", str(EXPEDITE_DAILY_CAP_DEFAULT))),
                    help="settle/publish: expedite carriers per UTC day")
    ap.add_argument("--urgent-cap", type=int,
                    default=int(os.environ.get("URGENT_DAILY_CAP", str(URGENT_DAILY_CAP_DEFAULT))),
                    help="settle: distinct PRs the owner may label merge-priority:urgent per UTC day")
    ap.add_argument("--expedite-pr", default=os.environ.get("EXPEDITE_PR", ""),
                    help="build/publish: settle's expedite window, the one PR number (re-validated live)")
    ap.add_argument("--out", default="", help="build: directory for train.bundle")
    ap.add_argument("--bundle", default="", help="publish: directory holding train.bundle")
    ap.add_argument("--run-id", default="")
    ap.add_argument("--attempt", default="")
    ap.add_argument("--workdir", default="")
    ap.add_argument("--run-url", default=os.environ.get("MERGE_TRAIN_RUN_URL", ""))
    ap.add_argument("--shadow", action="store_true", help="settle: post statuses and comments, never merge (phase 0)")
    ap.add_argument("--pr", type=int, default=0, help="owner-approval: exact PR number")
    ap.add_argument("--head", default="", help="owner-approval: full current head SHA")
    ap.add_argument("--decision", choices=["approve", "revoke"], default="approve")
    args = ap.parse_args()
    if args.self_test:
        return self_test()
    if args.check_declaration:
        return check_declaration()
    if not args.mode or not args.repo:
        ap.error("mode and --repo are required (or --self-test / --check-declaration)")
    if "GH_TOKEN" not in os.environ:
        ap.error("GH_TOKEN is required (read-only for build, the App token for publish/settle)")
    gh = GitHub(args.repo, args.branch, args.run_url)
    return guard_api(args.mode, lambda: run_mode(gh, args, ap))


def guard_api(mode: str, run) -> int:
    """Run one mode; a GitHub API outage (ApiAbort) ends the tick cleanly instead of failing the job."""
    try:
        return run()
    except ApiAbort as exc:
        return api_abort_exit(mode, exc)
    finally:
        log(api_stats_line(mode))


def api_abort_exit(mode: str, exc: ApiAbort) -> int:
    """A tick the API could not serve (#13400): a clean exit, never a verdict. Build reports no train
    (publish is skipped, the batch stays armed), settle reports in flight (nothing is built over a
    state it could not read), and no status, comment, bisect or halving is posted for any member."""
    log(f"::warning::merge-train {mode}: GitHub API unavailable ({exc}) — tick aborted, no member fault, "
        f"the batch is kept for the next tick")
    if mode == "owner-approval":
        return 1                              # an owner decision that was not recorded must fail visibly
    if mode == "build":
        write_output("has_train", "false")
        write_output("has_drops", "false")
    elif mode == "settle":
        write_output("in_flight", "true")
    return 0


def run_mode(gh, args, ap) -> int:
    if args.mode == "owner-status":
        line = owner_status_line(paginate(f"/repos/{gh.repo}/commits/{args.head}/statuses"))
        print(line or "no App status found")
        return 0 if line else 1
    if args.mode == "owner-approval":
        mode_owner_approval(gh, args.pr, args.head, args.decision)
        return 0
    workdir = args.workdir or os.getcwd()
    if args.mode == "build":
        if not args.out:
            ap.error("build needs --out")
        applied = mode_build(gh, Git(workdir), TrainBuilder(workdir), args.repo, args.out, args.batch_size,
                             expedite_arg(args, ap))
        write_output("has_train", "true" if applied else "false")
        write_output("has_drops", "true" if os.path.isfile(os.path.join(args.out, DROPS_FILE)) else "false")
        return 0
    git = Git(workdir, token=os.environ["GH_TOKEN"])
    if args.mode == "publish":
        if not args.bundle or not args.run_id or not args.attempt:
            ap.error("publish needs --bundle, --run-id and --attempt")
        log(f"publish: notices {mode_notice_drops(gh, git, args.bundle)}")
        stack = None
        if args.stack_pr or args.stack_head:
            if not (re.fullmatch(r"[0-9]+", args.stack_pr) and SHA_RE.fullmatch(args.stack_head)):
                ap.error("--stack-pr must be a PR number and --stack-head a full sha")
            stack = (int(args.stack_pr), args.stack_head)
        result = mode_publish(gh, git, args.repo, args.bundle, args.run_id, args.attempt, args.batch_size, stack,
                              expedite_arg(args, ap), args.expedite_cap)
        log(f"publish: {result}")
        return 0
    s = mode_settle(gh, git, args.repo, args.shadow, run_id=args.run_id, attempt=args.attempt,
                    strict_cap=args.strict_batch_cap, judge_cap=args.strict_judge_batch_cap, stack=args.speculative_stack == "true",
                    expedite=args.expedite_lane == "true", expedite_cap=args.expedite_cap,
                    urgent_cap=args.urgent_cap)
    log(f"settle: {s}")
    write_output("in_flight", "true" if s["in_flight"] else "false")
    window = s.get("stack_window")
    write_output("stack_pr", str(window[0]) if window else "")
    write_output("stack_head", window[1] if window else "")
    write_output("expedite_pr", str(s["expedite_window"]) if s.get("expedite_window") else "")
    return 0


def expedite_arg(args, ap) -> int | None:
    if not args.expedite_pr:
        return None
    if not re.fullmatch(r"[0-9]{1,9}", args.expedite_pr):
        ap.error("--expedite-pr must be a PR number")
    if args.expedite_cap < 1:
        ap.error("--expedite-cap must be a positive integer")
    return int(args.expedite_pr)


if __name__ == "__main__":
    sys.exit(main())
